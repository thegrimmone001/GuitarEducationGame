# Active Documentation Set

This folder contains the only documents allowed to define current behavior.

- Use AUTHORITATIVE_INDEX.md (project root) as the entry point.
- Supporting/legacy materials were moved to DOCS/ARCHIVE/2026-01-16.
