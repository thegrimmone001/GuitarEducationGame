# DOCS/ACTIVE

This folder contains the *current authoritative* documents for Guitar-Edu-UI.
Do not implement changes from archived docs.

Start here:
- ../..//AUTHORITATIVE_INDEX.md
- CHECKLIST.md
- MATCH_SETTINGS_SPEC.md

Evidence artifacts live in ../EVIDENCE.
