# Canon Compliance Report (Docs) — 2026-01-16

## Scope
- Archive-only cleanup to remove documentation bloat and eliminate conflicting authorities.
- No code/runtime behavior changes intended beyond terminology-string removal required for documentation compliance.

## What changed
### New canonical pointers
- AUTHORITATIVE_INDEX.md added at repo root.
- DOCS/ACTIVE created as the only authoritative documentation surface.
- DOCS/EVIDENCE created to store timeline ledger and term/feature evidence artifacts.

### Archived (moved out of active)
Moved to DOCS/ARCHIVE/2026-01-16/ with an archive header:
- ADVANCED_MATCH_OPTIONS_UI_MAPPING.md
- START_SCREEN_UI_MAPPING.md
- CANONICAL_LAYERS_DIAGRAM.md
- PLATFORM_STRATEGY.md
- MERGE_NOTES.md
- STABILITY_SIM_REPORT_2026-01-15.md

## What did NOT change
- No UI changes
- No refactors
- No deferred-issue fixes

## Notes
- Deprecated terminology string was removed from documents to comply with current terminology lock.
- Historical artifacts remain available in the archive for provenance.
