# Ledger vs Archive (Anchor 98) — Discrepancy Audit

Generated: 2026-01-17 04:21:19 UTC

Scope: Compare the *timeline ledger* (chat-derived) against authoritative docs inside `guitar-edu-ui_01_16_26_98.zip` (anchor archive).

Note: This audit reports mismatches and ambiguity nodes. It does not fix code.

---

## 1) Terminology Consistency

- **LAST_CHANCE token:** 2
  - Locations:
    - CHECKLIST.md: 1
    - BUILD_LOG.md: 1
- **"last chance" phrase:** 1
  - Locations:
    - CHECKLIST.md: 1

**Impact:** The ledger includes later hard bans on deprecated terminology. The anchor archive still contains deprecated term references (notably in CHECKLIST and BUILD_LOG), which will produce recurring drift unless the docs are versioned and an automated term-gate exists.


### Evidence in Archive

**CHECKLIST.md**
- 42:  - Note: Added ROUND_COMPLETE + LAST_CHANCE_STARTED alerts/logging in controller; requires runtime verification.
- 201:  _Implementation note:_ Dev/Test currently includes End Turn (TIMEOUT), Prev/Next Player, Clear Board, Force In-Match / Last Chance / Results, plus Paint/Erase mode.

**BUILD_LOG.md**
- 615:- Controller: handle **ROUND_COMPLETE** + **LAST_CHANCE_STARTED** effects (alerts + debug events) to support turn-loop visibility.

---

## 2) Utility Tabs vs Learning Types

- **Checklist lock present:** Utility tab labels locked to `Num / Note / Chord / Scale`.

- **Potential drift vector:** Docs also describe Note-tab display formats including `Intervals / Interval Roman`, and match settings include learning types like Intervals and Arpeggios.

**Interpretation rule for reconciliation:** Utility *tab labels* can remain locked while still supporting interval/arpeggio *learning types* via Match Settings (not Utility). If implementation removed interval/arpeggio as learning types (not merely Utility tabs), that would contradict MATCH_SETTINGS_SPEC + ADVANCED_MATCH_OPTIONS mapping.


### Archive excerpt (CHECKLIST: Utility area)

```
  - Auto (context)
- [ ] **GEG-072** Tritone spelling resolved by **scale/mode/key context** where applicable (some scales imply #IV, others ♭V).

---

## I) Utility area (tabs and controls)
> Utility tab labels are locked: **Num / Note / Chord / Scale**

- [ ] **GEG-080** Utility tabs exist and match labels: Num / Note / Chord / Scale.
- [ ] **GEG-081** Num tab:
  - 25-key (5×5) keypad with **0–24 only**
  - Instant selection behavior (no Enter/Del/Clear)
- [ ] **GEG-082** Note tab:
  - Display format (Names / Numbers / Intervals / Interval Roman)
  - Note visibility (All / Naturals / Enharmonic)
  - Tritone label options (see H)
- [ ] **GEG-083** Chord tab:
  - Chord menus and view options
  - Extended chord highlighting toggles (7/9/11/13)
  - Diagram display toggles (CAGED, etc.)
- [ ] **GEG-084** Scale tab:
  - Scale/mode selection and view options
  - Degree/interval display behavior

---

## J) Dev/Test mode
- [ ] **GEG-090** Dev/Test Mode toggle in Main Menu Settings works.
- [ ] **GEG-091** When Dev/Test is enabled, show dev options inside the Utility/Misc area (per spec).
- [ ] **GEG-092** Dev tools allow:
  - Force phase (bonus / last-chance / etc.)
  - Switch active player instantly
  - Inject prompts/notes
  - Paint/erase claims (for rapid testing)

  _Implementation note:_ Dev/Test currently includes End Turn (TIMEOUT), Prev/Next Player, Clear Board, Force In-Match / Last Chance / Results, plus Paint/Erase mode.

---

## K) Assets + hitboxes (alignment correctness)
- [ ] **GEG-100** Update fretboard background image and re-align hitboxes precisely.
- [ ] **GEG-101** Update staff + tablature background and re-align hitboxes precisely.
- [ ] **GEG-102** Confirm hover highlight + click zones align to the new art at different viewport sizes.

  _Implementation note:_ Asset loading/rendering issues were fixed by (1) ensuring `loadSvgIntoHost` is called with relative asset paths (it already applies `assetUrl` internally), and (2) adding `Guitar_FretBoard_Horizontal-NoNotes.svg` to the `public/` folder so Medium/Hard can start with a blank fretboard.
```

---

## 3) Deferred Issue vs Usability Blocking

- The ledger and protocol discussions treat **double boards** as an undesired side effect.

- The anchor archive includes render infrastructure (`RendererManager`, `FretboardRenderer2D`, staff/tab renderer) but does not clearly document an explicit “double board” known issue in the core checklist.

**Risk:** If the issue is deferred but also makes the playfield incomprehensible, it becomes a practical test blocker. This is a governance decision: either promote to a “blocking hotfix” checklist item or explicitly accept deferred UX confusion until scheduled.

---

## 4) Note Rail Constraints

- Ledger includes strict constraints: highlight active middle note only; no prompt labels.

- Archive docs mention "note rail" **17** times across the document set scanned.

**Actionable discrepancy check:** If any doc/spec says the note rail should show prompt history, “asked/answered” labels, or multi-note persistence, that conflicts with the locked constraint and should be captured as a conflict node in the ledger.

---

## 5) Recommended Governance Controls (to prevent future back-and-forth)

1. Add `AUTHORITATIVE_INDEX.md` with monotonic `CHANGE_ID`s, and require doc-sync on every change.

2. Add automated gates in `tools/` to fail CI if:
   - deprecated terms appear anywhere
   - duplicate checklist IDs exist
   - utility labels drift from the locked set

3. Require per-entry timestamps in checklist/spec updates and cross-link to ledger `CHANGE_ID`.
