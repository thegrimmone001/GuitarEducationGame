# LEDGER vs ANCHOR98 — Discrepancy Audit (v2)

**Inputs**
- Timeline ledger: `TIMELINE_LEDGER_MASTER.md`
- Anchor build: `guitar-edu-ui_01_16_26_98.zip` (extracted)


---

## 1) Ledger contamination (must be corrected before treating the ledger as authoritative for this project)

The Phase 2 ledger currently contains entries from threads that are not Guitar Learning Game work. Examples of thread titles present in the ledger:

- Economic strategies analysis
- Scenic Historic Drive Butte

Impact: these entries can introduce false conflict nodes and noise. Recommendation: regenerate the ledger using a strict allowlist (title contains 'guitar', 'guitar-edu', 'fretboard', 'tab', 'staff', 'rail', 'match', 'menu') OR by intersecting with repo-commit artifacts (BUILD_LOG/CHECKLIST references).

---

## 2) Utility tab labels — Checklist lock vs code reality

**Anchor98 Checklist lock (source of truth):**

```
- [ ] **GEG-070** Interval Roman display format: `I ii II iii III IV ...`
- [ ] **GEG-071** Tritone: make **all options available**:
  - TT
  - +/o (default for Interval Roman)
  - #IV / ♭V
  - +IV / oV
  - Auto (context)
- [ ] **GEG-072** Tritone spelling resolved by **scale/mode/key context** where applicable (some scales imply #IV, others ♭V).

---

## I) Utility area (tabs and controls)
> Utility tab labels are locked: **Num / Note / Chord / Scale**

- [ ] **GEG-080** Utility tabs exist and match labels: Num / Note / Chord / Scale.
- [ ] **GEG-081** Num tab:
  - 25-key (5×5) keypad with **0–24 only**
  - Instant selection behavior (no Enter/Del/Clear)
- [ ] **GEG-082** Note tab:
  - Display format (Names / Numbers / Intervals / Interval Roman)
  - Note visibility (All / Naturals / Enharmonic)
  - Tritone label options (see H)
- [ ] **GEG-083** Chord tab:
  - Chord menus and view options
  - Extended chord highlighting toggles (7/9/11/13)
  - Diagram display toggles (CAGED, etc.)
- [ ] **GEG-084** Scale tab:
  - Scale/mode selection and view options
  - Degree/interval display behavior

---

## J) Dev/Test mode
- [ ] **GEG-090** Dev/Test Mode toggle in Main Menu Settings works.
- [ ] **GEG-091** When Dev/Test is enabled, show dev options inside the Utility/Misc area (per spec).
- [ ] **GEG-092** Dev tools allow:
  - Force phase (bonus / last-chance / etc.)
  - Switch active player instantly
  - Inject prompts/notes
  - Paint/erase claims (for rapid testing)

  _Implementation note:_ Dev/Test currently includes End Turn (TIMEOUT), Prev/Next Player, Clear Board, Force In-Match / Last Chance / Results, plus Paint/Erase mode.

---

## K) Assets + hitboxes (alignment correctness)
```

**Anchor98 UI code currently renders additional Utility tabs (Interval + Arpeggio):**

```
1396	
  1397	
  1398	    el("div", { class: "section", "data-tabs": "right" }, [
  1399	      el("div", { class: "block-title" }, ["Utility"]),
  1400	      el("div", { class: "tabs compact" }, [
  1401	        el("button", { class: "tab active", type: "button", "data-tab": "num" }, ["Num"]),
  1402	        el("button", { class: "tab", type: "button", "data-tab": "note" }, ["Note"]),
  1403	        el("button", { class: "tab", type: "button", "data-tab": "interval" }, ["Interval"]),
  1404	        el("button", { class: "tab", type: "button", "data-tab": "chord" }, ["Chord"]),
  1405	        el("button", { class: "tab", type: "button", "data-tab": "scale" }, ["Scale"]),
  1406	        el("button", { class: "tab", type: "button", "data-tab": "arpeggio" }, ["Arpeggio"]),
  1407	        el("button", { class: "tab", type: "button", "data-tab": "teach", id: "utility-teach-tab", "data-teach-only": "1", hidden: "true" }, ["Teach"]),
  1408	      ]),
  1409	      el("div", { class: "tabpanes" }, [
  1410	        el("div", { class: "pane active", "data-pane": "num" }, [
```

**Mismatch:** Checklist locks labels to **Num/Note/Chord/Scale**, but UI includes **Interval** and **Arpeggio** (plus hidden Teach).

**Ledger indicator:** conflict node exists for Utility/Interval/Arpeggio (proves this oscillated in conversation history):

```
62:- **UTILITY_INTERVAL_ARPEGGIO** — first: 2025-12-08 14:51:06 UTC | last: 2026-01-16 13:34:05 UTC | mentions: 200
```

**Consequence:** This is a direct 'docs vs code' conflict inside the anchor build itself, independent of newer protocol text.

---

## 3) Deprecated term policy vs presence of LAST_CHANCE in anchor98

Your current thread protocol bans `LAST_CHANCE`. In anchor98, the term is still present across code and logs. Evidence:

```
/mnt/data/anchor98/src/app/gameController.ts:1531:  const inMatch = !!state && (state.phase === "IN_MATCH" || state.phase === "LAST_CHANCE");
/mnt/data/anchor98/src/app/gameController.ts:1784:    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;
/mnt/data/anchor98/src/app/gameController.ts:2106:        case "LAST_CHANCE_STARTED":
/mnt/data/anchor98/src/app/gameController.ts:2325:    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;
/mnt/data/anchor98/src/app/gameController.ts:2588:    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;
/mnt/data/anchor98/src/app/gameController.ts:2920:  btnDevPhaseLastChance?.addEventListener("click", () => forcePhase("LAST_CHANCE"));
/mnt/data/anchor98/src/shell/engineReducer.ts:873:	  // In normal gameplay, LAST_CHANCE is entered via end-of-round logic which
/mnt/data/anchor98/src/shell/engineReducer.ts:875:	  // Dev/Test forcing should replicate that setup; otherwise LAST_CHANCE can
/mnt/data/anchor98/src/shell/engineReducer.ts:877:	  if (action.phase === "LAST_CHANCE") {
/mnt/data/anchor98/src/shell/engineReducer.ts:897:	      effects.push({ type: "LAST_CHANCE_STARTED", totalRounds });
/mnt/data/anchor98/src/shell/engineReducer.ts:942:      if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return { state, effects };
/mnt/data/anchor98/src/shell/engineReducer.ts:1029:      state.phase = state.lastChance.active ? "LAST_CHANCE" : "IN_MATCH";
/mnt/data/anchor98/src/shell/engineReducer.ts:1091:      if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return { state, effects };
/mnt/data/anchor98/src/shell/engineReducer.ts:1103:      if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return { state, effects };
/mnt/data/anchor98/src/shell/engineReducer.ts:1222:          effects.push({ type: "LAST_CHANCE_STARTED", totalRounds });
/mnt/data/anchor98/src/shell/engineReducer.ts:1275:  state.phase = state.lastChance.active ? "LAST_CHANCE" : "IN_MATCH";
/mnt/data/anchor98/src/shell/types.ts:173:export type Phase = "TITLE" | "IN_MATCH" | "INTERMISSION" | "LAST_CHANCE" | "RESULTS";
/mnt/data/anchor98/src/shell/types.ts:238:  | { type: "LAST_CHANCE_STARTED"; totalRounds: number }
/mnt/data/anchor98/BUILD_LOG.md:615:- Controller: handle **ROUND_COMPLETE** + **LAST_CHANCE_STARTED** effects (alerts + debug events) to support turn-loop visibility.
/mnt/data/anchor98/CHECKLIST.md:42:  - Note: Added ROUND_COMPLETE + LAST_CHANCE_STARTED alerts/logging in controller; requires runtime verification.
```

The automated deprecated-terms list in `DOCS/DEPRECATED_TERMS.md` does **not** include `LAST_CHANCE`, so the existing checker will not catch this terminology drift:

```
17:<!-- DEPRECATED_TERMS:BEGIN -->
18-- combined configuration
19-- combined mode
20-- surface layers
21-- asked / answered / view
22-<!-- DEPRECATED_TERMS:END -->
23-
24----
25-
26-## Hard-banned terminology
27-
28-### 1) Gameplay “configuration modes” (legacy numbered system)
29-**Status:** HARD-BANNED.
30-
31-The project no longer defines session behavior using a numbered configuration system (historically referred to as “1–5”).
32-Session behavior is defined by:
33-- **Match Settings** (what is being tested)
34-- **Surface Controls** (Prompt / Mark / Display / SAM + cardinality)
35-- **Presentation Preferences** (visual only)
36-
37-**MUST NOT reintroduce:** any UI, logic, or documentation that relies on a numbered configuration selector as the primary behavior controller.
```

**Mismatch type:** Policy-level ban (ledger/protocol) vs implementation artifacts (code/docs).

**Note:** Resolving this is a *scheduled change* (per your anti-drift rules), but this audit confirms where it lives and that existing checks won’t prevent recurrence.

---

## 4) Deferred issue documentation coverage — double boards

The current thread protocol lists 'SVG/renderer duplication causing double boards' as a known deferred issue. In anchor98, there is only a minimal in-code comment acknowledging 'double board' visuals, but no matching entry in CHECKLIST/DECISIONS_LOG describing it as a tracked deferred item.

Evidence (code comment):

```
530:  // remain visible (they cause "double board" visuals). Pointer interaction remains on overlays.
```

**Mismatch type:** Deferred-issue ledger (conversation/protocol) vs anchor98 repo documentation coverage.

**Why it matters:** Without a doc-side entry, the issue is likely to be re-argued and reintroduced as 'mysterious behavior' instead of a tracked artifact.

---

## 5) Recommended reconciliation mechanics (documentation-only; no code changes implied)

To stop the 'back and forth' you described, the comparison suggests three documentation controls that are purely administrative:


1) **AUTHORITATIVE_INDEX.md** (one page)
   - Anchor build ID
   - Canon locks (including banned terms)
   - Deferred issues list
   - Pointer to current CHECKLIST checkpoint
   - Last-updated timestamps


2) **Monotonic timestamps in docs**
   - Add `Last Updated (UTC)` header to CHECKLIST, MATCH_SETTINGS_SPEC, DEPRECATED_TERMS, DECISIONS_LOG
   - Treat any undated guidance as 'non-authoritative'


3) **Tripwire checks**
   - Extend `tools/check_deprecated_terms.mjs` (or its input list) to include newly banned terms like `LAST_CHANCE` when they become banned
   - Add a checker for `CHECKLIST.md`-locked UI labels (e.g., Utility tabs) vs actual DOM labels in `src/ui/layout.ts`
