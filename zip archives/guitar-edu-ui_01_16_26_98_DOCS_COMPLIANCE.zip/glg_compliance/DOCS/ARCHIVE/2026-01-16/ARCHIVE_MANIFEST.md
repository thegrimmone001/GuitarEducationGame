# ARCHIVE_MANIFEST.md
DATE: 2026-01-16
POLICY: ARCHIVE ONLY

Files in this folder were moved out of the active doc set to reduce bloat and prevent contradictory authority.
They remain available for forensic reference.

Reason codes:
- NON_AUTHORITATIVE_SUPPORTING: Useful background/supporting material, but not allowed to define current behavior.
- SUPERSEDED_BY_ACTIVE_DOCS: Information duplicated or replaced by docs in DOCS/ACTIVE.

Archived files:
- ADVANCED_MATCH_OPTIONS_UI_MAPPING.md — NON_AUTHORITATIVE_SUPPORTING
- CANONICAL_LAYERS_DIAGRAM.md — NON_AUTHORITATIVE_SUPPORTING
- MERGE_NOTES.md — NON_AUTHORITATIVE_SUPPORTING
- PLATFORM_STRATEGY.md — NON_AUTHORITATIVE_SUPPORTING
- STABILITY_SIM_REPORT_2026-01-15.md — NON_AUTHORITATIVE_SUPPORTING
- START_SCREEN_UI_MAPPING.md — NON_AUTHORITATIVE_SUPPORTING
