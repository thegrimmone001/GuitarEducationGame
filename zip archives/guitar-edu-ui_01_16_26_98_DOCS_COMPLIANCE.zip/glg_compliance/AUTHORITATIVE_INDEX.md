# AUTHORITATIVE_INDEX.md
Project: Guitar Learning Game (Guitar-Edu-UI)

## Anchor
- Anchor Build (handoff base): guitar-edu-ui_01_16_26_98.zip
- Evidence Window: 2025-12-01 → 2026-01-16 (UTC)

## Purpose
Single entry point to resolve ambiguity and prevent drift.

## Source-of-Truth Hierarchy
1. CHECKLIST.md
2. MATCH_SETTINGS_SPEC.md and other specifications in DOCS/ACTIVE
3. Code
4. UI / runtime behavior

## Evidence Artifacts
- TIMELINE_LEDGER_MASTER.md (forensic, timestamped)
- GLG_Term_Feature_Timeline.xlsx (feature list + events)
- GLG_Term_Feature_Profiles.docx (per-feature profiles)

## Lifecycle States
ACTIVE | DEFERRED | SUPERSEDED | REMOVED | UNKNOWN

## Clarification Protocol
1) Identify the feature name from the spreadsheet.
2) Check Lifecycle State.
3) If UNKNOWN, log Decision Needed; do not implement.

## Archive Policy
ARCHIVE ONLY. Nothing is deleted.
