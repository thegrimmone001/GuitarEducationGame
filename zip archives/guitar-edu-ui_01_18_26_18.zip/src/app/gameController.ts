import {
  Action,
  DevSettings,
  Difficulty,
  GameSettings,
  GameState,
  MatchType,
  ModeId,
  Phase,
  PlayType,
  PlayerProfile,
  SlotType,
  VariantId,
} from "../shell/types";
import { reducer } from "../shell/engineReducer";
import { createChromaticRail, RailConfig } from "../shell/rail";
import { fromVariantId, IS_BLACK, pitchClassAt, toVariantId, variantLabel } from "../shell/music";
import { describePromptProfileId } from "../shell/promptProfiles";
import { cellCenter, computeLayoutFromSvg, hitTestCell, mapLayoutToNeck, parseSvgNeckBounds, parseSvgViewBox, FretboardLayout } from "../shell/fretboardLayout";
import { attachBoardPointerHandlers } from "../shell/uiAdapter";
import { renderOverlay } from "../shell/fretboardOverlay";
import { attachStaffTabPointerHandlers, createStaffTabOverlayState, parseStaffTabLayout, renderStaffTabOverlay, StaffTabLayout, StaffTabHit } from "../shell/staffTabOverlay";
import {
  addNoteEvent,
  addRestEvent,
  columnToOffset,
  createEmptyScore,
  ensureMeasure,
  fromInternalJson,
  importMusicXmlWithReport,
  measureDivisions,
  offsetToColumn,
  pitchToMidi,
  type ImportResult,
  type NotationEvent,
  type NotationPitch,
  type NotationTab,
} from "../shell/notationScore";
import { getLeaderboard, recordScore } from "../shell/storage";
import { PLAYER_COUNT_MULTI_MAX } from "./constants";

type UiRoot = HTMLElement | Document;

type StaffTabMode = "game" | "notation";

// ----------------------------
// Helpers
// ----------------------------

const PLAYER_COUNT_MULTI = PLAYER_COUNT_MULTI_MAX;

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

function formatMs(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${pad2(m)}:${pad2(r)}`;
}

function escapeHtml(s: string): string {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function pcFromUiNoteName(name: string): number {
  const n = String(name || "C").trim().toUpperCase();
  const map: Record<string, number> = {
    C: 0,
    "C#": 1,
    DB: 1,
    D: 2,
    "D#": 3,
    EB: 3,
    E: 4,
    F: 5,
    "F#": 6,
    GB: 6,
    G: 7,
    "G#": 8,
    AB: 8,
    A: 9,
    "A#": 10,
    BB: 10,
    B: 11,
  };
  return map[n] ?? 0;
}

function intervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "P1",
    1: "m2",
    2: "M2",
    3: "m3",
    4: "M3",
    5: "P4",
    6: "TT",
    7: "P5",
    8: "m6",
    9: "M6",
    10: "m7",
    11: "M7",
  };
  return names[s] ?? `+${s}`;
}

function pitchFromPc(pc: number, octave = 4): NotationPitch {
  // Default to sharp spellings for deterministic import/export.
  const table: Array<{ step: NotationPitch["step"]; alter: number }> = [
    { step: "C", alter: 0 },
    { step: "C", alter: 1 },
    { step: "D", alter: 0 },
    { step: "D", alter: 1 },
    { step: "E", alter: 0 },
    { step: "F", alter: 0 },
    { step: "F", alter: 1 },
    { step: "G", alter: 0 },
    { step: "G", alter: 1 },
    { step: "A", alter: 0 },
    { step: "A", alter: 1 },
    { step: "B", alter: 0 },
  ];
  const i = ((pc % 12) + 12) % 12;
  return { step: table[i].step, alter: table[i].alter, octave };
}

function midiToPitch(midi: number): NotationPitch {
  const m = Math.round(midi);
  const pc = ((m % 12) + 12) % 12;
  const octave = Math.floor(m / 12) - 1;
  return pitchFromPc(pc, octave);
}

function romanIntervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "I",
    1: "♭II",
    2: "II",
    3: "♭III",
    4: "III",
    5: "IV",
    6: "♭V",
    7: "V",
    8: "♭VI",
    9: "VI",
    10: "♭VII",
    11: "VII",
  };
  return names[s] ?? `+${s}`;
}

function numberDegreeName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "1",
    1: "\u266d2",
    2: "2",
    3: "\u266d3",
    4: "3",
    5: "4",
    6: "\u266f4",
    7: "5",
    8: "\u266d6",
    9: "6",
    10: "\u266d7",
    11: "7",
  };
  return names[s] ?? `+${s}`;
}

function romanDegreeName(semitones: number, style: TritoneStyle, preferSharp4: boolean): string {
  const s = ((semitones % 12) + 12) % 12;
  switch (s) {
    case 0: return "I";
    case 1: return "♭II";
    case 2: return "II";
    case 3: return "♭III";
    case 4: return "III";
    case 5: return "IV";
    case 6: {
      // Scale-degree tritone label. Use the same preference logic as Interval Roman.
      if (style === "TT") return "TT";
      if (style === "sharp4") return "♯IV";
      if (style === "flat5") return "♭V";
      // "sharpFlat" and "plusDimBoth" both indicate the desire to show both spellings.
      // For scale-degree roman, we render the conventional pair.
      if (style === "sharpFlat" || style === "plusDimBoth") return "♯IV/♭V";
      if (style === "auto") return preferSharp4 ? "♯IV" : "♭V";
      return preferSharp4 ? "♯IV" : "♭V";
    }
    case 7: return "V";
    case 8: return "♭VI";
    case 9: return "VI";
    case 10: return "♭VII";
    case 11: return "VII";
    default: return `+${s}`;
  }
}

// Tritone labeling policy. This affects both Interval Roman (custom system) and
// Roman (Scale Degree) labels when the semitone offset is the tritone.
//
// Canon options (CHECKLIST: GEG-071/072):
// - plusDim: "+/o" (default for Interval Roman) -> choose +IV OR oV by context
// - TT: "TT"
// - sharpFlat: "#IV / ♭V" (shows both)
// - plusDimBoth: "+IV / oV" (shows both)
// - auto: resolve by scale/mode/key context
//
// Legacy values kept for back-compat: "sharp4", "flat5".
type TritoneStyle = "plusDim" | "TT" | "sharpFlat" | "plusDimBoth" | "auto" | "sharp4" | "flat5";

function normalizeTritoneStyle(v: string | undefined | null): TritoneStyle {
  const raw = (v ?? "").trim();
  switch (raw) {
    case "plusDim":
    case "TT":
    case "sharpFlat":
    case "plusDimBoth":
    case "auto":
      return raw;
    // Legacy single-spelling options.
    case "sharp4":
    case "flat5":
      return raw;
    // Some older UIs stored these:
    case "sharp4flat5":
      return "sharpFlat";
    case "plusDimAll":
      return "plusDimBoth";
    default:
      return "plusDim";
  }
}

function inferPreferSharp4(settings: GameSettings): boolean {
  const pid = (settings.promptProfileId ?? "").toLowerCase();
  const rootNote = ((settings as any).rootNote ?? "").toLowerCase();
  // Context-driven defaults (GEG-072): some modes strongly imply a preferred spelling.
  if (pid.includes("lydian")) return true;   // #IV is a signature lydian spelling
  if (pid.includes("locrian")) return false; // ♭V is a signature locrian spelling
  // Otherwise prefer by key signature leaning.
  if (pid.includes(":flats") || rootNote.includes("b")) return false;
  if (pid.includes(":sharps") || rootNote.includes("#")) return true;
  return true;
}

function intervalRomanName(semitones: number, style: TritoneStyle, preferSharp4: boolean): string {
  const s = ((semitones % 12) + 12) % 12;
  switch (s) {
    case 0: return "I";
    case 1: return "ii";
    case 2: return "II";
    case 3: return "iii";
    case 4: return "III";
    case 5: return "IV";
    case 6: {
      if (style === "TT") return "TT";
      if (style === "sharp4") return "IV\u266f";
      if (style === "flat5") return "V\u266d";
      if (style === "sharpFlat") return "IV\u266f/V\u266d";
      if (style === "plusDimBoth") return "+IV/oV";
      if (style === "auto") return preferSharp4 ? "IV\u266f" : "V\u266d";
      return preferSharp4 ? "+IV" : "oV";
    }
    case 7: return "V";
    case 8: return "vi";
    case 9: return "VI";
    case 10: return "vii";
    case 11: return "VII";
    default: return `+${s}`;
  }
}

function labelForVariant(vid: VariantId, displayMode: string, rootPc: number, settings: GameSettings): string {
  // Back-compat: legacy romanIntervals is deprecated; treat as intervalRoman.
  if (displayMode === "romanIntervals") displayMode = "intervalRoman";

  if (displayMode === "numbers") {
    const pc = fromVariantId(vid).pitchClass;
    return numberDegreeName(pc - rootPc);
  }
  if (displayMode === "intervals") {
    const pc = fromVariantId(vid).pitchClass;
    return intervalName(pc - rootPc);
  }
  if (displayMode === "roman") {
    const pc = fromVariantId(vid).pitchClass;
    const style = normalizeTritoneStyle((settings as any).tritoneStyle ?? "plusDim");
    const preferSharp4 = inferPreferSharp4(settings);
    return romanDegreeName(pc - rootPc, style, preferSharp4);
  }
  if (displayMode === "intervalRoman") {
    const pc = fromVariantId(vid).pitchClass;
    const style = normalizeTritoneStyle((settings as any).tritoneStyle ?? "plusDim");
    const preferSharp4 = inferPreferSharp4(settings);
    return intervalRomanName(pc - rootPc, style, preferSharp4);
  }
  return variantLabel(vid);
}

function buildPlayers(count: number): PlayerProfile[] {
  const c = clamp(count, 1, 16);
  const out: PlayerProfile[] = [];
  for (let i = 0; i < c; i++) out.push({ id: i, name: `P${i + 1}`, colorId: i, patternId: i });
  return out;
}

function defaultSettings(): GameSettings {
  return {
    modeId: ModeId.FRETBOARD,
    playType: PlayType.MULTI,
    matchType: MatchType.BLACKOUT,
    difficulty: Difficulty.MEDIUM,
    fixedRoundsTotal: 3,
    timers: { turnMs: 15_000, intermissionMs: 900 },
    domain: { fretCount: 25, minFret: 0, maxFret: 24, enabledStrings: [true, true, true, true, true, true] },
    feedback: {
      samEnabled: true,
      samDurationMs: 900,
      samRevealMode: "single",
      claimLabelMode: "off",
      claimLabelDurationMs: 900,
      samIncludeLabel: true,
    },
    steal: {
      tokenCap: 10,
      globalStealOnExhausted: true,
      enharmonicOppositeStealBonus: 5,
      breakConnectMaxTierBonus: 25,
      vulnerableAfterMisses: 3,
    },
    accessibility: { colorBlindMode: true },
    dev: { enabled: false, paintEnabled: false, paintPlayerIndex: 0, paintLane: "prompt", paintMode: "paint" },
    notation: { view: "staffTab", pitch: "written" },
    promptProfileId: "chromatic",
  };
}

function modeToPromptProfileId(root: string, mode: string): string {
  const m = String(mode || "chromatic").toLowerCase();
  const r = String(root || "C").trim();
  if (m === "chromatic") return "chromatic";
  if (m === "pentatonic") return `scale:${r}:pentatonic:sharps`;
  if (m === "blues") return `scale:${r}:blues:sharps`;
  if (["ionian", "dorian", "phrygian", "lydian", "mixolydian", "aeolian", "locrian"].includes(m)) {
    return `scale:${r}:${m}:sharps`;
  }
  // Fallback
  return "chromatic";
}

function difficultyFromUi(v: string): Difficulty {
  const s = String(v || "medium").toLowerCase();
  if (s === "learning") return Difficulty.LEARNING;
  if (s === "easy") return Difficulty.EASY;
  if (s === "hard") return Difficulty.HARD;
  return Difficulty.MEDIUM;
}

function readEnabledStrings(root: UiRoot): boolean[] {
  const sel = (root as Document).querySelector<HTMLSelectElement>("#pref-strings");
  const enabled = [false, false, false, false, false, false];
  if (!sel) return [true, true, true, true, true, true];
  const values = Array.from(sel.selectedOptions).map((o) => o.value);
  if (values.length === 0) return [true, true, true, true, true, true];

  // UI values are string numbers "1".."6" (1st string = high E). Engine indices are 0..5 (0 = high E).
  for (const v of values) {
    const n = Number(v);
    if (!Number.isFinite(n)) continue;
    const engineIdx = clamp(n, 1, 6) - 1;
    if (engineIdx >= 0 && engineIdx < 6) enabled[engineIdx] = true;
  }
  return enabled;
}

function readInt(root: UiRoot, selector: string, fallback: number): number {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  const n = Number(el?.value);
  return Number.isFinite(n) ? n : fallback;
}

function readStr(root: UiRoot, selector: string, fallback: string): string {
  const el = (root as Document).querySelector<HTMLInputElement | HTMLSelectElement>(selector);
  return (el?.value ?? fallback) as string;
}

function readBool(root: UiRoot, selector: string, fallback = false): boolean {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  if (!el) return fallback;
  return !!el.checked;
}

function readActiveTab(root: UiRoot, containerSelector: string, fallback: string): string {
  const g = (root as Document).querySelector<HTMLElement>(containerSelector);
  const active = g?.querySelector<HTMLButtonElement>(".tab.active");
  return (active?.dataset.tab ?? fallback) as string;
}

function buildSettingsFromUi(root: UiRoot, session: "single" | "multi" | "edu"): GameSettings {
  const d = defaultSettings();

  const playType = session === "multi" ? PlayType.MULTI : PlayType.SINGLE;
  const learningType = readActiveTab(root, "#ops-modeTabs", "single");
  const difficulty = difficultyFromUi(readStr(root, "#ops-difficulty", "medium"));
  const rootNote = readStr(root, "#core-root", "C");
  const mode = readStr(root, "#core-modes", "chromatic");
  const promptProfileId = modeToPromptProfileId(rootNote, mode);

  let displayMode = readStr(root, "#core-display", "names");
  // Back-compat: legacy romanIntervals is deprecated; treat as intervalRoman.
  if (displayMode === "romanIntervals") displayMode = "intervalRoman";
  const tritoneStyle = normalizeTritoneStyle(readStr(root, "#pref-tritoneStyle", "plusDim"));
  const noteVisibilityUi = readStr(root, "#core-noteVisibility", "all");
  const accidentalViewUi = readStr(root, "#core-accidentalView", "both");
  let noteVisibility = (noteVisibilityUi as "all" | "natural" | "enharmonic") ?? "all";
  // Learning difficulty assumes the player knows nothing: allow all spellings by default.
  if (difficulty === Difficulty.LEARNING) noteVisibility = "all";

  // How to render accidentals on the note rail (and other name-based displays).
  // Default is "both" (stack sharp and flat). "auto" can later be used for key/mode recipes.
  const accidentalView = (difficulty === Difficulty.LEARNING ? "both" : accidentalViewUi) as any;

  // Notation preferences (UI only). Default mirrors printed guitar notation.
  const notationView = readStr(root, "#pref-notationView", "staffTab") as any;
  const notationPitch = readStr(root, "#pref-notationPitch", "written") as any;

  const samModeUi = readStr(root, "#core-sam", "single");
  // Canon: legacy "multiple" is deprecated and must not exist in UI/state.
  // Accept only "single", "all", or "equiv".
  const samRevealMode = (samModeUi === "all" || samModeUi === "equiv") ? (samModeUi as any) : "single";

  // Presentation preferences
  const vulnerableAfterMisses = clamp(readInt(root, "#pref-vulnerableAfterMisses", 3), 1, 10);
  const reducedMotion = readBool(root, "#pref-reducedMotion", false);

  const viewFrets = clamp(readInt(root, "#pref-fretView", 12), 1, 24);
  // Fret count represents playable columns including open string (fret 0).
  const fretCount = viewFrets + 1;

  // Canon: default range starts at fret 0.
  const minFretRaw = clamp(readInt(root, "#pref-fretMin", 0), 0, viewFrets);
  // 13 total by default: 0..12 inclusive.
  const maxFretRaw = clamp(readInt(root, "#pref-fretMax", 12), minFretRaw, viewFrets);
  const minFret = minFretRaw;
  const maxFret = maxFretRaw;
  const enabledStrings = readEnabledStrings(root);

  // Surface controls (what boards are in play).
  const surfFret = readBool(root, "#core-surface-fret", true);
  const surfRail = readBool(root, "#core-surface-rail", true);
  const surfStaff = readBool(root, "#core-surface-staff", true);
  const surfTab = readBool(root, "#core-surface-tab", true);

  // Mirroring behavior (surface-to-surface placement).
  // Canon (GEG-055): default mirrored notes are placed, and Learning difficulty
  // should mirror by default. Future hint-only mirror modes can be added later.
  const mirrorUi = readStr(root, "#core-mirror", "placed");
  const mirrorMode = (difficulty === Difficulty.LEARNING ? "placed" : mirrorUi) as any;

  // Token / Dev settings (Main Menu Settings)
  const tokenCap = clamp(readInt(root, "#core-tokenCap", 10), 0, 20);
  const startTokens = clamp(readInt(root, "#core-startTokens", 0), 0, tokenCap);
  const devEnabled = readBool(root, "#core-devMode", false);

  // Dev/Test pane settings (only takes effect when dev is enabled)
  const devPaintEnabled = readBool(root, "#dev-paintEnabled", false);
  const devPaintPlayerIndex = clamp(Number(readStr(root, "#dev-paintPlayer", "0")), 0, 4);
  const devPaintLane = readStr(root, "#dev-paintLane", "prompt") as any;
  const devPaintMode = readStr(root, "#dev-paintMode", "paint") as any;

  // Highlighting system (pitch-class filters). These are UI-facing helpers used for
  // educational overlays; they do not change core scoring rules.
  const hlRoot = readBool(root, "#core-hl-root", false);
  const hl3 = readBool(root, "#core-hl-3", false);
  const hl5 = readBool(root, "#core-hl-5", false);
  const hl7 = readBool(root, "#core-hl-7", false);
  const hl9 = readBool(root, "#core-hl-9", false);
  const hl11 = readBool(root, "#core-hl-11", false);
  const hl13 = readBool(root, "#core-hl-13", false);

  // Chord extension preference (UI-only for now; used by highlighting + chord tools later).
  const chordExtension = readStr(root, "#chords-extension", "triad") as any;

  const s: GameSettings = {
    ...d,
    modeId: ModeId.FRETBOARD,
    playType,
    matchType: MatchType.BLACKOUT,
    difficulty,
    promptProfileId,
    domain: { ...d.domain, fretCount, minFret, maxFret, enabledStrings },
    feedback: { ...d.feedback, samRevealMode },
    steal: { ...d.steal, tokenCap, vulnerableAfterMisses },
    dev: {
      ...d.dev,
      enabled: devEnabled,
      paintEnabled: devPaintEnabled,
      paintPlayerIndex: devPaintPlayerIndex,
      paintLane: devPaintLane,
      paintMode: devPaintMode,
    },
    notation: {
      view: (notationView === "staff" || notationView === "tab" ? notationView : "staffTab"),
      pitch: (notationPitch === "concert" ? "concert" : "written"),
      mode: session === "edu" ? "notation" : "game",
    },
  };

  // Non-typed extensions used by promptProfiles (kept compatible with the shell version).
  (s as any).noteVisibility = noteVisibility;
  (s as any).accidentalView = accidentalView;
  (s as any).displayMode = displayMode;
  (s as any).tritoneStyle = tritoneStyle;
  (s as any).mirrorMode = mirrorMode;
  (s as any).mirrorMode = mirrorMode;
  (s as any).rootNote = rootNote;
  (s as any).learningType = learningType;
  (s as any).highlight = { root: hlRoot, "3": hl3, "5": hl5, "7": hl7, "9": hl9, "11": hl11, "13": hl13 };
  (s as any).chordExtension = chordExtension;
  (s as any).startTokens = startTokens;
  (s as any).learningType = learningType;
  (s as any).reducedMotion = reducedMotion;
  (s as any).surfaces = { fretboard: surfFret, rail: surfRail, staff: surfStaff, tab: surfTab };
  return s;
}

// ----------------------------
// Controller
// ----------------------------

export function initGameController(root: UiRoot): void {
  const doc = root as Document;

  const splash = doc.querySelector<HTMLElement>("#splash");
  const promptText = doc.querySelector<HTMLElement>("#promptText");
  const alertsText = doc.querySelector<HTMLElement>("#alerts-text");

  const activeName = doc.querySelector<HTMLElement>("#activePlayer-name");
  const activeScore = doc.querySelector<HTMLElement>("#activePlayer-score");
  const activeMult = doc.querySelector<HTMLElement>("#activePlayer-mult");
  const activeTarget = doc.querySelector<HTMLElement>("#activePlayer-target");
  const activeTimer = doc.querySelector<HTMLElement>("#activePlayer-timer");
  const activeTokens = doc.querySelector<HTMLElement>("#activePlayer-tokens");
  const leaderboard = doc.querySelector<HTMLElement>("#leaderboard");
  const highscores = doc.querySelector<HTMLElement>("#highscores");

  const devTab = doc.querySelector<HTMLElement>("#misc-dev-tab");
  const devPane = doc.querySelector<HTMLElement>("#misc-dev-pane");

  const fretStage = doc.querySelector<HTMLElement>("#fretStage");
  const fretBgHost = doc.querySelector<HTMLElement>("#fretBgHost");
  const fretOverlaySvg = doc.querySelector<SVGSVGElement>("#fretOverlaySvg");
  const staffBgHost = doc.querySelector<HTMLElement>("#staffBgHost");
  const staffOverlaySvg = doc.querySelector<SVGSVGElement>("#staffOverlaySvg");
  const noteStripRail = doc.querySelector<HTMLElement>("#noteStrip-rail");

  if (!fretStage || !fretBgHost || !fretOverlaySvg) throw new Error("Fretboard surface not found");
  const fretStageEl: HTMLElement = fretStage;
  const fretBgHostEl: HTMLElement = fretBgHost;
  const fretOverlaySvgEl: SVGSVGElement = fretOverlaySvg;
  const staffBgHostEl: HTMLElement | null = staffBgHost;
  const staffOverlaySvgEl: SVGSVGElement | null = staffOverlaySvg;

  // Rail (shell feature)
  const rail = createChromaticRail();
  // GEG-016: Starting tokens must be adjustable and must respect the configured cap.
  // Keep the Start input clamped to Cap in the UI to prevent confusing states.
  const tokenCapEl = doc.querySelector<HTMLInputElement>("#core-tokenCap");
  const startTokensEl = doc.querySelector<HTMLInputElement>("#core-startTokens");

  const syncTokenUi = () => {
    if (!tokenCapEl || !startTokensEl) return;
    const cap = Number(tokenCapEl.value || 0);
    // Mirror the cap into the Start input's max to communicate the valid range.
    startTokensEl.max = String(Math.max(0, Math.min(20, cap)));
    const cur = Number(startTokensEl.value || 0);
    const next = Math.max(0, Math.min(cur, cap));
    if (next !== cur) startTokensEl.value = String(next);
  };

  tokenCapEl?.addEventListener("input", syncTokenUi);
  startTokensEl?.addEventListener("input", syncTokenUi);
  syncTokenUi();

  if (noteStripRail) {
    noteStripRail.innerHTML = "";
    noteStripRail.appendChild(rail.el);
  }

  // ----------------------------
  // Utility intent handlers (Education + Game scaffolding)
  // ----------------------------

  // Note intent (pitch-class + spelling slot)
  let utilNotePc: number = 0; // C
  let utilNoteSlot: SlotType = SlotType.NAT;

  const utilNotePitches = doc.getElementById("util-note-pitches");
  const utilNoteAcc = doc.getElementById("util-note-acc");
  const utilNoteSelected = doc.getElementById("util-note-selected");

  function renderUtilNoteSelected(): void {
    if (!utilNoteSelected) return;
    const vid = toVariantId(utilNotePc as any, utilNoteSlot);
    utilNoteSelected.textContent = variantLabel(vid);
  }

  function syncChipGroupActive(container: HTMLElement | null, match: (b: HTMLButtonElement) => boolean): void {
    if (!container) return;
    const btns = Array.from(container.querySelectorAll<HTMLButtonElement>("button.chip"));
    btns.forEach((b) => b.classList.toggle("active", match(b)));
  }

  utilNotePitches?.addEventListener("click", (ev) => {
    const btn = (ev.target as HTMLElement | null)?.closest?.("button.chip") as HTMLButtonElement | null;
    const pc = btn?.dataset?.pc;
    if (!btn || pc == null) return;
    utilNotePc = Number(pc);
    syncChipGroupActive(utilNotePitches, (b) => b.dataset.pc === pc);
    renderUtilNoteSelected();
    const vid = toVariantId(utilNotePc as any, utilNoteSlot);
    // Education: selecting from Utility also sets what will be placed.
    if (session === "edu") {
      eduSelectedVariantId = vid;
      updateEduSelectedUi();
      renderAll();
    }
    window.dispatchEvent(new CustomEvent("gedu:utilNoteIntent", { detail: { variantId: vid, pitchClass: utilNotePc, slot: utilNoteSlot } }));
  });

  utilNoteAcc?.addEventListener("click", (ev) => {
    const btn = (ev.target as HTMLElement | null)?.closest?.("button.chip") as HTMLButtonElement | null;
    const slotStr = btn?.dataset?.slot;
    if (!btn || !slotStr) return;
    utilNoteSlot = slotStr === "shr" ? SlotType.SHR : slotStr === "flt" ? SlotType.FLT : SlotType.NAT;
    syncChipGroupActive(utilNoteAcc, (b) => b.dataset.slot === slotStr);
    renderUtilNoteSelected();
    const vid = toVariantId(utilNotePc as any, utilNoteSlot);
    if (session === "edu") {
      eduSelectedVariantId = vid;
      updateEduSelectedUi();
      renderAll();
    }
    window.dispatchEvent(new CustomEvent("gedu:utilNoteIntent", { detail: { variantId: vid, pitchClass: utilNotePc, slot: utilNoteSlot } }));
  });

  renderUtilNoteSelected();

  // Interval intent scaffolding
  let utilIntDir: "either" | "up" | "down" = "either";
  let utilIntSemi = 0;
  const utilIntDirEl = doc.getElementById("util-int-dir");
  const utilIntSemiEl = doc.getElementById("util-int-semi");
  const utilIntSelectedEl = doc.getElementById("util-int-selected");
  const renderUtilIntervalSelected = () => {
    if (utilIntSelectedEl) utilIntSelectedEl.textContent = `${utilIntSemi} / ${utilIntDir}`;
  };
  utilIntDirEl?.addEventListener("click", (ev) => {
    const btn = (ev.target as HTMLElement | null)?.closest?.("button.chip") as HTMLButtonElement | null;
    const dir = btn?.dataset?.dir as any;
    if (!btn || !dir) return;
    utilIntDir = dir;
    syncChipGroupActive(utilIntDirEl, (b) => b.dataset.dir === dir);
    renderUtilIntervalSelected();
    window.dispatchEvent(new CustomEvent("gedu:utilIntervalIntent", { detail: { semitones: utilIntSemi, direction: utilIntDir } }));
  });
  utilIntSemiEl?.addEventListener("click", (ev) => {
    const btn = (ev.target as HTMLElement | null)?.closest?.("button.chip") as HTMLButtonElement | null;
    const semiStr = btn?.dataset?.semi;
    if (!btn || semiStr == null) return;
    utilIntSemi = Number(semiStr);
    syncChipGroupActive(utilIntSemiEl, (b) => b.dataset.semi === semiStr);
    renderUtilIntervalSelected();
    window.dispatchEvent(new CustomEvent("gedu:utilIntervalIntent", { detail: { semitones: utilIntSemi, direction: utilIntDir } }));
  });
  renderUtilIntervalSelected();

  // Arpeggio intent scaffolding + routing
  let utilArpTone: "triad" | "7th" | "extended" = "triad";
  let utilArpDir: "up" | "down" | "both" = "up";
  const utilArpToneEl = doc.getElementById("util-arp-tone");
  const utilArpDirEl = doc.getElementById("util-arp-dir");
  const utilArpSelectedEl = doc.getElementById("util-arp-selected");
  const utilArpSkip = doc.getElementById("util-arp-route-skip") as HTMLInputElement | null;
  const utilArpReturn = doc.getElementById("util-arp-route-return") as HTMLInputElement | null;
  const utilArpMaxJump = doc.getElementById("util-arp-route-maxJump") as HTMLInputElement | null;
  const renderUtilArpSelected = () => {
    if (utilArpSelectedEl) utilArpSelectedEl.textContent = `${utilArpTone} / ${utilArpDir}`;
  };
  function emitUtilArpIntent(): void {
    window.dispatchEvent(
      new CustomEvent("gedu:utilArpIntent", {
        detail: {
          toneSet: utilArpTone,
          direction: utilArpDir,
          route: {
            allowSkip: !!utilArpSkip?.checked,
            allowReturn: !!utilArpReturn?.checked,
            maxStringJump: clamp(Number(utilArpMaxJump?.value ?? 2), 1, 5),
          },
        },
      }),
    );
  }
  utilArpToneEl?.addEventListener("click", (ev) => {
    const btn = (ev.target as HTMLElement | null)?.closest?.("button.chip") as HTMLButtonElement | null;
    const tone = btn?.dataset?.tone as any;
    if (!btn || !tone) return;
    utilArpTone = tone;
    syncChipGroupActive(utilArpToneEl, (b) => b.dataset.tone === tone);
    renderUtilArpSelected();
    emitUtilArpIntent();
  });
  utilArpDirEl?.addEventListener("click", (ev) => {
    const btn = (ev.target as HTMLElement | null)?.closest?.("button.chip") as HTMLButtonElement | null;
    const dir = btn?.dataset?.dir as any;
    if (!btn || !dir) return;
    utilArpDir = dir;
    syncChipGroupActive(utilArpDirEl, (b) => b.dataset.dir === dir);
    renderUtilArpSelected();
    emitUtilArpIntent();
  });
  utilArpSkip?.addEventListener("change", emitUtilArpIntent);
  utilArpReturn?.addEventListener("change", emitUtilArpIntent);
  utilArpMaxJump?.addEventListener("input", emitUtilArpIntent);
  renderUtilArpSelected();
  emitUtilArpIntent();

  // Scale routing intent (shared contract with patterns)
  const utilRouteSkip = doc.getElementById("util-route-skip") as HTMLInputElement | null;
  const utilRouteReturn = doc.getElementById("util-route-return") as HTMLInputElement | null;
  const utilRouteMaxJump = doc.getElementById("util-route-maxJump") as HTMLInputElement | null;
  const emitUtilScaleRoute = () => {
    window.dispatchEvent(
      new CustomEvent("gedu:utilScaleRoute", {
        detail: {
          allowSkip: !!utilRouteSkip?.checked,
          allowReturn: !!utilRouteReturn?.checked,
          maxStringJump: clamp(Number(utilRouteMaxJump?.value ?? 2), 1, 5),
        },
      }),
    );
  };
  utilRouteSkip?.addEventListener("change", emitUtilScaleRoute);
  utilRouteReturn?.addEventListener("change", emitUtilScaleRoute);
  utilRouteMaxJump?.addEventListener("input", emitUtilScaleRoute);
  emitUtilScaleRoute();

  // Scale -> Arpeggio shortcut (canon: Arpeggios live under Chord, but Scale can provide a shortcut)
  const utilScaleArpShortcut = doc.getElementById("util-scale-arpShortcut") as HTMLButtonElement | null;
  utilScaleArpShortcut?.addEventListener("click", () => {
    const rightTabs = doc.querySelector<HTMLElement>("[data-tabs=\"right\"]");
    rightTabs?.querySelector<HTMLButtonElement>(".tab[data-tab=\"chord\"]")?.click();
    const arpDetails = doc.getElementById("util-arp-details") as HTMLDetailsElement | null;
    if (arpDetails) arpDetails.open = true;
    arpDetails?.scrollIntoView?.({ block: "nearest" });
  });

  let session: "single" | "multi" | "edu" = "single";

  // Multiplayer player count (drives "active players" rendering, including in-match leaderboard).
  // Default is 2; UI selection is read from the splash screen.
  let multiPlayerCount = 2;

  // Education mode (instructor) state
  let eduTool: "input" | "erase" | "rest" = "input";
  let eduEditMode: "overwrite" | "insert" = "overwrite";
  let eduRefingerOnPitchEdits = false;
  // VariantId convention in this codebase: 0=C natural, 1=C# ...; spelling is derived.
  let eduSelectedVariantId: number = 0;
  const eduFretMarks = new Map<number, number>(); // cellIndex -> variantId
  let eduShowStaff = true;
  let eduShowTab = true;
  let eduShowFret = true;
  // Education staff/TAB note value (16-column measure grid).
  // whole=16, half=8, quarter=4, eighth=2, sixteenth=1
  let eduNoteStepCols = 4;
  // Education note duration in MusicXML divisions (notation mode only).
  // Default is quarter note.
  let eduNoteDurDiv = 480;
  // Education placement cursor: advances after each placement.
  let eduCursorCol = 0;

  // Staff/TAB operational mode: "game" is pitch-first; "notation" is time-aware.
  // Defaults to game behavior at boot; session transitions set the appropriate mode.
  let staffTabMode: StaffTabMode = "game";
  let eduFretHandlersInstalled = false;
  let settings: GameSettings = buildSettingsFromUi(doc, session);
  let players: PlayerProfile[] = buildPlayers(session === "single" ? 1 : multiPlayerCount);
  let state: GameState | null = null;

  // Canon: Pause is removed. The match is either Ready (not running) or Running.
  let matchIsRunning = false;
  let turnEndsAt = 0;
  let timerHandle: number | null = null;
  let intermissionHandle: number | null = null;
  let samHandle: number | null = null;

  // Match timing (used for persistent high score entries)
  let matchStartedAtMs = 0;
  let matchRecorded = false;
  // TAB input state (instant): select string + fret (either order), claim immediately.
  let tabSelectedString: number | null = null;
  let tabSelectedFret: number | null = null;


  let fretLayout: FretboardLayout | null = null;
  let staffLayout: StaffTabLayout | null = null;
  const staffOverlayStateGame = createStaffTabOverlayState();
  const staffOverlayStateNotation = createStaffTabOverlayState();
  // NotationScore (time-aware). Used ONLY when staffTabMode === "notation".
  // Game-mode staff/tab remains column-driven and independent.
  let notationScore = createEmptyScore();
  // Keep the default Education duration aligned to notation divisions.
  eduNoteDurDiv = notationScore.divisionsPerQuarter;
  // Notation cursor (measureIndex + offsetDiv). Independent from the game cursor.
  // Education/Notation cursor: source of truth for authoring.
  // tick is stored as offsetDiv (MusicXML divisions).
  let eduNotationCursor = { measureIndex: 0, offsetDiv: 0, voice: "1", staff: 1 };
  let detachStaffHandlers: (() => void) | null = null;
  // Mirroring placement cursor for staff/tab columns.
  // Used when a successful fretboard claim should also "place" marks onto
  // other enabled surfaces (GEG-055).
  let mirrorColNext = 0;
  let activePulse: {
    playerId: number;
    variantId: number;
    durationMs: number;
    ghost: any | null;
    ghosts?: any[];
    scoreDelta: number;
    includeLabel?: boolean;
  } | null = null;
  let pulseHandle: number | null = null;

  function setAlert(msg: string): void {
    if (!alertsText) return;
    const phase = state?.phase ?? "TITLE";
    alertsText.textContent = `${phase}: ${msg}`;
  }

  function syncEducationPanels(): void {
    const playerCard = doc.getElementById("activePlayer-card") as HTMLElement | null;
    const eduWrap = doc.getElementById("eduTools-wrap") as HTMLElement | null;
    if (playerCard) playerCard.toggleAttribute("hidden", session === "edu");
    if (eduWrap) eduWrap.toggleAttribute("hidden", session !== "edu");
  }

  function activeStaffOverlayState(): ReturnType<typeof createStaffTabOverlayState> {
    return staffTabMode === "notation" ? staffOverlayStateNotation : staffOverlayStateGame;
  }

  function clearTimers(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    if (intermissionHandle !== null) window.clearTimeout(intermissionHandle);
    if (samHandle !== null) window.clearTimeout(samHandle);
    timerHandle = null;
    intermissionHandle = null;
    samHandle = null;
  }

  function stopTurnTimer(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    timerHandle = null;
    turnEndsAt = 0;
    if (activeTimer) activeTimer.textContent = "00:00";
  }

  function startTurnTimer(): void {
    stopTurnTimer();
    if (!state) return;
    if (!matchIsRunning) return;
    applySurfaceVisibility();
    const ms = state.settings.timers.turnMs;
    turnEndsAt = Date.now() + ms;
    if (activeTimer) activeTimer.textContent = formatMs(ms);
    timerHandle = window.setInterval(() => {
      if (!state || !matchIsRunning) return;
      const left = turnEndsAt - Date.now();
      if (activeTimer) activeTimer.textContent = formatMs(left);
      if (left <= 0) {
        stopTurnTimer();
        dispatch({ type: "TIMEOUT" } as Action);
      }
    }, 100);
  }

  function hideSplash(): void {
    splash?.classList.remove("show");
  }

  function showSplash(): void {
    splash?.classList.add("show");
  }


  function currentMatchDurationMs(): number {
    if (!matchStartedAtMs) return 0;
    const now = Date.now();
    return Math.max(0, now - matchStartedAtMs);
  }

  function syncDevTabVisibility(isDevEnabled?: boolean): void {
    const enabled =
      isDevEnabled ?? ((doc.querySelector<HTMLInputElement>("#core-devMode")?.checked ?? false) === true);
    if (devTab) devTab.classList.toggle("devHidden", !enabled);
    if (devPane) devPane.classList.toggle("devHidden", !enabled);

    // If dev is disabled and the dev pane is currently active, bounce back to Achievements.
    if (!enabled) {
      const miscTabs = doc.querySelector<HTMLElement>("[data-tabs=\"miscinfo\"]");
      const activeTab = miscTabs?.querySelector<HTMLElement>(".tab.active");
      if (activeTab && activeTab.getAttribute("data-tab") === "dev") {
        miscTabs?.querySelector<HTMLElement>(".tab[data-tab=\"ach\"]")?.click();
      }
    }
  }

  function updateHighScoresUi(useSettings?: GameSettings): void {
    if (!highscores) return;
    const s = useSettings ?? state?.settings ?? settings;
    const entries = getLeaderboard(s).slice(0, 10);
    if (entries.length === 0) {
      highscores.innerHTML = `<div class="hint">No saved scores yet. Finish a match to populate this list.</div>`;
      return;
    }
    highscores.innerHTML = entries
      .map((e) => {
        const when = new Date(e.atIso).toLocaleDateString();
        const dur = e.durationMs ? ` • ${formatMs(e.durationMs)}` : "";
        return `<div class="leader-row"><div class="leader-name">${escapeHtml(e.name)}</div><div class="leader-score">${e.score}</div><div class="leader-meta">${when}${dur}</div></div>`;
      })
      .join("");
  }

  function recordScoresIfNeeded(): void {
    if (!state) return;
    if (!matchIsRunning) return;
    if (matchRecorded) return;
    matchRecorded = true;
    const dur = currentMatchDurationMs();
    for (const p of state.players) {
      recordScore(state.settings, p.profile.name, p.score, dur);
    }
    updateHighScoresUi(state.settings);
  }

  const SVG_ENTITY_MAP: Record<string, string> = {
    ns_extend: "http://ns.adobe.com/Extensibility/1.0/",
    ns_ai: "http://ns.adobe.com/AdobeIllustrator/10.0/",
    ns_graphs: "http://ns.adobe.com/Graphs/1.0/",
    ns_vars: "http://ns.adobe.com/Variables/1.0/",
    ns_imrep: "http://ns.adobe.com/ImageReplacement/1.0/",
    ns_sfw: "http://ns.adobe.com/SaveForWeb/1.0/",
    ns_custom: "http://ns.adobe.com/GenericCustomNamespace/1.0/",
    ns_adobe_xpath: "http://ns.adobe.com/XPath/1.0/",
  };

  const ASSET_BASE = (import.meta as any).env?.BASE_URL ?? "/";
  function assetUrl(path: string): string {
    const clean = path.startsWith("/") ? path.slice(1) : path;
    return new URL(clean, window.location.origin + ASSET_BASE).toString();
  }

  // Staff/TAB hit-grid resolution.
  // 16 columns per measure = 16th-note grid in 4/4.
  // When we add smaller rhythmic divisions (32nds, tuplets, swing, etc.),
  // we can increase this (e.g., 32, 48, 64...) or move to a tick-based grid.
  const DEFAULT_STAFF_COLUMNS_PER_MEASURE = 16;

  function sanitizeSvgText(raw: string): string {
    let t = raw;

    // Replace Illustrator entity references (browsers do not evaluate SVG DTD entities when injecting via innerHTML).
    for (const [k, v] of Object.entries(SVG_ENTITY_MAP)) {
      t = t.replaceAll("&" + k + ";", v);
    }

    // Remove XML declaration and DOCTYPE (including internal subsets).
    t = t.replace(/<\?xml[\s\S]*?\?>/g, "");
    t = t.replace(/<!DOCTYPE[\s\S]*?\]>/g, "");
    t = t.replace(/<!DOCTYPE[^>]*>/g, "");
    t = t.replace(/<!ENTITY[\s\S]*?>/g, "");

    // Remove Adobe-only foreignObject blocks (keeps the real <g> content).
    t = t.replace(/<foreignObject[\s\S]*?<\/foreignObject>/g, "");

    return t;
  }

  async function loadSvgIntoHost(
    host: HTMLElement,
    urlPath: string,
    preserveAspectRatio: string = "xMidYMid meet",
  ): Promise<string> {
    const res = await fetch(assetUrl(urlPath));
    if (!res.ok) throw new Error("Failed to load " + urlPath + ": " + res.status);

    const raw = await res.text();
    const svgText = sanitizeSvgText(raw);
    host.innerHTML = svgText;

    const svg = host.querySelector("svg") as SVGSVGElement | null;
    if (svg) {
      svg.setAttribute("width", "100%");
      svg.setAttribute("height", "100%");
      svg.setAttribute("preserveAspectRatio", preserveAspectRatio);
    }

    return svgText;
  }


  async function setupSvgSurfaces(): Promise<void> {
    // Staff background (optional)
    if (staffBgHostEl && staffOverlaySvgEl) {
      // NOTE: loadSvgIntoHost expects a relative asset path (it applies assetUrl() internally).
      const staffText = await loadSvgIntoHost(staffBgHostEl, "/Guitar-Notes_Tab_Staff-Blank-3Measures.svg", "xMidYMid meet");
      const vb = parseSvgViewBox(staffText);
      staffOverlaySvgEl.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
      staffOverlaySvgEl.setAttribute("preserveAspectRatio", "xMidYMid meet");
      staffLayout = parseStaffTabLayout(staffText, DEFAULT_STAFF_COLUMNS_PER_MEASURE);
      renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());

      // (Re)bind staff/tab pointer handlers to the active overlay state.
      detachStaffHandlers?.();
      detachStaffHandlers = attachStaffTabPointerHandlers(staffOverlaySvgEl, staffLayout, activeStaffOverlayState(), (hit: StaffTabHit) => {
        window.dispatchEvent(new CustomEvent("gedu:staffPick", { detail: hit }));
      });

      // Apply the initial crop according to the notation view preference.
      const notationViewEl = doc.getElementById("pref-notationView") as HTMLSelectElement | null;
      const notationView = notationViewEl?.value ?? "staffTab";
      applyStaffTabCrop(notationView);
    }

    // Visual background SVG: prefer the v2i artwork; fall back to the vector SVG if needed.
    let bgText = "";
    try {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete_v2i.svg"),
        "xMinYMin meet",
      );
    } catch {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"),
        "xMinYMin meet",
      );
    }

    // Compute the hitbox layout directly from the background SVG whenever possible.
    // Our photo-style v2i asset now exposes enough geometry (via image transforms) to
    // recover fret and string positions, which keeps markers perfectly centered.
    let layout: FretboardLayout;
    let vb: { x: number; y: number; w: number; h: number };
    try {
      const cleanBgText = sanitizeSvgText(bgText);
      layout = computeLayoutFromSvg(cleanBgText);
      vb = layout.viewBox;
    } catch (e) {
      console.warn("Failed to compute layout from background SVG; falling back to vector geometry mapping.", e);

      // Geometry fallback: compute from the clean vector SVG and map into the background.
      const hitRaw = await (await fetch(assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"))).text();
      const hitText = sanitizeSvgText(hitRaw);
      const baseLayout = computeLayoutFromSvg(hitText);

      layout = baseLayout;
      vb = baseLayout.viewBox;
      try {
        const bgVB = parseSvgViewBox(bgText);
        const bgNeck = parseSvgNeckBounds(bgText);
        layout = mapLayoutToNeck(baseLayout, bgVB, bgNeck);
        vb = bgVB;
      } catch (e2) {
        console.warn("Failed to map fretboard layout to background SVG; using base layout.", e2);
      }
    }

    fretLayout = layout;

    fretOverlaySvgEl.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
    fretOverlaySvgEl.setAttribute("preserveAspectRatio", "xMinYMin meet");
    fretOverlaySvgEl.setAttribute("width", "100%");
    fretOverlaySvgEl.setAttribute("height", "100%");

    attachBoardPointerHandlers(
      { layout: fretLayout, svgRoot: fretOverlaySvgEl, dispatch },
      () => state,
      fretOverlaySvgEl,
    );

    // Education mode: allow placing markers on the fretboard even when no match is running.
    if (!eduFretHandlersInstalled) {
      eduFretHandlersInstalled = true;
      fretOverlaySvgEl.addEventListener("pointerdown", (ev: PointerEvent) => {
        if (session !== "edu") return;
        if (!fretLayout) return;
        // Convert client -> svg coords
        const rect = fretOverlaySvgEl.getBoundingClientRect();
        const vb = fretOverlaySvgEl.viewBox.baseVal;
        const sx = vb.x + ((ev.clientX - rect.left) * vb.width) / Math.max(1, rect.width);
        const sy = vb.y + ((ev.clientY - rect.top) * vb.height) / Math.max(1, rect.height);

        const hit = hitTestCell(fretLayout, sx, sy);
        if (!hit) return;
        const fretCols = Math.max(1, fretLayout.fretBoundaries.length - 1);
        const cellIndex = hit.stringIndex * fretCols + hit.fretIndex;
        if (eduTool === "erase") eduFretMarks.delete(cellIndex);
        else eduFretMarks.set(cellIndex, eduSelectedVariantId);
        renderEduFretMarks();
        applyEduVisibility();
      }, { passive: true });
    }

    // Initial render if a game is already running.
    updateOverlayOwnership();
    syncFretKeypadAvailability();
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());
  }

  function applyStaffTabCrop(notationView: string): void {
    if (!staffLayout || !staffOverlaySvgEl || !staffBgHostEl) return;

    const full = staffLayout.viewBox;
    let y0 = full.y;
    let y1 = full.y + full.h;

    // Add a small padding so we don't clip clefs/labels.
    const staffPad = staffLayout.staff.halfStep * 2;
    const tabGap = (staffLayout.tab.lineYs[1] ?? staffLayout.tab.lineYs[0] ?? 10) - (staffLayout.tab.lineYs[0] ?? 0);
    const tabPad = Math.max(6, Math.abs(tabGap) * 0.9);

    if (notationView === "staff") {
      // Staff only
      y0 = staffLayout.staff.yMin - staffPad;
      y1 = staffLayout.staff.yMax + staffPad;
    } else if (notationView === "tab") {
      // Tab only
      y0 = staffLayout.tab.yMin - tabPad;
      y1 = staffLayout.tab.yMax + tabPad;
    }

    // Clamp to the original viewBox.
    y0 = Math.max(full.y, y0);
    y1 = Math.min(full.y + full.h, y1);
    const h = Math.max(1, y1 - y0);

    const vbStr = `${full.x} ${y0} ${full.w} ${h}`;
    staffOverlaySvgEl.setAttribute("viewBox", vbStr);
    staffOverlaySvgEl.setAttribute("preserveAspectRatio", "xMidYMid meet");

    // Update the embedded background SVG to match.
    const bgSvg = staffBgHostEl.querySelector("svg");
    if (bgSvg) {
      bgSvg.setAttribute("viewBox", vbStr);
      bgSvg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    }
  }

  // --- Education helpers ---
  function updateEduSelectedUi(): void {
    const el = doc.getElementById("edu-selected");
    if (!el) return;
    const lab = variantLabel(eduSelectedVariantId);
    el.textContent = lab;
  }

  function updateEduCursorUi(): void {
    const el = doc.getElementById("edu-cursor");
    if (!el) return;
    const mi = Math.max(0, Math.round(eduNotationCursor.measureIndex));
    const off = Math.max(0, Math.round(eduNotationCursor.offsetDiv));
    el.textContent = `M${mi + 1} @ ${off}`;
  }

  function clearEduMarks(which: "all" | "staff" | "tab" | "fret"): void {
    const st = activeStaffOverlayState();
    if (which === "all" || which === "staff") st.staffMarksByCol.clear();
    if (which === "all" || which === "tab") st.tabMarksByCol.clear();
    if (which === "all" || which === "fret") eduFretMarks.clear();
    if (which === "all" || which === "staff" || which === "tab") {
      // Clear the time-aware notation score when clearing staff/tab marks.
      if (staffTabMode === "notation") {
        notationScore = createEmptyScore({ timeSig: notationScore.timeSig, divisionsPerQuarter: notationScore.divisionsPerQuarter });
        eduNotationCursor = { measureIndex: 0, offsetDiv: 0, voice: "1", staff: 1 };
        updateEduCursorUi();
      }
    }
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, st);
    renderEduFretMarks();
    applyEduVisibility();
  }

  function applyEduVisibility(): void {
    if (session !== "edu") return;
    if (staffOverlaySvgEl) {
      const gStaff = staffOverlaySvgEl.querySelector<SVGGElement>("#geduStaffMarks");
      const gTab = staffOverlaySvgEl.querySelector<SVGGElement>("#geduTabNumbers");
      if (gStaff) gStaff.style.display = eduShowStaff ? "" : "none";
      if (gTab) gTab.style.display = eduShowTab ? "" : "none";
    }
    const gFret = fretOverlaySvgEl.querySelector<SVGGElement>("#geduEduMarks");
    if (gFret) gFret.style.display = eduShowFret ? "" : "none";
  }

  function renderEduFretMarks(): void {
    if (session !== "edu") return;
    if (!fretLayout) return;

    const NS = "http://www.w3.org/2000/svg";
    let g = fretOverlaySvgEl.querySelector<SVGGElement>("#geduEduMarks");
    if (!g) {
      g = document.createElementNS(NS, "g") as SVGGElement;
      g.setAttribute("id", "geduEduMarks");
      fretOverlaySvgEl.appendChild(g);
    }
    while (g.firstChild) g.removeChild(g.firstChild);

    const fretCols = Math.max(1, fretLayout.fretBoundaries.length - 1);
    const r = Math.max(6, Math.min(10, fretLayout.dotRadius * 1.25));
    for (const [cellIndex, vid] of eduFretMarks.entries()) {
      const stringIndex = Math.floor(cellIndex / fretCols);
      const fretIndex = cellIndex % fretCols;
      const c = cellCenter(fretLayout, stringIndex, fretIndex);

      const circ = document.createElementNS(NS, "circle");
      circ.setAttribute("cx", String(c.cx));
      circ.setAttribute("cy", String(c.cy));
      circ.setAttribute("r", String(r));
      circ.setAttribute("fill", "rgba(255,255,255,0.12)");
      circ.setAttribute("stroke", "rgba(255,255,255,0.65)");
      circ.setAttribute("stroke-width", "1");
      g.appendChild(circ);

      const t = document.createElementNS(NS, "text");
      t.setAttribute("x", String(c.cx));
      t.setAttribute("y", String(c.cy + r * 0.35));
      t.setAttribute("text-anchor", "middle");
      t.setAttribute("font-size", String(Math.max(9, r * 0.95)));
      t.setAttribute("font-weight", "700");
      t.setAttribute("fill", "rgba(255,255,255,0.95)");
      t.textContent = variantLabel(vid);
      g.appendChild(t);
    }
  }

  void setupSvgSurfaces().catch((err) => {
    console.error("Failed to set up SVG surfaces", err);
  });

  function rebuildOverlay(): void {
    // No-op: fretboard interaction and rendering are handled by the SVG overlay.
    // This stub is kept so older calls (e.g., start/reset) don't crash.
  }

  function updateOverlayOwnership(): void {
    if (!state || !fretLayout) return;
    renderOverlay(fretOverlaySvgEl, fretLayout, state, activePulse);
  }

  function updateActivePlayerUi(): void {
    if (!state) return;
    if (!matchIsRunning) return;
    const pIndex = state.currentPlayer;
    const p = state.players[pIndex];
    if (!p) return;

    if (activeName) activeName.textContent = players[pIndex]?.name ?? `P${pIndex + 1}`;
    if (activeScore) activeScore.textContent = String(p.score);
    if (activeMult) activeMult.textContent = `×${1 + (state.turn?.streakTier ?? 0)}`;

    if (activeTokens) {
      const cap = state.settings.steal.tokenCap;
      activeTokens.innerHTML = "";
      for (let i = 0; i < cap; i++) {
        const dot = document.createElement("span");
        dot.className = "tokenDot" + (i < p.tokenCount ? " filled" : "");
        activeTokens.appendChild(dot);
      }
    }
  }

  function updateLeaderboardUi(): void {
    if (!state || !leaderboard) return;
    leaderboard.innerHTML = "";
    for (let i = 0; i < state.players.length; i++) {
      const p = state.players[i];
      const row = document.createElement("div");
      row.className = "leader-chip" + (i === state.currentPlayer ? " active" : "");
      row.innerHTML = `
        <div class="leader-avatar">${(players[i]?.name ?? `P${i + 1}`).slice(0, 2)}</div>
        <div class="leader-name">${players[i]?.name ?? `P${i + 1}`}</div>
        <div class="leader-score">${p.score}</div>
        <div class="leader-tokens">${p.tokenCount}</div>
      `;
      leaderboard.appendChild(row);
    }
  }

  function updatePromptUi(): void {
    if (!state) return;
    if (!matchIsRunning) return;
    const displayMode = (state.settings as any).displayMode ?? "names";
    const rootPc = pcFromUiNoteName((state.settings as any).rootNote ?? "C");
    const label = labelForVariant(state.prompt.variantId, displayMode, rootPc, state.settings);

    // Update the visible target label (and promptText if that element exists).
    if (promptText) promptText.textContent = label;
    if (activeTarget) {
      const v = fromVariantId(state.prompt.variantId);
      const isBlack = IS_BLACK[v.pitchClass];
      const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
      activeTarget.textContent = spelling ? `Target: ${label} (${spelling})` : `Target: ${label}`;
      activeTarget.classList.toggle("is-sharp", isBlack && v.spelling === SlotType.SHR);
      activeTarget.classList.toggle("is-flat", isBlack && v.spelling === SlotType.FLT);
    }

    // Rail config (GEG-061)
    // Canon: Chromatic/Accidentals use rotating compass rail; Keys/Scales/Chords use fixed reference.
    const pid = (state.settings.promptProfileId ?? "").trim().toLowerCase();
    const rotate = pid === "chromatic" || pid.startsWith("chromatic:") || pid === "accidentals" || pid.startsWith("accidentals:");
    const railMode: RailConfig["mode"] = rotate ? "ROTATE_COMPASS" : "FIXED_REFERENCE";
    const anchor = toVariantId(rootPc as any, SlotType.NAT);
    rail.setConfig(
      {
        mode: railMode,
        anchorVariantId: anchor,
        currentVariantId: state.prompt.variantId,
      },
      state.settings,
    );

    // Make the sharp/flat requirement visible at a glance without giving away fretboard positions.
    const v = fromVariantId(state.prompt.variantId);
    const isBlack = IS_BLACK[v.pitchClass];
    const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
    const targetSuffix = spelling ? ` | Target: ${label} (${spelling})` : ` | Target: ${label}`;
    setAlert(describePromptProfileId(state.settings.promptProfileId) + targetSuffix);
  }


  function syncFretKeypadAvailability(): void {
    const pad = doc.getElementById("keypad");
    if (!pad) return;

    // Disable keys outside the current playable domain range.
    // Note: the 24-key UI is always present, but keys outside [minFret..maxFret] are disabled.
    const minAllowed = state ? state.settings.domain.minFret : 0;
    const maxAllowed = state ? Math.min(24, state.settings.domain.maxFret) : 24;

    const keys = pad.querySelectorAll<HTMLButtonElement>("button.key");
    keys.forEach((b) => {
      const f = Number(b.dataset.fret);
      // Open string (0) remains available even when the focused fret range starts at 1.
      const disabled = !Number.isFinite(f) || (f !== 0 && (f < minAllowed || f > maxAllowed)) || (f === 0 && maxAllowed < 0);
      b.disabled = disabled;
      b.classList.toggle("disabled", disabled);
    });
  }

function applySurfaceVisibility(): void {
    // Surface participation is controlled by explicit surface/notation settings.
    // Keep sections in-layout to avoid reflow; hide only when the surface is toggled off.
    const surfaces = ((state?.settings as any)?.surfaces ?? { fretboard: true, rail: true, staff: true, tab: true }) as any;

    const staffSection = doc.getElementById("svgStage")?.closest(".section") as HTMLElement | null;
    if (staffSection) {
      const showStaffTab = !!surfaces.staff || !!surfaces.tab;
      staffSection.hidden = !showStaffTab;
    }

    const railSection = doc.getElementById("noteStrip")?.closest(".section") as HTMLElement | null;
    if (railSection) railSection.hidden = !surfaces.rail;

    const fretSection = doc.getElementById("fretStage")?.closest(".section") as HTMLElement | null;
    if (fretSection) fretSection.hidden = !surfaces.fretboard;

    // Crop Staff/Tab viewBox based on notation view preference (display control).
    const notationView = (state?.settings?.notation?.view ?? "staffTab") as string;
    applyStaffTabCrop(notationView);
  }

  function syncNotationOverlayFromScore(): void {
    const layout = staffLayout;
    if (!layout) return;
    if (staffTabMode !== "notation") return;
    const st = staffOverlayStateNotation;
    st.staffMarksByCol.clear();
    st.tabMarksByCol.clear();
    if (!st.ties) st.ties = [];
    else st.ties.length = 0;
    if (!st.tupletsByCol) st.tupletsByCol = new Map();
    else st.tupletsByCol.clear();

    const colsPerMeasure = layout.columnsPerMeasure;
    const mDiv = measureDivisions(notationScore);

    // Treble clef: bottom line is E4. Staff position is diatonic (line/space), not chromatic.
    const bottomLineY = layout.staff.lineYs[layout.staff.lineYs.length - 1] ?? layout.staff.stepCenters[Math.floor(layout.staff.stepCenters.length / 2)] ?? 0;
    let baseYIndex = 0;
    let bestD = Infinity;
    for (let i = 0; i < layout.staff.stepCenters.length; i++) {
      const d = Math.abs(layout.staff.stepCenters[i] - bottomLineY);
      if (d < bestD) {
        bestD = d;
        baseYIndex = i;
      }
    }

    const diatonicIndex = (step: string, octave: number): number => {
      const map: Record<string, number> = { C: 0, D: 1, E: 2, F: 3, G: 4, A: 5, B: 6 };
      const s = (String(step || "C").trim().toUpperCase() || "C")[0];
      const idx = map[s] ?? 0;
      const oct = Number.isFinite(octave as any) ? Math.round(octave as any) : 4;
      return oct * 7 + idx;
    };

    const E4_DIATONIC = diatonicIndex("E", 4);

    const mapPitchToYIndex = (p: NotationPitch): number => {
      const d = diatonicIndex(p.step, p.octave) - E4_DIATONIC;
      const idx = baseYIndex - d;
      return clamp(idx, 0, layout.staff.stepCenters.length - 1);
    };

    const pushStaffMark = (col: number, mark: { yIndex: number; voice?: string; kind?: "note" | "rest" }) => {
      const cur = st.staffMarksByCol.get(col) ?? [];
      cur.push(mark);
      st.staffMarksByCol.set(col, cur);
    };
    const pushTabMark = (col: number, mark: { stringIndex: number; fret: number; voice?: string }) => {
      const cur = st.tabMarksByCol.get(col) ?? [];
      cur.push(mark);
      st.tabMarksByCol.set(col, cur);
    };

    // Tie pairing (minimal): pair tieStart->tieStop by pitch+voice.
    const tieStarts = new Map<string, { col: number; yIndex: number }>();
    const tieKey = (p: NotationPitch, voice?: string) => `${p.step}${p.alter ?? 0}${p.octave}|${voice ?? ""}`;

    for (const meas of notationScore.measures) {
      const mi = meas.index;
      for (const ev of meas.events) {
        const colInMeasure = offsetToColumn(ev.pos.offsetDiv, mDiv, colsPerMeasure);
        const col = mi * colsPerMeasure + colInMeasure;

        if (ev.type === "rest") {
          const yIndex = Math.floor(layout.staff.stepCenters.length / 2);
          pushStaffMark(col, { yIndex, voice: (ev as any).voice, kind: "rest" });
          continue;
        }
        if (ev.type !== "note") continue;
        if (ev.tab) {
          const stringIndex = clamp(Math.round(ev.tab.string - 1), 0, 5);
          pushTabMark(col, { stringIndex, fret: clamp(Math.round(ev.tab.fret), 0, 24), voice: ev.voice });
        }
        const yIndex = Number.isFinite(ev.staffYIndexHint as any)
          ? clamp(Math.round(ev.staffYIndexHint as any), 0, layout.staff.stepCenters.length - 1)
          : mapPitchToYIndex(ev.pitch);

        pushStaffMark(col, { yIndex, voice: ev.voice, kind: "note" });

        if (ev.tuplet?.actual) {
          // Minimal label: show the tuplet number at the first note time.
          if (!st.tupletsByCol.has(col)) st.tupletsByCol.set(col, String(Math.max(2, Math.round(ev.tuplet.actual))));
        }

        // Tie pairing
        const k = tieKey(ev.pitch, ev.voice);
        if (ev.tieStart) {
          tieStarts.set(k, { col, yIndex });
        }
        if (ev.tieStop) {
          const start = tieStarts.get(k);
          if (start) {
            st.ties.push({ from: { col: start.col, yIndex: start.yIndex }, to: { col, yIndex } });
            tieStarts.delete(k);
          }
        }
      }
    }
  }

  function renderAll(): void {
    const shellEl = doc.getElementById("ge-shell");
    const rm = Boolean(state ? ((state.settings as any).reducedMotion ?? false) : ((settings as any).reducedMotion ?? false));
    if (shellEl) shellEl.classList.toggle("reducedMotion", rm);
    // Education mode renders overlays without the game engine state.
    if (!state) {
      if (session !== "edu") return;
      applySurfaceVisibility();
      updateEduSelectedUi();
      updateEduCursorUi();
      renderEduFretMarks();
      syncNotationOverlayFromScore();
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());
      applyEduVisibility();
      return;
    }
    applySurfaceVisibility();
    updatePromptUi();
    updateActivePlayerUi();
    updateLeaderboardUi();
    updateOverlayOwnership();
    syncFretKeypadAvailability();
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());
  }

  function handleEffects(effects: any[]): void {
    const s0 = state;
    if (!s0) return;

    for (const eff of effects) {
      switch (eff.type) {
        case "PROMPT_CHANGED":
          updatePromptUi();
          break;

        case "TURN_STARTED":
          setAlert("Turn started");
          startTurnTimer();
          break;

        case "TURN_ENDED":
          stopTurnTimer();
          // In single-player, keep things flowing.
          if (s0.settings.playType === PlayType.SINGLE) {
            dispatch({ type: "START_TURN" } as Action);
          } else {
            // Multiplayer: respect intermission.
            intermissionHandle = window.setTimeout(() => {
              if (!state || !matchIsRunning) return;
              dispatch({ type: "START_TURN" } as Action);
            }, s0.settings.timers.intermissionMs);
          }
          break;

        case "FEEDBACK_PULSE": {
          // SAM pulse (highlight correct locations)
          if (!s0.settings.feedback.samEnabled) break;

          activePulse = {
            playerId: eff.playerId,
            variantId: eff.variantId,
            durationMs: eff.durationMs ?? s0.settings.feedback.samDurationMs,
            ghost: (eff.ghost ?? null) as any,
            ghosts: (eff.ghosts ?? undefined) as any,
            scoreDelta: (eff.scoreDelta ?? 0) as any,
            includeLabel: (eff.includeLabel ?? false) as any,
          };

          if (samHandle !== null) window.clearTimeout(samHandle);
          samHandle = window.setTimeout(() => {
            activePulse = null;
            renderAll();
          }, activePulse.durationMs);
          break;
        }

        case "ALERT":
          setAlert(String(eff.message ?? ""));
          break;

        case "MATCH_COMPLETE":
          stopTurnTimer();
          matchIsRunning = false;
          
          recordScoresIfNeeded();
          updateHighScoresUi();
          setAlert("Match complete");
          showSplash();
          break;
      }
    }

    renderAll();
  }

  function dispatch(action: Action): void {
    const r = reducer(state, action);
    state = r.state;
    handleEffects(r.effects);
  }

  function beginMatch(sess: "single" | "multi"): void {
    clearTimers();
    matchIsRunning = false;

    session = sess;
    staffTabMode = "game";
    settings = buildSettingsFromUi(doc, session);
    (settings as any).notation = { ...(settings as any).notation, mode: staffTabMode };
    syncDevTabVisibility(!!settings.dev?.enabled);

    // Standard play uses the score card (not the education tools card).
    syncEducationPanels();
    const mp = clamp(multiPlayerCount | 0, 2, PLAYER_COUNT_MULTI);
    players = buildPlayers(session === "single" ? 1 : mp);

    const init = reducer(null, { type: "INIT_MATCH", settings, players } as Action);
    state = init.state;

    // Match timing (used for persistent high scores)
    matchStartedAtMs = 0;
    matchRecorded = false;

    // Apply starting tokens (clamped to the configured token cap).
    const startTokens = clamp(Number((settings as any).startTokens ?? 0), 0, settings.steal.tokenCap);
    if (state && startTokens > 0) {
      for (const p of state.players) p.tokenCount = startTokens;
    }

    updateHighScoresUi(settings);

    rebuildOverlay();
    // Ensure staff/tab handlers are bound to the game overlay state.
    if (staffOverlaySvgEl && staffLayout) {
      detachStaffHandlers?.();
      detachStaffHandlers = attachStaffTabPointerHandlers(staffOverlaySvgEl, staffLayout, activeStaffOverlayState(), (hit: StaffTabHit) => {
        window.dispatchEvent(new CustomEvent("gedu:staffPick", { detail: hit }));
      });
    }
    renderAll();
    handleEffects(init.effects);

    // Canon: match does not auto-start. User must press Start to begin first turn.
    hideSplash();
  }

  function startMatch(): void {
    if (!state) return;
    if (matchIsRunning) return;
    matchIsRunning = true;
    matchStartedAtMs = Date.now();
    setAlert("Running");
    dispatch({ type: "START_TURN" } as Action);
    if (state.phase === "IN_MATCH" || state.phase === "LAST_CHANCE") startTurnTimer();
    renderAll();
  }

  function beginEducation(): void {
    session = "edu";
    staffTabMode = "notation";
    settings = buildSettingsFromUi(doc, session);
    (settings as any).notation = { ...(settings as any).notation, mode: staffTabMode };
    // Instructor session: no scoring, no timers, no turns.
    players = buildPlayers(1);
    state = null;
    matchIsRunning = false;
    stopTurnTimer();
    setAlert("Education Mode");

    // Education mode UI (teaching tools card).
    syncEducationPanels();

    // Ensure staff/tab handlers are bound to the notation overlay state.
    if (staffOverlaySvgEl && staffLayout) {
      detachStaffHandlers?.();
      detachStaffHandlers = attachStaffTabPointerHandlers(staffOverlaySvgEl, staffLayout, activeStaffOverlayState(), (hit: StaffTabHit) => {
        window.dispatchEvent(new CustomEvent("gedu:staffPick", { detail: hit }));
      });
    }

    // Default selection reads from note rail if available; fall back to C.
    updateEduSelectedUi();

    // Reset the education placement cursor at the start of a session.
    eduCursorCol = 0;

    // Clear any previous marks and redraw.
    clearEduMarks("all");
    renderAll();
  }

  function endMatch(): void {
    if (!state) {
      showSplash();
      return;
    }
    clearTimers();
    matchIsRunning = false;
    
    dispatch({ type: "END_MATCH" } as Action);
    recordScoresIfNeeded();
    updateHighScoresUi();
    showSplash();
  }

  function resetGame(): void {
    clearTimers();
    matchIsRunning = false;
    matchStartedAtMs = 0;
    matchRecorded = false;
    state = null;
    rebuildOverlay();
    setAlert("Ready");
    showSplash();
  }

  function onCellClick(stringIndex: number, fretIndex: number): void {
    if (!state) return;
    if (!matchIsRunning) return;
    if (!matchIsRunning) return;
    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;

    const actingPlayer = state.currentPlayer;
    const actingVariantId = state.prompt.variantId;
    const fretCount = state.settings.domain.fretCount;
    const cellIndex = stringIndex * fretCount + fretIndex;

    // Capture ownership across all lanes so we can detect whether the tap/steal
    // resulted in a successful placement (including equivalent spellings).
    const ownBefore = [
      state.board.owner[SlotType.NAT][cellIndex],
      state.board.owner[SlotType.SHR][cellIndex],
      state.board.owner[SlotType.FLT][cellIndex],
    ];

    const slot = fromVariantId(state.prompt.variantId).spelling;
    const owner = state.board.owner[slot][cellIndex];
    const isOtherOwner = owner >= 0 && owner !== state.currentPlayer;
    const action: Action = isOtherOwner ? ({ type: "STEAL_CELL", stringIndex, fretIndex } as any) : ({ type: "TAP_CELL", stringIndex, fretIndex } as any);

    dispatch(action);

    // GEG-055: Mirroring behavior (default placed).
    // When a fretboard claim succeeds, place corresponding marks onto enabled
    // Staff/TAB surfaces (when visible) using the next available subdivision column.
    if (!state) return;
    if (!matchIsRunning) return;
    const mirrorMode = String((state.settings as any).mirrorMode ?? "placed");
    if (mirrorMode !== "off" && staffLayout && staffOverlaySvgEl) {
      const ownAfter = [
        state.board.owner[SlotType.NAT][cellIndex],
        state.board.owner[SlotType.SHR][cellIndex],
        state.board.owner[SlotType.FLT][cellIndex],
      ];
      const placed = ownBefore.some((v, i) => v !== actingPlayer && ownAfter[i] === actingPlayer);

      if (placed) {
        const surfaces = ((state.settings as any).surfaces ?? { staff: true, tab: true }) as any;
        const notationView = (state.settings?.notation?.view ?? "staffTab") as string;
        const staffEnabled = (notationView === "staff" || notationView === "staffTab") && !!surfaces.staff;
        const tabEnabled = (notationView === "tab" || notationView === "staffTab") && !!surfaces.tab;

        const st = activeStaffOverlayState();
        const totalCols = staffLayout.measures.length * staffLayout.columnsPerMeasure;
        const findCol = () => {
          if (totalCols <= 0) return 0;
          for (let i = 0; i < totalCols; i++) {
            const c = (mirrorColNext + i) % totalCols;
            if (!st.staffMarksByCol.has(c) && !st.tabMarksByCol.has(c)) return c;
          }
          return mirrorColNext % totalCols;
        };

        const col = findCol();
        mirrorColNext = (col + 1) % Math.max(1, totalCols);

        if (tabEnabled) {
          st.tabMarksByCol.set(col, [
            {
              stringIndex: Math.max(0, Math.min(5, stringIndex)),
              fret: Math.max(0, Math.min(24, fretIndex)),
            },
          ]);
        }

        if (staffEnabled) {
          const pc = fromVariantId(actingVariantId).pitchClass;
          const steps = staffLayout.staff.stepCenters.length;
          const mid = Math.floor(steps / 2);
          const offset = ((pc + 6) % 12) - 6; // -6..+5
          const yIndex = Math.max(0, Math.min(steps - 1, mid - offset));
          st.staffMarksByCol.set(col, [{ yIndex }]);
        }

        renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, st);
      }
    }
  }

  // Listen to layout events
  window.addEventListener("gedu:splashSelect", (e: any) => {
    const detail = e?.detail as { session: "single" | "multi" | "edu"; playerCount?: number };
    const sess = detail?.session ?? "single";

    // Education begins immediately.
    if (sess === "edu") {
      beginEducation();
      return;
    }

    // Match selection enters READY state (does not auto-start).
    if (sess === "multi") multiPlayerCount = clamp(Number(detail?.playerCount ?? multiPlayerCount), 2, PLAYER_COUNT_MULTI);
    session = sess;
    staffTabMode = "game";
    settings = buildSettingsFromUi(doc, session);
    (settings as any).notation = { ...(settings as any).notation, mode: staffTabMode };
    syncDevTabVisibility(!!settings.dev?.enabled);

    // Prepare UI for selected session but do not create match state yet.
    state = null;
    matchIsRunning = false;
    matchStartedAtMs = 0;
    matchRecorded = false;

    // Standard play uses the score card.
    syncEducationPanels();

    rebuildOverlay();
    setAlert("Ready");
    hideSplash();
    renderAll();
  });

  window.addEventListener("gedu:start", () => {
    if (session === "edu") {
      setAlert("Education Mode");
      renderAll();
      return;
    }

    // Canon: Start is the only way to enter Running. Selecting a session puts the match in Ready.
    if (!state) beginMatch(session === "multi" ? "multi" : "single");
    startMatch();
  });

  window.addEventListener("gedu:stop", () => {
    if (session === "edu") {
      clearEduMarks("all");
      showSplash();
      return;
    }
    endMatch();
  });

  window.addEventListener("gedu:new", () => {
    if (session === "edu") {
      clearEduMarks("all");
      setAlert("Education Mode");
      renderAll();
      return;
    }
    resetGame();
  });

  window.addEventListener("gedu:applyFretRange", () => {
    // Easiest deterministic behavior: restart match with new domain.
    if (!state) return;
    if (!matchIsRunning) return;
    beginMatch(session === "multi" ? "multi" : "single");
  });

  window.addEventListener("gedu:applySettings", () => {
    if (session === "edu") {
      settings = buildSettingsFromUi(doc, session);
      renderAll();
      return;
    }
    if (!state) return;
    if (!matchIsRunning) return;
    beginMatch(session as any);
  });

  // Note rail selection: in dev mode or Learning difficulty, clicking a rail cell sets the current prompt.
  window.addEventListener("gedu:railSelect", (e: any) => {
    const vid = Number(e?.detail?.variantId);
    if (!Number.isFinite(vid)) return;

    // Education mode: the rail selects what will be placed.
    if (session === "edu") {
      eduSelectedVariantId = vid;
      updateEduSelectedUi();
      renderAll();
      return;
    }

    if (!state) return;
    if (!matchIsRunning) return;
    const surfaces = ((state.settings as any).surfaces ?? { rail: true }) as any;
    if (!surfaces.rail) return;
    const allow = !!state.settings.dev?.enabled || state.settings.difficulty === Difficulty.LEARNING;
    if (!allow) return;
    dispatch({ type: "DEV_SET_PROMPT", variantId: vid } as any);
  });

  // GEG-063: Note rail input. Clicking a rail cell can act as a note-guess input surface.
  // We deterministically map the guessed pitch-class to the first enabled fretboard cell
  // in-domain and dispatch a TAP_CELL attempt through the engine.
  window.addEventListener("gedu:railPick", (e: any) => {
    const vid = Number(e?.detail?.variantId);
    if (!Number.isFinite(vid)) return;

    // Education mode: rail clicks are selection-only.
    if (session === "edu") return;
    if (!state) return;
    if (!matchIsRunning) return;

    const surfaces = ((state.settings as any).surfaces ?? { rail: true, fretboard: true }) as any;
    if (!surfaces.rail) return;
    // Rail picks resolve into an actionable placement through the same engine pipeline
    // as other inputs. If the fretboard surface is not in play, there is no placement
    // target to resolve against.
    if (!surfaces.fretboard) {
      setAlert("Fretboard is not in play for this match");
      return;
    }

    // Only meaningful during active play.
    if (state.phase !== "IN_MATCH") return;

    dispatch({ type: "TAP_VARIANT", variantId: vid } as any);
  });
  // 25-key fret selector (instant): on fret pick, claim if a TAB string is selected (or vice versa).
  window.addEventListener("gedu:fretPick", (e: any) => {
    const raw = Number(e?.detail?.fret);
    if (!Number.isFinite(raw)) return;

    // GEG-053: accept ONLY frets 0..24. Reject 25+ (and negatives) rather than clamping.
    const rawInt = Math.floor(raw);
    if (rawInt < 0 || rawInt > 24) {
      setAlert(`Invalid fret: ${raw}`);
      return;
    }

    // Store the last chosen fret even if a match hasn't started yet.
    tabSelectedFret = rawInt;
    // Keep the TAB overlay's default rendered number in sync with the last chosen fret.
    staffOverlayStateGame.tabDefaultNumber = tabSelectedFret;
    staffOverlayStateNotation.tabDefaultNumber = tabSelectedFret;

    if (!state) return;
    if (!matchIsRunning) return;
    const surfaces = ((state.settings as any).surfaces ?? { tab: true }) as any;
    if (!surfaces.tab) {
      setAlert("TAB input is disabled by surface settings");
      return;
    }

    const notationView = (state.settings?.notation?.view ?? "staffTab") as string;
    const tabEnabled = notationView === "tab" || notationView === "staffTab";
    if (!tabEnabled) {
      setAlert("TAB is currently hidden by Notation View");
      return;
    }

    // Open string (0) is always permitted for TAB entry even if the focused range starts at 1.
    const minAllowed = 0;
    const maxAllowed = Math.min(24, state.settings.domain.maxFret);
    const clampedFret = clamp(tabSelectedFret, minAllowed, maxAllowed);
    tabSelectedFret = clampedFret;
    staffOverlayStateGame.tabDefaultNumber = clampedFret;
    staffOverlayStateNotation.tabDefaultNumber = clampedFret;

    if (tabSelectedString === null) {
      setAlert(`TAB: fret ${clampedFret} selected (pick string)`);
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());
      return;
    }

    onCellClick(tabSelectedString, clampedFret);
  });


  // STAFF/TAB surface pick events (string selection for TAB entry)
  window.addEventListener("gedu:staffPick", (e: any) => {
    const region = String(e?.detail?.region ?? "");
    const col = Number(e?.detail?.col);
    const y = Number(e?.detail?.yIndex);
    if (!Number.isFinite(col) || !Number.isFinite(y)) return;

    // Education mode: place/erase simple markers on staff or tab.
    if (session === "edu") {
      const st = activeStaffOverlayState();

      const colsPerMeasure = staffLayout?.columnsPerMeasure ?? 16;
      const totalCols = staffLayout ? staffLayout.measures.length * colsPerMeasure : 3 * colsPerMeasure;

      const setCursorFromCol = (colGlobal: number) => {
        const mDiv = measureDivisions(notationScore);
        const colInMeasure = ((colGlobal % colsPerMeasure) + colsPerMeasure) % colsPerMeasure;
        const mi = Math.max(0, Math.floor(colGlobal / colsPerMeasure));
        const off = columnToOffset(colInMeasure, mDiv, colsPerMeasure);
        eduNotationCursor = { ...eduNotationCursor, measureIndex: mi, offsetDiv: off };
        eduCursorCol = mi * colsPerMeasure + colInMeasure;
        updateEduCursorUi();
      };

      const syncCursorToCol = () => {
        const mDiv = measureDivisions(notationScore);
        const colInMeasure = offsetToColumn(eduNotationCursor.offsetDiv, mDiv, colsPerMeasure);
        eduCursorCol = eduNotationCursor.measureIndex * colsPerMeasure + colInMeasure;
      };

      const moveCursorByDiv = (deltaDiv: number) => {
        const d = Math.max(1, Math.round(deltaDiv));
        const mDiv = measureDivisions(notationScore);
        let mi = Math.max(0, Math.round(eduNotationCursor.measureIndex));
        let off = Math.max(0, Math.round(eduNotationCursor.offsetDiv)) + d;
        while (off >= mDiv) {
          off -= mDiv;
          mi += 1;
        }
        eduNotationCursor = { ...eduNotationCursor, measureIndex: mi, offsetDiv: off };
        syncCursorToCol();
        updateEduCursorUi();
      };

      const pitchFromStaffYIndex = (yIndex: number): NotationPitch => {
        // Treble clef baseline: bottom line is E4 (diatonic).
        const map: Array<NotationPitch["step"]> = ["C", "D", "E", "F", "G", "A", "B"];
        const idx = clamp(Math.round(yIndex), 0, (staffLayout?.staff.stepCenters.length ?? 1) - 1);
        // Approximate: each yIndex step is one diatonic step.
        // Use E4 as anchor at the closest index to the bottom line.
        const layout = staffLayout;
        const bottomLineY = layout?.staff.lineYs[layout.staff.lineYs.length - 1] ?? (layout?.staff.stepCenters[Math.floor(layout.staff.stepCenters.length / 2)] ?? 0);
        let baseYIndex = 0;
        if (layout) {
          let bestD = Infinity;
          for (let i = 0; i < layout.staff.stepCenters.length; i++) {
            const d = Math.abs(layout.staff.stepCenters[i] - bottomLineY);
            if (d < bestD) {
              bestD = d;
              baseYIndex = i;
            }
          }
        }

        const diatonicE4 = 4 * 7 + 2; // E=2 in [C..B]
        const dSteps = baseYIndex - idx;
        const diatonic = diatonicE4 + dSteps;
        const octave = Math.floor(diatonic / 7);
        const step = map[((diatonic % 7) + 7) % 7] ?? "C";
        return { step, alter: 0, octave };
      };

      const pitchFromTab = (stringIndex: number, fret: number): NotationPitch => {
        // Prefer imported tuning if present; else standard guitar tuning.
        const std = [64, 59, 55, 50, 45, 40];
        const tuning = notationScore.tuningMidiByString;
        const sNum = clamp(stringIndex, 0, 5) + 1;
        const baseMidi = (tuning && Number.isFinite(tuning[sNum] as any) ? tuning[sNum] : std[clamp(stringIndex, 0, 5)]) ?? 64;
        const midi = baseMidi + clamp(fret, 0, 24);
        const pc = ((midi % 12) + 12) % 12;
        const octave = Math.floor(midi / 12) - 1;
        // Prefer sharps for now; rendering/round-trip improvements can refine spelling later.
        const map: Array<{ step: NotationPitch["step"]; alter: number }> = [
          { step: "C", alter: 0 },
          { step: "C", alter: 1 },
          { step: "D", alter: 0 },
          { step: "D", alter: 1 },
          { step: "E", alter: 0 },
          { step: "F", alter: 0 },
          { step: "F", alter: 1 },
          { step: "G", alter: 0 },
          { step: "G", alter: 1 },
          { step: "A", alter: 0 },
          { step: "A", alter: 1 },
          { step: "B", alter: 0 },
        ];
        const s = map[pc] ?? { step: "C", alter: 0 };
        return { step: s.step, alter: s.alter, octave };
      };

      const collectExistingAtCursor = (): NotationEvent[] => {
        const m = notationScore.measures[eduNotationCursor.measureIndex];
        if (!m) return [];
        const off = eduNotationCursor.offsetDiv;
        const v = eduNotationCursor.voice;
        return m.events.filter((ev) => ev.pos.offsetDiv === off && ((ev as any).voice ?? "1") === v);
      };

      const overwriteAtCursor = () => {
        const m = notationScore.measures[eduNotationCursor.measureIndex];
        if (!m) return;
        const off = eduNotationCursor.offsetDiv;
        const v = eduNotationCursor.voice;
        m.events = m.events.filter((ev) => !(ev.pos.offsetDiv === off && ((ev as any).voice ?? "1") === v));
      };

      const insertAtCursor = (shiftDiv: number) => {
        const mDiv = measureDivisions(notationScore);
        const startAbs = eduNotationCursor.measureIndex * mDiv + eduNotationCursor.offsetDiv;
        const v = eduNotationCursor.voice;

        const affected: Array<{ ev: NotationEvent; abs: number }> = [];
        for (const meas of notationScore.measures) {
          for (const ev of meas.events) {
            const voice = (ev as any).voice ?? "1";
            if (voice !== v) continue;
            const abs = meas.index * mDiv + ev.pos.offsetDiv;
            if (abs >= startAbs) affected.push({ ev, abs });
          }
        }
        if (affected.length === 0) return;

        // Remove originals
        for (const { ev } of affected) {
          const mi = ev.pos.measureIndex;
          const m = notationScore.measures[mi];
          if (!m) continue;
          m.events = m.events.filter((x) => x.id !== ev.id);
        }

        // Reinsert shifted
        for (const { ev, abs } of affected) {
          const newAbs = abs + Math.max(1, Math.round(shiftDiv));
          const newMi = Math.floor(newAbs / mDiv);
          const newOff = newAbs - newMi * mDiv;
          ev.pos.measureIndex = newMi;
          ev.pos.offsetDiv = newOff;
          const m = ensureMeasure(notationScore, newMi);
          m.events.push(ev);
          m.events.sort((a, b) => a.pos.offsetDiv - b.pos.offsetDiv);
        }
      };

      const applyEditModeAtCursor = () => {
        if (eduEditMode === "overwrite") overwriteAtCursor();
        else insertAtCursor(eduNoteDurDiv);
      };

      const placeRestAtCursor = (staffYIndexHint?: number) => {
        if (staffTabMode !== "notation") return;
        applyEditModeAtCursor();
        addRestEvent(
          notationScore,
          { measureIndex: eduNotationCursor.measureIndex, offsetDiv: eduNotationCursor.offsetDiv },
          { divisions: Math.max(1, eduNoteDurDiv) },
        );
        // Provide a stable visual position for rests.
        const hint = Number.isFinite(staffYIndexHint as any)
          ? clamp(Math.round(staffYIndexHint as any), 0, (staffLayout?.staff.stepCenters.length ?? 1) - 1)
          : Math.floor((staffLayout?.staff.stepCenters.length ?? 12) / 2);
        const colGlobal = eduCursorCol;
        const arr = st.staffMarksByCol.get(colGlobal) ?? [];
        arr.push({ yIndex: hint, voice: eduNotationCursor.voice, kind: "rest" });
        st.staffMarksByCol.set(colGlobal, arr);
      };

      const placeNoteAtCursor = (pitch: NotationPitch, staffYIndexHint?: number, tab?: NotationTab) => {
        if (staffTabMode !== "notation") return;
        applyEditModeAtCursor();
        addNoteEvent(
          notationScore,
          { measureIndex: eduNotationCursor.measureIndex, offsetDiv: eduNotationCursor.offsetDiv },
          { divisions: Math.max(1, eduNoteDurDiv) },
          pitch,
          tab,
          staffYIndexHint,
          { voice: eduNotationCursor.voice, staff: eduNotationCursor.staff },
        );
      };

      const eraseAtCol = (colGlobal: number) => {
        if (staffTabMode !== "notation") return;
        setCursorFromCol(colGlobal);
        overwriteAtCursor();
      };

      // Cursor snaps to the clicked subdivision.
      setCursorFromCol(col);

      if (staffTabMode === "notation") {
        if (eduTool === "erase") {
          eraseAtCol(col);
        } else if (eduTool === "rest") {
          placeRestAtCursor(y);
          moveCursorByDiv(eduNoteDurDiv);
        } else {
          if (region === "staff") {
            const existing = collectExistingAtCursor().find((ev) => ev.type === "note") as any;
            const prevTab: NotationTab | undefined = !eduRefingerOnPitchEdits ? existing?.tab : undefined;
            const pitch = pitchFromStaffYIndex(y);
            placeNoteAtCursor(pitch, y, prevTab);
            moveCursorByDiv(eduNoteDurDiv);
          }
          if (region === "tab") {
            const fret = clamp(Number(tabSelectedFret ?? st.tabDefaultNumber ?? 0), 0, 24);
            const stringIndex = clamp(y, 0, 5);
            const pitch = pitchFromTab(stringIndex, fret);
            // When editing TAB, TAB is authoritative.
            placeNoteAtCursor(pitch, undefined, { string: stringIndex + 1, fret });
            moveCursorByDiv(eduNoteDurDiv);
          }
        }

        // Rebuild notation overlay from the time-aware score for fidelity.
        syncNotationOverlayFromScore();
        updateEduCursorUi();
        if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayStateNotation);
        applyEduVisibility();
        return;
      }

      // Game mode (education): simple column markers.
      eduCursorCol = col;
      const advanceGameCursor = () => {
        eduCursorCol = (eduCursorCol + Math.max(1, eduNoteStepCols)) % Math.max(1, totalCols);
      };

      if (region === "staff") {
        if (eduTool === "erase") st.staffMarksByCol.delete(col);
        else {
          const cur = st.staffMarksByCol.get(col) ?? [];
          cur.push({ yIndex: y, voice: "1", kind: "note" });
          st.staffMarksByCol.set(col, cur);
          advanceGameCursor();
        }
      }
      if (region === "tab") {
        if (eduTool === "erase") st.tabMarksByCol.delete(col);
        else {
          const fret = clamp(Number(tabSelectedFret ?? st.tabDefaultNumber ?? 0), 0, 24);
          const stringIndex = clamp(y, 0, 5);
          const cur = st.tabMarksByCol.get(col) ?? [];
          cur.push({ stringIndex, fret, voice: "1" });
          st.tabMarksByCol.set(col, cur);
          advanceGameCursor();
        }
      }

      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, st);
      applyEduVisibility();
      return;
    }

    if (!state) return;
    if (!matchIsRunning) return;
    const surfaces = ((state.settings as any).surfaces ?? { staff: true, tab: true }) as any;
    if (region === "staff" && !surfaces.staff) {
      setAlert("STAFF input is disabled by surface settings");
      return;
    }
    if (region === "tab" && !surfaces.tab) {
      setAlert("TAB input is disabled by surface settings");
      return;
    }
    if (region !== "tab") return;

    const notationView = (state.settings?.notation?.view ?? "staffTab") as string;
    const tabEnabled = notationView === "tab" || notationView === "staffTab";
    if (!tabEnabled) return;

    tabSelectedString = Math.max(0, Math.min(5, y));

    // If a fret is already selected, claim immediately.
    if (tabSelectedFret !== null) {
      // Open string (0) is always permitted for TAB entry even if the focused range starts at 1.
      const minAllowed = 0;
      const maxAllowed = Math.min(24, state.settings.domain.maxFret);
      const clampedFret = clamp(tabSelectedFret, minAllowed, maxAllowed);
      tabSelectedFret = clampedFret;
      onCellClick(tabSelectedString, clampedFret);
      return;
    }

    setAlert(`TAB: string ${tabSelectedString + 1} selected (pick fret)`);
  });

  // Dev/Test UI wiring
  // Education (Teach) UI wiring
  const eduToolInput = doc.querySelector<HTMLInputElement>("#edu-tool-input");
  const eduToolErase = doc.querySelector<HTMLInputElement>("#edu-tool-erase");
  const eduToolRest = doc.querySelector<HTMLInputElement>("#edu-tool-rest");
  const eduNoteValueRadios = Array.from(doc.querySelectorAll<HTMLInputElement>("input[name='eduNoteValue']"));
  const eduEditModeRadios = Array.from(doc.querySelectorAll<HTMLInputElement>("input[name='eduEditMode']"));
  const eduRefingerChk = doc.querySelector<HTMLInputElement>("#edu-edit-refinger");
  const eduCursorReadout = doc.querySelector<HTMLDivElement>("#edu-cursor");
  const btnEduCursorLeft = doc.querySelector<HTMLButtonElement>("#edu-cursor-left");
  const btnEduCursorRight = doc.querySelector<HTMLButtonElement>("#edu-cursor-right");
  const btnEduCursorPrevMeasure = doc.querySelector<HTMLButtonElement>("#edu-cursor-prev-measure");
  const btnEduCursorNextMeasure = doc.querySelector<HTMLButtonElement>("#edu-cursor-next-measure");
  const eduStaffTabModeRadios = Array.from(doc.querySelectorAll<HTMLInputElement>("input[name='eduStaffTabMode']"));
  // Education marker visibility is a presentation preference (not a Utility toggle).
  const eduShowStaffChk = doc.querySelector<HTMLInputElement>("#pref-edu-show-staff");
  const eduShowTabChk = doc.querySelector<HTMLInputElement>("#pref-edu-show-tab");
  const eduShowFretChk = doc.querySelector<HTMLInputElement>("#pref-edu-show-fret");
  const btnEduClearAll = doc.querySelector<HTMLButtonElement>("#edu-clear-all");
  const btnEduClearStaff = doc.querySelector<HTMLButtonElement>("#edu-clear-staff");
  const btnEduClearTab = doc.querySelector<HTMLButtonElement>("#edu-clear-tab");
  const btnEduClearFret = doc.querySelector<HTMLButtonElement>("#edu-clear-fret");

  // Import/Export (Education)
  const eduImportFile = doc.querySelector<HTMLInputElement>("#edu-import-musicxml-file");
  const eduImportText = doc.querySelector<HTMLTextAreaElement>("#edu-import-musicxml-text");
  const btnEduImportMusicXml = doc.querySelector<HTMLButtonElement>("#edu-import-musicxml-btn");
  const btnEduExportInternal = doc.querySelector<HTMLButtonElement>("#edu-export-internal-btn");
  const eduImportStatus = doc.querySelector<HTMLDivElement>("#edu-import-status");
  const eduImportRequireTab = doc.querySelector<HTMLInputElement>("#edu-import-requireTab");
  const eduImportStrictTiming = doc.querySelector<HTMLInputElement>("#edu-import-strictTiming");
  const eduImportSummaryBody = doc.querySelector<HTMLDivElement>("#edu-import-summary-body");
  const eduImportWarningsList = doc.querySelector<HTMLUListElement>("#edu-import-warnings");

  const setEduImportStatus = (text: string) => {
    if (eduImportStatus) eduImportStatus.textContent = text || "";
  };

  const summarizeImportForPanel = (r: any): string => {
    if (!r) return "";
    if (r.status === "error") return r.warnings?.[0]?.message || "Import failed.";
    const base = `OK: ${r.stats?.measures ?? 0} measures, ${r.stats?.notes ?? 0} notes, ${r.stats?.rests ?? 0} rests`;
    const tab = (r.stats?.notesWithTab ?? 0) ? `; TAB on ${r.stats.notesWithTab} notes` : "; TAB not preserved";
    const warn = (r.warnings?.length ?? 0) ? `; warnings: ${r.warnings.length}` : "";
    return base + tab + warn;
  };

  const renderImportSummary = (r: any) => {
    if (eduImportSummaryBody) {
      if (!r) {
        eduImportSummaryBody.textContent = "No import yet.";
      } else if (r.status === "error") {
        eduImportSummaryBody.textContent = `Failed. ${r.warnings?.[0]?.message ?? ""}`.trim();
      } else {
        const s = r.stats || {};
        const tab = (s.notesWithTab ?? 0) ? `TAB preserved on ${s.notesWithTab} notes.` : "TAB not preserved.";
        const extras: string[] = [];
        if ((s.chordNotes ?? 0) > 0) extras.push(`Chord notes: ${s.chordNotes}`);
        if ((s.tiedNotes ?? 0) > 0) extras.push(`Tied notes: ${s.tiedNotes}`);
        if ((s.tupletNotes ?? 0) > 0) extras.push(`Tuplet notes: ${s.tupletNotes}`);
        if ((s.voicedNotes ?? 0) > 0) extras.push(`Voice-tagged notes: ${s.voicedNotes}`);
        const extraText = extras.length ? ` (${extras.join(", ")})` : "";
        eduImportSummaryBody.textContent = `Status: ${r.status}. Measures: ${s.measures ?? 0}. Notes: ${s.notes ?? 0}. Rests: ${s.rests ?? 0}. ${tab}${extraText}`;
      }
    }
    if (eduImportWarningsList) {
      eduImportWarningsList.innerHTML = "";
      const warns: any[] = Array.isArray(r?.warnings) ? r.warnings : [];
      for (const w of warns) {
        const li = document.createElement("li");
        const code = String(w?.code ?? "").trim();
        const msg = String(w?.message ?? "").trim();
        li.textContent = code ? `${code}: ${msg}` : msg;
        eduImportWarningsList.appendChild(li);
      }
      if (!warns.length) {
        const li = document.createElement("li");
        li.textContent = "(none)";
        eduImportWarningsList.appendChild(li);
      }
    }
  };

  const syncEduControlsToState = () => {
    if (eduToolInput) eduToolInput.checked = eduTool === "input";
    if (eduToolErase) eduToolErase.checked = eduTool === "erase";
    if (eduToolRest) eduToolRest.checked = eduTool === "rest";
    for (const r of eduEditModeRadios) {
      if (!r) continue;
      r.checked = String(r.value || "overwrite") === eduEditMode;
      // Edit mode is meaningful in notation mode only.
      r.disabled = session === "edu" && staffTabMode !== "notation";
    }
    if (eduRefingerChk) {
      eduRefingerChk.checked = !!eduRefingerOnPitchEdits;
      eduRefingerChk.disabled = session === "edu" && staffTabMode !== "notation";
    }
    if (eduShowStaffChk) eduShowStaffChk.checked = eduShowStaff;
    if (eduShowTabChk) eduShowTabChk.checked = eduShowTab;
    if (eduShowFretChk) eduShowFretChk.checked = eduShowFret;
    // Sync note value radios
    for (const r of eduNoteValueRadios) {
      if (!r) continue;
      const v = String(r.value || "");
      const step = v === "whole" ? 16 : v === "half" ? 8 : v === "quarter" ? 4 : v === "eighth" ? 2 : v === "sixteenth" ? 1 : 4;
      r.checked = step === eduNoteStepCols;
      // Note values are only meaningful in notation mode.
      r.disabled = session === "edu" && staffTabMode !== "notation";
    }
    // Sync staff/tab operational mode
    for (const r of eduStaffTabModeRadios) {
      if (!r) continue;
      r.checked = String(r.value || "") === staffTabMode;
    }
    updateEduSelectedUi();
    updateEduCursorUi();
    applyEduVisibility();
  };

  eduToolInput?.addEventListener("change", () => {
    if (eduToolInput.checked) eduTool = "input";
    if (session === "edu") renderAll();
  });
  eduToolErase?.addEventListener("change", () => {
    if (eduToolErase.checked) eduTool = "erase";
    if (session === "edu") renderAll();
  });

  eduToolRest?.addEventListener("change", () => {
    if (eduToolRest.checked) eduTool = "rest";
    if (session === "edu") renderAll();
  });

  for (const r of eduEditModeRadios) {
    r.addEventListener("change", () => {
      if (!r.checked) return;
      eduEditMode = (String(r.value || "overwrite") === "insert" ? "insert" : "overwrite");
      if (session === "edu") renderAll();
    });
  }
  eduRefingerChk?.addEventListener("change", () => {
    eduRefingerOnPitchEdits = !!eduRefingerChk.checked;
  });

  // Cursor buttons (Education/Notation)
  const moveCursorAbs = (measureIndex: number, offsetDiv: number) => {
    const mDiv = measureDivisions(notationScore);
    let mi = Math.max(0, Math.round(measureIndex));
    let off = Math.max(0, Math.round(offsetDiv));
    while (off < 0) {
      if (mi === 0) {
        off = 0;
        break;
      }
      mi -= 1;
      off += mDiv;
    }
    while (off >= mDiv) {
      off -= mDiv;
      mi += 1;
    }
    eduNotationCursor = { ...eduNotationCursor, measureIndex: mi, offsetDiv: off };
    updateEduCursorUi();
    if (session === "edu" && staffTabMode === "notation") {
      const colInMeasure = offsetToColumn(off, mDiv, staffLayout?.columnsPerMeasure ?? 16);
      eduCursorCol = mi * (staffLayout?.columnsPerMeasure ?? 16) + colInMeasure;
    }
    if (session === "edu") renderAll();
  };

  btnEduCursorLeft?.addEventListener("click", () => {
    if (session !== "edu" || staffTabMode !== "notation") return;
    moveCursorAbs(eduNotationCursor.measureIndex, eduNotationCursor.offsetDiv - Math.max(1, eduNoteDurDiv));
  });
  btnEduCursorRight?.addEventListener("click", () => {
    if (session !== "edu" || staffTabMode !== "notation") return;
    moveCursorAbs(eduNotationCursor.measureIndex, eduNotationCursor.offsetDiv + Math.max(1, eduNoteDurDiv));
  });
  btnEduCursorPrevMeasure?.addEventListener("click", () => {
    if (session !== "edu" || staffTabMode !== "notation") return;
    const mDiv = measureDivisions(notationScore);
    moveCursorAbs(Math.max(0, eduNotationCursor.measureIndex - 1), eduNotationCursor.offsetDiv);
  });
  btnEduCursorNextMeasure?.addEventListener("click", () => {
    if (session !== "edu" || staffTabMode !== "notation") return;
    moveCursorAbs(eduNotationCursor.measureIndex + 1, eduNotationCursor.offsetDiv);
  });

  for (const r of eduNoteValueRadios) {
    r.addEventListener("change", () => {
      if (!r.checked) return;
      const v = String(r.value || "");
      eduNoteStepCols = v === "whole" ? 16 : v === "half" ? 8 : v === "quarter" ? 4 : v === "eighth" ? 2 : v === "sixteenth" ? 1 : 4;
      const q = Math.max(1, Math.round(notationScore.divisionsPerQuarter || 480));
      eduNoteDurDiv = v === "whole" ? 4 * q : v === "half" ? 2 * q : v === "quarter" ? q : v === "eighth" ? Math.round(q / 2) : v === "sixteenth" ? Math.round(q / 4) : q;
      if (session === "edu") renderAll();
    });
  }

  for (const r of eduStaffTabModeRadios) {
    r.addEventListener("change", () => {
      if (!r.checked) return;
      const next = (String(r.value || "notation") === "game" ? "game" : "notation") as StaffTabMode;
      if (staffTabMode === next) return;
      staffTabMode = next;
      // Persist into settings so future import/conversion logic can key off it.
      (settings as any).notation = { ...(settings as any).notation, mode: staffTabMode };
      if (state) (state.settings as any).notation = { ...(state.settings as any).notation, mode: staffTabMode };

      // Rebind staff/tab pointer handlers to point at the active overlay state.
      if (staffOverlaySvgEl && staffLayout) {
        detachStaffHandlers?.();
        detachStaffHandlers = attachStaffTabPointerHandlers(staffOverlaySvgEl, staffLayout, activeStaffOverlayState(), (hit: StaffTabHit) => {
          window.dispatchEvent(new CustomEvent("gedu:staffPick", { detail: hit }));
        });
        renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());
      }
      syncEduControlsToState();
      if (session === "edu") renderAll();
    });
  }

  eduShowStaffChk?.addEventListener("change", () => { eduShowStaff = !!eduShowStaffChk.checked; applyEduVisibility(); });
  eduShowTabChk?.addEventListener("change", () => { eduShowTab = !!eduShowTabChk.checked; applyEduVisibility(); });
  eduShowFretChk?.addEventListener("change", () => { eduShowFret = !!eduShowFretChk.checked; applyEduVisibility(); });

  const readFileAsText = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onerror = () => reject(new Error("Failed to read file"));
      fr.onload = () => resolve(String(fr.result || ""));
      fr.readAsText(file);
    });

  btnEduImportMusicXml?.addEventListener("click", async () => {
    try {
      const policy = {
        requireTabTechnical: !!eduImportRequireTab?.checked,
        strictTiming: !!eduImportStrictTiming?.checked,
      };
      const pasted = String(eduImportText?.value || "").trim();
      if (pasted) {
        const r = (window as any).geduImportMusicXML?.(pasted, policy);
        setEduImportStatus(summarizeImportForPanel(r));
        renderImportSummary(r);
        return;
      }
      const f = eduImportFile?.files?.[0];
      if (!f) {
        setEduImportStatus("Provide a MusicXML file or paste XML into the box.");
        return;
      }
      const text = await readFileAsText(f);
      const r = (window as any).geduImportMusicXML?.(text, policy);
      setEduImportStatus(summarizeImportForPanel(r));
      renderImportSummary(r);
    } catch (err: any) {
      setEduImportStatus(`Import failed: ${String(err?.message || err)}`);
    }
  });

  btnEduExportInternal?.addEventListener("click", async () => {
    try {
      const json = String((window as any).geduExportInternalScore?.() || "");
      if (!json) {
        setEduImportStatus("Nothing to export.");
        return;
      }
      await navigator.clipboard.writeText(json);
      setEduImportStatus("Internal score JSON copied to clipboard.");
    } catch (err: any) {
      setEduImportStatus(`Copy failed: ${String(err?.message || err)}`);
    }
  });
  btnEduClearAll?.addEventListener("click", () => clearEduMarks("all"));
  btnEduClearStaff?.addEventListener("click", () => clearEduMarks("staff"));
  btnEduClearTab?.addEventListener("click", () => clearEduMarks("tab"));
  btnEduClearFret?.addEventListener("click", () => clearEduMarks("fret"));
  syncEduControlsToState();

  const devModeToggle = doc.querySelector<HTMLInputElement>("#core-devMode");
  devModeToggle?.addEventListener("change", () => {
    syncDevTabVisibility(!!devModeToggle.checked);
  });
  syncDevTabVisibility(!!devModeToggle?.checked);

  const btnDevPrev = doc.querySelector<HTMLButtonElement>("#dev-prevPlayer");
  const btnDevNext = doc.querySelector<HTMLButtonElement>("#dev-nextPlayer");
  const btnDevEndTurn = doc.querySelector<HTMLButtonElement>("#dev-endTurn");
  const btnDevClearBoard = doc.querySelector<HTMLButtonElement>("#dev-clearBoard");
  const btnDevPhaseInMatch = doc.querySelector<HTMLButtonElement>("#dev-forceInMatch");
  const btnDevPhaseIntermission = doc.querySelector<HTMLButtonElement>("#dev-forceIntermission");
  const btnDevPhaseLastChance = doc.querySelector<HTMLButtonElement>("#dev-forceLastChance");
  const btnDevPhaseResults = doc.querySelector<HTMLButtonElement>("#dev-forceResults");

  const devPaintEnabled = doc.querySelector<HTMLInputElement>("#dev-paintEnabled");
  const devPaintPlayer = doc.querySelector<HTMLSelectElement>("#dev-paintPlayer");
  const devPaintLane = doc.querySelector<HTMLSelectElement>("#dev-paintLane");
  const devPaintMode = doc.querySelector<HTMLSelectElement>("#dev-paintMode");

  const dispatchAndRender = (action: Action) => {
    if (!state) return;
    if (!matchIsRunning) return;
    dispatch(action);
    renderAll();
  };

  btnDevPrev?.addEventListener("click", () => {
    if (!state) return;
    if (!matchIsRunning) return;
    const n = state.players.length;
    const next = (state.currentPlayer - 1 + n) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });
  btnDevNext?.addEventListener("click", () => {
    if (!state) return;
    if (!matchIsRunning) return;
    const n = state.players.length;
    const next = (state.currentPlayer + 1) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });

  // Dev "End Turn" behavior:
  // Option A (selected): simulate the end of a turn by triggering the same pipeline as a natural timeout/miss.
  // This validates the real scoring/token/sequence logic.
  btnDevEndTurn?.addEventListener("click", () => dispatchAndRender({ type: "TIMEOUT" } as Action));

  btnDevClearBoard?.addEventListener("click", () => dispatchAndRender({ type: "DEV_CLEAR_BOARD" } as Action));

  const forcePhase = (phase: Phase) => dispatchAndRender({ type: "DEV_FORCE_PHASE", phase } as Action);
  btnDevPhaseInMatch?.addEventListener("click", () => forcePhase("IN_MATCH"));
  btnDevPhaseIntermission?.addEventListener("click", () => forcePhase("INTERMISSION"));
  btnDevPhaseLastChance?.addEventListener("click", () => forcePhase("LAST_CHANCE"));
  btnDevPhaseResults?.addEventListener("click", () => forcePhase("RESULTS"));

  const syncPaintControlsToState = () => {
    if (!state) return;
    if (!matchIsRunning) return;
    const patch: Partial<DevSettings> = {
      paintEnabled: !!devPaintEnabled?.checked,
      paintPlayerIndex: clamp(Number(devPaintPlayer?.value ?? 0), 0, Math.max(0, state.players.length - 1)),
      paintLane: (devPaintLane?.value as any) ?? "prompt",
      paintMode: (devPaintMode?.value as any) ?? "paint",
    };
    dispatchAndRender({ type: "DEV_SET_PAINT", patch } as Action);
  };

  devPaintEnabled?.addEventListener("change", syncPaintControlsToState);
  devPaintPlayer?.addEventListener("change", syncPaintControlsToState);
  devPaintLane?.addEventListener("change", syncPaintControlsToState);
  devPaintMode?.addEventListener("change", syncPaintControlsToState);


  // Live settings sync: when dropdowns/toggles change, update *visual* surfaces immediately
  // (notation view, note visibility, display labels, etc. take effect without requiring a restart).
  doc.addEventListener("change", (ev) => {
    const target = ev.target as HTMLElement | null;
    if (!target) return;
    const ds = (target as any).dataset as { setting?: string } | undefined;
    if (!ds?.setting) return;

    const next = buildSettingsFromUi(doc, session) as any;

    // Allow preview even before the first match is started.
    if (!state) {
      applySurfaceVisibility();
      return;
    }

    const cur = state.settings as any;
    cur.noteVisibility = next.noteVisibility;
    cur.displayMode = next.displayMode;
    cur.tritoneLabelMode = next.tritoneLabelMode;
    cur.rootNote = next.rootNote;
    cur.modeId = next.modeId;
    cur.chordKind = next.chordKind;
    cur.highlight = next.highlight;
    cur.notation = next.notation;
    cur.surfaces = next.surfaces;
    cur.mirrorMode = next.mirrorMode;

    applySurfaceVisibility();
    updatePromptUi();

    if (staffOverlaySvgEl && staffLayout) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());
    syncFretKeypadAvailability();
  });

  // ----------------------------------------
  // Notation import/export hooks (Education)
  // ----------------------------------------
  const applyNotationScore = (nextScore: any) => {
    try {
      notationScore = nextScore;
      // Ensure sane defaults.
      if (!notationScore || notationScore.version !== 1) notationScore = createEmptyScore();
      eduNotationCursor = { measureIndex: 0, offsetDiv: 0, voice: "1", staff: 1 };
      updateEduCursorUi();
      eduNoteDurDiv = Math.max(1, Math.round(notationScore.divisionsPerQuarter || 480));
      // Auto-switch into notation mode for Education if we are in session.
      if (session === "edu") staffTabMode = "notation";
      syncEduControlsToState();
      syncNotationOverlayFromScore();
      if (staffOverlaySvgEl && staffLayout) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, activeStaffOverlayState());
    } catch (err: any) {
      console.error(err);
      setAlert(`Import failed: ${String(err?.message || err)}`);
    }
  };

  const summarizeImport = (r: ImportResult): string => {
    const base = `Imported: ${r.stats.measures} measures, ${r.stats.notes} notes, ${r.stats.rests} rests`;
    const tab = r.stats.notesWithTab ? `; TAB preserved on ${r.stats.notesWithTab} notes` : "; TAB not preserved";
    if (!r.warnings.length) return base + tab;
    // Show at most 2 warnings in the alert to keep it readable.
    const top = r.warnings
      .slice(0, 2)
      .map((w) => w.message)
      .join(" | ");
    const more = r.warnings.length > 2 ? ` (+${r.warnings.length - 2} more)` : "";
    return `${base}${tab}. ${top}${more}`;
  };

  (window as any).geduImportMusicXML = (xmlText: string, policy?: { requireTabTechnical?: boolean; strictTiming?: boolean }) => {
    const r = importMusicXmlWithReport(String(xmlText || ""), policy);
    if (r.status === "error" || !r.score) {
      setAlert(r.warnings[0]?.message || "Import failed.");
      return r;
    }
    applyNotationScore(r.score);
    setAlert(summarizeImport(r));
    return r;
  };

  (window as any).geduImportInternalScore = (jsonText: string) => {
    const s = fromInternalJson(String(jsonText || ""));
    applyNotationScore(s);
    return s;
  };

  (window as any).geduExportInternalScore = () => {
    try {
      return JSON.stringify(notationScore);
    } catch {
      return "";
    }
  };

  // Initialize UI
  syncFretKeypadAvailability();
  updateHighScoresUi(buildSettingsFromUi(doc, session));
  setAlert("Choose Single or Multiplayer to begin");
  showSplash();
}
