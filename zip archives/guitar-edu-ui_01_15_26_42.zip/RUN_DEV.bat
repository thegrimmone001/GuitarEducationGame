\
@echo off
setlocal
cd /d "%~dp0"
echo.
echo === Guitar-Edu-UI Dev Server ===
echo Build: 01_15_26_21
echo.
echo If this is your first run:
echo   npm install
echo.
echo Starting dev server...
npm run dev
