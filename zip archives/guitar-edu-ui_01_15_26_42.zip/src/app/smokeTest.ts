type SmokeCheck = {
  id: string;
  ok: boolean;
  note?: string;
};

function getBoolParam(name: string): boolean {
  try {
    const url = new URL(window.location.href);
    const v = url.searchParams.get(name);
    if (!v) return false;
    return v === "1" || v.toLowerCase() === "true" || v.toLowerCase() === "yes";
  } catch {
    return false;
  }
}

function emit(eventType: string, detail: unknown) {
  try {
    window.dispatchEvent(new CustomEvent(eventType, { detail }));
  } catch {
    // never block boot
  }
}

function check(doc: Document, id: string, note?: string): SmokeCheck {
  const ok = !!doc.getElementById(id);
  return { id, ok, note: ok ? undefined : note };
}

export function runSmokeTestIfRequested(doc: Document) {
  if (!getBoolParam("smoke")) return;

  // Small delay so the layout + controller have a chance to mount.
  window.setTimeout(() => {
    const checks: SmokeCheck[] = [
      check(doc, "ge-shell", "Main shell container not found (layout did not mount)."),
      check(doc, "staffSection", "Staff section missing."),
      check(doc, "staffCanvas", "Staff canvas missing."),
      check(doc, "fretCanvas", "Fretboard canvas missing."),
      check(doc, "noteStrip-rail", "Note rail mount missing."),
      check(doc, "promptText", "Prompt banner value missing (promptText)."),
      check(doc, "taskContext", "Task Context panel missing."),
      check(doc, "ctx-learningTarget", "Learning Target row missing."),
      check(doc, "ctx-activeSurfaces", "Active Surfaces row missing."),
      check(doc, "ctx-requiredSurfaces", "Required Inputs row missing."),
      check(doc, "ctx-prompt", "Task Context prompt row missing."),
      check(doc, "eventLogBtn", "Event log button missing."),
      check(doc, "eventLogDownload", "Event log download button missing."),
      check(doc, "buildVersion", "Build badge missing."),
    ];

    const ok = checks.every((c) => c.ok);
    const payload = { ok, checks, href: window.location.href };

    if (ok) console.info("[GEDU] SMOKE PASS", payload);
    else console.error("[GEDU] SMOKE FAIL", payload);

    // EventLog will record any gedu:* event.
    emit("gedu:smokeTest", payload);
  }, 50);
}// Note rail sanity: should render 25 tiles and one prompt tile
const rail = doc.querySelector<HTMLElement>("#noteStrip-rail");
if (rail) {
  const tiles = Array.from(rail.querySelectorAll(".noteTile"));
  if (tiles.length !== 25) failures.push(`Note rail tile count expected 25, got ${tiles.length}`);
  const hasPrompt = tiles.some((t) => (t as HTMLElement).classList.contains("prompt"));
  if (!hasPrompt) failures.push("Note rail missing .prompt tile");
} else {
  failures.push("Note rail missing #noteStrip-rail");
}

async function lifecycleSmoke(): Promise<void> {
  // Ensure we can enter/exit/re-enter without duplicating engine init.
  const countEngine = (substr: string) =>
    (document.body.innerText.match(new RegExp(substr.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")) || []).length;

  const beforeInit = countEngine("ENGINE INIT_MATCH");
  window.dispatchEvent(new CustomEvent("gedu:enterUI", { detail: { intent: "challenge" } }));
  await new Promise((r) => setTimeout(r, 50));
  window.dispatchEvent(new CustomEvent("gedu:exitRequested"));
  await new Promise((r) => setTimeout(r, 50));
  window.dispatchEvent(new CustomEvent("gedu:enterUI", { detail: { intent: "challenge" } }));
  await new Promise((r) => setTimeout(r, 50));

  const afterInit = countEngine("ENGINE INIT_MATCH");
  // Expect at most +2 across enter+reenter; never a burst of duplicates.
  if (afterInit - beforeInit > 2) {
    throw new Error(`Lifecycle smoke failed: INIT_MATCH duplicated (delta=${afterInit - beforeInit}).`);
  }
}


