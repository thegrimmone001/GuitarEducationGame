# THREAD BOOT PROTOCOL

This document defines how ChatGPT operates on this project.

## Precedence
1. MATCH_SETTINGS_SPEC.md
2. DECISIONS_LOG.md
3. CODE
4. MEMORY

## Rules
- No deprecated terminology
- No speculative features
- Batch execution only
- Always return a versioned zip snapshot

## Output Requirements
- CHANGELOG.md updated
- BUILD_LOG.md updated
- TASK_BOARD.md updated

## Smoke mode and Report Pack (Hands-off verification)
- Launch the dev server normally.
- Append `?smoke=1` to the URL.
- The app will run a mount-assertion pass and emit `UI gedu:smokeTest { ok: true/false, ... }` in the Event Log.
- Open the Event Log and use **Download** to export a full Report Pack:
  - Build ID, URL
  - Last Match Options (JSON)
  - Last Engine Settings (JSON)
  - Event Log
