# TASK BOARD

| ID | Task | Status | Notes |
|----|------|--------|-------|
| GEG-001 | Restore rendering integrity (staff/tab/fretboard/note rail) | DONE | Force Canvas2D surfaces to repaint during `renderAll()` so panels cannot remain blank after splash/visibility transitions. |

| GEG-002 | Add Copy button for Event Log + fix Note Rail init ordering | DONE | Copy-to-clipboard for rapid bug reports; prevents TDZ init hazard |

| GEG-003 | De-dup matchOptions logging + boot guard + fix build label | DONE | Prevent duplicate init and noisy logs; build badge now reflects snapshot |

| GEG-004 | Fix boot guard (module-safe) + correct build badge rendering | DONE | Restores browser load; avoids import-in-block syntax |
| GEG-004 | Add smoke-test harness + stabilize boot for hands-off iteration | DONE | Smoke: ?smoke=1 asserts critical DOM mounts and emits gedu:smokeTest; boot() refactor prevents double init safely |

| GEG-004 | Enforce core surface mount contract (no hidden on fret/note rail) | DONE | Prevents canvas blanking and keeps layout stable |

| GEG-005 | Restore prompt visibility in UI (promptText banner) + smoke checks | DONE | Ensures prompt is always visible above note rail; smoke asserts mounts |

| GEG-006 | Prompt sequencing on turn start + Event Log Download export | DONE | Re-enables random prompt generation; adds one-click txt export |

| GEG-007 | Task Context clarity (learning target + required surfaces) | DONE | Makes active task explicit without manual testing |

| GEG-008 | Surface requirement clarity (Active Surfaces + Required Inputs) | DONE | Task Context now shows active and required input surfaces; smoke asserts mounts |

| GEG-009 | Input gating aligned with Required Inputs (ignore disabled surfaces) | DONE | Prevents phantom actions by disallowing input on non-required surfaces |

| GEG-010 | One-click Report Pack in Event Log Download (includes settings) | DONE | Downloaded .txt now includes Build ID + last matchOptions + last engine settings |

| GEG-011 | Add CHECKLIST_MASTER + hands-off verification protocol | DONE | Central checklist + smoke/report instructions for rapid iterations |

| GEG-012 | Validation uses required surfaces only when submitting composite answer | DONE | Prevents optional surfaces from being used as submission source (phantom fails) |

| GEG-012 | Required-surface truth from engine (fix phantom required surfaces) | DONE | getSurfaceMatrix now derives required inputs from engine modeId/notation.view while in match |

| GEG-013 | Staff/Tab surface clipping + notation contrast | DONE | Prevents staff bleed into tab area; improves canvas contrast |

| GEG-015 | Note Rail prompt highlight + exhaustion (asked-history) | DONE | Rail shows .prompt tile and dims asked tiles; railExhausted when prompt-profile set exhausted |

| GEG-016 | De-dupe + coalesce matchOptions emissions (fix double/triple loading) | DONE | UI now emits matchOptions once per actual change, coalescing init sync bursts |

| GEG-017 | Fatal boot error boundary + global error capture | DONE | Prevents blank page; shows Build ID + stack trace overlay on boot failures |

| GEG-018 | Fatal overlay copy/download controls | DONE | If boot fails, overlay supports copy + download of error details |

| GEG-019 | Hands-off run scripts + npm check command | DONE | Added RUN_DEV/SMOKE/CHECKS and npm run check/typecheck |

| GEG-020 | Event Log copy/download controls | DONE | Event Log panel now supports copy + download |

| GEG-021 | Idempotent init guards (HMR/double-load safety) | DONE | gameController + layout init now no-op if already installed |

| GEG-022 | One-shot reset mechanism (?reset=1 + Event Log button) | DONE | Clears GEDU localStorage keys and reloads for recoverable browser state |

| GEG-023 | Wire Exit Requested to clean shutdown + return to menu | DONE | gedu:exitRequested stops timers, clears state, emits gedu:exitToMenu |

| GEG-024 | Event Log download -> Report Pack (Build/URL/matchOptions/engine settings/log) | DONE | Download produces single txt artifact for bug reports |

| GEG-025 | Reset robustness + confirm dialog | DONE | Reset clears broader GEDU keys; Event Log reset prompts confirmation |

| GEG-026 | Event Log: Copy Report Pack button | DONE | One-click clipboard export of full report pack |

| GEG-027 | Idempotent guards for ENTER_UI / BEGIN_MATCH | DONE | Prevents double loading and duplicate engine init |

| GEG-028 | Smoke: lifecycle enter/exit/re-enter (dup init guard) | DONE | Smoke asserts INIT_MATCH does not burst on re-entry |

| GEG-029 | Wire Task Context panel to matchOptions | DONE | Task Context now reflects active/required surfaces and core match settings |

| GEG-030 | Coalesce duplicate matchOptions events | DONE | Identical payloads within 200ms are ignored |

| GEG-031 | Event Log: Clear button | DONE | Clears visible Event Log output for fresh capture |

| GEG-031 | Event Log: Clear button (buffer + UI) | DONE | Clears ring buffer and logs eventLog:cleared |

| GEG-032 | Event Log: quick filters (All/UI/Engine/Sys) | DONE | One-click filtering during capture |

| GEG-033 | Idempotent install guard for Event Log | DONE | Prevents duplicate eventLog listeners/panels on reload/HMR |

| GEG-034 | Capture unhandled errors into Event Log (Sys) | DONE | window.error + unhandledrejection recorded for Report Pack |

| GEG-035 | Diagnostics: console.warn/error capture + normalize global error hooks | DONE | Ensures complete handlers + captures console warnings/errors |

| GEG-036 | Fix reset=1 reload loop by stripping query flag after reset | DONE | Prevents repeated resets / page load instability |

| GEG-037 | Add SAFE MODE (?safe=1) to bypass engine start for UI diagnostics | DONE | Enables loading UI even when engine/startup is unstable |

| GEG-038 | SAFE mode indicator + quick toggle/reset buttons | DONE | Header shows SAFE toggle and Reset for fast recovery |

| GEG-039 | Header: Smoke button + heartbeat indicator | DONE | One-click smoke tests; shows seconds since last event |
