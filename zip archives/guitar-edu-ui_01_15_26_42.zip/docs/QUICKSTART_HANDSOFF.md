# Quickstart (Hands-off Verification)

This project supports a minimal interaction loop:

## 1) Run smoke mode (mount + contract assertions)
- Windows: run `RUN_SMOKE.bat`
- Open the Vite URL and append `?smoke=1`

Expected:
- Event Log contains `UI gedu:smokeTest { ok: true, ... }`
- No blank pages. If a fatal occurs, the overlay provides Copy/Download.

## 2) Export a Report Pack (single artifact)
- Open **Event Log**
- Click **Download**
- The downloaded `.txt` includes:
  - Build ID + URL
  - Last matchOptions (JSON)
  - Last engine settings (JSON)
  - Event log

## 3) Run checks (fast regression gate)
- Windows: `RUN_CHECKS.bat`
- Or: `npm run check`

This executes:
- TypeScript typecheck (no emit)
- Vite build


## Reset (if the browser gets into a bad state)
- Add `?reset=1` to the URL once.
- The app will clear GEDU-localStorage keys and reload automatically.
