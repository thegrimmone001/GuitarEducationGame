# Retired / Unassigned Task IDs (GEG-###)

This file exists to eliminate ambiguity when interpreting gaps in the GEG task numbering.

## Definitions

- **Unassigned**: The ID is not defined anywhere in `CHECKLIST.md` and has no recorded meaning.
- **Retired**: The ID previously existed but was intentionally removed/replaced; the replacement is recorded here.

## Current status (Build: 01_13_26_19)

### Unassigned ranges

The following IDs are **not defined** in `CHECKLIST.md` and therefore have no canonical meaning at this time:

- GEG-005–009
- GEG-017–019
- GEG-024–029
- GEG-037–039
- GEG-046–049
- GEG-056–059
- GEG-065–069
- GEG-073–079
- GEG-085–089
- GEG-093–099
- GEG-103–109
- GEG-114–199

## Retired items

None recorded yet.

When an item is retired, add an entry in this format:

- **GEG-0XX** — Retired on YYYY-MM-DD (Build ID)
  - Reason:
  - Replacement:
  - Notes:

## Known checklist notes (not retired yet)

- **GEG-030 / GEG-031** are explicitly noted as outdated in current planning discussions (replaced conceptually by match settings + surface controls), but they remain present in `CHECKLIST.md` until formally retired here.
