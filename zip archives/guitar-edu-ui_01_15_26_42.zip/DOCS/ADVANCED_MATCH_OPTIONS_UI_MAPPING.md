# Advanced Match Options – UI Mapping & Dependencies

This document canonically records how **Advanced Match Options** are grouped, ordered, and gated in the UI.
It exists to prevent ambiguity, re-litigation, or drift between design, implementation, and documentation.

This document:
- Introduces **no new systems**
- Changes **no definitions**
- Describes **placement, grouping, and dependency only**

---

## Panel Order (Top → Bottom)

1. Learning Type Details
2. Input Method
3. Domain Constraints
4. Surface Controls
5. Match Rules
6. Randomization (embedded per Learning Type)

This order reflects dependency flow:
**what is tested → how input occurs → where it occurs → how it is shown → how success/failure is timed**

---

## Panel 1 — Learning Type Details (§4.2)

Visible learning types:
- Single Notes
- Intervals
- Chords
- Scales
- Arpeggios

Rules:
- Only one Learning Type active at a time
- Selecting a Learning Type enables its parameter group
- Non-applicable controls are disabled (never hidden)

Intervals-only:
- Roman Numeral Interval System (On / Off)

---

## Panel 2 — Input Method (§4.2 Advanced Input Method)

Options:
- Single-Note Input
- Structure Placement (Library-Based)
- Partial Structure Placement

Dependencies:
- Enabled only for: Chords, Scales, Arpeggios
- Disabled for: Single Notes, Intervals

Notes:
- Input Method never changes correctness rules
- Input Method only affects interaction granularity

---

## Panel 3 — Domain Constraints (§4.4–§4.6)

Always visible:
- Instrument (including Custom Instrument)
- Tuning (preset + custom)
- String range
- Fret range
- Span
- Notes-per-string
- Position scope (start/end)

Rules:
- Domain constraints apply globally
- No other panel may override domain constraints
- Structure placement must obey all domain limits

---

## Panel 4 — Surface Controls (§4.8)

Always visible:
- Per-surface roles:
  - Active
  - Prompt
  - Mark
  - Display
  - SAM
- Cardinality per surface:
  - Off / Single / Equivalents / All
- Presets A–J

Rules:
- Surface Controls affect information flow only
- Cardinality never expands valid answer sets
- Presets only modify surface behavior

---

## Panel 5 — Match Rules (§4.7)

Always visible:
- Board topology:
  - Player boards
  - Shared board
- Timing models:
  - Disabled (Timing Off)
  - Per-turn window
  - Time-to-completion
  - Time bank
- Timing variables:
  - turn length
  - intermission
  - increments
  - penalties
  - runtime cap
- Accuracy requirement:
  - Single-domain
  - Multi-domain
- Failure Conditions (toggle list)
- Bonus Phase (Enabled / Disabled + behavior config)

Rules:
- Match Rules never change valid answers
- Accuracy requirement gates confirmation only

---

## Panel 6 — Randomization (Embedded)

Location:
- Appears inside the active Learning Type panel

Rules:
- Randomization is opt-in only
- Random selection always respects:
  - Domain constraints
  - Cardinality
  - Surface roles
- No global random toggle exists

---

## Dependency Summary

| Panel | Depends On | Enables |
|------|-----------|---------|
| Learning Type Details | — | Input Method |
| Input Method | Learning Type | Learning Type sub-controls |
| Domain Constraints | — | All other panels |
| Surface Controls | — | Display/Prompt/Mark behavior |
| Match Rules | — | Timing & confirmation |
| Randomization | Learning Type | Selection only |

---

## Canon Lock Statement

This document is authoritative for:
- Advanced Match Options UI structure
- Panel ordering
- Panel dependency rules

No future implementation or documentation may contradict this without an explicit versioned update.

---

## Do Not Reintroduce (Hard Guardrail)

This section explicitly binds this document to the project’s deprecated terminology and patterns list.
Its purpose is to prevent legacy systems, names, or mental models from re-entering implementation,
documentation, or discussion.

### Explicitly Prohibited Concepts

The following MUST NOT be reintroduced in any form:

- Numbered or named **“Modes”** (e.g., Mode 1–5, Combined Mode, Hybrid Mode)
- Any system where:
  - UI layout determines game rules
  - “Mode” implicitly controls surfaces, timing, or learning type
- Treating **Surface Layers** (View / Asked / Answered) as rule logic
- Any logic where:
  - Display implies correctness
  - Prompt implies required input
- Auto-revealing **equivalents** as a difficulty shortcut
- Systems that collapse:
  - Learning Type
  - Input Method
  - Surface Controls
  into a single selector

### Canonical Replacement Model (Reminder)

The ONLY valid model is:

- **Learning Type** — what knowledge is being tested
- **Input Method** — how input is applied
- **Domain Constraints** — where answers may exist
- **Surface Controls** — how information flows
- **Match Rules** — when success/failure occurs

These layers MUST remain independent and composable.

### Enforcement Rule

If a proposal, implementation, or refactor:

- Requires introducing a “mode”
- Cannot be expressed within the existing panels documented here
- Blends two or more canonical layers into one control

Then it is **non-compliant** and must be rejected or reworked.

This rule applies to:
- Code
- UI
- Documentation
- Future design discussions

This section is intentionally repetitive and explicit.
It exists to save time by eliminating re-litigation.

---

## Match Options Ordering (Speed Rule)

Within **Match Options** (the configuration screen reached from Single Player → Challenge and Multiplayer → Confirm Players),
the top-to-bottom ordering is fixed to support fast iteration:

1. **Domain Constraints** (Instrument / Tuning / Strings / Frets / Span / etc.)
2. **Surface Preset (A–J)**
3. All remaining Match Options (Learning Type, Input Method, Musical Context, Match Rules, etc.)

This is a UI-only ordering rule. It does not alter the canonical layer definitions or dependencies.

## Input shortcuts
- Right-click (mouse) opens an Answer Shortcut Menu on eligible answer surfaces (context-gated; unified input pipeline).
