# DOCS/DEPRECATED_TERMS.md

This file exists to prevent regressions and repeated clarification.
It lists **terms, UI concepts, and implementation artifacts** that are now **outdated** and must not be reintroduced.

Authoritative references:
- `PROJECT_NOTES.md` → §4 Game Menu (Start of session; locked after match start)
- `PROJECT_NOTES.md` → §4.8 Surface Control System (Active / Display / Prompt / Mark / SAM)
- `MATCH_SETTINGS_SPEC.md` → canonical match settings (non-surface)

---

## 1) Outdated terminology

### 1.1 “Modes” (Mode 1–5)
**Status:** Deprecated.

The project no longer defines session behavior using numbered “modes.”
Session behavior is defined by:
- **Match Settings** (what is being tested)
- **Surface Controls** (Active / Prompt / Mark / Display / SAM)
- **Presentation Preferences** (visual only)

**Do not introduce:** new features, docs, UI, or logic that rely on “Mode 1–5” as the primary behavior selector.

**Legacy artifact (exists in code today):**
- UI ids / fields like `core.gameMode` and internal values like `m1…m5` may still exist for backward compatibility.
- Treat these as implementation leftovers, not canon.

### 1.2 “Combined mode”
**Status:** Deprecated.

Any use of “combined mode” to mean “multiple tasks/surfaces enabled” is obsolete.
Use Surface Controls and cardinality instead.

### 1.3 “Asked / Answered / View” as rule controls
**Status:** Deprecated as gameplay rule controls.

These terms were used historically to describe visibility layers.
They are replaced by the **Surface Control System**:
- Active
- Prompt
- Mark
- Display
- SAM

If “asked/answered/view” appears in the UI, it must be treated as a visual layer concept only (not the rule system).

---

## 2) Outdated UI concepts

### 2.1 Surface Layers ≠ Surface Control System
**Status:** Clarification.

The archive contains a “Surface Layers” concept (often represented as checkboxes such as View / Asked / Answered).
Those are **visual-only filters**.

The canon rule system is **Surface Controls** (Active / Prompt / Mark / Display / SAM) with cardinality:
- Off / Single / Equivalents / All

Do not treat Surface Layers as a substitute for Surface Controls.

---

## 3) Disallowed behaviors

### 3.1 Spoiler behavior: “Equivalents are given away”
**Status:** Disallowed by default.

Equivalents must not be revealed automatically unless explicitly enabled by Surface Controls (cardinality) and/or SAM rules.

### 3.2 Reintroducing undocumented mechanics
**Status:** Disallowed.

No mechanics should be inferred from prior prototypes or memory.
If a behavior is not documented in the archive canon files, it is not allowed.

---

## 4) Migration notes (for maintainers)

When encountering legacy identifiers (e.g., `m1…m5`, “mode”, “combined”, “asked/answered/view”):
- Do not delete blindly.
- Prefer isolating and eventually routing behavior through Match Settings + Surface Controls.
- Update this file when a legacy term is fully removed.

---

## Cross‑Reference: Advanced Match Options UI Mapping

This deprecated-terms list is **explicitly bound** to:

- `DOCS/ADVANCED_MATCH_OPTIONS_UI_MAPPING.md`

That document defines the **current, canonical replacement model** for all deprecated
terms and patterns listed here.

### Enforcement Note

If a proposed feature, refactor, or discussion appears to require:
- reintroducing a deprecated term, or
- inventing a new “mode” or collapsed control,

then the proposal **must first be reconciled** against the panel structure and dependency
rules defined in the Advanced Match Options UI Mapping.

If reconciliation is not possible without violating those rules,
the proposal is **non‑compliant** and must be rejected or reworked.

This cross‑reference exists to create a **bi‑directional lock** between:
- what is no longer allowed, and
- what has formally replaced it.

