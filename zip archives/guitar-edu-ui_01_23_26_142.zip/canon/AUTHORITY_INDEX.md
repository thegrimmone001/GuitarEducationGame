# Authority Index (Build-Blocking)

These files are authoritative. The project must not run unless they are acknowledged and hash-locked.

- [required] canon/DECISIONS_LOG.md
- [required] canon/MATCH_SETTINGS_SPEC.md
- [required] canon/MTL_MASTER_TIMELINE_LEDGER.md

- [optional] canon/CANON_PROGRESS.md
- [optional] canon/AUTHORITY_INDEX.md
