import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const ROOT = process.cwd();
const CANON_DIR = path.join(ROOT,'canon');
const INDEX_PATH = path.join(CANON_DIR,'AUTHORITY_INDEX.md');
const LOCK_PATH  = path.join(CANON_DIR,'CANON_LOCK.json');

const sha256 = (b)=>crypto.createHash('sha256').update(b).digest('hex');
const fileSha = (p)=>sha256(fs.readFileSync(p));
const fail = (m)=>{ console.error(`\n[CANON LOCK FAILED]\n${m}\n`); process.exit(1); };

function parseIndex(md){
  const out=[];
  for (const line of md.split(/\r?\n/)){
    const m=line.match(/^\s*-\s*\[(required|optional)\]\s+(.+?)\s*$/i);
    if(!m) continue;
    const required=m[1].toLowerCase()==='required';
    const relPath=m[2].trim().replace(/^\.\//,'');
    out.push({required,relPath});
  }
  return out;
}

if(!fs.existsSync(INDEX_PATH)) fail(`Missing ${INDEX_PATH}`);
const entries=parseIndex(fs.readFileSync(INDEX_PATH,'utf8'));
if(!entries.length) fail('AUTHORITY_INDEX.md has no parsable entries.');

const files=[];
for(const e of entries){
  const abs=path.join(ROOT,e.relPath);
  if(!fs.existsSync(abs)) fail(`Missing file listed in index: ${e.relPath}`);
  files.push({relPath:e.relPath, required:e.required, sha256:fileSha(abs)});
}

const payload={version:1, generatedAtUtc:new Date().toISOString(), files};
fs.writeFileSync(LOCK_PATH, JSON.stringify(payload,null,2));
console.log(`[CANON LOCK WRITTEN] ${LOCK_PATH}`);
