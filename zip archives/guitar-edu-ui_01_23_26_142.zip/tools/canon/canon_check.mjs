import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const ROOT = process.cwd();
const CANON_DIR = path.join(ROOT,'canon');
const LOCK_PATH = path.join(CANON_DIR,'CANON_LOCK.json');
const ACK_PATH  = path.join(CANON_DIR,'ACKNOWLEDGEMENT.json');
const PKG_PATH  = path.join(ROOT,'package.json');

const sha256 = (b)=>crypto.createHash('sha256').update(b).digest('hex');
const readJson = (p)=>JSON.parse(fs.readFileSync(p,'utf8'));
const fileSha = (p)=>sha256(fs.readFileSync(p));
const fail = (m)=>{ console.error(`\n[CANON CHECK FAILED]\n${m}\n`); process.exit(1); };

if (!fs.existsSync(PKG_PATH)) fail('Missing package.json at repo root (bad zip layout?)');
if (!fs.existsSync(LOCK_PATH)) fail(`Missing canon lockfile: ${LOCK_PATH}`);
if (!fs.existsSync(ACK_PATH))  fail(`Missing acknowledgement: ${ACK_PATH}`);

const lock = readJson(LOCK_PATH);
const ack  = readJson(ACK_PATH);

if (!ack.buildId || typeof ack.buildId !== 'string') fail('ACKNOWLEDGEMENT.json missing buildId (string).');

const lockSha = sha256(fs.readFileSync(LOCK_PATH));
if (ack.authorityLockSha256 !== lockSha) {
  fail(`ACK lock hash mismatch.\nACK: ${ack.authorityLockSha256}\nLOCK: ${lockSha}\nUpdate ACKNOWLEDGEMENT.json after updating CANON_LOCK.json.`);
}

const required = (lock.files || []).filter(f => f.required === true);
const readSet = new Set((ack.readFiles || []).map(String));
for (const f of required) {
  if (!readSet.has(f.relPath)) fail(`ACK missing required read file: ${f.relPath}`);
}

for (const f of (lock.files || [])) {
  const abs = path.join(ROOT, f.relPath);
  if (!fs.existsSync(abs)) fail(`Authority file missing: ${f.relPath}`);
  const actual = fileSha(abs);
  if (actual !== f.sha256) {
    fail(`Authority hash mismatch: ${f.relPath}\nExpected: ${f.sha256}\nActual: ${actual}\nIf intentional, run: npm run canon:lock`);
  }
}

console.log(`[CANON CHECK PASSED] buildId=${ack.buildId}`);
