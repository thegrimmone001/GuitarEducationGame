# TASK BOARD

| ID | Task | Status | Notes |
|----|------|--------|-------|
| GEG-001 | Restore rendering integrity (staff/tab/fretboard/note rail) | DONE | Force Canvas2D surfaces to repaint during `renderAll()` so panels cannot remain blank after splash/visibility transitions. |

| GEG-002 | Add Copy button for Event Log + fix Note Rail init ordering | DONE | Copy-to-clipboard for rapid bug reports; prevents TDZ init hazard |

| GEG-003 | De-dup matchOptions logging + boot guard + fix build label | DONE | Prevent duplicate init and noisy logs; build badge now reflects snapshot |

| GEG-004 | Fix boot guard (module-safe) + correct build badge rendering | DONE | Restores browser load; avoids import-in-block syntax |
| GEG-004 | Add smoke-test harness + stabilize boot for hands-off iteration | DONE | Smoke: ?smoke=1 asserts critical DOM mounts and emits gedu:smokeTest; boot() refactor prevents double init safely |

| GEG-004 | Enforce core surface mount contract (no hidden on fret/note rail) | DONE | Prevents canvas blanking and keeps layout stable |

| GEG-005 | Restore prompt visibility in UI (promptText banner) + smoke checks | DONE | Ensures prompt is always visible above note rail; smoke asserts mounts |

| GEG-006 | Prompt sequencing on turn start + Event Log Download export | DONE | Re-enables random prompt generation; adds one-click txt export |

| GEG-007 | Task Context clarity (learning target + required surfaces) | DONE | Makes active task explicit without manual testing |

| GEG-008 | Surface requirement clarity (Active Surfaces + Required Inputs) | DONE | Task Context now shows active and required input surfaces; smoke asserts mounts |

| GEG-009 | Input gating aligned with Required Inputs (ignore disabled surfaces) | DONE | Prevents phantom actions by disallowing input on non-required surfaces |

| GEG-010 | One-click Report Pack in Event Log Download (includes settings) | DONE | Downloaded .txt now includes Build ID + last matchOptions + last engine settings |

| GEG-011 | Add CHECKLIST_MASTER + hands-off verification protocol | DONE | Central checklist + smoke/report instructions for rapid iterations |

| GEG-012 | Validation uses required surfaces only when submitting composite answer | DONE | Prevents optional surfaces from being used as submission source (phantom fails) |

| GEG-012 | Required-surface truth from engine (fix phantom required surfaces) | DONE | getSurfaceMatrix now derives required inputs from engine modeId/notation.view while in match |

| GEG-013 | Staff/Tab surface clipping + notation contrast | DONE | Prevents staff bleed into tab area; improves canvas contrast |

| GEG-015 | Note Rail prompt highlight + exhaustion (asked-history) | DONE | Rail shows .prompt tile and dims asked tiles; railExhausted when prompt-profile set exhausted |

| GEG-016 | De-dupe + coalesce matchOptions emissions (fix double/triple loading) | DONE | UI now emits matchOptions once per actual change, coalescing init sync bursts |

| GEG-017 | Fatal boot error boundary + global error capture | DONE | Prevents blank page; shows Build ID + stack trace overlay on boot failures |

| GEG-018 | Fatal overlay copy/download controls | DONE | If boot fails, overlay supports copy + download of error details |
