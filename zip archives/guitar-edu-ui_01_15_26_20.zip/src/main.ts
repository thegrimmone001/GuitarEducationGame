import "./styles.css";
import { mountLayout } from "./ui/layout";
import { initGameController } from "./app/gameController";
import { hydrateFromIndexedDb } from "./shell/storage";
import { installEventLog } from "./app/eventLog";
import { runSmokeTestIfRequested } from "./app/smokeTest";

function renderFatal(app: HTMLElement, err: unknown) {
  const msg = err instanceof Error ? (err.stack || err.message) : String(err);
  console.error("[GEDU] Fatal boot error:", err);
  app.innerHTML = `
    <div style="padding:16px;font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Arial;">
      <h2 style="margin:0 0 8px 0;">Guitar-Edu-UI failed to load</h2>
      <div style="margin:0 0 12px 0;opacity:0.9;">Build: <code>${BUILD_ID}</code></div>
      <p style="margin:0 0 12px 0;">A fatal error occurred during boot. Copy the details below and attach to your report pack.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 10px 0;"><button data-gedu-fatal-copy style="padding:8px 10px;border-radius:10px;border:1px solid rgba(255,255,255,0.25);background:rgba(0,0,0,0.35);color:#fff;cursor:pointer;">Copy error</button><button data-gedu-fatal-download style="padding:8px 10px;border-radius:10px;border:1px solid rgba(255,255,255,0.25);background:rgba(0,0,0,0.35);color:#fff;cursor:pointer;">Download error</button></div><textarea data-gedu-fatal-text readonly style="width:100%;height:240px;white-space:pre;overflow:auto;">${msg.replace(/</g,"&lt;")}</textarea>
    </div>
  `;
}


function boot() {
  const app = document.getElementById("app") as HTMLElement | null;
  if (!app) throw new Error("#app not found");
  try {

      mountLayout(app);
      installEventLog(document);

      // Engine-backed controller (merged from the shell version into the new layout).
      // IMPORTANT: initialize the controller immediately so UI events (enterUI, beginSession, etc.)
      // cannot fire before listeners are attached. Hydration runs after and should never block wiring.
      initGameController(document);

      // Optional, dev-friendly smoke test (query param driven).
      runSmokeTestIfRequested(document);

      // Hydrate any persisted snapshot (USB/offline friendly) AFTER controller wiring.
      (async () => {
        try {
          await hydrateFromIndexedDb();
        } catch {
          /* ignore */
        }
      })();
  } catch (err) {
    renderFatal(app, err);
  }
}

// Prevent accidental double-boot (e.g., HMR edge cases or duplicate script mounts)
const w = window as any;
if (w.__GEDU_BOOTED__) {
  console.warn("[GEDU] Boot already executed; skipping re-init.");
} else {
  w.__GEDU_BOOTED__ = true;
  if (!w.__GEDU_GLOBAL_ERRORS__) {
    w.__GEDU_GLOBAL_ERRORS__ = true;
    window.addEventListener("error", (e) => {
      const app = document.getElementById("app") as HTMLElement | null;
      if (!app) return;
      if (app.innerHTML.includes("failed to load")) return;
      renderFatal(app, (e as any).error ?? (e as any).message ?? e);
    });
    window.addEventListener("unhandledrejection", (e) => {
      const app = document.getElementById("app") as HTMLElement | null;
      if (!app) return;
      if (app.innerHTML.includes("failed to load")) return;
      renderFatal(app, (e as any).reason ?? e);
    });
  }
  boot();
}
