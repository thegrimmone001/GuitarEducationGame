# ADVANCED_WING_LAYOUT_CONTRACT.md
**Status:** LOCKED  
**Scope:** UI layout + behavior only  
**Applies to:** Match Settings → Advanced (Right Flyout Wing)  
**Out of scope:** Engine wiring, animation timing, sound FX

---

## 1. Purpose

This document defines the **exact structural, spatial, and behavioral contract** for the **Advanced Match Settings flyout wing** and its relationship to the menu spine system.

If behavior or layout is not explicitly allowed here, it is **not permitted**.

---

## 2. High-Level Behavioral Rules (Non-Negotiable)

1. **Advanced Match Settings is a RIGHT FLYOUT WING**
   - It is **not** a modal
   - It does **not** block navigation context
   - It does **not** replace the menu spine system

2. **The active menu owns the majority of screen real estate**
   - Previous menus collapse and shift left into spines
   - Future spine slots are visible but empty until selected

3. **Navigation is horizontal**
   - No stacked “pages” for core navigation
   - No full-wing scrolling for core sections

---

## 3. Canonical Wing Structure (Fixed Grid)

```
RIGHT FLYOUT WING (Fixed Width)
┌──────────────────────────────────────────────┐
│ TOP HEADER (FULL WIDTH)                      │
├──────────────────────────────────────────────┤
│ INSTRUMENT SETTINGS (FULL WIDTH)             │
├──────────────────────────────────────────────┤
│ PRESETS A–J (FULL WIDTH)                     │
├───────────────────────┬──────────────────────┤
│ COLUMN A (LEFT)       │ COLUMN B (RIGHT)     │
│ Core Controls         │ Mode-Dependent Area  │
├───────────────────────┼──────────────────────┤
│ COLUMN A – BOTTOM     │ COLUMN B – BOTTOM    │
│ Rules / Constraints   │ Assistive / Analysis │
└───────────────────────┴──────────────────────┘
```

---

## 4. Section Contents (What Goes Where)

### 4.1 Top Header (Full Width)
- Title: **Advanced Match Settings**
- Close button (non-destructive)
- No settings

### 4.2 Instrument Settings (Full Width)
Always visible. Never collapses.
- Instrument
- Tuning
- Strings / Range
- Capo / Transpose

### 4.3 Presets Row (Full Width)
- Presets **A–J** (single row)
- No renaming; intent A–G and H–J must not drift
- No duplication elsewhere

### 4.4 Column A (Left – Core Controls)
Static region; order never changes.
- Surface Controls
- Pitch Set Source: Intervals / Chords / Scales-Modes / Arpeggios

### 4.5 Column B (Right – Mode Dependent)
Dynamic region; changes **only inside Column B**.
- Mode Selector:
  - Single Note
  - Interval
  - Chord
  - Scale / Mode
  - Arpeggio
  - Progression
- Context-specific controls area (reserved space; no reflow)

### 4.6 Bottom Row (Split)
**Column A Bottom (Rules / Constraints)**
- Timers
- Board Rules
- Attempts / Penalties
- Match Constraints
- Misc.

**Column B Bottom (Assistive / Analysis)**
- Tonal Assist (read-only; reflects current edited object; never mutates config)

---

## 5. Navigation & Spine Interaction
- Advanced opens as a **right flyout wing**
- Match Settings remains visible behind it
- Closing Advanced restores Match Settings prominence
- Back navigation reverses forward navigation

---

## 6. DO NOT Instructions (Critical)

### Layout
- Do NOT use a modal
- Do NOT center the Advanced settings
- Do NOT stack the wing into a single vertical column
- Do NOT add full-wing scrolling
- Do NOT move Instrument settings into tabs
- Do NOT hide Presets behind dropdowns
- Do NOT let mode changes reflow Column A
- Do NOT resize Column A due to Column B content

### Behavior / Scope
- Do NOT invent features
- Do NOT rename canon terms
- Do NOT collapse concepts for convenience
- Do NOT apply “helpful defaults” not specified
- Suggestions are allowed; implementation requires approval

---

## 7. Change Control
Any change to layout, section ordering, or concept definitions requires:
- Document update
- Timestamped decision entry
- Explicit approval

---

## 8. Authority
This contract overrides:
- AI-generated visuals
- convenience refactors
- “industry standard” patterns

**This contract is the layout.**
