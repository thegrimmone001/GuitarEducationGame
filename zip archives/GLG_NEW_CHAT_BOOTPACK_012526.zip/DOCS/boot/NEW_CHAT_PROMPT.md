# GLG Thread Boot Prompt (Use as first message in a new chat)

You are continuing an existing, long-running **Guitar Learning Game** project.  
This is **NOT** a new design phase.

## A) Canon Priority (Non‑Negotiable)
Treat these as the authoritative sources of truth, in this order:
1) **Guitar_Learning_Game_Authoritative_System_Manual_v1_0_EXHAUSTIVE.docx**
2) **MTL_MASTER_TIMELINE_LEDGER.md**
3) **GLG_CONVERSATION_LEDGER.md**
4) **GLG_CONVERSATION_INDEX_GUITAR_GAME_sorted.json / .csv**
5) Latest verified build archives (including **guitar-edu-ui_01_25_26_148.zip** and later)

Conflict rules:
- Documents override chat memory
- Later timestamps override earlier
- No assumptions allowed
- If unsure → ask before proceeding

## B) Strict Process Rules
❌ Do not invent features  
❌ Do not rename canon terms  
❌ Do not collapse concepts for convenience  
❌ Do not change folder structure or naming conventions  
✅ Suggestions are allowed ONLY if clearly labeled as suggestions  
✅ Implementation changes require explicit approval  
✅ Educational system first, game second

## C) Locked Definitions (Must Not Drift)
1) **Answer Sets**
- Single: one specific instance
- Equivalent: same staff note AND same octave mapped to all valid fretboard locations producing that exact pitch (octave differences NOT equivalent)
- Octave: same note name across a defined octave range
- All: all instances of the same note name

2) **Visibility vs Persistence**
- Boards are always visible
- “Persistence” = whether correct answers remain after marking
- Persistence configurable per surface
- “display/visible/visibility” are deprecated for this concept

3) **Answer Set ≠ Answer Count**
Default:
- Answer Set = Single
- Answer Count = 1

4) **Surface Controls (Canon Roles)**
Surface roles are exactly:
- Prompt
- Mark
- Persistence
- SAM (Show After Mark)
Each role supports Surface Scope: single | rotating | all | random
Coordination exists for Prompt/Mark/Persistence; SAM does not require coordination.

5) **Presets A–J (Locked Intent)**
- A–G: Note Rail → Fretboard/Staff/TAB (various combinations)
- H–J: Board → Note Rail (recognition direction)
No renaming. Clarify only; do not reinterpret.
For H/I/J: Note Rail should NOT persist by default; FB/ST/TAB should (persistence flipped vs earlier draft).

## D) Current Phase / Where to Resume
Resume at:
**Phase B‑2 → Phase C** — Menu completion + Advanced Wing implementation

### Advanced Wing Layout Authority
The Advanced Wing must follow:
- `DOCS/contracts/ADVANCED_WING_LAYOUT_CONTRACT.md`
- The uploaded SVG mockups:
  - `MainMenu_Layout-Template-MatchMenu.svg`
  - `MainMenu_Layout-Template-AdvancedMenu.svg`

Core requirements:
- Right flyout wing (NOT modal)
- Fixed header: Instrument Settings
- Presets A–J row
- Two-column main grid (Column A + Column B)
- Two-column bottom grid (Rules + Tonal Assist)
- No shifting controls
- No full-wing scrolling
- Menus use spine collapse/expand behavior (current menu dominates screen)

## E) Mandatory “Read First” Procedure (Do this before any work)
1) Read the canon sources in priority order (A).  
2) Read repo instruction files about naming and folder structure.  
3) Identify any contradictions; ask before proceeding.  
4) Produce a short **Canon Snapshot** (what is locked, what is current phase, what is next deliverable).  
5) Then proceed only within scope.

## F) Immediate Task (Next Deliverable)
Implement the menu layout exactly per the SVG/mockups and contract:
- Main Menu → Single Player → Challenge → Match Settings → Advanced Wing → Advanced Submenus
- Main Menu → Multiplayer → Players → Match Settings → Advanced Wing → Advanced Submenus
- Main Menu → Settings → Game/Preferences/Audio/Graphics
- Main Menu → Education (to Main UI / Lessons)
- Main Menu → FAQ/Help (FAQ → topic → pages, Help, Tutorials)

Free Play rule:
- Single Player → Free Play goes directly to gameplay screen (no Match Settings).

No engine wiring yet; UI must serialize to the locked schemas.

First response requirements:
- Acknowledge canon sources
- Restate locked definitions briefly
- Confirm current phase and next step
- Then proceed
