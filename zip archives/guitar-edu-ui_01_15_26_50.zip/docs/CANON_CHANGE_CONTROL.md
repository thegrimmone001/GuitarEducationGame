# Canon Change Control (No-Drift Protocol)

This project treats **canon** as the source of truth for what can be added, changed, removed, renamed, or reordered.

Canon sources (in priority order):
1. `docs/DECISIONS_LOG.md`
2. `docs/CHECKLIST.md`
3. `docs/TASK_BOARD.md`
4. `docs/MATCH_SETTINGS_SPEC.md`
5. `docs/DEPRECATED_TERMS.md`
6. `docs/THREAD_HANDOFF.md`
7. `docs/BUILD_LOG.md` / `CHANGELOG.md`

## Rule 1 — No Drift
No new UI, features, toggles, flows, IDs, modes, terms, or diagnostics may be implemented unless it is already:
- explicitly listed in canon, **or**
- added to canon via the **Approval Gate** below.

If something seems “useful” but is not canon, it must be written to `docs/SUGGESTIONS_LOG.md` and held.

## Approval Gate (Required)
Before implementing any non-canon idea, create a **Suggestion Entry** and wait for explicit approval.

Minimum approval requirement:
- User replies with **APPROVED: <Suggestion ID>** (exact ID).

If not approved, the change is **not implemented**.

## Suggestion Entry Fields (Required)
Each suggestion must include:
- ID
- Title
- Category (UI / Engine / Data / Diagnostics / Docs / Build)
- Rationale (why it matters)
- Scope (exact files/areas impacted)
- Canon Mapping (which canon item would be updated, or “none”)
- Risk (breakage, UX churn, scope creep)
- Acceptance Criteria (how we know it’s done)
- Status (Proposed / Approved / Rejected / Implemented)

## Implementation Constraints
If Approved:
- Update the relevant canon file(s) FIRST (DECISIONS/CHECKLIST/TASK_BOARD/spec)
- Then implement code changes
- Then update `CHANGELOG.md` and `BUILD_LOG.md`
- Then mark suggestion as Implemented

## Periodic Review
During review sessions, suggestions are triaged into:
- Approved
- Rejected
- Deferred (needs more info)
- Converted into canon (with updated docs)

