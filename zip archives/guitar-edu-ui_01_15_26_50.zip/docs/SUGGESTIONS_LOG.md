# Suggestions Log (Pending Review)

Purpose: capture **non-canon** improvement ideas without implementing them until approved.

---

## Template

### SUG-000: <Title>
- **Category:** UI | Engine | Data | Diagnostics | Docs | Build
- **Rationale:** <why this matters>
- **Scope:** <files / modules / surfaces touched>
- **Canon Mapping:** <which canon file(s) would be updated, or "none">
- **Risk:** <what could break / confuse / expand scope>
- **Acceptance Criteria:** <testable conditions>
- **Status:** Proposed | Approved | Rejected | Implemented
- **Notes:** <any extra context>

---

## Current Suggestions

### SUG-001: SAFE MODE (bypass engine start for UI diagnostics)
- **Category:** Diagnostics
- **Rationale:** Allows UI inspection when startup/engine is unstable.
- **Scope:** `src/main.ts`, `src/app/gameController.ts`, possibly UI header.
- **Canon Mapping:** None (requires DECISIONS_LOG + CHECKLIST updates).
- **Risk:** Adds alternate runtime path; could mask real bugs if used incorrectly.
- **Acceptance Criteria:** When approved and implemented, `?safe=1` loads UI without starting match engine.
- **Status:** Proposed
- **Notes:** Previously prototyped; rolled back for canon compliance.

### SUG-002: Event Log quick filters + Clear button
- **Category:** Diagnostics
- **Rationale:** Faster capture and review of logs during troubleshooting.
- **Scope:** `src/app/eventLog.ts`
- **Canon Mapping:** None (requires DECISIONS_LOG + CHECKLIST updates).
- **Risk:** UI clutter; potential misuse by clearing context.
- **Acceptance Criteria:** Filters (All/UI/Engine/Sys) and Clear log work reliably and are included in report workflow.
- **Status:** Proposed
- **Notes:** Previously prototyped; rolled back for canon compliance.

### SUG-003: Header quick controls (Reset / Smoke)
- **Category:** UI
- **Rationale:** One-click recovery and smoke runs.
- **Scope:** `src/ui/layout.ts`
- **Canon Mapping:** None (requires Start Screen / menus canon update).
- **Risk:** Non-canon control surface expansion; visual drift.
- **Acceptance Criteria:** Buttons exist only if approved and match design rules.
- **Status:** Proposed
- **Notes:** Previously prototyped; rolled back for canon compliance.

