const NOTE_NAMES = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"];

type Opt = { label: string; value: string };

type ElAttrs = Record<string, string>;

const el = <K extends keyof HTMLElementTagNameMap>(
  tag: K,
  attrs: ElAttrs = {},
  children: Array<Element | Text | string> = [],
) => {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  for (const c of children) node.append(c instanceof Node ? c : document.createTextNode(c));
  return node;
};

const SVG_NS = "http://www.w3.org/2000/svg";

const elSvg = <K extends keyof SVGElementTagNameMap>(
  tag: K,
  attrs: ElAttrs = {},
  children: Array<SVGElement | Text | string> = [],
) => {
  const node = document.createElementNS(SVG_NS, tag) as SVGElementTagNameMap[K];
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  for (const c of children) node.append(c instanceof Node ? c : document.createTextNode(c));
  return node;
};

function build2OctaveRail(home: string) {
  const rail = el("div", { class: "rail", id: "noteStrip-rail" });
  const startIdx = NOTE_NAMES.indexOf(home);
  const seq: string[] = [];
  // Two-octave span centered on the current note.
  // 25 tiles: 12 notes to the left, the current note, 12 notes to the right.
  for (let offset = -12; offset <= 12; offset++) {
    seq.push(NOTE_NAMES[(startIdx + offset + 1200) % 12]);
  }

  seq.forEach((n, i) => {
    const isCenter = i === 12;
    rail.append(
      el(
        "div",
        {
          class: `noteTile ${n.includes("#") ? "acc" : ""}${isCenter ? " active" : ""}`.trim(),
          "data-note": n,
          "data-idx": String(i),
          ...(isCenter ? { "data-center": "1" } : {}),
        },
        [n],
      ),
    );
  });

  return rail;
}

function wireTabs(root: HTMLElement) {
  const groups = root.querySelectorAll<HTMLElement>("[data-tabs]");
  groups.forEach((g) => {
    const tabs = Array.from(g.querySelectorAll<HTMLButtonElement>(".tab"));
    const panes = Array.from(g.querySelectorAll<HTMLElement>(".pane"));
    const activate = (id: string) => {
      tabs.forEach((t) => t.classList.toggle("active", t.dataset.tab === id));
      panes.forEach((p) => p.classList.toggle("active", p.dataset.pane === id));
    };
    tabs.forEach((t) => t.addEventListener("click", () => activate(t.dataset.tab!)));
    activate(tabs[0]?.dataset.tab ?? "single");
  });
}

// ---- Form helpers (UI only; engine wiring comes later) ----
function selectEl(id: string, options: Opt[], settingKey?: string, value?: string) {
  const s = document.createElement("select");
  s.id = id;
  s.className = "select";
  if (settingKey) s.dataset.setting = settingKey;
  options.forEach((o) => {
    const opt = document.createElement("option");
    opt.value = o.value;
    opt.textContent = o.label;
    s.appendChild(opt);
  });
  if (value != null) s.value = value;
  return s;
}

function numberEl(id: string, min: number, max: number, settingKey?: string, value?: number) {
  const i = document.createElement("input");
  i.type = "number";
  i.id = id;
  i.className = "numInput";
  i.min = String(min);
  i.max = String(max);
  i.step = "1";
  if (settingKey) i.dataset.setting = settingKey;
  if (value != null) i.value = String(value);
  return i;
}

function checkboxEl(id: string, checked = false, settingKey?: string) {
  const i = document.createElement("input");
  i.type = "checkbox";
  i.id = id;
  i.checked = checked;
  i.className = "toggle";
  if (settingKey) i.dataset.setting = settingKey;
  return i;
}

function formRow(label: string, control: HTMLElement, hint?: string) {
  return el("div", { class: "formRow" }, [
    el("div", { class: "formLabel" }, [label]),
    el("div", { class: "formControl" }, [control]),
    ...(hint ? [el("div", { class: "formHint" }, [hint])] : []),
  ]);
}

function formRowInline(label: string, controls: HTMLElement[]) {
  return el("div", { class: "formRow" }, [
    el("div", { class: "formLabel" }, [label]),
    el("div", { class: "formControl" }, [el("div", { class: "inline" }, controls)]),
  ]);
}

function checkGroup(title: string, items: Array<{ label: string; id: string; key: string }>) {
  const wrap = el("div", { class: "checkGroup" });
  if (title.trim().length) wrap.append(el("div", { class: "groupTitle" }, [title]));
  const grid = el("div", { class: "checks" });
  items.forEach((it) => {
    const row = el("label", { class: "check" }, [
      checkboxEl(it.id, false, it.key),
      el("span", { class: "checkText" }, [it.label]),
    ]);
    grid.append(row);
  });
  wrap.append(grid);
  return wrap;
}

function miniBtn(id: string, eventName: string, text: string, color: string) {
  const b = el("button", { class: "btn btn-sm", id, type: "button" }, [
    el("span", { class: `dot ${color}` }),
    el("span", { class: "btnText" }, [text]),
  ]);
  b.addEventListener("click", () => window.dispatchEvent(new CustomEvent(eventName)));
  return b;
}

function buildKeypad() {
  const keypad = document.getElementById("keypad");
  const display = document.getElementById("keypad-display");
  if (!keypad || !display) return;

  // 25-key fret selector (instant):
  // - 5 columns × 5 rows
  // - keys: 0..24
  // - no ENTER / DEL / CLEAR (selection is immediate)
  // Layout (row-major):
  //  0  1  2  3  4
  //  5  6  7  8  9
  // 10 11 12 13 14
  // 15 16 17 18 19
  // 20 21 22 23 24
  const keys: Array<{ label: string; value: number }> = Array.from({ length: 25 }, (_, i) => ({
    label: String(i),
    value: i,
  }));

  keypad.innerHTML = "";
  keypad.classList.add("keypad-25");

  keys.forEach((k) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "key";
    b.dataset.fret = String(k.value);
    b.textContent = k.label;
    b.addEventListener("click", () => {
      // Set display for visibility; gameplay is handled by the controller listener.
      display.textContent = k.label;
      window.dispatchEvent(new CustomEvent("gedu:fretPick", { detail: { fret: k.value } }));
    });
    keypad.appendChild(b);
  });
}

export function mountLayout(target: HTMLElement) {
  const shell = el("div", { class: "ge-shell", id: "ge-shell" });

  // --- Launch / Menu Stage ---
  // Central menu is the starting point. Menus expand left→right into columns.
  // Educational and Single Player → Free Play enter the UI directly.
  // Single Player → Challenge and Multiplayer flow into Match Options.

  // Launch menu (shown first)
  const launch = el("div", { class: "ge-launch", id: "ge-launch" });
  const launchCols = el("div", { class: "ge-launchCols", id: "ge-launchCols" });
  launch.append(launchCols);

  // Main app layout (hidden until an entry path is chosen)
  const main = el("div", { class: "ge-main hidden" });

  type LaunchIntent = "educational" | "freeplay" | "challenge" | "multiplayer";
  const launchState: {
    intent: LaunchIntent | null;
    playerCount: number;
    playersConfirmed: boolean;
  } = { intent: null, playerCount: 1, playersConfirmed: false };

  const clearColsFrom = (idx: number) => {
    const kids = Array.from(launchCols.children);
    kids.slice(idx).forEach((k) => k.remove());
  };

  const addCol = (title: string, items: Array<{ label: string; onPick: () => void }>) => {
    const col = el("div", { class: "ge-menuCol" });
    col.append(el("div", { class: "ge-menuTitle" }, [title]));
    const list = el("div", { class: "ge-menuList" });
    items.forEach((it) => {
      const b = el("button", { class: "ge-menuItem", type: "button" }, [it.label]);
      b.addEventListener("click", it.onPick);
      list.append(b);
    });
    col.append(list);
    launchCols.append(col);
    return col;
  };

  let currentIntent: "educational" | "freeplay" | "challenge" | "multiplayer" | "" = "";

  const enterUI = () => {
    currentIntent = launchState.intent;
    launch.classList.add("hidden");
    main.classList.remove("hidden");
    // Teaching Tools are only available for Educational / Free Play.
    // Challenge + Multiplayer are locked to pre-match settings.
    const allowTeachingTools = currentIntent === "educational" || currentIntent === "freeplay";
    const tt = document.getElementById("teachingTools");
    if (tt) tt.classList.toggle("hidden", !allowTeachingTools);
    window.dispatchEvent(new CustomEvent("gedu:enterUI", { detail: { intent: launchState.intent } }));
  };

  // Match Options: Domain Constraints first, then Presets, then all other options.
  // This is a UI-only ordering rule to speed up iteration.
  const showMatchOptions = () => {
    clearColsFrom(2);

    // Local state for the Match Options shell (wiring is event-driven; no refactor).
    const mo = {
      domain: {
        instrument: "guitar",
        tuning: "standard",
        // String selection is explicit (6..1). Stored as a CSV for now (UI shell).
        strings: "6,5,4,3,2,1",
        fretMin: 0,
        fretMax: 12,
        span: 4,
      },
      // Surface controls (Active / Prompt / Mark / Display / SAM) + Cardinality.
      // These are configuration-only flags emitted with Match Options.
      surfaces: {
        fretboard: { active: true, prompt: true, mark: true, display: true, sam: true, cardinality: "all" },
        staff: { active: true, prompt: false, mark: true, display: true, sam: false, cardinality: "single" },
        tab: { active: true, prompt: false, mark: true, display: true, sam: false, cardinality: "single" },
        noteRail: { active: true, prompt: true, mark: false, display: true, sam: false, cardinality: "single" },
      },
      preset: "A" as string,
      learningType: "single" as string,
      inputMethod: "singleNote" as string,
      context: {
        key: "C",
        collection: "chromatic",
        accidentals: "auto",
      },
      rules: {
        difficulty: "medium",
        timer: "off",
        accuracy: "singleDomain",
        board: "shared",
      },
    };

    const emit = () => {
      window.dispatchEvent(new CustomEvent("gedu:matchOptions", { detail: structuredClone(mo) }));
    };

    const col = el("div", { class: "ge-menuCol ge-matchOptionsCol" });
    col.append(el("div", { class: "ge-menuTitle" }, ["Match Options"]));

    const section = (title: string) => {
      const s = el("div", { class: "ge-moSection" });
      s.append(el("div", { class: "ge-moSectionTitle" }, [title]));
      return s;
    };

    const row = () => el("div", { class: "ge-moRow" });

    const labeledSelect = (
      label: string,
      opts: Array<{ v: string; t: string }>,
      value: string,
      onChange: (v: string) => void,
    ) => {
      const wrap = el("label", { class: "ge-moField" });
      wrap.append(el("div", { class: "ge-moLabel" }, [label]));
      const sel = document.createElement("select");
      sel.className = "ge-moSelect";
      opts.forEach((o) => {
        const op = document.createElement("option");
        op.value = o.v;
        op.textContent = o.t;
        sel.appendChild(op);
      });
      sel.value = value;
      sel.addEventListener("change", () => onChange(sel.value));
      wrap.append(sel);
      return wrap;
    };

    const labeledNumber = (label: string, value: number, min: number, max: number, onChange: (v: number) => void) => {
      const wrap = el("label", { class: "ge-moField" });
      wrap.append(el("div", { class: "ge-moLabel" }, [label]));
      const inp = document.createElement("input");
      inp.type = "number";
      inp.className = "ge-moNumber";
      inp.value = String(value);
      inp.min = String(min);
      inp.max = String(max);
      inp.addEventListener("change", () => {
        const n = Math.max(min, Math.min(max, Number(inp.value || value)));
        inp.value = String(n);
        onChange(n);
      });
      wrap.append(inp);
      return wrap;
    };

    // 0) Difficulty (TOP; locked after match start)
    const sDiff = section("Difficulty");
    const r0 = row();
    r0.append(
      labeledSelect(
        "Difficulty",
        [
          { v: "learning", t: "Learning" },
          { v: "easy", t: "Easy" },
          { v: "medium", t: "Medium" },
          { v: "hard", t: "Hard" },
        ],
        mo.rules.difficulty,
        (v) => {
          mo.rules.difficulty = v;
          emit();
        },
      ),
    );
    sDiff.append(r0);
    col.append(sDiff);

    // 1) Domain Constraints (SECOND)
    const sDomain = section("Domain Constraints");
    const r1 = row();
    r1.append(
      labeledSelect(
        "Instrument",
        [
          { v: "guitar", t: "Guitar" },
          { v: "bass", t: "Bass" },
          { v: "ukulele", t: "Ukulele" },
          { v: "banjo", t: "Banjo" },
          { v: "custom", t: "Custom" },
        ],
        mo.domain.instrument,
        (v) => {
          mo.domain.instrument = v;
          emit();
        },
      ),
    );
    r1.append(
      labeledSelect(
        "Tuning",
        [
          { v: "standard", t: "Standard" },
          { v: "dropD", t: "Drop D" },
          { v: "ebStd", t: "E♭ Standard" },
          { v: "dStd", t: "D Standard" },
          { v: "dropC", t: "Drop C" },
          { v: "cStd", t: "C Standard" },
          { v: "openG", t: "Open G" },
          { v: "openD", t: "Open D" },
          { v: "custom", t: "Custom" },
        ],
        mo.domain.tuning,
        (v) => {
          mo.domain.tuning = v;
          emit();
        },
      ),
    );
    sDomain.append(r1);
    const r2 = row();
    // Strings: explicit 6..1 checkboxes (stored as CSV in mo.domain.strings)
    {
      const wrap = el("div", { class: "ge-moField" });
      wrap.append(el("div", { class: "ge-moLabel" }, ["Strings"]));
      const group = el("div", { class: "ge-moPillRow ge-moPillRow--strings" });
      const getSet = () => new Set((mo.domain.strings || "").split(",").map((s) => s.trim()).filter(Boolean));
      const sync = () => {
        const set = getSet();
        group.querySelectorAll("button[data-str]").forEach((b) => {
          const k = (b as HTMLButtonElement).dataset.str || "";
          (b as HTMLButtonElement).classList.toggle("is-active", set.has(k));
        });
      };
      const toggle = (k: string) => {
        const set = getSet();
        if (set.has(k)) set.delete(k);
        else set.add(k);
        // Keep ordering stable (6..1)
        const order = ["6", "5", "4", "3", "2", "1"].filter((x) => set.has(x));
        // Require at least one string
        mo.domain.strings = order.length ? order.join(",") : "6";
        sync();
        emit();
      };
      ["6", "5", "4", "3", "2", "1"].forEach((k) => {
        const b = el("button", { class: "ge-moPill", type: "button" }, [k]) as HTMLButtonElement;
        b.dataset.str = k;
        b.addEventListener("click", () => toggle(k));
        group.append(b);
      });
      wrap.append(group);
      sync();
      r2.append(wrap);
    }
    r2.append(
      labeledNumber("Fret Min", mo.domain.fretMin, 0, 24, (n) => {
        mo.domain.fretMin = n;
        if (mo.domain.fretMax < n) mo.domain.fretMax = n;
        emit();
      }),
    );
    r2.append(
      labeledNumber("Fret Max", mo.domain.fretMax, 0, 24, (n) => {
        mo.domain.fretMax = n;
        if (mo.domain.fretMin > n) mo.domain.fretMin = n;
        emit();
      }),
    );
    sDomain.append(r2);
    const r3 = row();
    r3.append(
      labeledNumber("Span", mo.domain.span, 1, 12, (n) => {
        mo.domain.span = n;
        emit();
      }),
    );
    sDomain.append(r3);
    col.append(sDomain);

    // 2) Presets A–J (SECOND)
    const sPreset = section("Surface Preset (A–J)");
    const grid = el("div", { class: "ge-moPresetGrid" });
    const presetButtons: HTMLButtonElement[] = [];
    const setPreset = (p: string) => {
      mo.preset = p;
      presetButtons.forEach((b) => b.classList.toggle("is-active", b.dataset.preset === p));
      emit();
    };
    "ABCDEFGHIJ".split("").forEach((p) => {
      const b = el("button", { class: "ge-moPresetBtn", type: "button" }, [p]) as HTMLButtonElement;
      b.dataset.preset = p;
      b.addEventListener("click", () => setPreset(p));
      presetButtons.push(b);
      grid.append(b);
    });
    sPreset.append(grid);
    col.append(sPreset);
    setPreset(mo.preset);

    // 2.5) Surface controls (quick overrides beneath presets)
    const sSurface = section("Surface Controls");
    sSurface.append(
      el("div", { class: "ge-moHint" }, [
        "Override surface roles for this match. Presets (A–J) are the fast starting point; these are the surgical adjustments.",
      ]),
    );

    const matrix = el("div", { class: "ge-moMatrix", role: "group", "aria-label": "Surface Controls" });
    const header = el("div", { class: "ge-moMatrixRow ge-moMatrixHeader" });
    header.append(el("div", { class: "ge-moMatrixCell ge-moMatrixCell--surface" }, ["Surface"]));
    ["Active", "Prompt", "Mark", "Display", "SAM", "Card"].forEach((h) =>
      header.append(el("div", { class: "ge-moMatrixCell ge-moMatrixCell--h" }, [h])),
    );
    matrix.append(header);

    const mkCheck = (key: keyof typeof mo.surfaces.fretboard, surfKey: keyof typeof mo.surfaces, label: string) => {
      const id = `mo_${String(surfKey)}_${String(key)}`;
      const wrap = el("label", { class: "ge-moMatrixCell ge-moMatrixCell--check", for: id });
      const inp = document.createElement("input");
      inp.type = "checkbox";
      inp.id = id;
      (inp as HTMLInputElement).checked = Boolean((mo.surfaces as any)[surfKey][key]);
      inp.addEventListener("change", () => {
        (mo.surfaces as any)[surfKey][key] = (inp as HTMLInputElement).checked;
        emit();
      });
      wrap.append(inp);
      wrap.append(el("span", { class: "ge-moSr" }, [label]));
      return wrap;
    };

    const mkCard = (surfKey: keyof typeof mo.surfaces) => {
      const wrap = el("div", { class: "ge-moMatrixCell ge-moMatrixCell--card" });
      const sel = document.createElement("select");
      sel.className = "ge-moCardSelect";
      [
        { v: "off", t: "Off" },
        { v: "single", t: "Single" },
        { v: "equivalents", t: "Equivalents" },
        { v: "all", t: "All" },
      ].forEach((o) => {
        const op = document.createElement("option");
        op.value = o.v;
        op.textContent = o.t;
        sel.appendChild(op);
      });
      sel.value = (mo.surfaces as any)[surfKey].cardinality;
      sel.addEventListener("change", () => {
        (mo.surfaces as any)[surfKey].cardinality = sel.value;
        emit();
      });
      wrap.append(sel);
      return wrap;
    };

    const addSurfaceRow = (surfKey: keyof typeof mo.surfaces, title: string) => {
      const r = el("div", { class: "ge-moMatrixRow" });
      r.append(el("div", { class: "ge-moMatrixCell ge-moMatrixCell--surface" }, [title]));
      r.append(mkCheck("active", surfKey, `${title} active`));
      r.append(mkCheck("prompt", surfKey, `${title} prompt`));
      r.append(mkCheck("mark", surfKey, `${title} mark`));
      r.append(mkCheck("display", surfKey, `${title} display`));
      r.append(mkCheck("sam", surfKey, `${title} sam`));
      r.append(mkCard(surfKey));
      matrix.append(r);
    };

    addSurfaceRow("fretboard", "Fretboard");
    addSurfaceRow("staff", "Staff");
    addSurfaceRow("tab", "TAB");
    addSurfaceRow("noteRail", "Note Rail");

    sSurface.append(matrix);
    col.append(sSurface);

    // 3) Remaining options
    const sLT = section("Learning Type");
    const rLT = row();
    rLT.append(
      labeledSelect(
        "Type",
        [
          { v: "single", t: "Single Notes" },
          { v: "interval", t: "Intervals" },
          { v: "chord", t: "Chords" },
          { v: "scale", t: "Scales" },
          { v: "arpeggio", t: "Arpeggios" },
        ],
        mo.learningType,
        (v) => {
          mo.learningType = v;
          // Gate input method availability (UI only).
          const allow = v === "chord" || v === "scale" || v === "arpeggio";
          inputMethodSelect.disabled = !allow;
          if (!allow) mo.inputMethod = "singleNote";
          inputMethodSelect.value = mo.inputMethod;
          emit();
        },
      ),
    );
    sLT.append(rLT);
    col.append(sLT);

    const sIM = section("Input Method");
    const rIM = row();
    // Create select first so Learning Type gating can reference it.
    const inputMethodField = el("label", { class: "ge-moField" });
    inputMethodField.append(el("div", { class: "ge-moLabel" }, ["Method"]));
    const inputMethodSelect = document.createElement("select");
    inputMethodSelect.className = "ge-moSelect";
    ;[
      { v: "singleNote", t: "Single-Note" },
      { v: "structure", t: "Structure" },
      { v: "partial", t: "Partial" },
    ].forEach((o) => {
      const op = document.createElement("option");
      op.value = o.v;
      op.textContent = o.t;
      inputMethodSelect.appendChild(op);
    });
    inputMethodSelect.value = mo.inputMethod;
    inputMethodSelect.addEventListener("change", () => {
      mo.inputMethod = inputMethodSelect.value;
      emit();
    });
    inputMethodField.append(inputMethodSelect);
    rIM.append(inputMethodField);
    sIM.append(rIM);
    col.append(sIM);

    const sCtx = section("Musical Context");
    const rCtx = row();
    rCtx.append(
      labeledSelect(
        "Key",
        ["C", "G", "D", "A", "E", "B", "F#", "C#", "F", "Bb", "Eb", "Ab", "Db", "Gb", "Cb"].map((k) => ({
          v: k,
          t: k,
        })),
        mo.context.key,
        (v) => {
          mo.context.key = v;
          emit();
        },
      ),
    );
    rCtx.append(
      labeledSelect(
        "Collection",
        [
          { v: "chromatic", t: "Chromatic" },
          { v: "pentatonic", t: "Pentatonic" },
          { v: "blues", t: "Blues" },
          { v: "ionian", t: "Ionian (Major)" },
          { v: "aeolian", t: "Aeolian (Minor)" },
        ],
        mo.context.collection,
        (v) => {
          mo.context.collection = v;
          emit();
        },
      ),
    );
    rCtx.append(
      labeledSelect(
        "Accidentals",
        [
          { v: "all", t: "All" },
          { v: "naturals", t: "Naturals" },
          { v: "sharps", t: "Sharps" },
          { v: "flats", t: "Flats" },
          { v: "auto", t: "Auto" },
        ],
        mo.context.accidentals,
        (v) => {
          mo.context.accidentals = v;
          emit();
        },
      ),
    );
    sCtx.append(rCtx);
    col.append(sCtx);

    const sRules = section("Match Rules (Quick)");
    const rRules = row();
    rRules.append(
      labeledSelect(
        "Timer",
        [
          { v: "off", t: "Off" },
          { v: "completion", t: "Time-to-Completion" },
          { v: "turnWindow", t: "Turn Window" },
        ],
        mo.rules.timer,
        (v) => {
          mo.rules.timer = v;
          emit();
        },
      ),
    );
    rRules.append(
      labeledSelect(
        "Accuracy",
        [
          { v: "singleDomain", t: "Single-Domain" },
          { v: "multiDomain", t: "Multi-Domain" },
        ],
        mo.rules.accuracy,
        (v) => {
          mo.rules.accuracy = v;
          emit();
        },
      ),
    );
    rRules.append(
      labeledSelect(
        "Boards",
        [
          { v: "shared", t: "Shared" },
          { v: "perPlayer", t: "Player Boards" },
        ],
        mo.rules.board,
        (v) => {
          mo.rules.board = v;
          emit();
        },
      ),
    );
    sRules.append(rRules);
    col.append(sRules);

    const actions = el("div", { class: "ge-moActions" });
    const startBtn = el("button", { class: "ge-moStart", type: "button" }, ["Start Match"]) as HTMLButtonElement;
    startBtn.addEventListener("click", () => {
      emit();
      enterUI();
    });
    const backBtn = el("button", { class: "ge-moBack", type: "button" }, ["Back"]) as HTMLButtonElement;
    backBtn.addEventListener("click", () => clearColsFrom(1));
    actions.append(startBtn, backBtn);
    col.append(actions);

    launchCols.append(col);
    emit();
  };

  const showPlayers = () => {
    clearColsFrom(1);
    addCol("Players", [
      {
        label: "Add Player (+1)",
        onPick: () => {
          launchState.playerCount = Math.min(8, launchState.playerCount + 1);
          window.dispatchEvent(new CustomEvent("gedu:players", { detail: { count: launchState.playerCount } }));
        },
      },
      {
        label: "Remove Player (-1)",
        onPick: () => {
          launchState.playerCount = Math.max(2, launchState.playerCount - 1);
          window.dispatchEvent(new CustomEvent("gedu:players", { detail: { count: launchState.playerCount } }));
        },
      },
      {
        label: "Confirm Players",
        onPick: () => {
          launchState.playersConfirmed = true;
          showMatchOptions();
        },
      },
      {
        label: "Back",
        onPick: () => clearColsFrom(0),
      },
    ]);
  };

  const showSinglePlayer = () => {
    clearColsFrom(1);
    addCol("Single Player", [
      {
        label: "Free Play",
        onPick: () => {
          launchState.intent = "freeplay";
          enterUI();
        },
      },
      {
        label: "Challenge",
        onPick: () => {
          launchState.intent = "challenge";
          showMatchOptions();
        },
      },
      {
        label: "Back",
        onPick: () => clearColsFrom(0),
      },
    ]);
  };

  const showHelp = () => {
    clearColsFrom(1);
    addCol("Help", [
      { label: "FAQ", onPick: () => window.dispatchEvent(new CustomEvent("gedu:help", { detail: { page: "faq" } })) },
      { label: "Back", onPick: () => clearColsFrom(0) },
    ]);
  };

  const showOptions = () => {
    clearColsFrom(1);
    addCol("Options", [
      {
        label: "System Settings",
        onPick: () => window.dispatchEvent(new CustomEvent("gedu:systemSettings")),
      },
      { label: "Back", onPick: () => clearColsFrom(0) },
    ]);
  };

  const showRootMenu = () => {
    clearColsFrom(0);
    addCol("Menu", [
      { label: "Single Player", onPick: () => showSinglePlayer() },
      {
        label: "Multiplayer",
        onPick: () => {
          launchState.intent = "multiplayer";
          launchState.playerCount = Math.max(2, launchState.playerCount);
          showPlayers();
        },
      },
      {
        label: "Educational",
        onPick: () => {
          launchState.intent = "educational";
          enterUI();
        },
      },
      { label: "Options", onPick: () => showOptions() },
      { label: "Help", onPick: () => showHelp() },
      {
        label: "Exit",
        onPick: () => window.dispatchEvent(new CustomEvent("gedu:exitRequested")),
      },
    ]);
  };

  // In-match Exit returns to the authoritative Start Menu.
  window.addEventListener("gedu:exitToMenu", () => {
    main.classList.add("hidden");
    launch.classList.remove("hidden");
    currentIntent = "";
    showRootMenu();
  });

  // Initial central menu (authoritative entry point)
  showRootMenu();

  // Main 3 columns (game UI)
  // --- Left column ---
  const ops = el("div", { class: "section" }, [
    el("div", { class: "block-title" }, ["Operations"]),

    el("details", { class: "collapse", id: "ops-playstyle" }, [
      el("summary", { class: "collapseSummary" }, ["Play Style Options"]),
      el("div", { class: "collapseBody" }, [
        checkGroup("", [
          { label: "SAM (Show After Miss)", id: "ps-sam", key: "ps.sam" },
        ]),
        el("label", { class: "check", id: "ps-personalBoardsRow" }, [
          checkboxEl("ps-personalBoards", false, "ps.personalBoards"),
          el("span", { class: "checkText" }, ["Personal Boards"]),
        ]),
      ]),
    ]),

    el("div", { class: "opsGrid" }, [
      miniBtn("btn-stop", "gedu:stop", "End", "red"),
      miniBtn("btn-new", "gedu:new", "New", "blue"),
      miniBtn("btn-exit", "gedu:exitToMenu", "Exit", "yellow"),
    ]),
  ]);


  // Teaching Tools: available for Educational / Free Play only.
  // These are playfield modifiers intended to help instruction and should not be available
  // for Challenge or Multiplayer unless explicitly sanctioned later.
  const coreSettings = el("div", { class: "section", id: "teachingTools" }, [
    el("div", { class: "block-title" }, ["Teaching Tools"]),
    formRow(
      "Root Note",
      selectEl(
        "core-root",
        [
          { label: "C", value: "C" },
          { label: "C#", value: "C#" },
          { label: "D", value: "D" },
          { label: "D#", value: "D#" },
          { label: "E", value: "E" },
          { label: "F", value: "F" },
          { label: "F#", value: "F#" },
          { label: "G", value: "G" },
          { label: "G#", value: "G#" },
          { label: "A", value: "A" },
          { label: "A#", value: "A#" },
          { label: "B", value: "B" },
        ],
        "core.root",
        "C",
      ),
    ),
    formRow(
      "Modes",
      selectEl(
        "core-modes",
        [
          { label: "Chromatic", value: "chromatic" },
          { label: "Pentatonic", value: "pentatonic" },
          { label: "Blues", value: "blues" },
          { label: "Ionian (Major)", value: "ionian" },
          { label: "Dorian", value: "dorian" },
          { label: "Phrygian", value: "phrygian" },
          { label: "Lydian", value: "lydian" },
          { label: "Mixolydian", value: "mixolydian" },
          { label: "Aeolian (Minor)", value: "aeolian" },
          { label: "Locrian", value: "locrian" },
        ],
        "core.modes",
        "chromatic",
      ),
    ),
    formRow(
      "Display",
      selectEl(
        "core-display",
        [
          { label: "Note Names", value: "names" },
          { label: "Intervals", value: "intervals" },
          { label: "Roman Numeral Intervals (\u266dII style)", value: "romanIntervals" },
          { label: "Interval Roman (I/ii/II/iii...)", value: "intervalRoman" },
        ],
        "core.display",
        "names",
      ),
    ),
    formRowInline("Chord Display", [
      selectEl(
        "chords-visibility",
        [
          { label: "Roman Numerals", value: "roman" },
          { label: "Nashville Numbers", value: "nashville" },
          { label: "Chord Name", value: "name" },
        ],
        "chords.visibility",
        "name",
      ),
      selectEl(
        "chords-extension",
        [
          { label: "None", value: "none" },
          { label: "Triad", value: "triad" },
          { label: "7th", value: "7th" },
          { label: "9th", value: "9th" },
        ],
        "chords.extension",
        "triad",
      ),
    ]),
    formRow(
      "Note Visibility",
      selectEl(
        "core-noteVisibility",
        [
          { label: "All", value: "all" },
          { label: "Naturals", value: "naturals" },
          { label: "Enharmonics", value: "enharmonics" },
        ],
        "core.noteVisibility",
        "all",
      ),
    ),

    formRow(
      "Accidentals",
      selectEl(
        "core-accidentalView",
        [
          { label: "Both", value: "both" },
          { label: "Sharps only", value: "sharps" },
          { label: "Flats only", value: "flats" },
          { label: "Auto (context)", value: "auto" },
        ],
        "core.accidentalView",
        "both",
      ),
    ),
    checkGroup("Highlight Tones", [
      { label: "Root / Tonic", id: "core-hl-root", key: "core.hl.root" },
      { label: "3rd", id: "core-hl-3", key: "core.hl.3" },
      { label: "5th", id: "core-hl-5", key: "core.hl.5" },
      { label: "7th", id: "core-hl-7", key: "core.hl.7" },
    ]),

    el("div", { class: "subTitle" }, ["Game Options"]),
    formRowInline("Tokens", [
      el("div", { class: "inlineLabeled" }, [
        el("div", { class: "miniLabel" }, ["Cap"]),
        numberEl("core-tokenCap", 0, 20, "core.tokenCap", 10),
      ]),
      el("div", { class: "inlineLabeled" }, [
        el("div", { class: "miniLabel" }, ["Start"]),
        numberEl("core-startTokens", 0, 20, "core.startTokens", 0),
      ]),
    ]),
    formRowInline("Dev/Test", [
      el("label", { class: "check" }, [
        checkboxEl("core-devMode", false, "core.devMode"),
        el("span", { class: "checkText" }, ["Enable"]),
      ]),
    ]),
  ]);

  // Hidden by default; shown when entering Educational or Free Play.
  coreSettings.classList.add("hidden");

  const preferences = el("div", { class: "section" }, [
    el("div", { class: "block-title" }, ["Preferences"]),
    formRow(
      "Instrument",
      selectEl(
        "pref-instrument",
        [
          { label: "Guitar", value: "guitar" },
          { label: "Bass", value: "bass" },
          { label: "Ukulele", value: "ukulele" },
          { label: "Banjo", value: "banjo" },
        ],
        "pref.instrument",
        "guitar",
      ),
    ),
    formRow(
      "Instrument Tuning",
      selectEl(
        "pref-tuning",
        [
          { label: "Standard", value: "standard" },
          { label: "Drop D", value: "dropD" },
          { label: "Open G", value: "openG" },
        ],
        "pref.tuning",
        "standard",
      ),
    ),
    el("div", { class: "subTitle" }, ["Notation"]),
    formRow(
      "Notation View",
      selectEl(
        "pref-notationView",
        [
          { label: "Staff + TAB", value: "staffTab" },
          { label: "Staff Only", value: "staff" },
          { label: "TAB Only", value: "tab" },
        ],
        "pref.notationView",
        "staffTab",
      ),
      "Display control only (does not change game rules).",
    ),
    formRow(
      "Notation Pitch",
      selectEl(
        "pref-notationPitch",
        [
          { label: "Written (default)", value: "written" },
          { label: "Concert", value: "concert" },
        ],
        "pref.notationPitch",
        "written",
      ),
      "Written is the standard for printed guitar music; Concert matches sounding pitch.",
    ),

    formRow(
      "Mode 3 Spelling",
      selectEl(
        "pref-mode3SpellingPolicy",
        [
          { label: "Strict (C# != Db)", value: "strict" },
          { label: "Allow Enharmonic", value: "enharmonic" },
        ],
        "pref.mode3SpellingPolicy",
        "strict",
      ),
      "Controls STAFF spelling validation when STAFF is required in Mode 3.",
    ),

    formRowInline("Surface Layers", [
      el("label", { class: "check" }, [
        checkboxEl("pref-layerView", true, "pref.layers.view"),
        el("span", { class: "checkText" }, ["Display"]),
      ]),
      el("label", { class: "check" }, [
        checkboxEl("pref-layerAsked", true, "pref.layers.asked"),
        el("span", { class: "checkText" }, ["Prompt"]),
      ]),
      el("label", { class: "check" }, [
        checkboxEl("pref-layerAnswered", true, "pref.layers.answered"),
        el("span", { class: "checkText" }, ["Marks"]),
      ]),
    ]),
    formRow(
      "Tritone Label",
      selectEl(
        "pref-tritoneStyle",
        [
          { label: "+/o (default)", value: "plusDim" },
          { label: "TT", value: "TT" },
          { label: "IV\u266f", value: "sharp4" },
          { label: "V\u266d", value: "flat5" },
          { label: "Auto (context)", value: "auto" },
        ],
        "note.tritone",
        "plusDim",
      ),
      "Affects Interval Roman display only.",
    ),
    el("div", { class: "subTitle" }, ["Fretboard Controls"]),
    formRow(
      "Default View",
      selectEl(
        "pref-fretView",
        [
          { label: "5 frets", value: "5" },
          { label: "12 frets", value: "12" },
          { label: "24 frets", value: "24" },
        ],
        "pref.fretView",
        "12",
      ),
    ),
    formRowInline("Default Range", [
      numberEl("pref-fretMin", 0, 24, "pref.fretMin", 1),
      numberEl("pref-fretMax", 0, 24, "pref.fretMax", 12),
    ]),
  ]);

  const help = el("div", { class: "section" }, [
    el("div", { class: "block-title" }, ["Help & Support"]),
    el("div", { class: "helpRow" }, [
      el("button", { class: "btn btn-sm", type: "button", id: "help-faq" }, ["FAQ"]),
      el("button", { class: "btn btn-sm", type: "button", id: "help-tutorials" }, ["Tutorials"]),
    ]),
  ]);

  const left = el("div", { class: "ge-panel ge-left" }, [
    el("div", { class: "section ge-logo" }, [
      el("div", { class: "note", "aria-hidden": "true" }),
      el("div", { class: "brand" }, ["Guitar", el("span", { class: "edu" }, ["Edu"]) ]),
    ]),
    ops,
    el("div", { class: "scrollCol" }, [coreSettings, preferences, help]),
  ]);

  // --- Center column ---
  const center = el("div", { class: "ge-panel ge-center" }, [
    el("div", { class: "section" }, [
      el("div", { class: "block-title" }, ["Staff + TAB"]),
      el("div", { class: "svgStage", id: "staffTabStage" }, [
        // Background + overlay are injected/managed by the controller so we can keep hitboxes
        // perfectly aligned to the SVG geometry.
        el("div", { class: "svgHost", id: "staffBgHost", "aria-hidden": "true" }),
        elSvg("svg", { class: "svgOverlay", id: "staffOverlaySvg", "aria-label": "Staff + TAB interaction layer" }),
      ]),
    ]),
    el("div", { class: "section" }, [
      el("div", { class: "noteStrip noteRail", id: "noteStrip" }, [
        el("div", { class: "homeMarker", id: "noteStrip-marker", "aria-hidden": "true" }),
        el("div", { class: "noteRailMount", id: "noteStrip-rail", "aria-label": "Note strip" }, []),
      ]),
    ]),
    el("div", { class: "section col" }, [
      el("div", { class: "fretStage", id: "fretStage" }, [
        el("div", { class: "svgHost", id: "fretBgHost", "aria-hidden": "true" }),
        elSvg("svg", { class: "svgOverlay", id: "fretOverlaySvg", "aria-label": "Fretboard interaction layer" }),
      ]),
    ]),
  ]);

  // --- Right column ---
  const right = el("div", { class: "ge-panel ge-right" }, [
    // Current player (upper right)
    el("div", { class: "section", style: "padding:0" }, [
      el("div", { class: "ge-playercard", id: "activePlayer-card" }, [
        el("div", { class: "avatar", "aria-hidden": "true" }),
        el("div", { class: "player-scoreRow" }, [
          el("div", { class: "score", id: "activePlayer-score" }, ["0"]),
          el("div", { class: "mult", id: "activePlayer-mult" }, ["×1"]),
        ]),
        el("div", { class: "player-target", id: "activePlayer-target", title: "Current target note (spelling matters for sharps/flats)" }, [""]),
        // Token / bonus indicators (filled in controller)
        el("div", { class: "tokenRow", id: "activePlayer-tokens", "aria-label": "Tokens" }, []),
        el("div", { class: "player-bottom" }, [
          el("div", { id: "activePlayer-name" }, ["Player 1"]),
          el("div", { class: "badge", id: "activePlayer-timer" }, ["00:00"]),
        ]),
      ]),
    ]),


    el("div", { class: "section", "data-tabs": "right" }, [
      el("div", { class: "block-title" }, ["Utility"]),
      el("div", { class: "tabs compact" }, [
        el("button", { class: "tab active", type: "button", "data-tab": "num" }, ["Num"]),
        el("button", { class: "tab", type: "button", "data-tab": "note" }, ["Note"]),
        el("button", { class: "tab", type: "button", "data-tab": "chord" }, ["Chord"]),
        el("button", { class: "tab", type: "button", "data-tab": "scale" }, ["Scale"]),
        el("button", { class: "tab", type: "button", "data-tab": "teach", id: "utility-teach-tab", "data-teach-only": "1", hidden: "true" }, ["Teach"]),
      ]),
      el("div", { class: "tabpanes" }, [
        el("div", { class: "pane active", "data-pane": "num" }, [
          el("div", { class: "display", id: "keypad-display" }, ["0"]),
          el("div", { style: "height:10px" }),
          el("div", { class: "keypad", id: "keypad" }),
        ]),
        el("div", { class: "pane", "data-pane": "note" }, [
          el("div", { class: "noteTools" }, [
            el("div", { class: "teachSubTitle" }, ["Staff Accidentals"]),
            el("div", { style: "font-size:12px;color:rgba(215,230,255,.75);margin-bottom:10px" }, [
              "Pre-select how staff clicks mark accidentals. Prompt asks each time.",
            ]),
            el("div", { class: "teachRow" }, [
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "staffAccPref", id: "note-acc-prompt", checked: "true" }),
                el("span", {}, ["Prompt"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "staffAccPref", id: "note-acc-natural" }),
                el("span", {}, ["Natural"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "staffAccPref", id: "note-acc-sharp" }),
                el("span", {}, ["Sharp"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "staffAccPref", id: "note-acc-flat" }),
                el("span", {}, ["Flat"]),
              ]),
            ]),
          ]),
        ]),
        el("div", { class: "pane", "data-pane": "chord" }, [
          el("div", { style: "font-size:12px;color:rgba(215,230,255,.8)" }, ["Chords UI placeholder."]),
        ]),
        el("div", { class: "pane", "data-pane": "scale" }, [
          el("div", { style: "font-size:12px;color:rgba(215,230,255,.8)" }, ["Misc UI placeholder."]),
        ]),
        el("div", { class: "pane", "data-pane": "teach", id: "utility-teach-pane", hidden: "true" }, [
          el("div", { class: "teachPane" }, [
            el("div", { class: "teachTitle" }, ["Education Mode Tools"]),
            el("div", { class: "teachBody" }, [
              el("div", { class: "teachHint" }, [
                "Input places markers. Eraser removes. Use the note rail to choose what you place.",
              ]),

              el("div", { class: "teachRow" }, [
                el("label", { class: "teachRadio" }, [
                  el("input", { type: "radio", name: "eduTool", id: "edu-tool-input", checked: "true" }),
                  el("span", {}, ["Input"]),
                ]),
                el("label", { class: "teachRadio" }, [
                  el("input", { type: "radio", name: "eduTool", id: "edu-tool-erase" }),
                  el("span", {}, ["Eraser"]),
                ]),
              ]),

              el("div", { class: "teachRow" }, [
                el("div", { class: "teachSelected" }, [
                  el("div", { class: "k" }, ["Selected:"]),
                  el("div", { class: "v", id: "edu-selected" }, ["C"]),
                ]),
                el("button", { class: "btn btn-sm", type: "button", id: "edu-clearAll" }, ["Clear All"]),
              ]),

              el("div", { class: "teachSubTitle" }, ["Show Markers"]),
              el("div", { class: "teachRow" }, [
                el("label", { class: "teachCheck" }, [
                  el("input", { type: "checkbox", id: "edu-show-staff", checked: "true" }),
                  el("span", {}, ["Staff"]),
                ]),
                el("label", { class: "teachCheck" }, [
                  el("input", { type: "checkbox", id: "edu-show-tab", checked: "true" }),
                  el("span", {}, ["TAB"]),
                ]),
                el("label", { class: "teachCheck" }, [
                  el("input", { type: "checkbox", id: "edu-show-fret", checked: "true" }),
                  el("span", {}, ["Fretboard"]),
                ]),
              ]),

              el("div", { class: "teachSubTitle" }, ["Clear Surface"]),
              el("div", { class: "teachRow" }, [
                el("button", { class: "btn btn-sm", type: "button", id: "edu-clearStaff" }, ["Staff"]),
                el("button", { class: "btn btn-sm", type: "button", id: "edu-clearTab" }, ["TAB"]),
                el("button", { class: "btn btn-sm", type: "button", id: "edu-clearFret" }, ["Fret"]),
              ]),
            ]),
          ]),
        ]),
      ]),
    ]),

    el("div", { class: "section", "data-tabs": "miscinfo" }, [
      el("div", { class: "block-title" }, ["Misc. Information"]),
      el("div", { class: "tabs compact" }, [
        el("button", { class: "tab active", type: "button", "data-tab": "ach" }, ["Achievements"]),
        el("button", { class: "tab", type: "button", "data-tab": "chord" }, ["Chords"]),
        el("button", { class: "tab", type: "button", "data-tab": "scales" }, ["Scales"]),
        el("button", { class: "tab", type: "button", "data-tab": "lb" }, ["Leaderboard"]),
        el("button", { class: "tab devHidden", type: "button", "data-tab": "dev", id: "misc-dev-tab" }, ["Dev/Test"]),
      ]),
      el("div", { class: "tabpanes" }, [
        el("div", { class: "pane active", "data-pane": "ach" }, [
          el("div", { class: "miscPane" }, ["Achievements placeholder"]),
        ]),
        el("div", { class: "pane", "data-pane": "chord" }, [
          el("div", { class: "miscPane" }, ["Chord library placeholder"]),
        ]),
        el("div", { class: "pane", "data-pane": "scales" }, [
          el("div", { class: "miscPane" }, ["Scale library placeholder"]),
        ]),
        el("div", { class: "pane", "data-pane": "lb" }, [
          el("div", { class: "tabs compact subTabs", "data-tabs": "lbsub" }, [
            el("button", { class: "tab active", type: "button", "data-tab": "match" }, ["Match"]),
            el("button", { class: "tab", type: "button", "data-tab": "high" }, ["High Scores"]),
          ]),
          el("div", { class: "tabpanes" }, [
            el("div", { class: "pane active", "data-pane": "match" }, [
              el("div", { class: "leader-list", id: "leaderboard" }, []),
            ]),
            el("div", { class: "pane", "data-pane": "high" }, [
              el("div", { class: "leader-list", id: "highscores" }, []),
            ]),
          ]),
        ]),

        el("div", { class: "pane", "data-pane": "dev", id: "misc-dev-pane" }, [
          el("div", { class: "paneForm" }, [
            el("div", { class: "formHint" }, ["Dev/Test tools are for rapid testing only."] ),
            el("div", { class: "opsGrid" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "dev-prevPlayer" }, ["Prev Player"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-nextPlayer" }, ["Next Player"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-endTurn" }, ["End Turn"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-clearBoard" }, ["Clear Board"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceInMatch" }, ["Force In-Match"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceLastChance" }, ["Force Last Chance"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceResults" }, ["Force Results"]),
            ]),

            el("div", { class: "subTitle" }, ["Staff/TAB Timeline Stress"]),
            el("div", { class: "opsGrid" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "dev-fillStaffTab" }, ["Fill Window"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-advanceStaffTab" }, ["Advance 1"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-advanceStaffTab16" }, ["Advance 16"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-fillAndShift" }, ["Fill + Shift"]),
            ]),

            el("div", { class: "subTitle" }, ["Mode 3 Truth Table Verification"]),
            el("div", { class: "opsGrid" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "dev-runMode3Strict" }, ["Run (Strict)"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-runMode3Enh" }, ["Run (Enharmonic)"]),
            ]),
            el(
              "textarea",
              {
                id: "dev-mode3Report",
                class: "mono",
                rows: "9",
                spellcheck: "false",
                style: "width:100%; resize:vertical; padding:8px; border-radius:10px; border:1px solid rgba(0,0,0,0.12);",
                placeholder: "Mode 3 matrix verification results will appear here…",
              },
              [],
            ),

            el("div", { class: "subTitle" }, ["Persistence (USB/Offline)"]),
            el("div", { class: "opsGrid" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "dev-exportSave" }, ["Export Save"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-importSave" }, ["Import Save"]),
            ]),
            el(
              "input",
              {
                id: "dev-importSaveFile",
                type: "file",
                accept: "application/json",
                style: "display:none",
              },
              [],
            ),
            el("div", { class: "formHint" }, [
              "Exports a single JSON snapshot (settings + leaderboards). Import replaces local data and writes to IndexedDB.",
            ]),

            el("div", { class: "subTitle" }, ["Paint / Erase"]),
            formRowInline("Enable", [checkboxEl("dev-paintEnabled", false)]),
            formRowInline("Player", [
              selectEl(
                "dev-paintPlayer",
                [
                  { label: "P1", value: "0" },
                  { label: "P2", value: "1" },
                  { label: "P3", value: "2" },
                  { label: "P4", value: "3" },
                  { label: "P5", value: "4" },
                ],
              ),
              selectEl(
                "dev-paintMode",
                [
                  { label: "Paint", value: "paint" },
                  { label: "Erase", value: "erase" },
                ],
              ),
            ]),
            formRow(
              "Lane",
              selectEl(
                "dev-paintLane",
                [
                  { label: "Prompt", value: "prompt" },
                  { label: "Natural", value: "nat" },
                  { label: "Sharp", value: "shr" },
                  { label: "Flat", value: "flt" },
                ],
              ),
              "Click the fretboard to paint/erase claims.",
            ),
            el("div", { class: "formHint" }, ["Tip: Click a rail tile to set the current prompt (dev only)."] ),
          ]),
        ]),
      ]),
    ]),
  ]);

  main.append(left, center, right);

  // Footer
  const footer = el("div", { class: "ge-panel ge-footer" }, [
    el("div", { class: "alerts" }, [
      el("div", { class: "alert-pill" }, ["ALERTS"]),
      el("div", { class: "alert-text", id: "alerts-text" }, ["Ready."]),
    ]),
    el(
      "button",
      {
        class: "badge devQuick devHidden",
        id: "devQuick",
        type: "button",
        title: "Open Dev/Test tools",
      },
      ["DEV"],
    ),
    el(
      "div",
      { class: "badge", id: "buildVersion", title: "Click 5x to unlock Dev/Test tools" },
      ["Build 01_13_26_18"],
    ),
  ]);

  shell.append(launch, main, footer);

    // --- Legacy splash/session overlays removed ---
  // The project now uses the central Start Menu + column flow as the sole entry authority.
  // The prior Splash + Start Setup overlays (including any legacy "mode" selectors) are intentionally removed
  // to prevent regression and duplicated session-routing UI.

// --- Match start overlay (Ready / Engage gate; Turn 1 does NOT begin immediately) ---
  const matchStart = el("div", { class: "matchStartOverlay", id: "matchStartOverlay" }, [
    el("div", { class: "matchStartCard ge-panel" }, [
      el("div", { class: "matchStartTitle" }, ["Ready"]),
      el("div", { class: "matchStartHint", id: "matchStart-hint" }, ["Tap anywhere to engage"]),
      el("div", { class: "matchStartActions" }, [
        el("button", { class: "btn", type: "button", id: "matchStart-engage" }, ["Engage"]),
      ]),
    ]),
  ]);
  shell.append(matchStart);

  // --- Intermission overlay (multiplayer; shown between turns) ---
  const intermission = el("div", { class: "intermissionOverlay", id: "intermissionOverlay" }, [
    el("div", { class: "intermissionCard ge-panel" }, [
      el("div", { class: "intermissionTitle" }, ["Intermission"]),
      el("div", { class: "intermissionNext", id: "intermission-next" }, ["Next: "] ),
      el("div", { class: "intermissionTimer", id: "intermission-timer" }, ["00:00"]),
      el("div", { class: "intermissionHint" }, ["Tap anywhere to start early"]),
      el("div", { class: "intermissionActions" }, [
        el("button", { class: "btn", type: "button", id: "intermission-start" }, ["Start Turn"]),
      ]),
    ]),
  ]);
  shell.append(intermission);

  // --- Staff accidental prompt overlay (Natural / Sharp / Flat) ---
  const acc = el("div", { class: "accidentalOverlay", id: "accidentalOverlay", hidden: "true" }, [
    el("div", { class: "accidentalCard ge-panel" }, [
      el("div", { class: "accidentalTitle" }, ["Staff Accidental"]),
      el("div", { class: "accidentalHint" }, ["Select the accidental for this staff mark."]),
      el("div", { class: "accidentalActions" }, [
        el("button", { class: "btn btn-sm", type: "button", id: "accidental-natural" }, ["Natural ♮"]),
        el("button", { class: "btn btn-sm", type: "button", id: "accidental-sharp" }, ["Sharp ♯"]),
        el("button", { class: "btn btn-sm", type: "button", id: "accidental-flat" }, ["Flat ♭"]),
      ]),
      el("div", { style: "height:10px" }),
      el("div", { class: "accidentalActions" }, [
        el("button", { class: "btn btn-sm", type: "button", id: "accidental-cancel" }, ["Cancel"]),
      ]),
    ]),
  ]);
  shell.append(acc);

  target.replaceChildren(shell);

  wireTabs(shell);
  buildKeypad();
}
