## Build: guitar-edu-ui_01_13_26_20

- Docs: Added a task-ID gap policy and ledger.
  - Added `DOCS/RETIRED_TASK_IDS.md` (currently records all undefined IDs as **Unassigned**).
  - Linked the ledger from `CHECKLIST.md`.
- Docs: Updated `CANON_PROGRESS.md` build package reference to `guitar-edu-ui_01_13_26_19.zip`.

## Build: guitar-edu-ui_01_13_26_19

- Docs: Reconciled `MATCH_SETTINGS_SPEC.md` with `DOCS/ADVANCED_MATCH_OPTIONS_UI_MAPPING.md`.
  - Added **Arpeggios** to Learning Type.
  - Canonized **Input Method** as a match setting (interaction granularity only).
  - Expanded **Domain Constraints** in spec (string range, span, notes-per-string, position scope).
  - Expanded **Timing Rules** to include disabled state + time bank/intermission/increments/penalties/runtime cap.
  - Canonized **Randomization** rules (opt-in; embedded; no global toggle).
  - Placed **Failure Conditions**, **Bonus Phase**, and **Roman Numeral Interval System** in Advanced Match Options mapping.

## Build: guitar-edu-ui_01_13_26_03

- Lexicon: Removed the deprecated "combined" label from `ModeId` (kept the legacy internal value for backward compatibility).
- Note Rail: Default layer state now treats the rail as a **prompt-first** surface (`asked` ON, `answered` OFF by default). This avoids implying rail history persistence while keeping the prompt highlight active.

## Build: guitar-edu-ui_01_13_26_05

- Docs: Added `DOCS/DEPRECATED_TERMS.md` to enumerate obsolete terms and disallowed regressions (no numbered “modes”, no “combined mode”, no treating asked/answered/view as rules).
- Docs: Added `MATCH_SETTINGS_SPEC.md` into the archive and expanded match settings details for learning structures, timing, accuracy, failure, and bonus requirements.

## Build: guitar-edu-ui_01_13_26_01

- Splash: Selecting a session now opens a **Start Setup** gate (content/mode/root/fret range) instead of immediately starting a match.
- Start Setup: Applies selections into the existing canonical settings controls and then dispatches `gedu:beginSession`.
- Compatibility: `gedu:splashSelect` is still supported in the controller for older builds.

## Build: guitar-edu-ui_01_12_26_14

- Platform: Added **PWA** support (manifest + service worker) via `vite-plugin-pwa`.
- Offline: Defined current offline asset boundary (static build + required public assets) in `DOCS/PLATFORM_STRATEGY.md`.
- Persistence: Added IndexedDB snapshot (settings + leaderboards) with **Export Save / Import Save** tools in Dev/Test panel.
- Bootstrap: App hydrates local state from IndexedDB on load (without breaking existing localStorage keys).

## Build: guitar-edu-ui_01_12_26_13

- E2E: Playwright now runs against **built output** via `vite preview` on **port 4173** (shipping-aligned; reduces Windows/Node optional-dep flakiness).
- E2E: Added `start-server-and-test` and updated `npm run e2e` / `npm run e2e:ui` to: `build -> preview -> playwright`.
- Docs: Updated `TESTING.md` to document preview-based E2E behavior and baseURL override.

## Build: guitar-edu-ui_01_12_26_12

- Docs: Added `DOCS/PLATFORM_STRATEGY.md` defining the shipping architecture: **Web + PWA + Desktop (Tauri)** from one codebase.
- Docs: Recorded the decision in `DECISIONS_LOG.md` and progress notes in `CANON_PROGRESS.md`.

## Build: guitar-edu-ui_01_12_26_11

- Hotfix: Windows one-click dev runner now guarantees `npm run dev` executes and logs output (removed fragile PowerShell Tee-Object invocation; runner uses direct `call npm run dev >> logs\devserver.log`).
- Hotfix: RUN_DEV logging block repaired and paths normalized (backslashes).

## Build: guitar-edu-ui_01_12_26_10

- Fixed `RUN_DEV.bat` dev-server launch on Windows by removing fragile nested-quote `start ... cmd /k "..."` invocation.
- Added `DEVSERVER_RUNNER.bat` to run `npm run dev` in the Dev Server window while teeing output into `logs/devserver.log`.
- `RUN_DEV.bat` now launches the runner directly and logs the step to `logs/run_dev.log`.

## Build: guitar-edu-ui_01_12_26_09

- One-click runners now write always-on logs to `./logs/`:
  - `run_dev.log`, `devserver.log`, `run_tests.log`
- `RUN_DEV.bat` port-probe made silent to avoid noisy console output.


## Build: guitar-edu-ui_01_11_26_10

- Mode 3: added explicit STAFF spelling policy toggle (Strict vs Allow Enharmonic).
- Staff overlay: improved chord accidental positioning to avoid collisions with clustered noteheads.
- Staff overlay: pending STAFF marks now render (preview-only) with lighter styling.

## Build: guitar-edu-ui_01_11_26_13

- Dev/Test access hardened: footer **DEV** button appears when unlocked and opens Dev/Test pane.
- TAB persistence bug fix: incomplete TAB entries (null fret) are never committed into accepted history.
- Increased first-measure playable inset to prevent early-slot note collisions with clef / TAB label.

## Build: guitar-edu-ui_01_12_26_01

### Phase A — Unit Tests (Vitest)

- Added Vitest unit test harness (`vitest.config.ts`) and `tests/unit/` suite.
- Timeline shift-left correctness: accepted + pending maps shift together; oldest drops; cursor behavior validated.
- Commit gate: accepted history only mutates on successful composite acceptance; pending never leaks into accepted.
- Mode 3 spelling policy truth table tests (Strict vs Enharmonic).
- TAB stacking tests: multi-string slots persist and shift correctly.
- Ledger preview constraint test: clip groups exist so staff/ledger visuals cannot bleed into TAB.

### Developer workflow

- Added `npm run test` (watch) and `npm run test:ci` (one-shot).

## Build: guitar-edu-ui_01_12_26_03

- Fixed unit test harness enum usage so Mode 3 spelling tests run against the same `SlotType` enum used by runtime logic.
- Result: `npm run test:ci` passes cleanly (9/9 tests).

## Build: guitar-edu-ui_01_12_26_04

### Phase B — E2E Tests (Playwright)

- Added Playwright E2E harness (`playwright.config.ts`) and `tests/e2e/` suite.
- E2E coverage:
  - Dev unlock: 5-click build badge **and** Ctrl+Shift+D; footer DEV opens Dev/Test panel.

## Build: guitar-edu-ui_01_12_26_05

### Phase C — One-Click Runner (Windows)

- Added **RUN_DEV.bat** at repo root:
  - installs dependencies if needed
  - starts the dev server
  - opens the app in the default browser (Vite default: `http://localhost:5173`)
- Added **RUN_TESTS.bat** at repo root:
  - installs dependencies if needed
  - ensures Playwright browsers are installed
  - runs `npm run test:ci` then `npm run e2e` (headless)
- Updated `TESTING.md` to document the one-click workflow.
  - RUN_DEV and RUN_TESTS usage notes.

# Changelog

Canon zip-to-zip changes for the Guitar Education Game UI.

## 2026-01-11 — Patch 01_11_26_09
- Phase 3 correctness (Mode 3 triangle) on top of accepted-marks persistence:
  - STAFF is authoritative when required: staff letter + chosen accidental must match prompt pitch and spelling (black-key sharp/flat strict; white keys natural).
  - When TAB + FRET are both required, enforce exact string+fret match (TAB authoritative for position).
  - Commit pipeline hardened: snapshot pending staff/tab marks before reducer effects can clear previews; commit snapshot only after successful composite validation.
## 2026-01-11 — Patch 01_11_26_05
- Removed all remaining **Pause** references (legacy controller + leaderboard comment).
  - Internal interaction gating is now referred to as **freeze** (used only for Ready/Engage and safe transitions).
- Enforced A-contract: **Staff/TAB remain spatially static** (removed UI-mode viewBox crop/zoom behavior).
- Extended **Surface Layers** (Display / Prompt / Marks) to all three domains:
  - Staff/TAB: Display toggles the notation grid, Prompt toggles hover/selection, Marks toggles accepted marks visibility.
  - Fretboard: Marks toggles claimed dots, Display toggles learning labels, Prompt toggles SAM/pulse overlays.


## 2026-01-10 — Patch 01_10_26_16
- Fixed a phase constant mismatch that disabled input gating (`in_match` vs `IN_MATCH`).
- Implemented a **Surface Input Matrix** to define, per UI mode, which surfaces are required, accept input, and show placed marks.
- Added composite submission logic so **Staff drives pitch**, and (when required) **Fret + Tab must match** the same string/fret.
- Implemented TAB entry ordering: **string → fret** or **fret → string**, including retaining the selected TAB column.
- Fixed TAB default number handling to avoid null/default rendering issues.
- Cleaned up Staff+Tab overlay mark visibility toggling per UI mode.

## 2026-01-10 — Patch 01_10_26_17
- Aligned the Staff+Tab stage container id (`staffTabStage`) with the controller so surface-matrix gating applies reliably.
- Added **Surface Layers** checkboxes (**View / Asked / Answered**) and wired them into gameplay mark visibility (visual only; surfaces remain present).
- Added `rail.setLayers()` with view-layer label hiding and asked-layer target highlighting control.

## 2026-01-10 — Patch 01_10_26_18
- Renamed Surface Layers UI labels to **Display / Prompt / Marks** (was **View / Asked / Answered**) without changing underlying preference keys.

## 2026-01-10 — Patch 01_10_26_19
- Staff+TAB overlay: fixed geometry extraction for the 3-measure blank staff/TAB template.
  - Normalize STAFF to the core **5 lines** (for correct treble-line letter mapping).
  - Derive measure spans from repeated long line segments (robust even with shortened left-most measure lines for clef/TAB label).
  - Stabilizes column math and prevents TAB number placement from collapsing into a tiny segment.
  - Added a safe fallback `getBlank3MeasureStaffTabLayout()` so the overlay can stay correct even if the background is swapped to a raster asset (no SVG line primitives).

## 2026-01-10 — Patch 01_10_26_20
- Added root **`README.md`** as the canonical repo entrypoint.
- Documented the required **Thread Boot Protocol** and canon-doc read order to prevent cross-thread drift.
- Added **`CANON_PROGRESS.md`** to pin “where we are in the canon list” (A1.xx alignment crosswalk) and keep progress visible in the repo.

## 2026-01-10 — Patch 01_10_26_22
- Added a meta backlog bucket: **E) Refinements, Adjustments, and Fine Tuning** in `CANON_PROGRESS.md` to track recurring rendering/UX polish items and prevent regressions.
- Updated `README.md` to include `CANON_PROGRESS.md` in the canon-doc read order and highlight the Refinements bucket during Thread Boot.

## 2026-01-10 — Patch 01_10_26_23
- Added a multiplayer **Intermission overlay** that visibly represents the `INTERMISSION` phase between turns.
- Overlay includes a countdown timer and supports **tap/button to start the next turn early**.
- Turn start now explicitly clears intermission UI/timers to prevent stuck overlay states.

## 2026-01-10 — Patch 01_10_26_24
- Fixed missing TURN countdown: the engine now emits `TURN_STARTED` so the controller starts the turn timer reliably.
- Intermission countdown: default increased to **5 seconds** and countdown formatting now avoids displaying `00:00` while time remains.
- Surface Matrix: Mode 3 (TAB) now requires the player to also select the matching **Fretboard** position before submission.
- Staff/TAB hover feedback: replaced full-column shading with a thin alignment line and a local hover box to reduce “marking the whole staff” confusion.

## 2026-01-11 — Patch 01_10_26_25
- **Mode 3 composite correctness:** TAB + FRET no longer require the *same string/fret*; instead, each required answer surface must match the **prompt pitch** (staff-driven when staff is required).
  - Prevents false mismatches when multiple correct positions exist for the same note.
  - Ensures TAB-only or FRET-only entry can’t “override” the other; both required surfaces must be correct before submission.
- Composite submission now uses the **most recently updated answer surface** (TAB vs FRET) when dispatching to the engine.
- Added a lightweight **pending fretboard selection ring** during composite entry to reduce “no answer registered” confusion.

## 2026-01-11 — Patch 01_10_26_26
- **TAB entry no longer auto-stamps `0`:** if a TAB slot is clicked without a chosen fret, the overlay shows a **pending slot** (outline) and waits for an explicit fret number.
- TAB keypad selection and "selected" highlight now stay in sync even if the selection is set indirectly.
- Turn/prompt resets now clear TAB keypad state cleanly (prevents stale-number carryover between prompts).

## 2026-01-11 — Patch 01_11_26_02
- **Pause removed entirely:** removed the Pause button and pause event handling (no user-facing pause control).
- Added a **Ready/Engage overlay** so Turn 1 does not start immediately after starting a match.
  - Engage starts the match clock and starts the appropriate timer behavior.
- **Timer settings are now stored in seconds** (`turnSec`, `intermissionSec`) and converted to milliseconds only when scheduling.
- Single-player timer display is now a **stopwatch** (time-to-complete) by default.
- Added `THREAD_HANDOFF.md` and updated `CANON_PROGRESS.md` build package marker.

## 2026-01-11 — Patch 01_11_26_04
- **Staff/TAB timeline persistence (foundation):** STAFF/TAB marks are no longer cleared on each turn.
  - Marks persist as a running record until the visible area fills.
  - When full, the timeline scrolls left by one 8th-note slot (spatially static; no viewBox changes).
- **Default notation grid is now 4/4 in 8th-note slots:** `columnsPerMeasure = 8`.
- STAFF marks now support **multiple noteheads per rhythmic slot** (fan-out for legibility).
- STAFF/TAB horizontal placement during match uses a **timeline cursor** rather than click-x position.

## 2026-01-11 — Patch 01_11_26_06
- **Mode 3 correctness tightened (TAB ↔ FRET alignment):** when UI Mode is `m3` (TAB mode), the required fretboard pick must match the TAB selection **exactly** (same string + same fret), not just the pitch class.
  - Uses the existing accepted-marks pipeline: accepted TAB entries persist in the timeline; failed composite attempts clear only the transient slot.

## 2026-01-11 — Patch 01_11_26_07
- **Phase 1.1: Timeline persistence stress tools:** added Dev/Test buttons to auto-fill the STAFF/TAB window and simulate shift-left beyond capacity.
- **Phase 1.2: Stacking rules:** TAB now supports **multiple strings per rhythmic slot** (chord-style tablature). Rendering remains spatially static and subdivision-aligned.

## 2026-01-11 — Patch 01_11_26_08
- **Accepted-marks persistence pipeline implemented:** STAFF/TAB clicks now create **pending (preview) marks** that do *not* become part of the persistent record until the composite answer is accepted.
  - Pending previews render in separate overlay layers (`geduStaffPending`, `geduTabPending`) and obey the **Asked** checkbox layer.
  - On accepted composite submission, pending marks for the active slot are committed to the persistent record, then the timeline cursor advances.
  - On prompt/turn change or failed attempt, pending previews are cleared while accepted history remains.
- **Shift-left pipeline extended:** when the visible STAFF/TAB area is full, shift-left now also reindexes any pending previews safely.

## 2026-01-11 — Patch 01_11_26_11
- **Ledger-line preview + dense-range rules:**
  - STAFF ledger lines are now **union-rendered per rhythmic slot** (no double-drawing when multiple chord tones share the same ledger positions).
  - Pending STAFF marks now include ledger-line preview when above/below the 5-line staff.
  - Hovering a STAFF cell now shows **ledger-line preview** for that placement (clipped to the STAFF region).
- **Dev/Test: Mode 3 matrix verification:** added buttons in Dev/Test to run a deterministic Mode 3 truth-table report for **Strict** vs **Enharmonic** spelling policies.

## 2026-01-11 — Patch 01_11_26_12
- **Dev/Test access restored (failsafe unlock):** added a clickable build badge in the footer. Click **5x** (or press **Ctrl+Shift+D**) to unlock Dev/Test tools even if menus regress.
- **Notation lead-in spacing:** the first measure now reserves a lead-in region so the first rhythmic slot does not collide with the treble clef / "TAB" label.
  - Implemented as a constant inset on measure 1's playable x-range (STAFF/TAB remain spatially static; no viewBox cropping).

## Build: guitar-edu-ui_01_12_26_02

- Unit tests: fixed SlotType import path so Mode 3 spelling policy tests run correctly.

## Build: guitar-edu-ui_01_12_26_03

- Mode 3 Strict spelling: enforce **naturals on white keys** (both prompt spelling and STAFF entry must be NAT).
- Fix: eliminate undefined-branch crash surfaced by unit tests (SlotType.NAT access).



## Build: guitar-edu-ui_01_12_26_04

- Phase B: added Playwright E2E harness and minimal real E2E coverage (Dev unlock, staff accidental commit, shift-left stress, Mode 3 strict/enharmonic).

## Build: guitar-edu-ui_01_12_26_05

- Phase C: added one-click Windows runners (RUN_DEV.bat, RUN_TESTS.bat).

## Build: guitar-edu-ui_01_12_26_06

- Patch: RUN_DEV.bat now waits for the dev server to become reachable and opens the first responding localhost port (5173–5180).
- Patch: RUN_DEV.bat logs Vite output to devserver.log for diagnostics.

## Build: guitar-edu-ui_01_12_26_07

- Patch: RUN_DEV.bat now anchors to its own folder, fully quotes paths, and starts Vite without fragile output redirection.
- Patch: Browser auto-open probes ports 5173–5180 after launching the dev server (more reliable on Windows).

## Build: guitar-edu-ui_01_12_26_08

- Patch: RUN_DEV.bat detects Node major version and, on Node >= 23, automatically uses an optional-dependency install flow and performs a Rollup load sanity check.
- Patch: If Rollup native deps are missing on Windows (common optional-deps issue), RUN_DEV.bat runs an automated repair (clean install with `--include=optional` + `npm rebuild rollup`).


## 01_12_26_15
- Added RUN_PREVIEW.bat (one-click build + vite preview + auto-open browser) with logging to logs/run_preview.log.

## Build: guitar-edu-ui_01_13_26_02

- Phase 1: STAFF chord stacking enabled within a single timeline slot.
  - STAFF clicks no longer clear other pending marks in the same column.
  - Clicking the same STAFF step again toggles that note off (keeps single-note entry simple while enabling chords).
  - Accidental prompt commit respects chord stacking (does not clear other pending marks).
