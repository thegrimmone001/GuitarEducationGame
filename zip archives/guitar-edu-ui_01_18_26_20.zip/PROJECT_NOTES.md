# GUITAR LEARNING GAME — PROJECT NOTES (Living Document)

## 1) Core vision
This application is a **guitar-focused educational game** that teaches the relationship between:
- **Fretboard**
- **Music Staff**
- **Tablature (TAB)**

The system must be **bidirectional**:
- Staff/TAB → Fretboard
- Fretboard → Staff/TAB

The goal is transferable literacy between representations.

## 2) Game sessions (top-level)
1. **Education Mode (Instructor / Teaching Tool)**
2. **Single-Player Mode (Learning & Practice)**
3. **Multiplayer Mode (Competitive / Social)**

## 3) Education Mode (Instructor)
Education Mode is an **interactive teaching surface** and is not governed by fairness constraints.

Required capabilities:
- **Input Mode**: Place notes/chords/scales/arpeggios on staff, TAB, or fretboard
- **Eraser Mode**: Remove placed items
- **Surface toggles**: Show/Hide markings independently on:
  - Staff
  - TAB
  - Fretboard
- **Clear** functions:
  - Clear staff
  - Clear TAB
  - Clear fretboard
  - Clear all

Instructor placement workflows (must support multiple directions):
- Choose a **note** and place it on staff / TAB / fretboard
- Choose a **chord** and place it on staff / TAB / fretboard
- Choose a **scale** and place it on staff / TAB / fretboard
- Choose an **arpeggio** and place it on staff / TAB / fretboard

Library-driven building (Education Mode):
- Selecting a root + quality shows a **live preview** of chord/scale tones
- Optional “placement GUI” can allow choosing:
  - shape
  - position
  - inversion/voicing

## 4) Single-Player Mode
Single-player is learning oriented.
- Tokens may be used for **buying time** (if enabled)
- No competitive stealing
- Bonus logic (if any) must be **explicitly defined** and must not be assumed

## 5) Multiplayer Mode
Multiplayer is competitive and turn-based.
Core concepts:
- Finding notes reveals them
- When a structure/pattern reaches its unlock condition (explicitly defined per mode), its notes may become **stealable**

Tokens in multiplayer are used for:
- **Stealing notes** (as defined by the mode rules)
- **Buying time** (if enabled)

No hidden mechanics.

## 6) Tokens
- Players start with **0 tokens by default**
- Starting tokens are configurable in main menu settings
- Tokens are not auto-earned via invented mechanics (e.g., no streak-to-token rule unless explicitly defined)

Token usage is restricted to:
- Buy time
- Steal notes (multiplayer)

## 7) Bonus / special phases
- There is **NO** automatic bonus for “finding all notes” unless explicitly defined
- Completion/unlock behavior is tied to the multiplayer stealing mechanic, not an assumed bonus
- If/when a Bonus Phase exists, it must have:
  - A defined activation rule per mode
  - A defined objective
  - A defined scoring / token interaction rule

## 8) Board states
At minimum:
- **Normal board state**: active gameplay / discovery
- **Bonus or Special board state**: distinct visuals, read-only evidence view unless rules say otherwise

Board states must share the same underlying musical truth.

## 9) Representation rules
### TAB
- TAB must render **string + fret numbers** (no dots)
- Placement must snap to string lines

### Staff
- Staff placement must align to staff positions (lines/spaces + ledger when implemented)
- Ultimately must include clef placement, key signatures, time signatures, and rhythmic alignment

### Multiple correct answers
- A staff pitch can map to multiple fretboard/TAB positions
- The engine must support multiple valid answers

### Shapes
- A physical shape/pattern is treated as a distinct object
- A shape may be reused in a different position for a different identity (e.g., transposed)
- Some advanced chords may have multiple valid names; naming variations may award bonus points only when explicitly enabled

## 10) Libraries
Planned libraries:
- Chord Library
- Scale Library
- Arpeggio Library

Expected behavior:
- Selecting a root highlights related notes
- Selecting a quality/type refines the tone set
- Optional placement GUI chooses shape/position/inversion

## 11) Metadata & analytics (future)
Planned collection:
- “Found first / found last” locations
- Common misses
- Difficulty heatmaps (fretboard/staff/TAB)
- Instructor insights and adaptive learning (future)

## 12) Longer-term ideas (not implemented)
- Guitar Pro file import for song lessons
- Microphone input / pitch detection
- MIDI playback with high-quality guitar sound fonts
- Optional piano keyboard / piano roll UI
- Cosmetic customization:
  - menu themes (wood/stone/metal)
  - fretboard wood + inlays

## 13) Guardrails
- This document is a **source of truth**.
- New mechanics must be **proposed and approved** before implementation.
- Avoid inventing scoring, triggers, or defaults that were not defined.



## 14) Operational invariants (canon)
- **No Pause.** A match is either **Ready** (not running) or **Running**.
- Selecting Education/Single/Multiplayer should never auto-start a match; it enters **Ready** and requires **Start** to begin the first turn.
- **End** terminates the current match instance cleanly and returns to Splash.
- System/settings menus that are not required during play should remain on the Splash screen to preserve play space.
- Dev/Test tools may be present but must be **deliberately revealed** (e.g., hidden 5-click unlock) and disappear when disabled.
- Runtime test cadence: run smoke/runtime tests every 15 build iterations starting at build 90 (90, 105, 120, ...).
