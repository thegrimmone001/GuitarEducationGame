# Changelog (project zips)

## 2026-01-18
- Bonus phase now exists as a distinct, visible phase (BONUS) triggered when a player earns connect score or mints tokens.
- Added dev control to force BONUS phase.
- Added bonus banner UI and timer-driven END_BONUS handoff into intermission/next turn.


## Step 14.8 (GEG-B1 Vulnerability after misses)
- Added miss-streak tracking per prompt variant; after **3 consecutive misses** on the same prompt, one owned cell for that prompt becomes **vulnerable**.
- Vulnerable fret cells now **blink** (CSS animation) to reflect canon.
- Added `steal.vulnerableAfterMisses` to settings (default: 3).
- Appended CC-0009 and CC-0010 to `DOCS/conversation_composite.json`.

## Step 14.1 (Regression cleanup)
- Replaced fretboard SVG with `Guitar_FretBoard_Horizontal-Complete_v2i.svg` content (better aligned hitbox art).
- Restored Note Visibility selector to include **All** and set default to **All**.
- Restored controller defaults for `core.noteVisibility` to **all** (was regressed to naturals).
- Fixed minor indentation regression in controller settings change handler.
- Confirmed project zips must not include `node_modules/` or `dist/`.

## Step 14.2 (GEG-016 Starting tokens)
- Implemented UI coupling between Token Cap and Starting Tokens so Start is clamped to Cap in real time (Main Menu Settings).
- Marked **GEG-016** complete in CHECKLIST.md.

## Step 14.3 (GEG-020 Player card timer)
- Verified Player Card contains avatar, score, tokens, and turn timer display.
- Marked **GEG-020** complete in CHECKLIST.md.

## Step 14.4 (GEG-022 Active players only)
- Added a Multiplayer player-count selector to the splash screen (2–5).
- Match init now uses the selected player count so the in-match leaderboard renders only active players.
- Marked **GEG-022** complete in CHECKLIST.md.

## Step 14.5 (Multiplayer cap correction)
- Corrected accidental Multiplayer hard-cap (2–5) by raising the upper bound to **2–12**.
- Centralized the Multiplayer upper bound in `src/app/constants.ts` so UI + engine stay in sync.
- Preserved GEG-022 behavior: leaderboard still renders **active players only** (no empty slots).

## Step 14.6 (GEG-023 Persistent high scores)
- Confirmed the persistent High Score Board is wired to local storage via `src/shell/storage.ts` and is rendered in the Utility area under **Misc. Information → Leaderboard → High Scores**.
- Marked **GEG-023** complete in CHECKLIST.md.

## Step 14.7 (GEG-030/031 Mode selector compliance)
- Verified Game Mode selector (Modes 1–5) drives surface visibility per locked spec.
- Fixed Staff/Tab panel mode-disable styling and input gating by adding `staffSection` class to the Staff+Tab section.
- Marked **GEG-030** and **GEG-031** complete in CHECKLIST.md.


## Step 14.8 (Surface controls replace legacy board-selection modes)
- Removed the legacy surface-selection “mode” concept from canon: **Mode** is reserved for musical modes only.
- Added **Surface Controls → In Play** toggles in Core Settings (Fretboard / Note Rail / Staff / TAB).
- Surface toggles now gate both **rendering** and **allowed input** for Staff/TAB/Rail.
- Notation View remains a display crop only (Staff Only / TAB Only / Staff+TAB).
- Updated CHECKLIST Section D: marked GEG-030/031 as deprecated; marked GEG-032 complete.

## Step 14.9 (GEG-040 Learning difficulty labels)
- Confirmed Learning difficulty renders **all note labels** across the fretboard (including grayed-out range) while keeping hitboxes interactive (labels are `pointer-events:none`).
- Verified normal play actions remain available in Learning difficulty (claim/highlight, connect-segments, token awards).
- Marked **GEG-040** complete in CHECKLIST.md.

## Step 14.10 (GEG-041 SAM reveal options)
- Added **SAM Reveal** selector in Core Settings with `single` (best/closest) and `multiple` (all correct) options.
- Wired selector to `settings.feedback.samRevealMode` via `#core-sam` (mapped to `single` vs `all`).
- Marked **GEG-041** complete in CHECKLIST.md.

## Step 14.11 (GEG-041 SAM equivalents)
- Updated SAM options to the flushed-out spec: **Single**, **Equivalent (same pitch)**, **All**.
- Removed the deprecated “Multiple” label/value from the Core Settings selector.
- Extended the engine SAM pulse to support `samRevealMode: "equiv"`, revealing all actionable targets for the same pitch across allowed spellings.

## Step 14.12 (GEG-042 Default fret range)
- Set the default fret range to **min 0, max 12**, with **13 frets visible** by default.
- Updated controller defaults to respect the checklist defaults when settings are not yet stored.
- Marked **GEG-042** complete in CHECKLIST.md.

## Step 14.13 (Conversation composite added)
- Added `DOCS/conversation_composite.json` as the project-scoped, minimal canon record (append-only) capturing only implementation-relevant conversation decisions.
- Intended to be read/validated before each checklist step to prevent drift.

## Step 14.14 (GEG-043 Note visibility modes)
- Standardized Note Visibility enum values to: `all`, `natural`, `enharmonic`.
- Note Rail now reflects note visibility:
  - `natural` hides accidentals
  - `enharmonic` hides naturals and shows enharmonic spellings for accidentals
  - `all` shows all notes
- Fretboard label visibility remains driven by `variants.allowed`, so labels follow the same Note Visibility filter.
- Marked **GEG-043** complete in CHECKLIST.md.

## Step 14.15 (GEG-044 Extended tone highlighting)
- Expanded the Highlight Tones system to include **9th / 11th / 13th** (in addition to Root/3/5/7).
- Implemented the educational highlight overlay on the fretboard: selected tones are rendered as subtle rings behind ownership dots.
- Extended Chord Display → Extension options to include **11th** and **13th** for forward compatibility.
- Marked **GEG-044** complete in CHECKLIST.md.

## Step 14.16 (GEG-045 Note display options)
- Updated Core Settings → Display to the locked, global options: **Note Names / Numbers / Intervals / Interval Roman**.
- Implemented the new `numbers` display mode (degree-style labels: 1, ♭2, 2, ♭3, 3, 4, ♯4, 5, ♭6, 6, ♭7, 7) across the note rail and prompt labels.
- Deprecated legacy `romanIntervals` display mode by mapping it to `intervalRoman` for back-compat (no UI exposure).
- Marked **GEG-045** complete in CHECKLIST.md.

## Step 14.17 (Roman note display added)
- Added Core Settings → Display option: **Roman (Scale Degree)**, distinct from **Interval Roman** (Roman Numeral Interval System).
- Implemented Roman (scale-degree/function) labels across the Note Rail, prompt labels, and rail label resolver.
- Updated `DOCS/conversation_composite.json` with the canon decision for this distinction.

## Step 14.18 (GEG-050 Staff hover alignment)
- Improved the Staff hover overlay to visually confirm snapping to staff **lines/spaces** by adding a precision guide line at the snapped center.
- Click placement continues to snap to the same staff line/space grid (including ledger steps) using the shared hit-grid.
- Marked **GEG-050** complete in CHECKLIST.md.

## Step 14.19 (GEG-051 TAB hover alignment)
- Improved the TAB hover overlay to visually confirm snapping to **string lines** (string band center) and **measure subdivisions** (column center).
- Added precision guides on TAB hover: horizontal guide at snapped string center and vertical guide at snapped column center.
- Click placement continues to snap to the same subdivision column centers used by the shared STAFF+TAB timeline grid.
- Marked **GEG-051** complete in CHECKLIST.md.

## Step 14.20 (GEG-052 TAB input order)
- Confirmed TAB entry supports both input orders:
  - **select string → pick fret** (string pick arms TAB, keypad pick commits)
  - **pick fret → select string** (keypad pick arms TAB, string pick commits)
- Implementation is handled by the paired event handlers `gedu:fretPick` and `gedu:staffPick` (TAB region) in `src/app/gameController.ts`.
- Marked **GEG-052** complete in CHECKLIST.md.

## Step 14.21 (GEG-052 TAB digit visibility)
- Adjusted STAFF+TAB overlay z-order so hover indicators never obscure **TAB fret digits**.
- Enforced group order: grid (bottom) → hover (middle) → marks (top) in `src/shell/staffTabOverlay.ts`.

## Step 14.22 (GEG-051a Shared subdivision timeline)
- Confirmed STAFF + TAB share a single subdivision timeline grid rendered across both regions.
- Hover indicates the active subdivision column across both Staff and TAB using one snapped column center.
- Click placement on both surfaces uses the same snapped column mapping.
- Marked **GEG-051a** complete in CHECKLIST.md.

## Step 14.23 (GEG-053 Keypad bounds)
- Enforced strict fret bounds for `gedu:fretPick`: accept only **0–24** and reject **25+** (and negatives) rather than clamping.
- Marked **GEG-053** complete in CHECKLIST.md.

## Step 14.24 (GEG-054 Multiple valid answers)
- Implemented clean handling for multiple valid answers on the fretboard.
- Normal taps now accept any location matching the prompt pitch class, and for black-key prompts will claim the cell in either the prompt spelling lane or the opposite enharmonic lane when that lane is allowed/visible.
- Steal attempts now prefer the prompt spelling lane but can also target the opposite enharmonic lane when it is allowed and the cell is stealable there.
- Added helper `promptEquivalentLanes(...)` to centralize lane-equivalence resolution.
- Marked **GEG-054** complete in CHECKLIST.md.

## Step 14.25 (GEG-055 Mirroring behavior)
- Added **Core Settings → Mirroring** selector: `Placed (default)` or `Off`.
- Canon: Learning difficulty forces Mirroring to `Placed`.
- Successful fretboard claims now auto-place corresponding marks onto the shared STAFF+TAB subdivision grid:
  - TAB mark stores the selected **string + fret**
  - STAFF mark uses a deterministic pitch-class → staff-step mapping (placeholder until true pitch-octave staff mapping is introduced)
- Marked **GEG-055** complete in CHECKLIST.md.

## Step 14.26 (GEG-060 Note Rail compass loop)
- Implemented the Note Rail as a true compass-style strip:
  - Current note remains centered (index 12) with a **two-octave / 25-cell** window.
  - Added a fixed **center marker** so the "centered" target is visually unambiguous.
  - Added short, semitone-step **slide animation** (shortest delta, small jumps only) to create the "endless loop" illusion when prompts advance.
- Marked **GEG-060** complete in CHECKLIST.md.

## Step 14.27 (GEG-061 Rail mode by context)
- Canonized rail behavior by prompt context:
  - **Chromatic / Accidentals** use the **rotating compass** rail (current prompt centered).
  - **Key / Scale / Chord contexts** use the **fixed reference** rail (anchored to the context root).
- Implemented the rule in `updatePromptUi()` by choosing rail mode from `promptProfileId`.
- Marked **GEG-061** complete in CHECKLIST.md.

## Step 14.28 (GEG-062 Rail label overflow containment)
- Ensured Note Rail labels never overflow their cells:
  - `railLabel` is now a full-size, centered flex container with `overflow:hidden` and `white-space:nowrap`.
  - Split enharmonic labels (sharp/flat) are slightly reduced in size to guarantee they fit.
  - The half-block indicator is an absolute overlay so it never participates in layout or pushes labels.
- Marked **GEG-062** complete in CHECKLIST.md.

## Step 14.29 (GEG-063 Rail as input surface)
- Rail clicks now emit a dedicated `gedu:railPick` event in addition to selection.
- The controller maps the clicked note's pitch-class to the first enabled in-domain fretboard cell and dispatches a `TAP_CELL` attempt.
  - This enables rail-only note guessing when the fretboard prompt/display is reduced by surface controls.
- Marked **GEG-063** complete in CHECKLIST.md.

## Step 14.30 (GEG-064 Rail unified input pipeline)
- Rail pick input now routes through a single engine action: `TAP_VARIANT`.
- The engine resolves the picked variant into an actionable in-domain fretboard placement, applying the same tap rules as direct cell taps.
- Controller gates rail-pick gameplay by Surface Controls (rail must be in play; fretboard must be in play for placement resolution).
- Marked **GEG-064** complete in CHECKLIST.md.


## Step 14.31 (GEG-070 Interval Roman display format)
- Verified Interval Roman display formatting matches canon: `I, ii, II, iii, III, IV, (tritone), V, vi, VI, vii, VII`.
- Confirmed consistent formatting in both the Note Rail label resolver and the global label resolver.
- Marked **GEG-070** complete in CHECKLIST.md.

## Step 14.32 (GEG-071/072 Tritone label options + context resolution)
- Updated Tritone label preference to expose all canon options:
  - `+/o` (default)
  - `TT`
  - `#IV / ♭V`
  - `+IV / oV`
  - `Auto (context)`
- Implemented full tritone rendering support for both Interval Roman and Roman (Scale Degree) labels.
- Improved **Auto** resolution to prefer `#IV` in Lydian contexts and `♭V` in Locrian contexts, otherwise leaning by key signature (flat keys prefer `♭V`).
- Added back-compat normalization for legacy stored values (e.g., `sharp4`, `flat5`).
- Marked **GEG-071** and **GEG-072** complete in CHECKLIST.md.

## Step 14.33 (Utility Intent Contracts: presentation vs utility, pause removal, prefs)
- Removed **Pause** from Operations (Pause is non-canon; end-of-match and intermission/ready states handle flow).
- Replaced the legacy Gameplay Mode toggle with a **Learning Type** tab strip: **Single Note / Intervals / Chords / Scales / Arpeggios**.
  - Wired as an inline (pane-less) tab group and stored as `settings.learningType` for future intent contracts.
- Moved/confirmed **Tritone label options** are a **presentation preference** (not a utility control).
- Added Preferences:
  - **Notation Pitch** (Written / Concert)
  - **Vulnerable After Misses** (steal prompt visibility threshold)
  - **Reduced Motion** (suppresses vulnerable blink animation)
  - **Education Marker Visibility** moved to Preferences (Staff / TAB / Fretboard)
- Fixed Education clear-button ids to match controller wiring (`edu-clear-all/staff/tab/fret`).

## Step 14.34 (Utility Menus: Note/Interval/Arp intent palettes + routing scaffolding)
- Expanded **Utility** tabs to include **Interval** and **Arp** (alongside Num/Note/Chord/Scale/Teach).
- Implemented a **Note Palette** intent selector (pitch + accidental/spelling) in Utility:
  - Updates the Utility "Selected" readout.
  - In **Education Mode**, utility note selection also sets what will be placed (syncs with the Education selected indicator).
  - Emits `gedu:utilNoteIntent` events to formalize the intent contract for later engine binding.
- Added **Interval** intent scaffolding (direction + semitone count) and `gedu:utilIntervalIntent` event emission.
- Added **Arpeggio** intent scaffolding (tone set + direction) with routing constraints and `gedu:utilArpIntent` emission.
- Added **Scale routing** scaffolding (string skipping / return-crossing / max string-jump) and `gedu:utilScaleRoute` emission.

## Step 14.35 (Implementation Audit: wire Utility intents + align controller learningType)
- Aligned UI controller state to the canonical **Learning Type** set: `single / intervals / chords / scales / arpeggios`.
  - Removed the legacy `paused` run state (Pause is non-canon and no longer represented in controller state).
  - Learning Type selection now stores `match.learningType` in settings for downstream intent contracts.
- Wired **Utility intent palettes** to real UI behavior:
  - Note Palette updates selection, syncs Education selected note, and dispatches `gedu:utilNoteIntent`.
  - Interval Palette updates selection and dispatches `gedu:utilIntervalIntent`.
  - Arpeggio Palette updates selection and dispatches `gedu:utilArpIntent` including routing constraints.
  - Scale routing controls dispatch `gedu:utilScaleRoute`.
- Preferences: `pref.reducedMotion` now toggles `.reducedMotion` on the app shell at runtime.

## Step 14.36 (Education Mode Structural Upgrade: tools card + note values)
- **Education Mode** now replaces the upper-right **Player Score Card** with an **Education Tools** card.
  - Teaching tools were removed from Utility tabs to keep Utility focused on **intent controls** (selectors/modifiers) rather than presentation.
  - Education tools include Input/Eraser, Selected note indicator, preference shortcuts, and per-surface clear actions.
- Added **Note Value** selection (Whole / Half / Quarter / 8th / 16th) for Education Mode.
  - Education Staff/TAB input now advances the placement column by the selected note value on the **16th-note grid** (16 columns per measure).
  - Cursor is tracked implicitly from the last click column.

## Step 14.37 (Education Staff/TAB Dual-Mode Scaffolding)
- Added **Staff/TAB Operational Mode** toggle in Education Tools: **Notation** vs **Game**.
  - **Notation**: time-aware surface (durations/measures) intended for future import (MusicXML/Guitar Pro).
  - **Game**: pitch-first behavior aligned with gameplay.
- Introduced separate overlay state stores for **Game** vs **Notation** so import/export can target notation without corrupting gameplay marks.
- Updated staff/tab pointer handler binding to support hot-swapping the active overlay state (attach returns a cleanup function).
- Added `notation.mode` to settings for forward compatibility.

## Step 14.38 (Education NotationScore + MusicXML import/export hooks)
- Implemented a time-aware **NotationScore** model (`src/shell/notationScore.ts`) aligned to MusicXML concepts:
  - Measures, divisions-per-quarter, per-event durations, pitched notes, and optional TAB technical (string/fret).
- Education **Notation** mode now writes placements into NotationScore (in addition to drawing marks), enabling future interoperability.
- Added best-effort **MusicXML import** (primary part, measures, notes/rests, durations, pitch, and `technical/string` + `technical/fret` when present) plus internal JSON import/export hooks:
  - `window.geduImportMusicXML(xmlText)`
  - `window.geduImportInternalScore(jsonText)`
  - `window.geduExportInternalScore()`
- Added a renderer sync that rehydrates the Staff/TAB overlay maps from NotationScore when in Notation mode.
  - Pitch-to-staff mapping is a placeholder heuristic (semitone-step mapping) until the proper treble-clef diatonic mapping is implemented.

## Step 14.39 (MusicXML Import Contract enforcement: validation + TAB detection + UI)
- Added a structured **MusicXML Import Result** contract (`ImportResult`) including status, warnings, and basic import statistics.
- Implemented **MusicXML validation + TAB detection** via `importMusicXmlWithReport(xmlText)`:
  - Hard failures for invalid XML, missing `<part>`, missing measures, or missing pitch on non-rest notes.
  - Soft warnings for missing `<divisions>` and missing `<duration>` (defaults applied).
  - TAB detection tiers:
    - Preserved when per-note `technical/string` + `technical/fret` exists.
    - Warns when TAB clef exists but no per-note technical data is found.
    - Warns when neither TAB clef nor per-note technical data exists.
- Updated `window.geduImportMusicXML` to return an `ImportResult` and display a concise alert summary.
- Added an **Education Tools → Import/Export** panel:
  - File chooser + Import button
  - Optional MusicXML paste box
  - Copy Internal Score JSON button
  - Status line for quick feedback

## Step 14.40 (MusicXML Import UX + strictness controls + treble-clef staff mapping)
- Added **Import Policy** controls to the Education Import/Export panel:
  - **Require TAB (string+fret)**: fails import when per-note technical TAB data is missing.
  - **Strict timing (divisions+durations)**: fails import if `<divisions>` is missing or if any note/rest is missing `<duration>`.
- Import panel now includes a structured **Import Summary** card (stats + warnings list) to support predictable classroom workflows.
- Implemented correct **treble-clef diatonic staff placement** for imported pitches:
  - Staff mapping anchors bottom line to **E4** and maps line/space positions by diatonic steps (ignoring accidentals for placement).

## Step 14.41 (Build system normalization + reproducible packaging)
- Normalized npm scripts to use local bin wrappers: `vite` and `tsc` (no direct `node ./node_modules/...` paths).
- Added `engines.node` (>=18) and `.nvmrc` (20) for consistent runtime expectations.
- Added `DOCS/BUILD.md` with the clean install/build protocol.
- Added `npm run verify:clean` (tools/verify_clean_build.cjs) as the release gate: remove artifacts, run `npm ci`, then `npm run build`.
- Removed `node_modules/`, `dist/`, `.vite/`, and TS build info from the shipped archive (source + lockfile only).

## Step 14.42 (Utility Tab Canon Compliance + Interval/Arp nesting + Scale → Arp shortcut)
- Enforced Utility top-level tabs to exactly: **Num / Note / Chord / Scale** (canon compliance).
- Moved **Intervals** into the **Note** pane as a nested collapsible subpanel (IDs preserved: `util-int-*`).
- Moved **Arpeggios** into the **Chord** pane as a nested collapsible subpanel (IDs preserved: `util-arp-*`).
- Added **Scale → Arpeggio** shortcut button (`util-scale-arpShortcut`) that:
  - switches to the **Chord** tab and
  - opens the **Arpeggios** subpanel (`util-arp-details`).
- Confirmed Utility remains intent-focused (selectors/modifiers), keeping view/visibility preferences out of Utility.

## Step 14.43 (MusicXML coverage expansion: chords, ties, voices, tuplets + TAB/tuning validation)
- Expanded MusicXML parsing fidelity in `NotationScore`:
  - Chords via `<chord/>` (simultaneous notes share a start time and do not advance the measure cursor).
  - Basic tie preservation via `<tie type="start|stop">` and `<notations><tied type="start|stop">`.
  - Voice and staff metadata preservation (`<voice>`, `<staff>`).
  - Basic tuplet preservation via `<time-modification>` (stores actual vs normal note counts).
  - Cursor now honors `<backup>` and `<forward>` to better support multi-voice files.
- Added best-effort TAB validation warnings (string/fret validity and tuning-range checks when tuning is present).
- Import Summary now includes additional fidelity counters (`chordNotes`, `tiedNotes`, `tupletNotes`, `voicedNotes`).
- Added `DOCS/IMPORT_TESTS.md` with a reusable set of MusicXML import test cases.

## Step 14.44 (Notation rendering fidelity pass: chords, ties, tuplets + voice offsets)
- Upgraded the Staff/TAB overlay renderer to support **multiple marks per subdivision column** (chords/polyphony) in Notation Mode.
- Added minimal **tie arc rendering** and **tuplet number labels** for imported MusicXML.
- Added basic **voice-based vertical offsets** (voice 2 rendered slightly lower) to improve readability in multi-voice scores.
- Updated Staff/TAB pointer handler + Education placement logic to match the new mark storage model (arrays per column).

## Step 14.45 (Notation Cursor + Editing v1)
- Added an **Education → Cursor** section (readout + left/right + prev/next measure) to author notation deterministically.
- Added **Edit Mode** controls:
  - **Overwrite**: replace events at the cursor time.
  - **Insert**: shift later events forward by the selected duration (voice-scoped) before inserting.
- Added a **Rest tool** for Notation Mode authoring.
- Implemented **TAB authority rules** (v1):
  - Editing in TAB writes both pitch and TAB.
  - Editing in STAFF can preserve existing TAB unless **Refinger on pitch edits** is enabled.
- Extended the overlay renderer to display a minimal **rest glyph** and ensured `syncNotationOverlayFromScore()` emits rest marks.
## 2026-01-18 (_01_18_26_20)
- GEG-004: Added BONUS phase as a first-class phase (reachable in normal play when tokens/connect score earned).
- Added bonus banner overlay and dev force button (Force Bonus).
- Added bonusMs timer to settings normalization and defaults.
