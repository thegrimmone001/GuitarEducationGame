from __future__ import annotations
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]

def apply(path: Path, fn):
    s = path.read_text(encoding='utf-8')
    ns = fn(s)
    if ns == s:
        raise SystemExit(f'No changes made to {path}')
    path.write_text(ns, encoding='utf-8')

# ---- src/shell/types.ts ----

def patch_types(s: str) -> str:
    # Add bonusMs to timers
    s = re.sub(
        r"(timers:\s*\{\s*\n\s*// Multiplayer: per-turn countdown\.\s*\n\s*// Single player: treated as a per-note countdown in the UI \(average time per note is tracked there\)\.\s*\n\s*turnMs: number;\s*\n\s*// Delay overlay between turns \(multiplayer only\)\.\s*\n\s*intermissionMs: number;\s*\n)",
        r"\1    // Bonus phase window (optional; UI-driven).\n    bonusMs: number;\n",
        s,
        flags=re.M,
    )

    # Add BONUS to Phase union
    s = re.sub(r"export type Phase = \"TITLE\" \| \"IN_MATCH\" \| \"INTERMISSION\" \| \"LAST_CHANCE\" \| \"RESULTS\";",
               r"export type Phase = \"TITLE\" | \"IN_MATCH\" | \"BONUS\" | \"INTERMISSION\" | \"LAST_CHANCE\" | \"RESULTS\";",
               s)

    # Add bonus state interface and field on GameState
    if "export interface BonusState" not in s:
        insert_at = s.find("export interface LastChanceState")
        if insert_at == -1:
            raise SystemExit("Could not find insertion point for BonusState")
        bonus_iface = (
            "export interface BonusState {\n"
            "  active: boolean;\n"
            "  endedPlayerId: PlayerId;\n"
            "  nextPlayerId: PlayerId;\n"
            "}\n\n"
        )
        s = s[:insert_at] + bonus_iface + s[insert_at:]

    # Add bonus field to GameState
    s = re.sub(r"(roundIndex: number;\n\s*lastChance: LastChanceState;\n)", r"\1\n  bonus: BonusState;\n", s)

    # Add effects BONUS_STARTED / BONUS_ENDED
    if "BONUS_STARTED" not in s:
        s = re.sub(
            r"\| \{ type: \"TURN_ENDED\"; playerId: PlayerId; nextPlayerId\?: PlayerId \}\n",
            "| { type: \"TURN_ENDED\"; playerId: PlayerId; nextPlayerId?: PlayerId }\n"
            "  | { type: \"BONUS_STARTED\"; playerId: PlayerId; nextPlayerId?: PlayerId }\n"
            "  | { type: \"BONUS_ENDED\"; playerId: PlayerId; nextPlayerId?: PlayerId }\n",
            s,
        )

    # Add Action END_BONUS
    if "END_BONUS" not in s:
        s = re.sub(r"\| \{ type: \"TIMEOUT\" \}\n\s*\| \{ type: \"END_MATCH\" \};",
                   "| { type: \"TIMEOUT\" }\n  | { type: \"END_BONUS\" }\n  | { type: \"END_MATCH\" };",
                   s)

    return s

# ---- src/shell/engineReducer.ts ----

def patch_engine(s: str) -> str:
    # Ensure createInitialState sets bonus
    # Find object literal in createInitialState return.
    if "bonus:" not in s:
        # Insert bonus field into initial state right after lastChance init (first occurrence).
        s, n = re.subn(r"\n\s*lastChance: \{ active: false, order: new Int16Array\(0\), pos: 0 \},",
                       lambda m: m.group(0) + "\n    bonus: { active: false, endedPlayerId: profiles[0].id, nextPlayerId: profiles[0].id },",
                       s,
                       count=1)
        if n != 1:
            raise SystemExit("Could not inject bonus init into createInitialState")

    # Add END_BONUS case
    if "case \"END_BONUS\"" not in s:
        # Insert before END_MATCH case near bottom
        s = re.sub(
            r"\n\s*case \"END_MATCH\": \{",
            "\n    case \"END_BONUS\": {\n"
            "      if (!state) throw new Error(\"State required\");\n"
            "      if (state.phase !== \"BONUS\") return { state, effects };\n"
            "      const endedId = state.bonus.endedPlayerId;\n"
            "      const nextId = state.bonus.nextPlayerId;\n"
            "      state.bonus.active = false;\n"
            "      // Resume normal flow. Multiplayer uses intermission; single-player continues immediately.\n"
            "      if (state.settings.playType === PlayType.MULTI) {\n"
            "        state.phase = \"INTERMISSION\";\n"
            "      } else {\n"
            "        state.phase = state.lastChance.active ? \"LAST_CHANCE\" : \"IN_MATCH\";\n"
            "      }\n"
            "      effects.push({ type: \"BONUS_ENDED\", playerId: endedId, nextPlayerId: nextId });\n"
            "      effects.push({ type: \"TURN_ENDED\", playerId: endedId, nextPlayerId: state.settings.playType === PlayType.MULTI ? nextId : undefined });\n"
            "      return { state, effects };\n"
            "    }\n\n    case \"END_MATCH\": {",
            s,
            count=1,
        )

    # Modify finalizeTurnWithPulse: insert bonus transition before advancing players.
    # We'll add: if eligible -> set bonus state, phase BONUS, set currentPlayer (next), emit BONUS_STARTED and return.
    if "BONUS_STARTED" not in s:
        raise SystemExit("Effect type BONUS_STARTED not referenced in engineReducer; types may not have been patched")

    # Add bonus trigger in multiplayer branch before setting INTERMISSION
    # We'll target the section just before 'state.phase = "INTERMISSION";' inside multiplayer handling.
    # For lastChance.active branch
    def inject_before_intermission(block: str) -> str:
        if "// Bonus phase" in block:
            return block
        return block.replace(
            'state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"',
            'if (!state.lastChance.active && (connectScore > 0 || tokensToAward > 0)) {\n'
            '      state.bonus.active = true;\n'
            '      state.bonus.endedPlayerId = endedPlayerId;\n'
            '      state.bonus.nextPlayerId = state.players[state.currentPlayer].profile.id;\n'
            '      state.phase = "BONUS";\n'
            '      effects.push({ type: "BONUS_STARTED", playerId: endedPlayerId, nextPlayerId: state.bonus.nextPlayerId });\n'
            '      return;\n'
            '    }\n\n    state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"'
        )

    # Apply injection for both occurrences
    s = s.replace('state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"',
                  'state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"')
    # Use regex to replace first two occurrences with injected code. We'll do manual using split.
    parts = s.split('state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"')
    if len(parts) < 3:
        raise SystemExit("Could not locate INTERMISSION transition sites")
    # Rebuild with injection for the first two occurrences
    rebuilt = parts[0] + inject_before_intermission('state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"') + parts[1]
    # After first injection, we need to ensure second occurrence also injected. It's in rebuilt+... tricky.
    # Instead do regex substitution with count=2.
    pattern = re.escape('state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"')
    repl = ('if (!state.lastChance.active && (connectScore > 0 || tokensToAward > 0)) {\n'
            '      state.bonus.active = true;\n'
            '      state.bonus.endedPlayerId = endedPlayerId;\n'
            '      state.bonus.nextPlayerId = state.players[state.currentPlayer].profile.id;\n'
            '      state.phase = "BONUS";\n'
            '      effects.push({ type: "BONUS_STARTED", playerId: endedPlayerId, nextPlayerId: state.bonus.nextPlayerId });\n'
            '      return;\n'
            '    }\n\n    state.phase = "INTERMISSION";\n      effects.push({ type: "TURN_ENDED"')
    s, n = re.subn(pattern, repl, s, count=2)
    if n != 2:
        raise SystemExit(f"Expected to inject bonus before 2 intermission sites, injected {n}")

    # Single player branch: before setting phase IN_MATCH/LAST_CHANCE and TURN_ENDED, insert bonus trigger
    # Find 'state.phase = state.lastChance.active ? "LAST_CHANCE" : "IN_MATCH";'
    sp_pat = 'state.phase = state.lastChance.active ? "LAST_CHANCE" : "IN_MATCH";'
    if sp_pat in s and "BONUS" not in s.split(sp_pat)[0][-500:]:
        s = s.replace(
            sp_pat,
            'if (!state.lastChance.active && (connectScore > 0 || tokensToAward > 0)) {\n'
            '    state.bonus.active = true;\n'
            '    state.bonus.endedPlayerId = endedPlayerId;\n'
            '    state.bonus.nextPlayerId = endedPlayerId;\n'
            '    state.phase = "BONUS";\n'
            '    effects.push({ type: "BONUS_STARTED", playerId: endedPlayerId });\n'
            '    return;\n'
            '  }\n\n  ' + sp_pat
        )

    return s

# ---- src/ui/layout.ts ----

def patch_layout(s: str) -> str:
    # Add bonus banner near intermission banner
    if 'id: "bonus-banner"' not in s:
        s = s.replace(
            'el("div", { class: "intermissionBanner", id: "intermission-banner", hidden: "true" }, [\n      el("div", { class: "intermissionTitle" }, ["Intermission"]),\n      el("div", { class: "intermissionText", id: "intermission-text" }, [""\n      ])\n    ])',
            'el("div", { class: "bonusBanner", id: "bonus-banner", hidden: "true" }, [\n      el("div", { class: "bonusTitle" }, ["Bonus Phase"]),\n      el("div", { class: "bonusText", id: "bonus-text" }, [""])\n    ]),\n    el("div", { class: "intermissionBanner", id: "intermission-banner", hidden: "true" }, [\n      el("div", { class: "intermissionTitle" }, ["Intermission"]),\n      el("div", { class: "intermissionText", id: "intermission-text" }, [""])\n    ])'
        )

    # Add dev force bonus button near other phase buttons
    if 'id: "dev-forceBonus"' not in s:
        s = s.replace(
            'el("button", { class: "btn", id: "dev-forceIntermission" }, ["Force Intermission"]),',
            'el("button", { class: "btn", id: "dev-forceIntermission" }, ["Force Intermission"]),\n            el("button", { class: "btn", id: "dev-forceBonus" }, ["Force Bonus"]),'
        )

    return s

# ---- src/styles.css ----

def patch_css(s: str) -> str:
    if ".bonusBanner" not in s:
        # Mirror intermission banner styles
        s += "\n\n/* Bonus phase banner */\n.bonusBanner{\n  position:absolute;\n  top:8px;\n  left:50%;\n  transform:translateX(-50%);\n  background:rgba(0,0,0,0.78);\n  color:#fff;\n  padding:10px 14px;\n  border-radius:12px;\n  border:1px solid rgba(255,255,255,0.18);\n  z-index:30;\n  display:flex;\n  gap:10px;\n  align-items:baseline;\n}\n.bonusTitle{\n  font-weight:800;\n  letter-spacing:0.02em;\n}\n.bonusText{\n  opacity:0.92;\n}\n"
    return s

# ---- src/app/gameController.ts ----

def patch_controller(s: str) -> str:
    # Add bonus UI handles and timers near intermission
    if "bonusBanner" not in s:
        # After intermission banner query
        s = s.replace(
            'const intermissionBanner = doc.getElementById("intermission-banner") as HTMLElement | null;\n  const intermissionText = doc.getElementById("intermission-text") as HTMLElement | null;\n',
            'const bonusBanner = doc.getElementById("bonus-banner") as HTMLElement | null;\n  const bonusText = doc.getElementById("bonus-text") as HTMLElement | null;\n  const intermissionBanner = doc.getElementById("intermission-banner") as HTMLElement | null;\n  const intermissionText = doc.getElementById("intermission-text") as HTMLElement | null;\n'
        )

    # Add bonus handles state near intermission handles
    if "bonusHandle" not in s:
        s = s.replace(
            'let intermissionHandle: number | null = null;\n  let intermissionTickHandle: number | null = null;\n  let samHandle: number | null = null;\n',
            'let bonusHandle: number | null = null;\n  let bonusTickHandle: number | null = null;\n  let intermissionHandle: number | null = null;\n  let intermissionTickHandle: number | null = null;\n  let samHandle: number | null = null;\n'
        )

    # Add bonus info struct
    if "type BonusInfo" not in s:
        s = s.replace(
            'type IntermissionInfo = {\n  endsAtMs: number;\n  nextPlayerName: string;\n};\n',
            'type IntermissionInfo = {\n  endsAtMs: number;\n  nextPlayerName: string;\n};\n\ntype BonusInfo = {\n  endsAtMs: number;\n  nextPlayerName: string;\n};\n'
        )

    if "let bonusInfo" not in s:
        s = s.replace(
            'let intermissionInfo: IntermissionInfo | null = null;\n',
            'let bonusInfo: BonusInfo | null = null;\n\n  let intermissionInfo: IntermissionInfo | null = null;\n'
        )

    # Add clearBonusUi and updateBonusUi functions
    if "function clearBonusUi" not in s:
        insert_point = s.find("function clearIntermissionUi")
        if insert_point == -1:
            raise SystemExit("clearIntermissionUi not found")
        bonus_funcs = (
            "function clearBonusUi(): void {\n"
            "    bonusInfo = null;\n"
            "    if (bonusHandle !== null) {\n"
            "      window.clearTimeout(bonusHandle);\n"
            "      bonusHandle = null;\n"
            "    }\n"
            "    if (bonusTickHandle !== null) {\n"
            "      window.clearInterval(bonusTickHandle);\n"
            "      bonusTickHandle = null;\n"
            "    }\n"
            "    if (bonusBanner) bonusBanner.hidden = true;\n"
            "    if (bonusText) bonusText.textContent = \"\";\n"
            "  }\n\n"
            "  function updateBonusUi(): void {\n"
            "    if (!bonusBanner || !bonusText) return;\n"
            "    if (!state || !matchIsRunning) {\n"
            "      bonusBanner.hidden = true;\n"
            "      return;\n"
            "    }\n"
            "    if (state.phase !== \"BONUS\") {\n"
            "      bonusBanner.hidden = true;\n"
            "      return;\n"
            "    }\n"
            "    bonusBanner.hidden = false;\n"
            "    const now = Date.now();\n"
            "    const ends = bonusInfo?.endsAtMs ?? now;\n"
            "    const rem = Math.max(0, ends - now);\n"
            "    const nextName = bonusInfo?.nextPlayerName || \"\";\n"
            "    bonusText.textContent = `${nextName ? `Next: ${nextName} — ` : \"\"}${formatMs(rem)}`;\n"
            "  }\n\n"
        )
        s = s[:insert_point] + bonus_funcs + s[insert_point:]

    # Ensure clearTimers clears bonus timers
    if "bonusHandle" in s and "window.clearTimeout(bonusHandle" not in s:
        s = s.replace(
            'function clearTimers(): void {\n    if (timerHandle !== null) window.clearInterval(timerHandle);\n',
            'function clearTimers(): void {\n    if (timerHandle !== null) window.clearInterval(timerHandle);\n    if (bonusHandle !== null) window.clearTimeout(bonusHandle);\n    if (bonusTickHandle !== null) window.clearInterval(bonusTickHandle);\n'
        )
        s = s.replace('timerHandle = null;\n    intermissionHandle = null;',
                      'timerHandle = null;\n    bonusHandle = null;\n    bonusTickHandle = null;\n    intermissionHandle = null;')

    # renderAll should call updateBonusUi
    if "updateBonusUi();" not in s:
        s = s.replace('updateIntermissionUi();', 'updateBonusUi();\n    updateIntermissionUi();')

    # Handle effects BONUS_STARTED and BONUS_ENDED
    if "case \"BONUS_STARTED\"" not in s:
        s = s.replace(
            'case "TURN_ENDED":',
            'case "BONUS_STARTED": {\n'
            '          stopTurnTimer();\n'
            '          clearIntermissionUi();\n'
            '          // Bonus window before intermission / next turn (GEG-004).\n'
            '          const bonusMs = (s0.settings.timers as any).bonusMs ?? 8000;\n'
            '          const nextName = String(state?.players?.[state.currentPlayer]?.profile?.name ?? "").trim();\n'
            '          bonusInfo = { endsAtMs: Date.now() + bonusMs, nextPlayerName: nextName };\n'
            '          updateBonusUi();\n'
            '          if (bonusTickHandle !== null) window.clearInterval(bonusTickHandle);\n'
            '          bonusTickHandle = window.setInterval(updateBonusUi, 250);\n'
            '          if (bonusHandle !== null) window.clearTimeout(bonusHandle);\n'
            '          bonusHandle = window.setTimeout(() => {\n'
            '            if (!state || !matchIsRunning) return;\n'
            '            dispatch({ type: "END_BONUS" } as Action);\n'
            '          }, bonusMs);\n'
            '          setAlert("Bonus phase");\n'
            '          break;\n'
            '        }\n\n        case "BONUS_ENDED":\n          clearBonusUi();\n          break;\n\n        case "TURN_ENDED":'
        )

    # Gate inputs during BONUS
    s = s.replace('if (state.phase === "INTERMISSION" || state.phase === "RESULTS") return;',
                  'if (state.phase === "BONUS" || state.phase === "INTERMISSION" || state.phase === "RESULTS") return;')

    # Dev force bonus button wiring
    if "dev-forceBonus" not in s:
        s = s.replace(
            'const btnDevPhaseIntermission = doc.querySelector<HTMLButtonElement>("#dev-forceIntermission");\n',
            'const btnDevPhaseIntermission = doc.querySelector<HTMLButtonElement>("#dev-forceIntermission");\n  const btnDevPhaseBonus = doc.querySelector<HTMLButtonElement>("#dev-forceBonus");\n'
        )
        s = s.replace('btnDevPhaseIntermission?.addEventListener("click", () => forcePhase("INTERMISSION"));',
                      'btnDevPhaseIntermission?.addEventListener("click", () => forcePhase("INTERMISSION"));\n  btnDevPhaseBonus?.addEventListener("click", () => forcePhase("BONUS"));')

    return s

# Apply patches
apply(root/'src/shell/types.ts', patch_types)
apply(root/'src/shell/engineReducer.ts', patch_engine)
apply(root/'src/ui/layout.ts', patch_layout)
apply(root/'src/styles.css', patch_css)
apply(root/'src/app/gameController.ts', patch_controller)

print('Patched bonus phase.')
