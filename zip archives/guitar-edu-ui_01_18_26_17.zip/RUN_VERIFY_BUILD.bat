@echo off
setlocal
npm run verify:clean
if errorlevel 1 (
  echo.
  echo VERIFY CLEAN BUILD FAILED
  exit /b 1
)
echo.
echo VERIFY CLEAN BUILD OK
exit /b 0
