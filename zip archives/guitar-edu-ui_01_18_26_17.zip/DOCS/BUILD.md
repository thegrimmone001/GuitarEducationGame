# Build & Run (Reproducible)

## Requirements
- Node.js: **18+** (recommended: Node 20)
- npm: comes with Node

## Clean install (recommended)
```bash
npm ci
```

## Dev server
```bash
npm run dev
```

## Production build
```bash
npm run build
```

## Preview production build
```bash
npm run preview
```

## Verify clean build (release gate)
This simulates a fresh machine install by removing local build artifacts and dependencies, reinstalling, and running a full build.

```bash
npm run verify:clean
```

## Packaging rule (project zips)
Project zips **must not include**:
- `node_modules/`
- `dist/`
- `.vite/`

Zips should include source + lockfile so users run `npm ci` locally.
