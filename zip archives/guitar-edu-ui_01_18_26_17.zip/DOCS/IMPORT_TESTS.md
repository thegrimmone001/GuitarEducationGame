# MusicXML Import Tests (Notation Mode)

This document defines repeatable import tests to validate MusicXML handling in **Education → Notation**.

## How to run
1. Launch the app.
2. Select **Education**.
3. Set **Staff/TAB Operational Mode** to **Notation**.
4. Open **Education Tools → Import/Export**.
5. Import the file (or paste MusicXML) and review the Import Summary + Warnings.

---

## Test 1: Basic notes and rests
**Source:** Any notation app exporting a single part with one measure.

**Content:**
- 1 measure of quarter notes (C4, D4, E4, F4)
- 1 measure containing at least one rest

**Expected:**
- Import status: OK (or OK with warnings if timing/divisions missing)
- `notes >= 4`, `rests >= 1`
- Notes appear in correct treble-clef positions (diatonic mapping)

---

## Test 2: Chords (simultaneous notes)
**Content:** A measure containing at least one triad chord (three notes at the same start time).

**Expected:**
- Import succeeds
- Import Summary shows `chordNotes > 0`
- Multiple noteheads stack at the same horizontal position on the staff

---

## Test 3: Ties
**Content:** A note tied across a barline (tie start in one measure, tie stop in the next).

**Expected:**
- Import succeeds
- Import Summary shows `tiedNotes > 0`
- Underlying note events preserve `tieStart` and `tieStop` flags (even if rendering is minimal)

---

## Test 4: Tuplets (triplet)
**Content:** An eighth-note triplet or quarter-note triplet using MusicXML `<time-modification>`.

**Expected:**
- Import succeeds
- Import Summary shows `tupletNotes > 0`
- Durations remain time-placeable (no dropped events)

---

## Test 5: TAB technical preservation
**Content:** A guitar part with per-note TAB technical string/fret data.

**Expected (Permissive policy):**
- Import succeeds
- `notesWithTab > 0`

**Expected (Require TAB policy enabled):**
- Import fails only if `notesWithTab == 0`
- Failure code: `TAB_REQUIRED_MISSING`

---

## Test 6: TAB clef but no technical data
**Content:** MusicXML includes a TAB staff/clef, but notes do not include per-note technical string/fret.

**Expected (Permissive policy):**
- Import succeeds
- Warning code: `TAB_CLEF_NO_TECH`

**Expected (Require TAB policy enabled):**
- Import fails
- Failure code: `TAB_REQUIRED_MISSING`
