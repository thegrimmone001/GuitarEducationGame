# Merge Notes

Baseline: `guitar-edu-ui_v31_notation_toggles_prefs`.

This merge adds:
- `PROJECT_NOTES.md` (source-of-truth spec)
- `DOCS/CHANGELOG.md`
- Clean packaging (no `node_modules` or `dist`)

No gameplay mechanics were changed by this merge.
