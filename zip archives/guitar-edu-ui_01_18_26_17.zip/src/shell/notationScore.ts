// NotationScore: a time-aware staff+TAB representation designed for interoperability.
//
// This module intentionally mirrors MusicXML concepts (measures, divisions, durations,
// pitched notes, optional TAB technical string/fret) so we can import/export without
// coupling to game-mode surfaces.

export type NotationEventType = "note" | "rest";

export interface TimeSignature {
  num: number;
  den: number;
}

export interface NotationPitch {
  step: "A" | "B" | "C" | "D" | "E" | "F" | "G";
  alter: number; // -2..2 (MusicXML <alter>); 0 when omitted
  octave: number; // scientific pitch octave
}

export interface NotationTab {
  // 1..6 in MusicXML; we also allow 0..5 internally for convenience.
  string: number;
  fret: number;
}

export interface NotationDuration {
  // Duration measured in MusicXML divisions.
  divisions: number;
  dots?: number;
}

export interface NotationPos {
  measureIndex: number;
  // Offset from measure start, in divisions.
  offsetDiv: number;
}

export interface NotationEventBase {
  id: string;
  type: NotationEventType;
  pos: NotationPos;
  dur: NotationDuration;
}

export interface NotationNoteEvent extends NotationEventBase {
  type: "note";
  pitch: NotationPitch;
  tab?: NotationTab;
  // Optional MusicXML metadata preserved for fidelity/future rendering.
  voice?: string;
  staff?: number;
  tieStart?: boolean;
  tieStop?: boolean;
  tuplet?: { actual: number; normal: number };
  // Optional staff mapping hint (renderer may ignore).
  staffYIndexHint?: number;
}

export interface NotationRestEvent extends NotationEventBase {
  type: "rest";
}

export type NotationEvent = NotationNoteEvent | NotationRestEvent;

export interface NotationMeasure {
  index: number;
  events: NotationEvent[];
}

export interface NotationScore {
  version: 1;
  timeSig: TimeSignature;
  divisionsPerQuarter: number;
  measures: NotationMeasure[];
  // Optional tuning (MusicXML staff-details/staff-tuning). Stored as (stringNumber -> midi)
  // when available. Not required for basic TAB preservation.
  tuningMidiByString?: Record<number, number>;
}

export type ImportStatus = "ok" | "ok_with_warnings" | "error";

export interface ImportWarning {
  code: string;
  message: string;
}

export interface ImportStats {
  measures: number;
  notes: number;
  rests: number;
  notesWithTab: number;
  chordNotes?: number;
  tiedNotes?: number;
  tupletNotes?: number;
  voicedNotes?: number;
  droppedEvents: number;
}

export interface ImportResult {
  status: ImportStatus;
  score: NotationScore | null;
  warnings: ImportWarning[];
  stats: ImportStats;
}

export interface ImportPolicy {
  // If true, import fails unless per-note TAB technical string+fret are present.
  requireTabTechnical: boolean;
  // If true, import fails if <divisions> is missing OR any note/rest is missing <duration>.
  strictTiming: boolean;
}

export function createEmptyScore(opts?: Partial<Pick<NotationScore, "timeSig" | "divisionsPerQuarter">>): NotationScore {
  return {
    version: 1,
    timeSig: opts?.timeSig ?? { num: 4, den: 4 },
    divisionsPerQuarter: opts?.divisionsPerQuarter ?? 480,
    measures: [],
  };
}

export function measureDivisions(score: NotationScore): number {
  // divisionsPerQuarter is per quarter note. A measure spans num beats, where each beat
  // is (4/den) quarters.
  const qPerBeat = 4 / Math.max(1, score.timeSig.den);
  const totalQ = score.timeSig.num * qPerBeat;
  return Math.max(1, Math.round(totalQ * score.divisionsPerQuarter));
}

export function ensureMeasure(score: NotationScore, idx: number): NotationMeasure {
  while (score.measures.length <= idx) {
    score.measures.push({ index: score.measures.length, events: [] });
  }
  return score.measures[idx];
}

let _idSeq = 1;
function nextId(prefix: string): string {
  _idSeq++;
  return `${prefix}_${Date.now().toString(36)}_${_idSeq}`;
}

export function addNoteEvent(
  score: NotationScore,
  pos: NotationPos,
  dur: NotationDuration,
  pitch: NotationPitch,
  tab?: NotationTab,
  staffYIndexHint?: number,
  meta?: Partial<Pick<NotationNoteEvent, "voice" | "staff" | "tieStart" | "tieStop" | "tuplet">>,
): NotationNoteEvent {
  const m = ensureMeasure(score, pos.measureIndex);
  const ev: NotationNoteEvent = {
    id: nextId("n"),
    type: "note",
    pos: { ...pos },
    dur: { ...dur },
    pitch,
    tab,
    staffYIndexHint,
    ...(meta ?? {}),
  };
  m.events.push(ev);
  m.events.sort((a, b) => a.pos.offsetDiv - b.pos.offsetDiv);
  return ev;
}

export function addRestEvent(score: NotationScore, pos: NotationPos, dur: NotationDuration): NotationRestEvent {
  const m = ensureMeasure(score, pos.measureIndex);
  const ev: NotationRestEvent = { id: nextId("r"), type: "rest", pos: { ...pos }, dur: { ...dur } };
  m.events.push(ev);
  m.events.sort((a, b) => a.pos.offsetDiv - b.pos.offsetDiv);
  return ev;
}

export function clearScore(score: NotationScore): void {
  score.measures.length = 0;
}

function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n));
}

export function pitchToMidi(p: NotationPitch): number {
  const base: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  const pc = base[p.step] ?? 0;
  return (p.octave + 1) * 12 + pc + (p.alter ?? 0);
}

export function parseMusicXmlToScore(xmlText: string): NotationScore {
  const dom = new DOMParser().parseFromString(xmlText, "application/xml");
  const parserErr = dom.querySelector("parsererror");
  if (parserErr) throw new Error("Invalid MusicXML");

  const score = createEmptyScore();

  // Prefer first <divisions>, <time> found.
  const divEl = dom.querySelector("divisions");
  const div = divEl ? Number(divEl.textContent ?? "") : NaN;
  if (Number.isFinite(div) && div > 0) score.divisionsPerQuarter = Math.round(div);

  const beatsEl = dom.querySelector("time > beats");
  const beatTypeEl = dom.querySelector("time > beat-type");
  const beats = beatsEl ? Number(beatsEl.textContent ?? "") : NaN;
  const beatType = beatTypeEl ? Number(beatTypeEl.textContent ?? "") : NaN;
  if (Number.isFinite(beats) && beats > 0 && Number.isFinite(beatType) && beatType > 0) {
    score.timeSig = { num: Math.round(beats), den: Math.round(beatType) };
  }

  // Measures: support partwise; take the first part as primary.
  const part = dom.querySelector("part");
  if (!part) return score;

  const measures = Array.from(part.querySelectorAll("measure"));
  for (let mi = 0; mi < measures.length; mi++) {
    const meas = measures[mi];
    ensureMeasure(score, mi);

    // Simple time cursor inside measure.
    let cursorDiv = 0;
    let lastStartDiv = 0;

    // Iterate direct children to support <backup>/<forward> and chord groupings.
    const children = Array.from(meas.children);
    for (const el of children) {
      const tag = (el.tagName ?? "").toLowerCase();
      if (tag === "backup" || tag === "forward") {
        const durEl = el.querySelector("duration");
        const durDiv = durEl ? Number(durEl.textContent ?? "") : NaN;
        const d = Number.isFinite(durDiv) && durDiv > 0 ? Math.round(durDiv) : score.divisionsPerQuarter;
        cursorDiv += tag === "backup" ? -d : d;
        cursorDiv = Math.max(0, cursorDiv);
        continue;
      }

      if (tag !== "note") continue;
      const n = el;
      const isChord = !!n.querySelector("chord");
      const isRest = !!n.querySelector("rest");
      const durEl = n.querySelector("duration");
      const durDiv = durEl ? Number(durEl.textContent ?? "") : NaN;
      const d = Number.isFinite(durDiv) && durDiv > 0 ? Math.round(durDiv) : score.divisionsPerQuarter;

      const startDiv = isChord ? lastStartDiv : cursorDiv;

      if (isRest) {
        // Rests in chord groups are unusual; treat them as occupying time only when not chord-tagged.
        addRestEvent(score, { measureIndex: mi, offsetDiv: startDiv }, { divisions: d });
        if (!isChord) cursorDiv += d;
        lastStartDiv = startDiv;
        continue;
      }

      const pitchEl = n.querySelector("pitch");
      const step = (pitchEl?.querySelector("step")?.textContent ?? "C").trim().toUpperCase() as NotationPitch["step"];
      const alter = Number(pitchEl?.querySelector("alter")?.textContent ?? "0");
      const octave = Number(pitchEl?.querySelector("octave")?.textContent ?? "4");
      const pitch: NotationPitch = {
        step: ("ABCDEFG".includes(step) ? step : "C") as any,
        alter: Number.isFinite(alter) ? alter : 0,
        octave: Number.isFinite(octave) ? Math.round(octave) : 4,
      };

      // TAB technical
      const stringEl = n.querySelector("notations technical string");
      const fretEl = n.querySelector("notations technical fret");
      const sNum = stringEl ? Number(stringEl.textContent ?? "") : NaN;
      const fNum = fretEl ? Number(fretEl.textContent ?? "") : NaN;
      const tab = Number.isFinite(sNum) && Number.isFinite(fNum) ? { string: Math.round(sNum), fret: Math.round(fNum) } : undefined;

      // Voice/staff metadata
      const voice = (n.querySelector("voice")?.textContent ?? "").trim();
      const staffNum = Number((n.querySelector("staff")?.textContent ?? "").trim());
      const staff = Number.isFinite(staffNum) && staffNum > 0 ? Math.round(staffNum) : undefined;

      // Tie metadata (support both <tie> and <notations><tied>)
      const tieTypes = Array.from(n.querySelectorAll("tie, notations tied"))
        .map((t) => (t.getAttribute("type") ?? "").trim().toLowerCase())
        .filter(Boolean);
      const tieStart = tieTypes.includes("start");
      const tieStop = tieTypes.includes("stop");

      // Tuplet metadata (basic)
      const tm = n.querySelector("time-modification");
      const actual = Number((tm?.querySelector("actual-notes")?.textContent ?? "").trim());
      const normal = Number((tm?.querySelector("normal-notes")?.textContent ?? "").trim());
      const tuplet = Number.isFinite(actual) && actual > 0 && Number.isFinite(normal) && normal > 0 ? { actual: Math.round(actual), normal: Math.round(normal) } : undefined;

      addNoteEvent(
        score,
        { measureIndex: mi, offsetDiv: startDiv },
        { divisions: d },
        pitch,
        tab,
        undefined,
        {
          voice: voice || undefined,
          staff,
          tieStart: tieStart || undefined,
          tieStop: tieStop || undefined,
          tuplet,
        },
      );

      if (!isChord) cursorDiv += d;
      lastStartDiv = startDiv;
    }
  }

  // Optional tuning extraction (best-effort)
  const tuningEls = Array.from(dom.querySelectorAll("staff-details staff-tuning"));
  if (tuningEls.length) {
    const out: Record<number, number> = {};
    for (const st of tuningEls) {
      const line = Number(st.getAttribute("line") ?? "");
      const step = (st.querySelector("tuning-step")?.textContent ?? "").trim().toUpperCase();
      const alter = Number(st.querySelector("tuning-alter")?.textContent ?? "0");
      const octave = Number(st.querySelector("tuning-octave")?.textContent ?? "0");
      if (!Number.isFinite(line) || line <= 0) continue;
      if (!step || !"ABCDEFG".includes(step)) continue;
      const p: NotationPitch = {
        step: step as any,
        alter: Number.isFinite(alter) ? alter : 0,
        octave: Number.isFinite(octave) ? Math.round(octave) : 0,
      };
      out[Math.round(line)] = pitchToMidi(p);
    }
    if (Object.keys(out).length) score.tuningMidiByString = out;
  }

  return score;
}

export function importMusicXmlWithReport(xmlText: string, policy?: Partial<ImportPolicy>): ImportResult {
  const warnings: ImportWarning[] = [];
  const zero: ImportStats = { measures: 0, notes: 0, rests: 0, notesWithTab: 0, chordNotes: 0, tiedNotes: 0, tupletNotes: 0, voicedNotes: 0, droppedEvents: 0 };

  const pol: ImportPolicy = {
    requireTabTechnical: !!policy?.requireTabTechnical,
    strictTiming: !!policy?.strictTiming,
  };

  try {
    const dom = new DOMParser().parseFromString(String(xmlText || ""), "application/xml");
    const parserErr = dom.querySelector("parsererror");
    if (parserErr) {
      return { status: "error", score: null, warnings: [{ code: "INVALID_XML", message: "File could not be read as MusicXML." }], stats: zero };
    }

    const part = dom.querySelector("part");
    if (!part) {
      return { status: "error", score: null, warnings: [{ code: "NO_PART", message: "MusicXML contains no <part>; nothing to import." }], stats: zero };
    }
    const measures = Array.from(part.querySelectorAll("measure"));
    if (!measures.length) {
      return {
        status: "error",
        score: null,
        warnings: [{ code: "NO_MEASURES", message: "MusicXML contains no measures; nothing to import." }],
        stats: zero,
      };
    }

    // Hard requirement: pitched notes must have <pitch>, rests must have <rest>.
    const badPitch = Array.from(part.querySelectorAll("note")).filter((n) => !n.querySelector("rest") && !n.querySelector("pitch"));
    if (badPitch.length) {
      return {
        status: "error",
        score: null,
        warnings: [{ code: "PITCH_MISSING", message: `One or more notes are missing pitch information (${badPitch.length}).` }],
        stats: zero,
      };
    }

    // Timing signals.
    const hasDivisions = !!dom.querySelector("divisions");
    const missingDur = Array.from(part.querySelectorAll("note")).filter((n) => !n.querySelector("duration"));

    if (!hasDivisions) {
      if (pol.strictTiming) {
        return {
          status: "error",
          score: null,
          warnings: [{ code: "NO_DIVISIONS", message: "Strict timing is enabled, but no <divisions> was found." }],
          stats: zero,
        };
      }
      warnings.push({ code: "NO_DIVISIONS", message: "No <divisions> found; durations will be normalized with defaults." });
    }
    if (missingDur.length) {
      if (pol.strictTiming) {
        return {
          status: "error",
          score: null,
          warnings: [{ code: "MISSING_DURATION", message: `Strict timing is enabled, but some notes/rests are missing <duration> (${missingDur.length}).` }],
          stats: zero,
        };
      }
      warnings.push({ code: "MISSING_DURATION", message: `Some notes/rests are missing <duration> (${missingDur.length}); defaults applied.` });
    }

    const hasTabClef = Array.from(dom.querySelectorAll("clef > sign")).some((s) => (s.textContent ?? "").trim().toUpperCase() === "TAB");

    const score = parseMusicXmlToScore(String(xmlText || ""));
    let notes = 0,
      rests = 0,
      notesWithTab = 0;
    // Additional fidelity counters (used for future UX, not required for core import).
    let chordNotes = 0,
      tiedNotes = 0,
      tupletNotes = 0,
      voicedNotes = 0;

    const tuningMaxString = score.tuningMidiByString ? Math.max(...Object.keys(score.tuningMidiByString).map((k) => Number(k)).filter((n) => Number.isFinite(n))) : NaN;
    for (const m of score.measures) {
      for (const ev of m.events) {
        if (ev.type === "rest") rests++;
        if (ev.type === "note") {
          notes++;
          if (ev.tab) notesWithTab++;
          if (ev.voice) voicedNotes++;
          if (ev.tieStart || ev.tieStop) tiedNotes++;
          if (ev.tuplet) tupletNotes++;

          // TAB validation warnings (never block unless strict policies choose to).
          if (ev.tab) {
            const s = ev.tab.string;
            const f = ev.tab.fret;
            if (!Number.isFinite(s) || s <= 0) {
              warnings.push({ code: "TAB_STRING_INVALID", message: "TAB string value is invalid on one or more notes." });
            } else if (Number.isFinite(tuningMaxString) && tuningMaxString > 0 && s > tuningMaxString) {
              warnings.push({ code: "TAB_STRING_OUT_OF_RANGE", message: "TAB string exceeds detected tuning string count on one or more notes." });
            }
            if (!Number.isFinite(f)) {
              warnings.push({ code: "TAB_FRET_INVALID", message: "TAB fret value is invalid on one or more notes." });
            } else {
              if (f < 0) warnings.push({ code: "TAB_FRET_NEGATIVE", message: "TAB fret is negative on one or more notes." });
              if (f > 36) warnings.push({ code: "TAB_FRET_HIGH", message: "TAB fret is unusually high (>36) on one or more notes." });
            }
          }
        }
      }
    }

    // Chord note count (derived: notes at identical pos within a measure beyond 1).
    for (const m of score.measures) {
      const byPos = new Map<number, number>();
      for (const ev of m.events) {
        if (ev.type !== "note") continue;
        byPos.set(ev.pos.offsetDiv, (byPos.get(ev.pos.offsetDiv) ?? 0) + 1);
      }
      for (const [, c] of byPos) if (c > 1) chordNotes += c;
    }

    if (pol.requireTabTechnical && notesWithTab === 0) {
      return {
        status: "error",
        score: null,
        warnings: [{ code: "TAB_REQUIRED_MISSING", message: "TAB is required, but no per-note string/fret technical data was found." }],
        stats: zero,
      };
    }

    if (notesWithTab === 0) {
      if (hasTabClef) {
        warnings.push({
          code: "TAB_CLEF_NO_TECH",
          message: "TAB staff detected, but no per-note string/fret technical data was found. Notation imported; TAB fingering not preserved.",
        });
      } else {
        warnings.push({
          code: "NO_TAB_DATA",
          message: "No TAB data detected (no TAB clef and no per-note string/fret). Notation imported only.",
        });
      }
    }

    const stats: ImportStats = {
      measures: score.measures.length,
      notes,
      rests,
      notesWithTab,
      chordNotes,
      tiedNotes,
      tupletNotes,
      voicedNotes,
      droppedEvents: 0,
    };

    const status: ImportStatus = warnings.length ? "ok_with_warnings" : "ok";
    return { status, score, warnings, stats };
  } catch (err: any) {
    return {
      status: "error",
      score: null,
      warnings: [{ code: "IMPORT_ERROR", message: `Import failed: ${String(err?.message || err)}` }],
      stats: zero,
    };
  }
}

export function toInternalJson(score: NotationScore): string {
  return JSON.stringify(score);
}

export function fromInternalJson(text: string): NotationScore {
  const obj = JSON.parse(text);
  if (!obj || obj.version !== 1 || !Array.isArray(obj.measures)) throw new Error("Invalid internal score");
  return obj as NotationScore;
}

export function offsetToColumn(offsetDiv: number, measureDiv: number, colsPerMeasure: number): number {
  const t = measureDiv > 0 ? offsetDiv / measureDiv : 0;
  return clamp(Math.round(t * colsPerMeasure), 0, colsPerMeasure - 1);
}

export function columnToOffset(colInMeasure: number, measureDiv: number, colsPerMeasure: number): number {
  const t = colsPerMeasure > 0 ? colInMeasure / colsPerMeasure : 0;
  return clamp(Math.round(t * measureDiv), 0, Math.max(0, measureDiv - 1));
}
