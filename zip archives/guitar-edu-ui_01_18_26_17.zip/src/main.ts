import "./styles.css";
import { mountLayout } from "./ui/layout";
import { initGameController } from "./app/gameController";

const app = document.getElementById("app");
if (!app) throw new Error("#app not found");

mountLayout(app);

// Engine-backed controller (merged from the shell version into the new layout).
initGameController(document);

