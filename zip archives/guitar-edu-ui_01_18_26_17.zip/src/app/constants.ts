// Centralized constants used across UI + controller.
// Keep these values conservative for layout stability, but do not hard-limit the engine unnecessarily.

// Multiplayer sessions must allow more than 5 players (per project canon: classroom / larger groups).
// The splash selector and the engine both use this as the current upper bound.
export const PLAYER_COUNT_MULTI_MAX = 12;
