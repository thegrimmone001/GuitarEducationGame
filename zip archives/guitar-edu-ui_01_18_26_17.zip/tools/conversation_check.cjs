/*
  conversation_check.cjs
  Canon guard: before executing any CHECKLIST step, read the latest project conversation composite.

  This script:
  - Prefers DOCS/conversation_composite.json (repo-scoped canon)
  - Falls back to conversation.json only if the composite is not present
  - Prints absolute path + mtime
  - Prints a short preview (first 60 lines)

  NOTE: If neither file is present in the repo, this script exits 0 with a warning.
*/

const fs = require('fs');
const path = require('path');

const candidates = [
  // Preferred: repo-scoped composite
  path.resolve(process.cwd(), 'DOCS', 'conversation_composite.json'),

  // Fallbacks: full exports (optional)
  path.resolve(process.cwd(), 'conversation.json'),
  path.resolve(process.cwd(), 'DOCS', 'conversation.json'),
  path.resolve(process.cwd(), 'docs', 'conversation.json'),
  path.resolve(process.cwd(), 'data', 'conversation.json')
];

function statSafe(p) {
  try {
    return fs.statSync(p);
  } catch {
    return null;
  }
}

let found = null;
for (const p of candidates) {
  const st = statSafe(p);
  if (st && st.isFile()) {
    found = { p, st };
    break;
  }
}

if (!found) {
  console.log('[conversation_check] WARNING: No conversation composite (or conversation.json) found in the repo zip.');
  console.log('[conversation_check] Searched:');
  for (const p of candidates) console.log(' - ' + p);
  console.log('[conversation_check] Recommended: add DOCS/conversation_composite.json to the repo zip.');
  process.exit(0);
}

console.log('[conversation_check] FOUND: ' + found.p);
console.log('[conversation_check] Modified: ' + found.st.mtime.toISOString());

const raw = fs.readFileSync(found.p, 'utf8');
const lines = raw.split(/\r?\n/);
const preview = lines.slice(0, 60).join('\n');
console.log('--- conversation preview (first 60 lines) ---');
console.log(preview);
console.log('--- end preview ---');
