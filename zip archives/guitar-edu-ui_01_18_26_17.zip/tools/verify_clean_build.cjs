/*
  verify_clean_build.cjs
  Release gate: simulate a fresh install + build.

  - Removes node_modules, dist, .vite, and TypeScript build info
  - Runs: npm ci
  - Runs: npm run build

  Exit code:
    0 = success
    1 = failure
*/

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');

const pathsToRemove = [
  'node_modules',
  'dist',
  '.vite',
  'tsconfig.tsbuildinfo',
];

function rmSafe(rel) {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) return;
  try {
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      fs.rmSync(p, { recursive: true, force: true });
    } else {
      fs.rmSync(p, { force: true });
    }
    console.log(`[verify] removed: ${rel}`);
  } catch (e) {
    console.error(`[verify] failed to remove ${rel}:`, e.message);
  }
}

function run(cmd, args) {
  console.log(`\n[verify] running: ${cmd} ${args.join(' ')}`);
  const r = cp.spawnSync(cmd, args, {
    cwd: ROOT,
    stdio: 'inherit',
    shell: process.platform === 'win32',
  });
  return r.status === 0;
}

function main() {
  console.log('[verify] clean build verification starting...');
  for (const p of pathsToRemove) rmSafe(p);

  if (!run('npm', ['ci'])) {
    console.error('\n[verify] npm ci failed');
    process.exit(1);
  }

  if (!run('npm', ['run', 'build'])) {
    console.error('\n[verify] npm run build failed');
    process.exit(1);
  }

  console.log('\n[verify] SUCCESS: clean install + build completed');
  process.exit(0);
}

main();
