# Build Log

This log tracks packaged zip milestones and their intent.

## Canon progress marker

For “where we are in the master checklist,” keep `CANON_PROGRESS.md` up to date. Each build should either advance or reaffirm the canon position.

## 2026-01-13 — 01_13_26_01
- Purpose: Phase 1 UX alignment — add a Start Setup gate between Splash and session start.
- Core:
  - Splash session selection now opens Start Setup (content/mode/root/fret range) instead of starting immediately.
  - Start Setup writes choices into canonical settings controls and dispatches `gedu:beginSession`.
  - Controller listens to `gedu:beginSession` (keeps `gedu:splashSelect` for backward compatibility).

## 2026-01-13 — 01_13_26_03
- Purpose: Canon alignment pass — remove deprecated lexicon and ensure note rail defaults remain prompt-first.
- Core:
  - Renamed `ModeId.COMBINED` to `ModeId.STAFF_TAB_FRET` (legacy value string retained for backward compatibility).
  - Note rail default layers: `asked` ON (prompt highlight), `answered` OFF by default (no implied rail history).

## 2026-01-12 — 01_12_26_13
- Purpose: Stabilize E2E test execution by aligning Playwright to **shipping behavior** (built output) instead of relying on the dev server.
- Core:
  - `npm run e2e` and `npm run e2e:ui` now perform: `build -> vite preview (4173) -> playwright`.
  - Updated `playwright.config.ts` baseURL defaults to preview port (override via `E2E_BASE_URL`).
  - Updated `TESTING.md` to document preview-based E2E.

## 2026-01-12 — 01_12_26_10
- Purpose: Fix Windows `RUN_DEV.bat` dev-server launch reliability (nested-quote `start` parsing issue) and ensure Vite output is both visible and logged.
- Change: Add `DEVSERVER_RUNNER.bat` and route `RUN_DEV.bat` through it.

## 2026-01-12 — 01_12_26_05
- Purpose: Phase C workflow acceleration — add a no-terminal-friendly Windows runner for dev and tests.
- Core:
  - Added `RUN_DEV.bat` to install deps if needed, start the Vite dev server, and open the browser.
  - Added `RUN_TESTS.bat` to install deps if needed, ensure Playwright browsers are installed, then run:
    - `npm run test:ci`
    - `npm run e2e` (headless)
  - Updated `TESTING.md` with one-click runner instructions.

## 2026-01-12 — 01_12_26_09
- Purpose: Make one-click workflows debuggable when launch fails.
- Core:
  - `RUN_DEV.bat` now always writes `logs/run_dev.log` and `logs/devserver.log`.
  - `RUN_TESTS.bat` now always writes `logs/run_tests.log`.
  - Updated `TESTING.md` with a Logs section.

## 2026-01-11 — 01_11_26_09
- Purpose: Phase 3 correctness on top of the accepted-marks persistence pipeline (STAFF+TAB+FRET truth triangle).
- Core:
  - When STAFF is required, STAFF is the authoritative pitch source: staff letter + chosen accidental must match the prompt’s pitch and spelling (black-key sharp/flat strictness; white keys must be natural).
  - When TAB + FRET are both required, enforce exact string+fret match (TAB is authoritative for position).
  - Commit pipeline hardened: snapshot pending STAFF/TAB marks before reducer effects can clear them; commit snapshot only after successful composite validation.

## 2026-01-11 — 01_11_26_05
- Purpose: A-contract audit follow-through: restore/verify timers + overlays + checkbox layers without violating the static Staff/TAB requirement.
- Core:
  - Purged remaining legacy Pause references (no pause state or events).
  - Removed Staff/TAB viewBox cropping so the notation surface never zooms/crops per UI mode.
  - Wired Surface Layers (Display / Prompt / Marks) into Staff/TAB (grid/hover/marks) and Fretboard (claimed dots, learning labels, pulse overlays).

## 2026-01-11 — 01_10_26_26
- Purpose: remove TAB-input ambiguity and eliminate the accidental “0” stamping / disappearing-number behavior reported in Mode 3.
- Core:
  - Clicking a TAB slot without a chosen fret now creates a **pending TAB slot** (outline) instead of placing `0`.
  - TAB number selection is explicitly required (including open-string `0`) before a TAB answer is committed.
  - Turn/prompt resets now clear TAB keypad UI state so a prior selection cannot leak into a new prompt.

## 2026-01-11 — 01_11_26_02
- Purpose: restore match flow to the updated contract (pause removed, Ready/Engage gate, seconds-based timers, single-player time-to-complete default).
- Core:
  - Removed Pause button and pause event handling (no user-facing pause).
  - Added a Ready/Engage overlay gate so Turn 1 does not start immediately.
  - Timers are stored in seconds (`turnSec`, `intermissionSec`) and converted to ms only for scheduling.
  - Single-player displays a stopwatch by default.

## 2026-01-11 — 01_10_26_25
- Purpose: make Mode 3 composite answering behave like a real “multi-surface” check (TAB + FRET both must be correct to the prompt), while improving clarity during composite entry.
- Core:
  - TAB + FRET validation is now **pitch-based**, not strict string/fret equality.
  - Submits using the most recently updated Answer surface.
  - Adds a pending “ring” marker on the fretboard to show the selected cell during composite entry.

## 2026-01-10 — 01_10_26_16
- Purpose: lock in Staff+Tab overlay rewrite and controller-owned mark state.
- Core: Surface Input Matrix + composite submission gating (Staff drives pitch).

## 2026-01-10 — 01_10_26_17
- Purpose: stabilize surface-matrix application in the DOM and add user-facing layer toggles.
- Core: `staffTabStage` id alignment; Surface Layers (View/Asked/Answered); rail layer controls.

## 2026-01-10 — 01_10_26_18
- Purpose: align the user-facing Surface Layers terminology with the Surface Matrix vocabulary.
- Core: rename UI labels to Display/Prompt/Marks (internal keys unchanged).

## 2026-01-10 — 01_10_26_19
- Purpose: make the Staff+TAB overlay geometry match the 3-measure rendered template.
- Core: normalize to the core 5 staff lines + derive measure spans from repeated long line segments (fixes column math and enables reliable tab-number rendering).
- Added: `getBlank3MeasureStaffTabLayout()` fallback so geometry remains correct even if the background is swapped to a raster render (no SVG line primitives).

## 2026-01-10 — 01_10_26_20
- Purpose: restore a canonical repo entrypoint for onboarding and cross-thread alignment.
- Core: added root `README.md` including Thread Boot Protocol and the project’s canon docs order.
- Canon: introduced `CANON_PROGRESS.md` as the crosswalk between the DOCX canon and the repo backlog.

## 2026-01-10 — 01_10_26_22
- Purpose: add an explicit meta tracking bucket for recurring UI/UX and rendering refinements to reduce cross-thread regressions.
- Core: `CANON_PROGRESS.md` gains **E) Refinements, Adjustments, and Fine Tuning** (cross-cutting), and `README.md` references it as part of the boot protocol.

## 2026-01-10 — 01_10_26_23
- Purpose: restore the missing multiplayer intermission UX so the phase is visible and behaves like a real turn break.
- Core: phase-driven intermission overlay with countdown + tap-to-start-early; auto-transition to the next turn remains controller-driven.

## 2026-01-10 — 01_10_26_24
- Purpose: fix regressions reported in 01_10_26_23 (timers + Mode 3 surface requirements) and reduce staff/tab hover confusion.
- Core:
  - Engine now emits `TURN_STARTED` so the controller reliably starts the turn countdown.
  - Intermission default increased to 5s and countdown formatting now avoids showing 00:00 while time remains.
  - Mode 3 now requires **TAB + Fretboard** before submission (no auto-fret claim from TAB-only input).
  - Staff/TAB hover feedback changed from full-column shading to a thin alignment line + local hover box.

## 2026-01-11 — 01_11_26_04
- Purpose: implement STAFF/TAB timeline persistence groundwork while keeping notation spatially static.
- Core:
  - Default STAFF/TAB grid set to 8th-note slots (8 columns per measure).
  - STAFF/TAB marks persist across turns; new accepted marks advance a timeline cursor.
  - When the visible window is full, marks scroll left by one slot (no viewBox crop/zoom).
  - STAFF supports multiple noteheads per slot for multi-answer alignment.

## 2026-01-11 — 01_11_26_06
- Purpose: tighten Mode 3 correctness using the persistent accepted-marks timeline.
- Core:
  - In UI Mode `m3` (TAB mode), the fretboard pick must match the TAB selection exactly (same string + fret).
  - Failed composite attempts clear only the transient timeline slot; accepted TAB entries persist until the window scrolls.

## 2026-01-11 — 01_11_26_07
- Purpose: Phase 1.1 + 1.2 validation layer before Mode 3 truth-table lock.
- Core:
  - Added Dev/Test timeline stress tools: fill window, advance cursor, and simulate shift-left beyond capacity.
  - TAB overlay now supports multiple strings per slot (chord-style stacking) while remaining subdivision-aligned and spatially static.

## 2026-01-11 — 01_11_26_08
- Purpose: Implement the accepted-marks persistence pipeline required for Mode 3 truth-model locking.
- Core:
  - STAFF/TAB match clicks now write to pending preview maps; only accepted composite submissions commit them into the persistent timeline record.
  - Pending previews render on separate overlay layers that obey the Asked checkbox layer.
  - Shift-left pipeline now safely reindexes both accepted and pending maps.


---

## guitar-edu-ui_01_11_26_10

- Added Mode 3 staff spelling policy UI toggle (strict vs enharmonic).
- Staff overlay: chord accidental column placement to reduce collisions.
- Added pending STAFF preview rendering (separate layer group).

## 2026-01-11 — Build 01_11_26_11
- Ledger-line preview added for STAFF hover/pending; ledger lines union-rendered per slot.
- Added Dev/Test Mode 3 matrix verification report (strict vs enharmonic).

## 2026-01-12 — Build 01_12_26_01
- Purpose: Phase A (Unit Tests) for faster iteration and regression prevention.
- Core:
  - Added Vitest harness and unit test suite (`tests/unit/`).
  - Extracted deterministic helpers for:
    - STAFF/TAB shift-left pipeline (`src/shell/staffTabTimeline.ts`)
    - STAFF spelling policy checks (`src/shell/spellingPolicy.ts`)
    - TAB multi-string slot stability (`src/shell/tabStack.ts`)
    - Snapshot commit gate (accepted-only, no null frets) (`src/shell/staffTabCommit.ts`)
  - Controller now delegates to these helpers so tests validate real behavior.

## 2026-01-12 — Build 01_12_26_03
- Purpose: fix Phase A test harness so it matches runtime enums.
- Core: aligned unit tests to import/use the canonical `SlotType` enum used by `spellingPolicy`.
- Result: `npm run test:ci` passes (9/9).

## 2026-01-12 — Build 01_12_26_04
- Purpose: Phase B (E2E) for no-terminal-friendly iteration and regression prevention.
- Core:
  - Added Playwright harness (`playwright.config.ts`) and `tests/e2e/` specs.
  - Added scripts: `npm run e2e` (headless) and `npm run e2e:ui` (interactive).
  - E2E validates:
    - Dev unlock paths (5-click build badge + Ctrl+Shift+D) and footer DEV panel access.
    - Staff accidental prompt and commit persistence.
    - Fill + shift-left stress for STAFF/TAB persistence and TAB number visibility.
    - Mode 3 strict vs enharmonic policy verification via Dev/Test truth-table report.
  - Added `TESTING.md` with install + run instructions.


### 01_12_26_06
- Patched RUN_DEV.bat: wait-for-server loop (ports 5173-5180) before opening browser.
- Patched RUN_DEV.bat: writes dev server output to `devserver.log` for quick troubleshooting.


## guitar-edu-ui_01_12_26_07
- Fix RUN_DEV.bat: robust working-directory anchoring, safe quoting, and reliable browser open after server startup.

## guitar-edu-ui_01_12_26_08
- Tooling: RUN_DEV.bat now detects Node major version and, on Node >= 23, automatically uses an optional-dependency install flow and validates Rollup can be required.
- Tooling: When Rollup's Windows native optional dependency is missing, RUN_DEV.bat performs an automated repair (clean install with `--include=optional` + `npm rebuild rollup`).

## 2026-01-12 — Patch 01_12_26_11
- Hotfix: DEVSERVER_RUNNER now runs `call npm run dev` directly and appends all output to `logs\\devserver.log` (no PowerShell Tee-Object quoting failures).
- Hotfix: RUN_DEV logging initialization repaired; log paths normalized to Windows backslashes.

## 2026-01-12 — Patch 01_12_26_12
- Docs: Platform endgame locked to **Web + PWA + Desktop (Tauri)**.
- Added `DOCS/PLATFORM_STRATEGY.md` and recorded the decision in `DECISIONS_LOG.md`.

## 2026-01-12 — Patch 01_12_26_14
- PWA: Added manifest + service worker via `vite-plugin-pwa`.
- Persistence: Implemented IndexedDB snapshot (settings + leaderboards) with Dev/Test export/import helpers.
- App boot: Added IndexedDB hydrate step before controller init.



## 01_12_26_15
- Added RUN_PREVIEW.bat (one-click build + vite preview + auto-open browser) with logging to logs/run_preview.log.

## 2026-01-13 — Patch 01_13_26_02
- Phase 1: Enabled chord-style STAFF stacking within a single timeline slot (pending).
  - STAFF picks now toggle a note on/off in the pending list instead of replacing the slot.
  - Accidental prompt commit no longer clears other pending STAFF/TAB marks in the same column.
