import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";

function readBuildId() {
  const p = path.join("src","app","buildInfo.ts");
  const txt = fs.readFileSync(p, "utf8");
  const m = txt.match(/BUILD_ID\s*=\s*"([^"]+)"/);
  return m ? m[1] : "unknown";
}

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

// This script intentionally does NOT run `npm install`.
// Expected usage:
//   npm ci
//   npm run build
//   npm run release:zip
//
// It uses PowerShell's Compress-Archive on Windows for a deterministic artifact.
const buildId = readBuildId();
const releasesDir = path.join("releases");
ensureDir(releasesDir);

const zipName = `guitar-edu-ui_${buildId}_release.zip`;
const zipPath = path.join(releasesDir, zipName);

// Always regenerate
if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

const includes = [
  "dist",
  "docs",
  "CHANGELOG.md",
  "BUILD_LOG.md",
  "package.json",
  "package-lock.json"
].filter((p) => fs.existsSync(p));

const quoted = includes.map((p) => `"${p}"`).join(", ");
const ps = `Compress-Archive -Force -Path ${quoted} -DestinationPath "${zipPath}"`;

try {
  execSync(`powershell -NoProfile -ExecutionPolicy Bypass -Command ${JSON.stringify(ps)}`, { stdio: "inherit" });
} catch (e) {
  console.error("Packaging failed. On non-Windows systems, create a zip from:", includes);
  process.exit(1);
}

console.log(`OK: ${zipPath}`);
