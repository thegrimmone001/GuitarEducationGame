# Confirmation Protocol (Canon Guardrail)

Purpose: prevent drift. Any change that is *not explicitly in canon* must be proposed, logged, and approved **before** it is implemented.

## Definitions
- **Canon**: the current project rules and requirements defined in the docs inside the archive (e.g., CHECKLIST_MASTER.md, MATCH_SETTINGS_SPEC.md, DEPRECATED_TERMS.md, DECISIONS_LOG.md, TASK_BOARD.md).
- **Non-canon change**: any new feature, new UI element, new rule, renamed term, or behavioral change not already described in canon.

## Workflow
1) **Detect**
   - If a change is not clearly demanded by canon, treat it as non-canon.

2) **Propose**
   - Add an entry to `docs/SUGGESTIONS_LOG.md` with:
     - ID (SUG-###)
     - Title
     - Description
     - Canon references (if any)
     - Impact (UI/engine/docs/build)
     - Risk / tradeoffs
     - Minimal implementation outline

3) **Confirm**
   - Only proceed after you explicitly respond with:
     - `APPROVE: SUG-###` (implement now) **or**
     - `DEFER: SUG-###` (keep logged, do not implement) **or**
     - `REJECT: SUG-###` (close the suggestion)

4) **Implement**
   - Implementation must reference the approved SUG-### in:
     - CHANGELOG.md
     - BUILD_LOG.md
     - TASK_BOARD.md (as a task)

## Emergency Exception (Stability-only)
Allowed without confirmation:
- Fixes that prevent the app from booting, compiling, or loading (syntax errors, crashes, guards, missing imports).
Even then:
- Add a short note in BUILD_LOG.md describing what broke and what was fixed.

