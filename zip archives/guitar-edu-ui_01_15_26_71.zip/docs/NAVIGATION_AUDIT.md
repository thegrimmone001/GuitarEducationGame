# Navigation and Lifecycle Audit (Step I)

Goal: eliminate page-load failures and double initialization by enforcing a single, verifiable lifecycle.

## Findings
1. `installEventLog()` was not idempotent and could be re-installed, re-patching `window.dispatchEvent`.
2. `gedu:enterUI` was listened to on both `window` and `document` for backwards compatibility; if a build dispatched to both, it could start a session twice.

## Fixes
- Added `window.__GEDU_EVENTLOG_INSTALLED__` guard in `src/app/eventLog.ts`.
- Added `window.__GEDU_ENTERUI_GUARD__` debounce in `src/app/gameController.ts` (100ms, same intent).

## Verification checklist
- Reload page: no duplicate `SYS eventLog:installed` events.
- Starting a session: only one `ENGINE ENTER_UI` and one `ENGINE BEGIN_MATCH` per click.
- Console: no repeated patching warnings.

## Notes
These are stability-only changes (no gameplay feature additions).

## Boot guard
- main.ts now suppresses duplicate boot to prevent double-mount / double installers.
