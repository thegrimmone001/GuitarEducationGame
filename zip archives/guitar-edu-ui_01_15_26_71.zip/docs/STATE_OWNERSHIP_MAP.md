# State Ownership Map (Deterministic Lifecycle)

This document defines the *single authoritative owner* for each category of state. The goal is to prevent double initialization, race conditions, and page-load failures.

## Boot and installers

### Boot sequence
- **Owner:** `src/main.ts`
- **Single entry:** `boot()` guarded by `window.__GEDU_BOOT_ALREADY_RAN__`.
- **Order constraints:**
  1. `mountLayout(app)` (DOM scaffold)
  2. `installEventLog(document)` (diagnostics)
  3. `initGameController(document)` (event listeners + engine bridge)
  4. `runSmokeTestIfRequested(document)`
  5. `hydrateFromIndexedDb()` (must never block wiring)

### Installer idempotence
- **Event Log installer:** `installEventLog()` now guarded by `window.__GEDU_EVENTLOG_INSTALLED__`.
- **Game controller installer:** `initGameController()` guarded by `window.__GEDU_GAME_CONTROLLER_INSTALLED__`.

## UI routing and navigation

### UI layout + control surfaces
- **Owner:** `src/ui/layout.ts`
- **Responsibilities:**
  - Build the DOM for splash, match UI, overlays, and panels.
  - Emit `gedu:matchOptions` as the canonical UI → engine settings bridge.
  - Suppress init-phase `matchOptions` spam; emit once after mount completes.

### Session start events
- **Owner:** UI emits; controller routes.
- **UI emits:** `gedu:enterUI` or `gedu:beginSession`.
- **Controller routes:** `src/app/gameController.ts` maps event → `beginMatch(...)` / `beginEducation()`.
- **Determinism guard:** `handleEnterUi` ignores duplicate intent events within 100ms (`window.__GEDU_ENTERUI_GUARD__`).

## Engine and match state

### Match state
- **Owner:** `src/app/gameController.ts`
- **Responsibilities:**
  - Own and mutate `state` (match, phase, prompt, timers, score, board).
  - Own session mode (`single`, `multi`, `edu`).
  - Own the “Ready / Engage” start gate.
  - Own authoritative exit path (`gedu:exitRequested`).

### Rendering
- **Owner:** `src/app/gameController.ts` (drives), `src/render/*` (implements)
- **Responsibilities:**
  - Ensure surfaces are always mounted.
  - Suppress visuals via styling (not DOM removal).
  - Keep prompt rail and prompt banner deterministic.

## Diagnostics

### Event Log
- **Owner:** `src/app/eventLog.ts`
- **Responsibilities:**
  - Capture `gedu:*` events.
  - Maintain bounded event list (MAX).
  - Provide copy/download support (overlay controls + report pack).

## Invariants (must never regress)
- Boot runs once.
- Installers run once.
- Session start routes once per intent.
- Hydration never blocks event wiring.
