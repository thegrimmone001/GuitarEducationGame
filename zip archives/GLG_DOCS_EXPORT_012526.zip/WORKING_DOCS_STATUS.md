# Working Docs Status — 012526

## What I checked

- Canon Continuation (text)
- Schema Registry
- v1.1 JSON schemas: MatchOptions, Surface Controls, Pitch Sets (Interval/Chord/Scale-Mode/Arpeggio), Tonal Assist

## Currency / Up-to-date check

All provided schema files are internally consistent:
- MatchOptions schema references: `surfaceControls`, `timers`, `pitchSets`, `progression`, `tonalAssistSettingsRef`.
- Surface Controls schema uses roles: `prompt`, `mark`, `persistence`, `sam`, with scopes `single|rotating|all|random`, and coordination omitted for SAM (as locked).
- Answer Rules include `answerSet` enum: `single|equivalent|octave|all`, plus `answerCount`, and `octaveRange` gated by `octave`.

No deprecated term drift was found in the schemas (they do not use “display/visibility” for Persistence).

## Immediate deltas to enforce in UI (from your notes)

- Advanced UI must be **wing flyout** (not modal), with a **two-column** main region and **no scrolling**.
- Control alignment must be grid-stable: no shifting, no resizing, dropdowns as overlays.
- Timer UI must treat Check Clock / Chess Clock / Time Bank as a single clock-mode system (no duplicated dropdown blocks).

(These are UI contract concerns; schemas are ready for serialization.)
