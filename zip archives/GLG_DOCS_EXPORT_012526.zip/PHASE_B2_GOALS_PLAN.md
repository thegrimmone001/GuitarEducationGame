# Phase B-2 Goals & Plan

## Phase B-2 — Resume Plan (Menu Completion + Serialization)

### Goal
Finish menu UI shells that serialize cleanly to the locked v1.1 schemas, with layout behavior enforced by `ADVANCED_WING_LAYOUT_CONTRACT.md`.

### Order of work
1. Implement Advanced Wing Flyout per contract (two-column, no scroll, Subpanel drawer).
2. Surface Controls section:
   - Per-surface rows (FB/ST/TAB/NR)
   - Roles Prompt/Mark/Persistence/SAM
   - Scope + Coordination rules
3. Pitch Sets builders (shells only)
4. Progressions builder + per-step override Subpanel
5. Timers (single clock-mode system)
6. System → Tonal Assist settings

### Non-goals (locked)
- No new gameplay logic.
- No new terminology.
- No engine wiring; only serialization.

### Verification
- Visual stability: controls never jump.
- No folder/naming drift: repo structure unchanged.
- Exported match options JSON validates against MatchOptions schema v1.1.
