# Interval Pitch Set Schema v1.1

Repo-ready mirror of the current authoritative schema text (v1.1).

## JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "glg.pitchSet.interval.schema.v1.1",
  "title": "GLG Interval Pitch Set",
  "type": "object",
  "required": [
    "id",
    "type",
    "reference",
    "intervals",
    "constraints"
  ],
  "properties": {
    "id": {
      "type": "string"
    },
    "type": {
      "const": "interval"
    },
    "reference": {
      "type": "string",
      "enum": [
        "fixed",
        "relative"
      ]
    },
    "intervals": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "direction": {
      "type": "string",
      "enum": [
        "up",
        "down",
        "either"
      ]
    },
    "compoundAllowed": {
      "type": "boolean"
    },
    "constraints": {
      "type": "object",
      "properties": {
        "strings": {
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "span": {
          "type": "object"
        }
      }
    }
  },
  "additionalProperties": false
}
```
