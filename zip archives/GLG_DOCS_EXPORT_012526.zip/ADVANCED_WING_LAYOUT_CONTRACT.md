# Advanced Wing Layout Contract

This contract specifies the **Advanced Wing** UI layout and interaction rules. It is intended to be implementation-proof and enforceable in code review.

## 1) Core Intent

- The playfield is **not** part of menu structure. Menus are **overlays** on top of the playfield.
- The Advanced system is a **Wing Flyout**, not a centered modal.
- The wing provides a **larger dual-column layout** with **no scrolling** in the main wing area.
- Builders/editors that exceed the wing’s visible space must use an **internal right-edge slide-over drawer** ("Subpanel") anchored **inside** the wing.

## 2) Wing Flyout Requirements (Non-Negotiable)

### 2.1 Positioning and Behavior
- Anchored to the **right edge** of the application viewport.
- Opens/closes without shifting underlying layout (no reflow of base page).
- Dismiss methods:
  - Dedicated **Close** control in the wing header.
  - `Esc` key closes wing.
  - Clicking outside closes wing **only if** it does not conflict with in-progress edits (if unsure, disable outside-click close).
- Z-index: wing always above playfield and any basic menu panels.

### 2.2 Dimensions
- Fixed width (responsive clamp allowed), tuned for 16:9 and smart-board usage.
- Wing height fits within viewport with consistent top/bottom gutters.
- **No vertical scrolling in the wing’s main content region.**
  - If content would overflow, it must be moved into a Subpanel (see §4), or converted to paging within a section.

### 2.3 Header + Section Navigator
- Header row contains:
  - Title: **“Advanced Match Settings”**
  - Close control aligned top-right
- Immediately below header: **Section Navigator** (tabs or segmented controls), fixed height, single row, no wrapping:
  - Core
  - Surface Controls
  - Pitch Sets
  - Progressions
  - Timers
  - System
- Switching sections must not change wing size, padding, or grid alignment.

## 3) Two-Column Grid Contract

### 3.1 Grid
- Main wing content is a 2-column grid:
  - **Left Column:** primary configuration fields and concise summaries
  - **Right Column:** complementary configuration fields and concise summaries
- Column widths are stable; controls do not jump when state changes.

### 3.2 Alignment Rules (No Shifting Controls)
- Every row uses consistent label height + input height.
- Dropdowns, toggles, steppers share a baseline and equal heights.
- When showing/hiding conditional controls:
  - Reserve space using placeholder slots OR
  - Use a fixed-height container with internal visibility toggles
  - Never allow neighboring controls to shift positions.

### 3.3 Interaction Stability
- Opening a dropdown must not push other controls (use portal/overlay menus).
- Focus/active rings must not change layout metrics (no border-size growth).

## 4) Subpanel (Internal Drawer) Contract

### 4.1 Purpose
Used for detailed builders/editors that cannot fit in the wing without scrolling (e.g., step overrides, complex lists, cardinality configuration, etc.).

### 4.2 Behavior
- Subpanel slides in from the **right edge of the wing** (not the viewport).
- Subpanel does not cover the Section Navigator.
- Subpanel header displays explicit context, e.g.:
  - “Answer Rules — Cardinality”
  - “Surface Controls — Fretboard / Mark”
  - “Progressions — Step 3 Overrides”
- Subpanel has its own Close/Back control.

## 5) Advanced Wing Content Responsibilities

The wing hosts UI shells only. No engine wiring required at this phase, but all values must serialize to the locked schemas.

### 5.1 Core
- Instrument controls (Instrument, Tuning, Strings, Span)
- Player/Board options (as applicable)
- Presets A–J selector (no renaming; intent locked)

### 5.2 Surface Controls
- Per-surface rows: Fretboard, Staff, TAB, Note Rail
- Roles per surface:
  - Prompt, Mark, Persistence, SAM
- Each role has:
  - Enabled toggle
  - Surface Scope: single | rotating | all | random
  - Coordination (Prompt/Mark/Persistence only) where applicable
- SAM has no coordination.

### 5.3 Pitch Sets
- Shell builders for:
  - Intervals
  - Chords
  - Scales/Modes
  - Arpeggios

### 5.4 Progressions
- Builder + per-step overrides shell
- Mode-aware degrees supported through per-step overrides (no engine logic here).

### 5.5 Timers
- Timers section is a single coherent model:
  - Turn Timer
  - Clock mode (Off | Check Clock | Chess Clock | Time Bank)
  - Runtime Cap
  - Attempts per Turn
  - Increment / penalty / add-subtract fields
- **Check Clock, Chess Clock, and Time Bank are clock modes of one system** (not separate duplicated dropdown systems).

### 5.6 System → Tonal Assist Settings
- Tonal Assist settings live here and serialize to the Tonal Assist schema.

## 6) Acceptance Tests (UI)
A build meets this contract if:

1. Opening Advanced Match Settings presents a **right-anchored wing** (not centered modal).
2. Wing shows **two visible columns** without vertical scrolling.
3. Switching between sections does not move/resize controls.
4. Dropdowns open as overlays without pushing layout.
5. Conditional controls do not cause neighboring controls to jump.
6. Any “deep edit” opens in the **Subpanel**, not by expanding the wing into scroll.
7. All settings serialize to the v1.1 schemas without added fields.
