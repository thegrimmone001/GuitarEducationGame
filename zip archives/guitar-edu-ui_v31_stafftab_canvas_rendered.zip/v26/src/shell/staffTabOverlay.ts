import { SlotType, VariantId } from "./types";
import { fromVariantId, IS_BLACK } from "./music";

// ----------------------------
// Types
// ----------------------------

export type StaffTabRegion = "staff" | "tab";

export interface StaffTabHit {
  region: StaffTabRegion;
  /** Global column index (0..totalCols-1). */
  col: number;
  /** Measure index (0..measureCount-1). */
  measureIndex: number;
  /** Column index inside measure (0..columnsPerMeasure-1). */
  colInMeasure: number;
  /** Canvas-local hit point (CSS pixels). */
  x: number;
  y: number;
  /**
   * Staff: step index (ledger-step granularity) from the bottom line reference,
   * Tab: string index (0=high e .. 5=low E).
   */
  yIndex: number;
  /**
   * Column rect in canvas-local pixels.
   */
  rect: { x0: number; x1: number; y0: number; y1: number };
}

export interface StaffTabLayout {
  width: number;
  height: number;
  uiMode: string;
  columnsPerMeasure: number;
  measureCount: number;
  totalCols: number;

  padX: number;
  padY: number;
  labelW: number;
  innerLeft: number;
  innerRight: number;

  measures: Array<{ x0: number; x1: number }>; // inner coordinates

  staff: {
    enabled: boolean;
    lineYs: number[]; // 5 lines
    halfStep: number; // between adjacent diatonic steps
    stepCenters: number[]; // for hit-testing / rendering
    yMin: number;
    yMax: number;
  };

  tab: {
    enabled: boolean;
    lineYs: number[]; // 6 lines
    stringCenters: number[]; // 6 centers
    yMin: number;
    yMax: number;
    dividerY: number;
  };
}

export interface StaffTabOverlayState {
  hover: StaffTabHit | null;

  // Optional debug/paint marks (used in Dev/Test). Keys are global col index.
  staffMarksByCol: Map<number, { yIndex: number }>;
  tabMarksByCol: Map<number, { stringIndex: number; fret: number }>;

  tabDefaultNumber: number;
  selectedString: number | null;
  promptVariantId?: VariantId;
}

export function createStaffTabOverlayState(): StaffTabOverlayState {
  return {
    hover: null,
    staffMarksByCol: new Map(),
    tabMarksByCol: new Map(),
    tabDefaultNumber: 0,
    selectedString: null,
    promptVariantId: undefined,
  };
}

// ----------------------------
// Staff math (future-proof: real note rendering driven by tab grid)
// ----------------------------

// Standard tuning open-string MIDI (sounding), string order:
// high e .. low E.
const OPEN_STRING_MIDI = [64, 59, 55, 50, 45, 40];

// Staff reference: bottom line is E4 in treble clef (written).
// Guitar is written 1 octave higher than it sounds.
const REF_LETTER_E = 2; // C=0 D=1 E=2
const REF_OCTAVE_E4 = 4;

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function midiOctave(midi: number): number {
  return Math.floor(midi / 12) - 1;
}

function diatonicNumber(letter: number, octave: number): number {
  // C=0..B=6, each octave adds 7.
  return octave * 7 + letter;
}

const REF_DIATONIC_E4 = diatonicNumber(REF_LETTER_E, REF_OCTAVE_E4);

function writtenMidiForGuitar(soundingMidi: number): number {
  return soundingMidi + 12;
}

function spellForLane(pc: number, lane: SlotType): { letter: number; acc: -1 | 0 | 1 } {
  // Natural pitch classes map
  const natMap: Record<number, number> = { 0: 0, 2: 1, 4: 2, 5: 3, 7: 4, 9: 5, 11: 6 };
  if (!IS_BLACK[pc]) return { letter: natMap[pc] ?? 0, acc: 0 };

  if (lane === SlotType.FLT) {
    // Db, Eb, Gb, Ab, Bb
    const flatMap: Record<number, number> = { 1: 1, 3: 2, 6: 4, 8: 5, 10: 6 };
    return { letter: flatMap[pc] ?? 1, acc: -1 };
  }
  // Default to sharps for black notes.
  const sharpMap: Record<number, number> = { 1: 0, 3: 1, 6: 3, 8: 4, 10: 5 };
  return { letter: sharpMap[pc] ?? 0, acc: 1 };
}

function staffIndexForWrittenMidi(writtenMidi: number, lane: SlotType): { staffIndex: number; acc: -1 | 0 | 1 } {
  const pc = ((writtenMidi % 12) + 12) % 12;
  const { letter, acc } = spellForLane(pc, lane);
  const oct = midiOctave(writtenMidi);
  const d = diatonicNumber(letter, oct);
  return { staffIndex: d - REF_DIATONIC_E4, acc };
}

// ----------------------------
// Layout + hit testing
// ----------------------------

function canvasToLocal(canvas: HTMLCanvasElement, clientX: number, clientY: number): { x: number; y: number } {
  const r = canvas.getBoundingClientRect();
  const x = clientX - r.left;
  const y = clientY - r.top;
  return { x, y };
}

function ensureCanvasResolution(canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D) {
  const dpr = Math.max(1, Math.round(window.devicePixelRatio || 1));
  const r = canvas.getBoundingClientRect();
  const w = Math.max(1, Math.floor(r.width));
  const h = Math.max(1, Math.floor(r.height));
  const pw = w * dpr;
  const ph = h * dpr;
  if (canvas.width !== pw || canvas.height !== ph) {
    canvas.width = pw;
    canvas.height = ph;
  }
  // Draw in CSS pixels.
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { w, h };
}

export function parseStaffTabLayout(
  canvas: HTMLCanvasElement,
  uiMode: string,
  columnsPerMeasure = 16,
  measureCount = 3,
): StaffTabLayout {
  const r = canvas.getBoundingClientRect();
  const width = Math.max(1, r.width);
  const height = Math.max(1, r.height);

  const padX = 14;
  const padY = 12;
  const labelW = 28;

  const innerLeft = padX + labelW;
  const innerRight = width - padX;

  const totalCols = Math.max(1, (columnsPerMeasure | 0) * (measureCount | 0));
  const mc = Math.max(1, measureCount | 0);
  const gutter = clamp((innerRight - innerLeft) * 0.02, 8, 18);
  const avail = Math.max(1, (innerRight - innerLeft) - gutter * (mc - 1));
  const measureW = avail / mc;

  const measures: Array<{ x0: number; x1: number }> = [];
  for (let i = 0; i < mc; i++) {
    const x0 = innerLeft + i * (measureW + gutter);
    const x1 = x0 + measureW;
    measures.push({ x0, x1 });
  }

  const showStaff = uiMode !== "m3"; // tab-only hides staff
  const showTab = uiMode !== "m2"; // staff-only hides tab

  // Vertical split
  const gap = clamp(height * 0.03, 6, 12);
  let staffAreaTop = padY;
  let staffAreaH = height * 0.58;
  let tabAreaTop = staffAreaTop + staffAreaH;
  let tabAreaH = height - staffAreaH;

  if (showStaff && !showTab) {
    staffAreaTop = padY;
    staffAreaH = height - padY * 2;
    tabAreaTop = staffAreaTop + staffAreaH;
    tabAreaH = 0;
  } else if (showTab && !showStaff) {
    staffAreaTop = padY;
    staffAreaH = 0;
    tabAreaTop = padY;
    tabAreaH = height - padY * 2;
  } else {
    staffAreaTop = padY;
    staffAreaH = (height - padY * 2 - gap) * 0.58;
    tabAreaTop = staffAreaTop + staffAreaH + gap;
    tabAreaH = height - padY * 2 - gap - staffAreaH;
  }

  // Staff geometry
  const staffLines: number[] = [];
  let staffHalfStep = 6;
  const staffStepCenters: number[] = [];
  let staffYMin = 0;
  let staffYMax = 0;

  if (showStaff) {
    const staffPad = clamp(staffAreaH * 0.12, 10, 22);
    const yTopLine = staffAreaTop + staffPad;
    const yBottomLine = staffAreaTop + staffAreaH - staffPad;
    const gapLine = Math.max(10, (yBottomLine - yTopLine) / 4);
    staffHalfStep = gapLine / 2;

    // bottom line is index 0 for easier mapping with staffIndex math
    for (let i = 0; i < 5; i++) staffLines.push(yBottomLine - gapLine * i);

    // Provide a generous ledger range for hit-testing and rendering.
    // 0..14 mirrors the earlier SVG-based prototype.
    for (let si = 0; si < 15; si++) {
      staffStepCenters.push(yBottomLine - si * staffHalfStep);
    }
    staffYMin = staffStepCenters[staffStepCenters.length - 1] - staffHalfStep * 1.2;
    staffYMax = staffStepCenters[0] + staffHalfStep * 1.2;
  }

  // Tab geometry
  const tabLines: number[] = [];
  const tabStringCenters: number[] = [];
  let tabYMin = 0;
  let tabYMax = 0;
  const dividerY = showStaff && showTab ? tabAreaTop - gap / 2 : (showStaff ? (staffAreaTop + staffAreaH) : tabAreaTop);

  if (showTab) {
    const tabPad = clamp(tabAreaH * 0.18, 10, 24);
    const yTabTop = tabAreaTop + tabPad;
    const yTabBottom = tabAreaTop + tabAreaH - tabPad;
    const tabGap = Math.max(10, (yTabBottom - yTabTop) / 5);
    for (let s = 0; s < 6; s++) tabLines.push(yTabTop + tabGap * s);
    for (let s = 0; s < 6; s++) tabStringCenters.push(yTabTop + tabGap * s);
    tabYMin = yTabTop - tabGap * 0.8;
    tabYMax = yTabBottom + tabGap * 0.8;
  }

  return {
    width,
    height,
    uiMode,
    columnsPerMeasure: Math.max(1, columnsPerMeasure | 0),
    measureCount: mc,
    totalCols,

    padX,
    padY,
    labelW,
    innerLeft,
    innerRight,

    measures,

    staff: {
      enabled: showStaff,
      lineYs: staffLines,
      halfStep: staffHalfStep,
      stepCenters: staffStepCenters,
      yMin: staffYMin,
      yMax: staffYMax,
    },
    tab: {
      enabled: showTab,
      lineYs: tabLines,
      stringCenters: tabStringCenters,
      yMin: tabYMin,
      yMax: tabYMax,
      dividerY,
    },
  };
}

function hitTest(layout: StaffTabLayout, x: number, y: number): StaffTabHit | null {
  // Determine measure + column.
  let measureIndex = -1;
  for (let i = 0; i < layout.measures.length; i++) {
    const m = layout.measures[i];
    if (x >= m.x0 && x <= m.x1) {
      measureIndex = i;
      break;
    }
  }
  if (measureIndex < 0) return null;
  const m = layout.measures[measureIndex];
  const colW = (m.x1 - m.x0) / layout.columnsPerMeasure;
  const colInMeasure = clamp(Math.floor((x - m.x0) / colW), 0, layout.columnsPerMeasure - 1);
  const col = measureIndex * layout.columnsPerMeasure + colInMeasure;

  const x0 = m.x0 + colInMeasure * colW;
  const x1 = x0 + colW;

  // Region + yIndex
  if (layout.staff.enabled && y >= layout.staff.yMin && y <= layout.staff.yMax) {
    const centers = layout.staff.stepCenters;
    let best = 0;
    let bestD = Infinity;
    for (let i = 0; i < centers.length; i++) {
      const d = Math.abs(centers[i] - y);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    return {
      region: "staff",
      col,
      measureIndex,
      colInMeasure,
      x,
      y,
      yIndex: best,
      rect: { x0, x1, y0: layout.staff.yMin, y1: layout.staff.yMax },
    };
  }

  if (layout.tab.enabled && y >= layout.tab.yMin && y <= layout.tab.yMax) {
    const centers = layout.tab.stringCenters;
    let best = 0;
    let bestD = Infinity;
    for (let i = 0; i < centers.length; i++) {
      const d = Math.abs(centers[i] - y);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    return {
      region: "tab",
      col,
      measureIndex,
      colInMeasure,
      x,
      y,
      yIndex: best,
      rect: { x0, x1, y0: layout.tab.yMin, y1: layout.tab.yMax },
    };
  }

  return null;
}

// ----------------------------
// Rendering
// ----------------------------

function drawRoundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function drawNoteHead(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, alpha: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-0.25);
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 1.15, r * 0.85, 0, 0, Math.PI * 2);
  ctx.closePath();
  ctx.fillStyle = `rgba(255,255,255,${0.80 * alpha})`;
  ctx.strokeStyle = `rgba(255,255,255,${0.90 * alpha})`;
  ctx.lineWidth = 1.1;
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function deriveStaffNotesFromTabMarks(
  tabMarksByCol: Map<number, { stringIndex: number; fret: number }>,
  totalCols: number,
  preferLane: SlotType,
): Array<Array<{ staffIndex: number; acc: -1 | 0 | 1; ghost?: boolean }>> {
  const out: Array<Array<{ staffIndex: number; acc: -1 | 0 | 1; ghost?: boolean }>> = Array.from({ length: totalCols }, () => []);

  for (const [col, m] of tabMarksByCol.entries()) {
    if (col < 0 || col >= totalCols) continue;
    const open = OPEN_STRING_MIDI[m.stringIndex] ?? 40;
    const sounding = open + (m.fret ?? 0);
    const written = writtenMidiForGuitar(sounding);
    const lane = IS_BLACK[((sounding % 12) + 12) % 12] ? preferLane : SlotType.NAT;
    const { staffIndex, acc } = staffIndexForWrittenMidi(written, lane);
    out[col].push({ staffIndex, acc });
  }

  return out;
}

export function renderStaffTabOverlay(
  canvas: HTMLCanvasElement,
  layout: StaffTabLayout,
  st: StaffTabOverlayState,
): void {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const { w: W, h: H } = ensureCanvasResolution(canvas, ctx);

  ctx.clearRect(0, 0, W, H);

  // Palette (aligned to existing UI: soft whites on glass)
  const fg = "rgba(0,0,0,0.78)"; // lines on white panel
  const faint = "rgba(0,0,0,0.18)";
  const faint2 = "rgba(0,0,0,0.10)";
  const strong = "rgba(0,0,0,0.92)";
  const hoverFill = "rgba(0, 183, 255, 0.10)";
  const hoverStroke = "rgba(0, 183, 255, 0.18)";

  // Background (let the parent panel control the fill; keep canvas transparent)

  // Hover column highlight
  if (st.hover) {
    const r = st.hover.rect;
    ctx.fillStyle = hoverFill;
    ctx.strokeStyle = hoverStroke;
    ctx.lineWidth = 1;
    drawRoundedRect(ctx, r.x0 + 1, Math.max(layout.padY, r.y0) + 2, (r.x1 - r.x0) - 2, (Math.min(H - layout.padY, r.y1) - Math.max(layout.padY, r.y0)) - 4, 10);
    ctx.fill();
    ctx.stroke();
  }

  // Subdivision guides + measure boundaries
  for (let mi = 0; mi < layout.measures.length; mi++) {
    const m = layout.measures[mi];
    const colW = (m.x1 - m.x0) / layout.columnsPerMeasure;

    for (let ci = 0; ci <= layout.columnsPerMeasure; ci++) {
      const x = m.x0 + colW * ci;
      const isMeasureEdge = ci === 0 || ci === layout.columnsPerMeasure;
      const isBeat = (ci % 4) === 0;
      ctx.strokeStyle = isMeasureEdge ? faint : (isBeat ? faint2 : "rgba(0,0,0,0.06)");
      ctx.lineWidth = isMeasureEdge ? 1.4 : 1;
      ctx.beginPath();
      ctx.moveTo(x, layout.padY);
      ctx.lineTo(x, H - layout.padY);
      ctx.stroke();
    }
  }

  // Divider between staff and tab (when both are visible)
  if (layout.staff.enabled && layout.tab.enabled) {
    ctx.strokeStyle = faint2;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(layout.padX, layout.tab.dividerY);
    ctx.lineTo(W - layout.padX, layout.tab.dividerY);
    ctx.stroke();
  }

  // Staff lines
  if (layout.staff.enabled) {
    ctx.strokeStyle = fg;
    ctx.lineWidth = 1.2;
    for (const y of layout.staff.lineYs) {
      ctx.beginPath();
      ctx.moveTo(layout.innerLeft, y);
      ctx.lineTo(layout.innerRight, y);
      ctx.stroke();
    }
  }

  // Tab string labels + lines
  if (layout.tab.enabled) {
    const labels = ["e", "B", "G", "D", "A", "E"]; // high->low

    ctx.font = "700 12px system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    for (let s = 0; s < 6; s++) {
      const y = layout.tab.stringCenters[s] ?? 0;
      const selected = st.selectedString === s;
      ctx.fillStyle = selected ? strong : fg;
      ctx.fillText(labels[s] ?? "", layout.padX + layout.labelW / 2, y);
    }

    ctx.strokeStyle = fg;
    ctx.lineWidth = 1.1;
    for (const y of layout.tab.lineYs) {
      ctx.beginPath();
      ctx.moveTo(layout.innerLeft, y);
      ctx.lineTo(layout.innerRight, y);
      ctx.stroke();
    }
  }

  // Build tab grid for display (supports chords by storing multiple marks per column in the future).
  // Current state is 1 mark per column, but we allow collision handling for stability.
  const preferLane = (() => {
    if (st.promptVariantId == null) return SlotType.SHR;
    const v = fromVariantId(st.promptVariantId);
    return v.spelling;
  })();

  const staffNotesByCol = deriveStaffNotesFromTabMarks(st.tabMarksByCol, layout.totalCols, preferLane);

  // If there are no tab notes, show the current prompt as a faint centered target.
  const anyTab = st.tabMarksByCol.size > 0;
  if (!anyTab && st.promptVariantId != null && layout.staff.enabled) {
    const v = fromVariantId(st.promptVariantId);
    const written = 72 + v.pitchClass; // around C5
    const { staffIndex, acc } = staffIndexForWrittenMidi(written, v.spelling);
    const c = Math.floor(layout.totalCols / 2);
    staffNotesByCol[c].push({ staffIndex, acc, ghost: true });
  }

  // Tab numbers
  if (layout.tab.enabled) {
    ctx.font = "800 13px system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    for (const [col, m] of st.tabMarksByCol.entries()) {
      if (col < 0 || col >= layout.totalCols) continue;
      const measureIndex = Math.floor(col / layout.columnsPerMeasure);
      const colInMeasure = col % layout.columnsPerMeasure;
      const measure = layout.measures[measureIndex];
      if (!measure) continue;
      const colW = (measure.x1 - measure.x0) / layout.columnsPerMeasure;
      const x = measure.x0 + colW * (colInMeasure + 0.5);
      const y = layout.tab.stringCenters[m.stringIndex] ?? 0;
      const selected = st.selectedString === m.stringIndex;
      ctx.fillStyle = selected ? "rgba(0,0,0,0.92)" : "rgba(0,0,0,0.82)";
      ctx.fillText(String(m.fret), x, y);
    }

    // Preview number (hover) – shows what would be placed in Dev Paint mode.
    if (st.hover?.region === "tab" && st.selectedString != null) {
      const col = st.hover.col;
      const measureIndex = Math.floor(col / layout.columnsPerMeasure);
      const colInMeasure = col % layout.columnsPerMeasure;
      const measure = layout.measures[measureIndex];
      if (measure) {
        const colW = (measure.x1 - measure.x0) / layout.columnsPerMeasure;
        const x = measure.x0 + colW * (colInMeasure + 0.5);
        const y = layout.tab.stringCenters[st.selectedString] ?? 0;
        ctx.fillStyle = "rgba(0,0,0,0.28)";
        ctx.fillText(String(st.tabDefaultNumber | 0), x, y);
      }
    }
  }

  // Staff notes
  if (layout.staff.enabled) {
    const noteR = clamp(layout.staff.halfStep * 0.75, 4, 8);

    for (let col = 0; col < layout.totalCols; col++) {
      const group = staffNotesByCol[col] ?? [];
      if (!group.length) continue;

      const measureIndex = Math.floor(col / layout.columnsPerMeasure);
      const colInMeasure = col % layout.columnsPerMeasure;
      const measure = layout.measures[measureIndex];
      if (!measure) continue;
      const colW = (measure.x1 - measure.x0) / layout.columnsPerMeasure;
      const xCenter = measure.x0 + colW * (colInMeasure + 0.5);

      // Collision nudging
      const usedY: number[] = [];
      const sorted = [...group].sort((a, b) => a.staffIndex - b.staffIndex);

      for (const n of sorted) {
        const alpha = n.ghost ? 0.45 : 1.0;
        const y = layout.staff.lineYs[0] - n.staffIndex * layout.staff.halfStep;
        let x = xCenter;
        for (const uy of usedY) {
          if (Math.abs(uy - y) < layout.staff.halfStep * 0.6) x += noteR * 1.25;
        }
        usedY.push(y);

        // Ledger lines (simple)
        const yBottomLine = layout.staff.lineYs[0];
        const yTopLine = layout.staff.lineYs[4];
        ctx.strokeStyle = `rgba(0,0,0,${0.18 * alpha})`;
        ctx.lineWidth = 1.1;

        // Draw ledger lines every other staffIndex beyond visible staff.
        // Bottom line is staffIndex 0 (E4).
        const step = layout.staff.halfStep;
        const staffBottomIdx = 0;
        const staffTopIdx = 8; // 4 line gaps = 8 half-steps

        if (n.staffIndex < staffBottomIdx) {
          for (let si = staffBottomIdx - 2; si >= n.staffIndex; si -= 2) {
            const ly = yBottomLine - si * step;
            ctx.beginPath();
            ctx.moveTo(x - noteR * 1.6, ly);
            ctx.lineTo(x + noteR * 1.6, ly);
            ctx.stroke();
          }
        }
        if (n.staffIndex > staffTopIdx) {
          for (let si = staffTopIdx + 2; si <= n.staffIndex; si += 2) {
            const ly = yBottomLine - si * step;
            ctx.beginPath();
            ctx.moveTo(x - noteR * 1.6, ly);
            ctx.lineTo(x + noteR * 1.6, ly);
            ctx.stroke();
          }
        }

        // Accidental
        if (n.acc !== 0) {
          ctx.fillStyle = `rgba(0,0,0,${0.65 * alpha})`;
          ctx.font = `800 ${Math.max(11, noteR * 1.8)}px system-ui, -apple-system, Segoe UI, Roboto, sans-serif`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(n.acc > 0 ? "♯" : "♭", x - noteR * 2.1, y);
        }

        // Note head + stem
        drawNoteHead(ctx, x, y, noteR, alpha);

        // Stem (simple)
        const stemUp = n.staffIndex < 4;
        ctx.strokeStyle = `rgba(0,0,0,${0.38 * alpha})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        if (stemUp) {
          ctx.moveTo(x + noteR * 1.15, y);
          ctx.lineTo(x + noteR * 1.15, y - (layout.staff.halfStep * 8.8));
        } else {
          ctx.moveTo(x - noteR * 1.15, y);
          ctx.lineTo(x - noteR * 1.15, y + (layout.staff.halfStep * 8.8));
        }
        ctx.stroke();

        // Keep ledger render within the staff region visually
        if (y < yTopLine - step * 8 || y > yBottomLine + step * 8) {
          // Nothing special; the note head itself stays readable.
        }
      }
    }
  }
}

// ----------------------------
// Pointer handling
// ----------------------------

export function attachStaffTabPointerHandlers(
  canvas: HTMLCanvasElement,
  getLayout: () => StaffTabLayout,
  st: StaffTabOverlayState,
  onPick?: (hit: StaffTabHit) => void,
  opts?: { getPaintEnabled?: () => boolean },
): () => void {
  const paintEnabled = () => !!opts?.getPaintEnabled?.();

  const onMove = (ev: PointerEvent) => {
    const layout = getLayout();
    const p = canvasToLocal(canvas, ev.clientX, ev.clientY);
    const h = hitTest(layout, p.x, p.y);
    st.hover = h;
    renderStaffTabOverlay(canvas, layout, st);
  };

  const onLeave = () => {
    st.hover = null;
    const layout = getLayout();
    renderStaffTabOverlay(canvas, layout, st);
  };

  const onDown = (ev: PointerEvent) => {
    const layout = getLayout();
    const p = canvasToLocal(canvas, ev.clientX, ev.clientY);
    const h = hitTest(layout, p.x, p.y);
    if (!h) return;

    // Always dispatch a pick event (used for selecting tab string).
    try {
      window.dispatchEvent(new CustomEvent("gedu:staffPick", { detail: h }));
    } catch {
      // ignore
    }
    onPick?.(h);

    // Optional Dev Paint: click-to-place for staff/tab.
    if (paintEnabled()) {
      if (h.region === "tab") {
        // toggle
        if (st.tabMarksByCol.has(h.col) && st.tabMarksByCol.get(h.col)?.stringIndex === h.yIndex) {
          st.tabMarksByCol.delete(h.col);
        } else {
          st.tabMarksByCol.set(h.col, { stringIndex: h.yIndex, fret: st.tabDefaultNumber | 0 });
        }
      }

      if (h.region === "staff") {
        if (st.staffMarksByCol.has(h.col) && st.staffMarksByCol.get(h.col)?.yIndex === h.yIndex) {
          st.staffMarksByCol.delete(h.col);
        } else {
          st.staffMarksByCol.set(h.col, { yIndex: h.yIndex });
        }
      }
    }

    renderStaffTabOverlay(canvas, layout, st);
  };

  canvas.addEventListener("pointermove", onMove);
  canvas.addEventListener("pointerleave", onLeave);
  canvas.addEventListener("pointerdown", onDown);

  return () => {
    canvas.removeEventListener("pointermove", onMove);
    canvas.removeEventListener("pointerleave", onLeave);
    canvas.removeEventListener("pointerdown", onDown);
  };
}
