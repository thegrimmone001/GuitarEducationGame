# ADVANCED_WING_LAYOUT_CONTRACT_v1.2.md
**Guitar Learning Game — Canon UI Contract (Phase B-2)**

**Status:** Locked (v1.2)  
**Scope:** UI layout, structure, and behavior only  
**Explicitly Excludes:** engine logic, gameplay rules, scoring, rendering pipelines

---

## 1. Definition

The **Advanced Wing** is a **right-anchored fly-out panel** used for advanced configuration.

It is **not**:
- a modal
- a dialog
- a centered panel
- an extension of Basic Match Options

Any implementation failing to meet *any* requirement in this document is **non-compliant**.

---

## 2. Spatial Contract (Non-Negotiable)

### 2.1 Placement
- Anchored to the **right edge of the viewport**
- Extends full usable vertical height (minus header/footer offsets)
- Must **not** center horizontally
- Must **not** obscure spatial comprehension of the playfield

### 2.2 Visibility & Interaction
- No dimming scrim
- No modal focus trap
- Background remains visible and readable
- Wing closes via:
  - Explicit close button
  - Escape key
  - Clicking outside wing bounds

### 2.3 Dimensions
- Fixed width (documented value)
- Height-bounded
- **No internal scrolling** (`overflow: hidden`)

---

## 3. Internal Layout Contract (Critical)

### 3.1 Column Structure
The Advanced Wing contains a **fixed header region** and a **fixed body region**.

The body region includes:
- A full-width **Presets A–J row**
- A two-column **Main Grid** (Column A + Column B)
- A two-column **Bottom Grid** (Column A Bottom + Column B Bottom)

Single-column stacking for the wing body is **explicitly forbidden**.

---

## 4. Wing Regions (Required)

### 4.1 Top Header (Fixed)
The header region is always visible and contains:

**Instrument Settings (Fixed Grid):**
- Instrument
- Tuning
- Strings / Range
- Capo / Transpose

Rules:
- Never collapses
- Never changes by mode
- Never overridden by presets

---

### 4.2 Presets A–J Row (Fixed)
- Single horizontal row
- A–J only
- No duplication elsewhere

Selecting a preset:
- Immediately updates visible controls (values + enabled/disabled state)
- Never hides controls (no section removal)
- Serializes into the active configuration snapshot

---

### 4.3 Main Grid (Two Columns)

#### Column A (Mechanics — Stable)
Contains:
- Surface Controls
- Pitch Set Source selector (Intervals / Chords / Scales-Modes / Arpeggios)

Rules:
- Fixed width
- Never changes order
- No scrolling
- Optional controls reserve space and use disabled/opacity states

#### Column B (Pitch Intent — Contextual)
Contains:
- Mode Selector:
  - Single Note
  - Interval
  - Chord
  - Scale / Mode
  - Arpeggio
  - Progression
- Context-Specific Controls area:
  - Changes **only** based on Mode Selector
  - Uses reserved space (no resizing)
  - No nested tabs
  - No cards
  - No scrolling

---

### 4.4 Bottom Grid (Two Columns)

#### Column A Bottom (Rules / Constraints — Stable)
Contains:
- Timers
- Board Rules
- Attempts / Penalties
- Match Constraints
- Misc.

Rules:
- Fixed order
- No scrolling
- No mount/unmount on enable/disable

#### Column B Bottom (Assistive / Analysis — Stable)
Contains:
- Tonal Assist (read-only guidance)

Rules:
- Read-only presentation
- Reacts to the currently edited object
- Never drives configuration

---

## 5. Density & Stability Rules

### 5.1 No Layout Shift
- Controls must not move during interaction
- Dropdown expansion must not reflow surrounding UI
- Optional controls reserve space and use disabled/opacity states instead of removal

### 5.2 Alignment
- Labels align vertically across rows
- Inputs align horizontally
- Row heights remain consistent across sections

---

## 6. State & Emission Contract
- The Advanced Wing edits one authoritative configuration object
- That object is consumed at match start
- UI changes do not emit partial or speculative state
- A single deterministic snapshot exists at “Start Match”

---

## 7. Explicit Anti-Patterns (Always Invalid)
- Centered modal dialogs
- Scrollable Advanced panels
- Card-based layouts inside the wing
- Collapsible sections that change layout height
- Controls that appear/disappear instead of reserving space
- Advanced settings embedded inline with Basic Match Options

---

## 8. Compliance Test (Pass / Fail)
PASS only if all are true:
1. Wing opens from the right and is non-modal  
2. Header (Instrument) is always visible and fixed  
3. Presets A–J exist as a fixed row and apply immediately  
4. Main Grid is two columns (A mechanics, B pitch intent)  
5. Bottom Grid is two columns (A rules, B tonal assist)  
6. No internal scrolling exists  
7. Controls do not shift during interaction  
8. One configuration snapshot is used at match start  

Failure of any single item = FAIL

---

## 9. Authority & Change Control
Changes require:
- Explicit documentation update
- Timestamped approval
- Canon reconciliation entry
