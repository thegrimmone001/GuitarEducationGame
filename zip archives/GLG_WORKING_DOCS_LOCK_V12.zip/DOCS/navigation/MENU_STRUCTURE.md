# MENU_STRUCTURE.md
**Guitar Learning Game — Menu Flow Mockup (Current Working Spec)**

This file defines the navigation flow and which layers are full-screen vs overlay vs wing.

---

## Main Menu (Root)

- Single Player
- Multiplayer
- Education
- Settings
- FAQ / Help

---

## Single Player

### Free Play
Main Menu → Single Player → Free Play → Match Settings → Advanced ▶ (Wing) → Advanced Submenus (in-wing)

### Challenge
Main Menu → Single Player → Challenge → Match Settings → Advanced ▶ (Wing) → Advanced Submenus (in-wing)

---

## Multiplayer

Main Menu → Multiplayer → Players → Match Settings → Advanced ▶ (Wing) → Advanced Submenus (in-wing)

---

## Match Settings (Shared Across Modes)

- Match Settings is an overlay panel.
- Playfield remains visible behind it.
- Advanced opens as a right flyout wing.

---

## Advanced Wing (Critical)

Advanced Wing follows:
- `DOCS/contracts/ADVANCED_WING_LAYOUT_CONTRACT_v1.2.md`

---

## Settings (Non-Match)

Main Menu → Settings →
- Game
- Preferences
- Audio
- Graphics

(Settings are full-screen panels; no Advanced Wing.)

---

## Education

Main Menu → Education →
- To Main UI (Practice Mode)
- Lessons

---

## FAQ / Help

Main Menu → FAQ / Help →
- FAQ → Topic → Topic Page(s)
- Help
- Tutorials
