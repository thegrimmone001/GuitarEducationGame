import {
  Action,
  DevSettings,
  Difficulty,
  GameSettings,
  GameState,
  MatchType,
  ModeId,
  Phase,
  PlayType,
  PlayerProfile,
  SlotType,
  VariantId,
} from "../shell/types";
import { reducer } from "../shell/engineReducer";
import { createChromaticRail, RailConfig } from "../shell/rail";
import { fromVariantId, IS_BLACK, pitchClassAt, toVariantId, variantLabel, pcLabel, suggestChords } from "../shell/music";
import { describePromptProfileId } from "../shell/promptProfiles";
import { computeLayoutFromSvg, mapLayoutToNeck, parseSvgNeckBounds, parseSvgViewBox, FretboardLayout } from "../shell/fretboardLayout";
import { attachBoardPointerHandlers } from "../shell/uiAdapter";
import { renderOverlay } from "../shell/fretboardOverlay";
import { attachStaffTabPointerHandlers, createStaffTabOverlayState, parseStaffTabLayout, renderStaffTabOverlay, StaffTabLayout, StaffTabHit } from "../shell/staffTabOverlay";
import { getLeaderboard, recordScore } from "../shell/storage";

type UiRoot = HTMLElement | Document;

// ----------------------------
// Helpers
// ----------------------------

const PLAYER_COUNT_MULTI = 5;

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

function formatMs(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${pad2(m)}:${pad2(r)}`;
}

function escapeHtml(s: string): string {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function pcFromUiNoteName(name: string): number {
  const n = String(name || "C").trim().toUpperCase();
  const map: Record<string, number> = {
    C: 0,
    "C#": 1,
    DB: 1,
    D: 2,
    "D#": 3,
    EB: 3,
    E: 4,
    F: 5,
    "F#": 6,
    GB: 6,
    G: 7,
    "G#": 8,
    AB: 8,
    A: 9,
    "A#": 10,
    BB: 10,
    B: 11,
  };
  return map[n] ?? 0;
}

function intervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "P1",
    1: "m2",
    2: "M2",
    3: "m3",
    4: "M3",
    5: "P4",
    6: "TT",
    7: "P5",
    8: "m6",
    9: "M6",
    10: "m7",
    11: "M7",
  };
  return names[s] ?? `+${s}`;
}

function romanIntervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "I",
    1: "♭II",
    2: "II",
    3: "♭III",
    4: "III",
    5: "IV",
    6: "♭V",
    7: "V",
    8: "♭VI",
    9: "VI",
    10: "♭VII",
    11: "VII",
  };
  return names[s] ?? `+${s}`;
}

type TritoneStyle = "plusDim" | "TT" | "sharp4" | "flat5" | "auto";

function inferPreferSharp4(settings: GameSettings): boolean {
  const pid = (settings.promptProfileId ?? "").toLowerCase();
  if (pid.includes("lydian")) return true;
  if (pid.includes("locrian")) return false;
  if (pid.includes(":flats") || pid.includes("b")) return false;
  return true;
}

function intervalRomanName(semitones: number, style: TritoneStyle, preferSharp4: boolean): string {
  const s = ((semitones % 12) + 12) % 12;
  switch (s) {
    case 0: return "I";
    case 1: return "ii";
    case 2: return "II";
    case 3: return "iii";
    case 4: return "III";
    case 5: return "IV";
    case 6: {
      if (style === "TT") return "TT";
      if (style === "sharp4") return "IV\u266f";
      if (style === "flat5") return "V\u266d";
      if (style === "auto") return preferSharp4 ? "IV\u266f" : "V\u266d";
      return preferSharp4 ? "+IV" : "oV";
    }
    case 7: return "V";
    case 8: return "vi";
    case 9: return "VI";
    case 10: return "vii";
    case 11: return "VII";
    default: return `+${s}`;
  }
}

function labelForVariant(vid: VariantId, displayMode: string, rootPc: number, settings: GameSettings): string {
  if (displayMode === "intervals") {
    const pc = fromVariantId(vid).pitchClass;
    return intervalName(pc - rootPc);
  }
  if (displayMode === "romanIntervals") {
    const pc = fromVariantId(vid).pitchClass;
    return romanIntervalName(pc - rootPc);
  }
  if (displayMode === "intervalRoman") {
    const pc = fromVariantId(vid).pitchClass;
    const style = (((settings as any).tritoneStyle ?? "plusDim") as TritoneStyle);
    const preferSharp4 = inferPreferSharp4(settings);
    return intervalRomanName(pc - rootPc, style, preferSharp4);
  }
  return variantLabel(vid);
}

function buildPlayers(count: number): PlayerProfile[] {
  const c = clamp(count, 1, 16);
  const out: PlayerProfile[] = [];
  for (let i = 0; i < c; i++) out.push({ id: i, name: `P${i + 1}`, colorId: i, patternId: i });
  return out;
}

function defaultSettings(): GameSettings {
  return {
    modeId: ModeId.FRETBOARD,
    playType: PlayType.MULTI,
    matchType: MatchType.BLACKOUT,
    difficulty: Difficulty.MEDIUM,
    fixedRoundsTotal: 3,
    timers: { turnMs: 15_000, intermissionMs: 900 },
    domain: { fretCount: 25, minFret: 0, maxFret: 24, enabledStrings: [true, true, true, true, true, true] },
    feedback: {
      samEnabled: true,
      samDurationMs: 900,
      samRevealMode: "single",
      claimLabelMode: "off",
      claimLabelDurationMs: 900,
      samIncludeLabel: true,
    },
    steal: {
      tokenCap: 10,
      globalStealOnExhausted: true,
      enharmonicOppositeStealBonus: 5,
      breakConnectMaxTierBonus: 25,
    },
    accessibility: { colorBlindMode: true },
    dev: { enabled: false, paintEnabled: false, paintPlayerIndex: 0, paintLane: "prompt", paintMode: "paint" },
    notation: { view: "staffTab", pitch: "written" },
    promptProfileId: "chromatic",
  };
}

function modeToPromptProfileId(root: string, mode: string): string {
  const m = String(mode || "chromatic").toLowerCase();
  const r = String(root || "C").trim();
  if (m === "chromatic") return "chromatic";
  if (m === "pentatonic") return `scale:${r}:pentatonic:sharps`;
  if (m === "blues") return `scale:${r}:blues:sharps`;
  if (["ionian", "dorian", "phrygian", "lydian", "mixolydian", "aeolian", "locrian"].includes(m)) {
    return `scale:${r}:${m}:sharps`;
  }
  // Fallback
  return "chromatic";
}

function difficultyFromUi(v: string): Difficulty {
  const s = String(v || "medium").toLowerCase();
  if (s === "learning") return Difficulty.LEARNING;
  if (s === "easy") return Difficulty.EASY;
  if (s === "hard") return Difficulty.HARD;
  return Difficulty.MEDIUM;
}

function readEnabledStrings(root: UiRoot): boolean[] {
  const sel = (root as Document).querySelector<HTMLSelectElement>("#pref-strings");
  const enabled = [false, false, false, false, false, false];
  if (!sel) return [true, true, true, true, true, true];
  const values = Array.from(sel.selectedOptions).map((o) => o.value);
  if (values.length === 0) return [true, true, true, true, true, true];

  // UI values are string numbers "1".."6" (1st string = high E). Engine indices are 0..5 (0 = high E).
  for (const v of values) {
    const n = Number(v);
    if (!Number.isFinite(n)) continue;
    const engineIdx = clamp(n, 1, 6) - 1;
    if (engineIdx >= 0 && engineIdx < 6) enabled[engineIdx] = true;
  }
  return enabled;
}

function readInt(root: UiRoot, selector: string, fallback: number): number {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  const n = Number(el?.value);
  return Number.isFinite(n) ? n : fallback;
}

function readStr(root: UiRoot, selector: string, fallback: string): string {
  const el = (root as Document).querySelector<HTMLInputElement | HTMLSelectElement>(selector);
  return (el?.value ?? fallback) as string;
}

function readBool(root: UiRoot, selector: string, fallback = false): boolean {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  if (!el) return fallback;
  return !!el.checked;
}

function buildSettingsFromUi(root: UiRoot, session: "single" | "multi"): GameSettings {
  const d = defaultSettings();

  const playType = session === "single" ? PlayType.SINGLE : PlayType.MULTI;
  const difficulty = difficultyFromUi(readStr(root, "#ops-difficulty", "medium"));
  const uiMode = readStr(root, "#core-gameMode", "m4");
  const rootNote = readStr(root, "#core-root", "C");
  const mode = readStr(root, "#core-modes", "chromatic");
  const promptProfileId = modeToPromptProfileId(rootNote, mode);

  const displayMode = readStr(root, "#core-display", "names");
  const tritoneStyle = readStr(root, "#pref-tritoneStyle", "plusDim");
  const noteVisibilityUi = readStr(root, "#core-noteVisibility", "all");
  const accidentalViewUi = readStr(root, "#core-accidentalView", "both");
  let noteVisibility: "all" | "natural" | "enharmonic" =
    noteVisibilityUi === "all" ? "all" : noteVisibilityUi === "enharmonics" ? "enharmonic" : "natural";
  // Learning difficulty assumes the player knows nothing: allow all spellings by default.
  if (difficulty === Difficulty.LEARNING) noteVisibility = "all";

  // How to render accidentals on the note rail (and other name-based displays).
  // Default is "both" (stack sharp and flat). "auto" can later be used for key/mode recipes.
  const accidentalView = (difficulty === Difficulty.LEARNING ? "both" : accidentalViewUi) as any;

  // Notation preferences (UI only). Default mirrors printed guitar notation.
  const notationView = readStr(root, "#pref-notationView", "staffTab") as any;
  const notationPitch = readStr(root, "#pref-notationPitch", "written") as any;

  const samModeUi = readStr(root, "#core-sam", "single");
  const samRevealMode = samModeUi === "multiple" ? "all" : "single";

  const viewFrets = clamp(readInt(root, "#pref-fretView", 12), 1, 24);
  // Fret count represents playable columns including open string (fret 0).
  const fretCount = viewFrets + 1;

  const minFretRaw = clamp(readInt(root, "#pref-fretMin", 1), 0, viewFrets);
  const maxFretRaw = clamp(readInt(root, "#pref-fretMax", 12), minFretRaw, viewFrets);
  const minFret = minFretRaw;
  const maxFret = maxFretRaw;
  const enabledStrings = readEnabledStrings(root);

  // Token / Dev settings (Main Menu Settings)
  const tokenCap = clamp(readInt(root, "#core-tokenCap", 10), 0, 20);
  const startTokens = clamp(readInt(root, "#core-startTokens", 0), 0, tokenCap);
  const devEnabled = readBool(root, "#core-devMode", false);

  // Dev/Test pane settings (only takes effect when dev is enabled)
  const devPaintEnabled = readBool(root, "#dev-paintEnabled", false);
  const devPaintPlayerIndex = clamp(Number(readStr(root, "#dev-paintPlayer", "0")), 0, 4);
  const devPaintLane = readStr(root, "#dev-paintLane", "prompt") as any;
  const devPaintMode = readStr(root, "#dev-paintMode", "paint") as any;

  const s: GameSettings = {
    ...d,
    modeId: ModeId.FRETBOARD,
    playType,
    matchType: MatchType.BLACKOUT,
    difficulty,
    promptProfileId,
    domain: { ...d.domain, fretCount, minFret, maxFret, enabledStrings },
    feedback: { ...d.feedback, samRevealMode },
    steal: { ...d.steal, tokenCap },
    dev: {
      ...d.dev,
      enabled: devEnabled,
      paintEnabled: devPaintEnabled,
      paintPlayerIndex: devPaintPlayerIndex,
      paintLane: devPaintLane,
      paintMode: devPaintMode,
    },
    notation: {
      view: (notationView === "staff" || notationView === "tab" ? notationView : "staffTab"),
      pitch: (notationPitch === "concert" ? "concert" : "written"),
    },
  };

  // Non-typed extensions used by promptProfiles (kept compatible with the shell version).
  (s as any).noteVisibility = noteVisibility;
  (s as any).accidentalView = accidentalView;
  (s as any).displayMode = displayMode;
  (s as any).tritoneStyle = tritoneStyle;
  (s as any).rootNote = rootNote;
  (s as any).uiMode = uiMode;
  (s as any).startTokens = startTokens;
  return s;
}

// ----------------------------
// Controller
// ----------------------------

export function initGameController(root: UiRoot): void {
  const doc = root as Document;

  const splash = doc.querySelector<HTMLElement>("#splash");
  const promptText = doc.querySelector<HTMLElement>("#promptText");
  const alertsText = doc.querySelector<HTMLElement>("#alerts-text");

  const activeName = doc.querySelector<HTMLElement>("#activePlayer-name");
  const activeScore = doc.querySelector<HTMLElement>("#activePlayer-score");
  const activeMult = doc.querySelector<HTMLElement>("#activePlayer-mult");
  const activeTarget = doc.querySelector<HTMLElement>("#activePlayer-target");
  const activeTimer = doc.querySelector<HTMLElement>("#activePlayer-timer");
  const activeTokens = doc.querySelector<HTMLElement>("#activePlayer-tokens");
  const leaderboard = doc.querySelector<HTMLElement>("#leaderboard");
  const highscores = doc.querySelector<HTMLElement>("#highscores");

  // Chord Entry pane controls
  const chordEntryEnabledEl = doc.querySelector<HTMLInputElement>("#chordEntry-enabled");
  const chordEntryLockEl = doc.querySelector<HTMLButtonElement>("#chordEntry-lock");
  const chordEntryUnlockEl = doc.querySelector<HTMLButtonElement>("#chordEntry-unlock");
  const chordEntryClearEl = doc.querySelector<HTMLButtonElement>("#chordEntry-clear");
  const chordEntryClaimEl = doc.querySelector<HTMLButtonElement>("#chordEntry-claim");
  const chordEntrySuggestionsEl = doc.querySelector<HTMLSelectElement>("#chordEntry-suggestions");
  const chordEntryPcsEl = doc.querySelector<HTMLElement>("#chordEntry-pcs");

  const devTab = doc.querySelector<HTMLElement>("#misc-dev-tab");
  const devPane = doc.querySelector<HTMLElement>("#misc-dev-pane");

  const fretStage = doc.querySelector<HTMLElement>("#fretStage");
  const fretBgHost = doc.querySelector<HTMLElement>("#fretBgHost");
  const fretOverlaySvg = doc.querySelector<SVGSVGElement>("#fretOverlaySvg");
  const staffBgHost = doc.querySelector<HTMLElement>("#staffBgHost");
  const staffOverlaySvg = doc.querySelector<SVGSVGElement>("#staffOverlaySvg");
  const noteStripRail = doc.querySelector<HTMLElement>("#noteStrip-rail");

  if (!fretStage || !fretBgHost || !fretOverlaySvg) throw new Error("Fretboard surface not found");
  const fretStageEl: HTMLElement = fretStage;
  const fretBgHostEl: HTMLElement = fretBgHost;
  const fretOverlaySvgEl: SVGSVGElement = fretOverlaySvg;
  const staffBgHostEl: HTMLElement | null = staffBgHost;
  const staffOverlaySvgEl: SVGSVGElement | null = staffOverlaySvg;

  // Rail (shell feature)
  const rail = createChromaticRail();
  if (noteStripRail) {
    noteStripRail.innerHTML = "";
    noteStripRail.appendChild(rail.el);
  }

  let session: "single" | "multi" = "single";
  let settings: GameSettings = buildSettingsFromUi(doc, session);
  let players: PlayerProfile[] = buildPlayers(session === "single" ? 1 : PLAYER_COUNT_MULTI);
  let state: GameState | null = null;

  let paused = false;
  let turnEndsAt = 0;
  let timerHandle: number | null = null;
  let intermissionHandle: number | null = null;
  let samHandle: number | null = null;

  // Match timing (used for persistent high score entries)
  let matchStartedAtMs = 0;
  let pausedAtMs = 0;
  let pausedAccumMs = 0;
  let matchRecorded = false;
  // TAB input state (instant): select string + fret (either order), claim immediately.
  let tabSelectedString: number | null = null;
  let tabSelectedFret: number | null = null;

  // Chord Entry Ergonomics v2 (UI-only): multi-select fretboard positions,
  // lock the set, and pick from detected chord suggestions.
  const chordEntry = {
    enabled: false,
    locked: false,
    selected: new Set<number>(), // cell indices
    prefer: "sharp" as "sharp" | "flat",
    chosenLabel: "" as string,
  };

  // Lightweight custom context menu (used for chord entry shortcuts; right-click canon).
  let chordCtxMenuEl: HTMLDivElement | null = null;
  function closeChordCtxMenu(): void {
    if (chordCtxMenuEl) {
      chordCtxMenuEl.remove();
      chordCtxMenuEl = null;
    }
  }

  function openChordCtxMenu(x: number, y: number): void {
    closeChordCtxMenu();

    const wrap = document.createElement("div");
    wrap.className = "geduCtxMenu";
    wrap.style.left = `${x}px`;
    wrap.style.top = `${y}px`;

    const mkBtn = (label: string, onClick: () => void, disabled = false) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "geduCtxBtn";
      b.textContent = label;
      b.disabled = disabled;
      b.addEventListener("click", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        closeChordCtxMenu();
        onClick();
      });
      return b;
    };

    // Mirror the existing pane actions (no new logic here; just ergonomic access).
    wrap.appendChild(
      mkBtn(
        chordEntry.locked ? "Unlock" : "Lock",
        () => (chordEntry.locked ? chordEntryUnlockEl?.click() : chordEntryLockEl?.click()),
        !chordEntry.enabled,
      ),
    );
    wrap.appendChild(mkBtn("Clear", () => chordEntryClearEl?.click(), !chordEntry.enabled));
    wrap.appendChild(
      mkBtn(
        "Claim",
        () => chordEntryClaimEl?.click(),
        !chordEntry.enabled || chordEntry.selected.size < 3,
      ),
    );

    document.body.appendChild(wrap);
    chordCtxMenuEl = wrap;

    // Close behavior
    const onDocDown = () => closeChordCtxMenu();
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === "Escape") closeChordCtxMenu();
    };
    window.setTimeout(() => {
      document.addEventListener("pointerdown", onDocDown, { once: true, capture: true });
      document.addEventListener("keydown", onKey, { once: true, capture: true });
    }, 0);
  }


  let fretLayout: FretboardLayout | null = null;
  let staffLayout: StaffTabLayout | null = null;
  const staffOverlayState = createStaffTabOverlayState();
  let activePulse: {
    playerId: number;
    variantId: number;
    durationMs: number;
    ghost: any | null;
    ghosts?: any[];
    scoreDelta: number;
    includeLabel?: boolean;
  } | null = null;
  let pulseHandle: number | null = null;

  function setAlert(msg: string): void {
    if (!alertsText) return;
    const phase = state?.phase ?? "TITLE";
    alertsText.textContent = `${phase}: ${msg}`;
  }

  function clearTimers(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    if (intermissionHandle !== null) window.clearTimeout(intermissionHandle);
    if (samHandle !== null) window.clearTimeout(samHandle);
    timerHandle = null;
    intermissionHandle = null;
    samHandle = null;
  }

  function stopTurnTimer(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    timerHandle = null;
    turnEndsAt = 0;
    if (activeTimer) activeTimer.textContent = "00:00";
  }

  function startTurnTimer(): void {
    stopTurnTimer();
    if (!state) return;
    applyUiModeVisibility();
    const ms = state.settings.timers.turnMs;
    turnEndsAt = Date.now() + ms;
    if (activeTimer) activeTimer.textContent = formatMs(ms);
    timerHandle = window.setInterval(() => {
      if (!state || paused) return;
      const left = turnEndsAt - Date.now();
      if (activeTimer) activeTimer.textContent = formatMs(left);
      if (left <= 0) {
        stopTurnTimer();
        dispatch({ type: "TIMEOUT" } as Action);
      }
    }, 100);
  }

  function hideSplash(): void {
    splash?.classList.remove("show");
  }

  function showSplash(): void {
    splash?.classList.add("show");
  }

  function notePauseChange(isNowPaused: boolean): void {
    const now = Date.now();
    if (isNowPaused) {
      if (pausedAtMs === 0) pausedAtMs = now;
      return;
    }
    if (pausedAtMs !== 0) {
      pausedAccumMs += Math.max(0, now - pausedAtMs);
      pausedAtMs = 0;
    }
  }

  function currentMatchDurationMs(): number {
    if (!matchStartedAtMs) return 0;
    const now = Date.now();
    const pauseExtra = pausedAtMs ? Math.max(0, now - pausedAtMs) : 0;
    const pausedTotal = pausedAccumMs + pauseExtra;
    return Math.max(0, now - matchStartedAtMs - pausedTotal);
  }

  function syncDevTabVisibility(isDevEnabled?: boolean): void {
    const enabled =
      isDevEnabled ?? ((doc.querySelector<HTMLInputElement>("#core-devMode")?.checked ?? false) === true);
    if (devTab) devTab.classList.toggle("devHidden", !enabled);
    if (devPane) devPane.classList.toggle("devHidden", !enabled);

    // If dev is disabled and the dev pane is currently active, bounce back to Achievements.
    if (!enabled) {
      const miscTabs = doc.querySelector<HTMLElement>("[data-tabs=\"miscinfo\"]");
      const activeTab = miscTabs?.querySelector<HTMLElement>(".tab.active");
      if (activeTab && activeTab.getAttribute("data-tab") === "dev") {
        miscTabs?.querySelector<HTMLElement>(".tab[data-tab=\"ach\"]")?.click();
      }
    }
  }

  function updateHighScoresUi(useSettings?: GameSettings): void {
    if (!highscores) return;
    const s = useSettings ?? state?.settings ?? settings;
    const entries = getLeaderboard(s).slice(0, 10);
    if (entries.length === 0) {
      highscores.innerHTML = `<div class="hint">No saved scores yet. Finish a match to populate this list.</div>`;
      return;
    }
    highscores.innerHTML = entries
      .map((e) => {
        const when = new Date(e.atIso).toLocaleDateString();
        const dur = e.durationMs ? ` • ${formatMs(e.durationMs)}` : "";
        return `<div class="leader-row"><div class="leader-name">${escapeHtml(e.name)}</div><div class="leader-score">${e.score}</div><div class="leader-meta">${when}${dur}</div></div>`;
      })
      .join("");
  }

  function recordScoresIfNeeded(): void {
    if (!state) return;
    if (matchRecorded) return;
    matchRecorded = true;
    const dur = currentMatchDurationMs();
    for (const p of state.players) {
      recordScore(state.settings, p.profile.name, p.score, dur);
    }
    updateHighScoresUi(state.settings);
  }

  const SVG_ENTITY_MAP: Record<string, string> = {
    ns_extend: "http://ns.adobe.com/Extensibility/1.0/",
    ns_ai: "http://ns.adobe.com/AdobeIllustrator/10.0/",
    ns_graphs: "http://ns.adobe.com/Graphs/1.0/",
    ns_vars: "http://ns.adobe.com/Variables/1.0/",
    ns_imrep: "http://ns.adobe.com/ImageReplacement/1.0/",
    ns_sfw: "http://ns.adobe.com/SaveForWeb/1.0/",
    ns_custom: "http://ns.adobe.com/GenericCustomNamespace/1.0/",
    ns_adobe_xpath: "http://ns.adobe.com/XPath/1.0/",
  };

  const ASSET_BASE = (import.meta as any).env?.BASE_URL ?? "/";
  function assetUrl(path: string): string {
    const clean = path.startsWith("/") ? path.slice(1) : path;
    return new URL(clean, window.location.origin + ASSET_BASE).toString();
  }

  // Staff/TAB hit-grid resolution.
  // 16 columns per measure = 16th-note grid in 4/4.
  // When we add smaller rhythmic divisions (32nds, tuplets, swing, etc.),
  // we can increase this (e.g., 32, 48, 64...) or move to a tick-based grid.
  const DEFAULT_STAFF_COLUMNS_PER_MEASURE = 16;

  function sanitizeSvgText(raw: string): string {
    let t = raw;

    // Replace Illustrator entity references (browsers do not evaluate SVG DTD entities when injecting via innerHTML).
    for (const [k, v] of Object.entries(SVG_ENTITY_MAP)) {
      t = t.replaceAll("&" + k + ";", v);
    }

    // Remove XML declaration and DOCTYPE (including internal subsets).
    t = t.replace(/<\?xml[\s\S]*?\?>/g, "");
    t = t.replace(/<!DOCTYPE[\s\S]*?\]>/g, "");
    t = t.replace(/<!DOCTYPE[^>]*>/g, "");
    t = t.replace(/<!ENTITY[\s\S]*?>/g, "");

    // Remove Adobe-only foreignObject blocks (keeps the real <g> content).
    t = t.replace(/<foreignObject[\s\S]*?<\/foreignObject>/g, "");

    return t;
  }

  async function loadSvgIntoHost(
    host: HTMLElement,
    urlPath: string,
    preserveAspectRatio: string = "xMidYMid meet",
  ): Promise<string> {
    const res = await fetch(assetUrl(urlPath));
    if (!res.ok) throw new Error("Failed to load " + urlPath + ": " + res.status);

    const raw = await res.text();
    const svgText = sanitizeSvgText(raw);
    host.innerHTML = svgText;

    const svg = host.querySelector("svg") as SVGSVGElement | null;
    if (svg) {
      svg.setAttribute("width", "100%");
      svg.setAttribute("height", "100%");
      svg.setAttribute("preserveAspectRatio", preserveAspectRatio);
    }

    return svgText;
  }


  async function setupSvgSurfaces(): Promise<void> {
    // Staff background (optional)
    if (staffBgHostEl && staffOverlaySvgEl) {
      // NOTE: loadSvgIntoHost expects a relative asset path (it applies assetUrl() internally).
      const staffText = await loadSvgIntoHost(staffBgHostEl, "/Guitar-Notes_Tab_Staff-Blank-3Measures.svg", "xMidYMid meet");
      const vb = parseSvgViewBox(staffText);
      staffOverlaySvgEl.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
      staffOverlaySvgEl.setAttribute("preserveAspectRatio", "xMidYMid meet");
      staffLayout = parseStaffTabLayout(staffText, DEFAULT_STAFF_COLUMNS_PER_MEASURE);
      renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      attachStaffTabPointerHandlers(staffOverlaySvgEl, staffLayout, staffOverlayState, (hit: StaffTabHit) => {
        window.dispatchEvent(new CustomEvent("gedu:staffPick", { detail: hit }));
      });

      // Apply the initial crop according to the current UI Mode.
      // (Mode 2 = staff only, Mode 3 = tab only, others = both.)
      const uiModeEl = doc.getElementById("core-gameMode") as HTMLSelectElement | null;
      const uiMode = uiModeEl?.value ?? "m4";
      applyStaffTabCrop(uiMode);
    }

    // Visual background SVG: prefer the v2i artwork; fall back to the vector SVG if needed.
    let bgText = "";
    try {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete_v2i.svg"),
        "xMinYMin meet",
      );
    } catch {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"),
        "xMinYMin meet",
      );
    }

    // Compute the hitbox layout directly from the background SVG whenever possible.
    // Our photo-style v2i asset now exposes enough geometry (via image transforms) to
    // recover fret and string positions, which keeps markers perfectly centered.
    let layout: FretboardLayout;
    let vb: { x: number; y: number; w: number; h: number };
    try {
      const cleanBgText = sanitizeSvgText(bgText);
      layout = computeLayoutFromSvg(cleanBgText);
      vb = layout.viewBox;
    } catch (e) {
      console.warn("Failed to compute layout from background SVG; falling back to vector geometry mapping.", e);

      // Geometry fallback: compute from the clean vector SVG and map into the background.
      const hitRaw = await (await fetch(assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"))).text();
      const hitText = sanitizeSvgText(hitRaw);
      const baseLayout = computeLayoutFromSvg(hitText);

      layout = baseLayout;
      vb = baseLayout.viewBox;
      try {
        const bgVB = parseSvgViewBox(bgText);
        const bgNeck = parseSvgNeckBounds(bgText);
        layout = mapLayoutToNeck(baseLayout, bgVB, bgNeck);
        vb = bgVB;
      } catch (e2) {
        console.warn("Failed to map fretboard layout to background SVG; using base layout.", e2);
      }
    }

    fretLayout = layout;

    fretOverlaySvgEl.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
    fretOverlaySvgEl.setAttribute("preserveAspectRatio", "xMinYMin meet");
    fretOverlaySvgEl.setAttribute("width", "100%");
    fretOverlaySvgEl.setAttribute("height", "100%");

    attachBoardPointerHandlers(
      { layout: fretLayout, svgRoot: fretOverlaySvgEl, dispatch },
      () => state,
      fretOverlaySvgEl,
      {
        chordSelect: {
          isActive: () => chordEntry.enabled,
          isLocked: () => chordEntry.locked,
          toggleCell: (stringIndex: number, fretIndex: number) => {
            if (!state) return;
            const idx = stringIndex * state.settings.domain.fretCount + fretIndex;
            if (state.domainCellEnabled[idx] === 0) return;
            if (chordEntry.selected.has(idx)) chordEntry.selected.delete(idx);
            else chordEntry.selected.add(idx);
            chordEntry.chosenLabel = "";
            updateChordEntryUi();
            updateOverlayOwnership();
          },
        },
      },
    );

    // Right-click shortcut menu for chord entry (canon). Only active when chord
    // selection mode is enabled; otherwise allow the browser default menu.
    fretOverlaySvgEl.addEventListener(
      "contextmenu",
      (ev) => {
        if (!chordEntry.enabled) return;
        ev.preventDefault();
        openChordCtxMenu(ev.clientX, ev.clientY);
      },
      { passive: false },
    );

    // Initial render if a game is already running.
    updateOverlayOwnership();
    syncFretKeypadAvailability();
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
  }

  function applyStaffTabCrop(uiMode: string): void {
    if (!staffLayout || !staffOverlaySvgEl || !staffBgHostEl) return;

    const full = staffLayout.viewBox;
    let y0 = full.y;
    let y1 = full.y + full.h;

    // Add a small padding so we don't clip clefs/labels.
    const staffPad = staffLayout.staff.halfStep * 2;
    const tabGap = (staffLayout.tab.lineYs[1] ?? staffLayout.tab.lineYs[0] ?? 10) - (staffLayout.tab.lineYs[0] ?? 0);
    const tabPad = Math.max(6, Math.abs(tabGap) * 0.9);

    if (uiMode === "m2") {
      // Staff only
      y0 = staffLayout.staff.yMin - staffPad;
      y1 = staffLayout.staff.yMax + staffPad;
    } else if (uiMode === "m3") {
      // Tab only
      y0 = staffLayout.tab.yMin - tabPad;
      y1 = staffLayout.tab.yMax + tabPad;
    }

    // Clamp to the original viewBox.
    y0 = Math.max(full.y, y0);
    y1 = Math.min(full.y + full.h, y1);
    const h = Math.max(1, y1 - y0);

    const vbStr = `${full.x} ${y0} ${full.w} ${h}`;
    staffOverlaySvgEl.setAttribute("viewBox", vbStr);
    staffOverlaySvgEl.setAttribute("preserveAspectRatio", "xMidYMid meet");

    // Update the embedded background SVG to match.
    const bgSvg = staffBgHostEl.querySelector("svg");
    if (bgSvg) {
      bgSvg.setAttribute("viewBox", vbStr);
      bgSvg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    }
  }

  void setupSvgSurfaces().catch((err) => {
    console.error("Failed to set up SVG surfaces", err);
  });

  // Ensure chord pane starts in a consistent state.
  updateChordEntryUi();

  function rebuildOverlay(): void {
    // No-op: fretboard interaction and rendering are handled by the SVG overlay.
    // This stub is kept so older calls (e.g., start/reset) don't crash.
  }

  function updateOverlayOwnership(): void {
    if (!state || !fretLayout) return;
    const chordSel = chordEntry.enabled
      ? { selected: Array.from(chordEntry.selected.values()), locked: chordEntry.locked }
      : null;
    renderOverlay(fretOverlaySvgEl, fretLayout, state, activePulse, chordSel);
  }

  function updateActivePlayerUi(): void {
    if (!state) return;
    const pIndex = state.currentPlayer;
    const p = state.players[pIndex];
    if (!p) return;

    if (activeName) activeName.textContent = players[pIndex]?.name ?? `P${pIndex + 1}`;
    if (activeScore) activeScore.textContent = String(p.score);
    if (activeMult) activeMult.textContent = `×${1 + (state.turn?.streakTier ?? 0)}`;

    if (activeTokens) {
      const cap = state.settings.steal.tokenCap;
      activeTokens.innerHTML = "";
      for (let i = 0; i < cap; i++) {
        const dot = document.createElement("span");
        dot.className = "tokenDot" + (i < p.tokenCount ? " filled" : "");
        activeTokens.appendChild(dot);
      }
    }
  }

  function updateLeaderboardUi(): void {
    if (!state || !leaderboard) return;
    leaderboard.innerHTML = "";
    for (let i = 0; i < state.players.length; i++) {
      const p = state.players[i];
      const row = document.createElement("div");
      row.className = "leader-chip" + (i === state.currentPlayer ? " active" : "");
      row.innerHTML = `
        <div class="leader-avatar">${(players[i]?.name ?? `P${i + 1}`).slice(0, 2)}</div>
        <div class="leader-name">${players[i]?.name ?? `P${i + 1}`}</div>
        <div class="leader-score">${p.score}</div>
        <div class="leader-tokens">${p.tokenCount}</div>
      `;
      leaderboard.appendChild(row);
    }
  }

  function updatePromptUi(): void {
    if (!state) return;
    const displayMode = (state.settings as any).displayMode ?? "names";
    const rootPc = pcFromUiNoteName((state.settings as any).rootNote ?? "C");
    const label = labelForVariant(state.prompt.variantId, displayMode, rootPc, state.settings);

    // Update the visible target label (and promptText if that element exists).
    if (promptText) promptText.textContent = label;
    if (activeTarget) {
      const v = fromVariantId(state.prompt.variantId);
      const isBlack = IS_BLACK[v.pitchClass];
      const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
      activeTarget.textContent = spelling ? `Target: ${label} (${spelling})` : `Target: ${label}`;
      activeTarget.classList.toggle("is-sharp", isBlack && v.spelling === SlotType.SHR);
      activeTarget.classList.toggle("is-flat", isBlack && v.spelling === SlotType.FLT);
    }

    // Rail config
    const railMode: RailConfig["mode"] = state.settings.promptProfileId.startsWith("scale") || state.settings.promptProfileId.startsWith("key") ? "FIXED_REFERENCE" : "ROTATE_COMPASS";
    const anchor = toVariantId(rootPc as any, SlotType.NAT);
    rail.setConfig(
      {
        mode: railMode,
        anchorVariantId: anchor,
        currentVariantId: state.prompt.variantId,
      },
      state.settings,
    );

    // Make the sharp/flat requirement visible at a glance without giving away fretboard positions.
    const v = fromVariantId(state.prompt.variantId);
    const isBlack = IS_BLACK[v.pitchClass];
    const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
    const targetSuffix = spelling ? ` | Target: ${label} (${spelling})` : ` | Target: ${label}`;
    setAlert(describePromptProfileId(state.settings.promptProfileId) + targetSuffix);
  }


  function syncFretKeypadAvailability(): void {
    const pad = doc.getElementById("keypad");
    if (!pad) return;

    // Disable keys outside the current playable domain range.
    // Note: the 24-key UI is always present, but keys outside [minFret..maxFret] are disabled.
    const minAllowed = state ? state.settings.domain.minFret : 0;
    const maxAllowed = state ? Math.min(24, state.settings.domain.maxFret) : 24;

    const keys = pad.querySelectorAll<HTMLButtonElement>("button.key");
    keys.forEach((b) => {
      const f = Number(b.dataset.fret);
      // Open string (0) remains available even when the focused fret range starts at 1.
      const disabled = !Number.isFinite(f) || (f !== 0 && (f < minAllowed || f > maxAllowed)) || (f === 0 && maxAllowed < 0);
      b.disabled = disabled;
      b.classList.toggle("disabled", disabled);
    });
  }

function applyUiModeVisibility(overrideUiMode?: string): void {
    const uiMode: string = overrideUiMode ?? (((state?.settings as any) ?? {}) as any).uiMode ?? "m4";
    const showStaffTab = uiMode !== "m1";
    const showFret = uiMode !== "m5";

    const staffSection = doc.getElementById("svgStage")?.closest(".section") as HTMLElement | null;
    if (staffSection) {
      // Keep the Staff/Tab panel in the layout so the UI does not jump;
      // in modes where it is not active we simply mark it disabled.
      staffSection.hidden = false;
      staffSection.classList.toggle("isDisabled", !showStaffTab);
    }

    const fretSection = doc.getElementById("fretStage")?.closest(".section") as HTMLElement | null;
    if (fretSection) fretSection.hidden = !showFret;

    // If staff+tab is visible, crop the viewBox based on the selected UI Mode.
    // m2 = staff only, m3 = tab only, others = both.
    if (showStaffTab) applyStaffTabCrop(uiMode);
  }

  function renderAll(): void {
    if (!state) return;
    applyUiModeVisibility();
    updatePromptUi();
    updateActivePlayerUi();
    updateLeaderboardUi();
    updateOverlayOwnership();
    syncFretKeypadAvailability();
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
  }

  function handleEffects(effects: any[]): void {
    const s0 = state;
    if (!s0) return;

    for (const eff of effects) {
      switch (eff.type) {
        case "PROMPT_CHANGED":
          updatePromptUi();
          break;

        case "TURN_STARTED":
          setAlert("Turn started");
          startTurnTimer();
          break;

        case "TURN_ENDED":
          stopTurnTimer();
          // In single-player, keep things flowing.
          if (s0.settings.playType === PlayType.SINGLE) {
            dispatch({ type: "START_TURN" } as Action);
          } else {
            // Multiplayer: respect intermission.
            intermissionHandle = window.setTimeout(() => {
              if (!state || paused) return;
              dispatch({ type: "START_TURN" } as Action);
            }, s0.settings.timers.intermissionMs);
          }
          break;

        case "FEEDBACK_PULSE": {
          // SAM pulse (highlight correct locations)
          if (!s0.settings.feedback.samEnabled) break;

          activePulse = {
            playerId: eff.playerId,
            variantId: eff.variantId,
            durationMs: eff.durationMs ?? s0.settings.feedback.samDurationMs,
            ghost: (eff.ghost ?? null) as any,
            ghosts: (eff.ghosts ?? undefined) as any,
            scoreDelta: (eff.scoreDelta ?? 0) as any,
            includeLabel: (eff.includeLabel ?? false) as any,
          };

          if (samHandle !== null) window.clearTimeout(samHandle);
          samHandle = window.setTimeout(() => {
            activePulse = null;
            renderAll();
          }, activePulse.durationMs);
          break;
        }

        case "ALERT":
          setAlert(String(eff.message ?? ""));
          break;

        case "MATCH_COMPLETE":
          stopTurnTimer();
          paused = true;
          notePauseChange(true);
          recordScoresIfNeeded();
          updateHighScoresUi();
          setAlert("Match complete");
          showSplash();
          break;
      }
    }

    renderAll();
  }

  function dispatch(action: Action): void {
    const r = reducer(state, action);
    state = r.state;
    handleEffects(r.effects);
  }

  function beginMatch(sess: "single" | "multi"): void {
    clearTimers();
    paused = false;

    session = sess;
    settings = buildSettingsFromUi(doc, session);
    syncDevTabVisibility(!!settings.dev?.enabled);
    players = buildPlayers(session === "single" ? 1 : PLAYER_COUNT_MULTI);

    const init = reducer(null, { type: "INIT_MATCH", settings, players } as Action);
    state = init.state;

    // Match timing (used for persistent high scores)
    matchStartedAtMs = Date.now();
    pausedAtMs = 0;
    pausedAccumMs = 0;
    matchRecorded = false;

    // Apply starting tokens (clamped to the configured token cap).
    const startTokens = clamp(Number((settings as any).startTokens ?? 0), 0, settings.steal.tokenCap);
    if (state && startTokens > 0) {
      for (const p of state.players) p.tokenCount = startTokens;
    }

    updateHighScoresUi(settings);

    rebuildOverlay();
    renderAll();
    handleEffects(init.effects);

    // Start the first turn immediately.
    dispatch({ type: "START_TURN" } as Action);
    hideSplash();
  }

  function endMatch(): void {
    if (!state) return;
    clearTimers();
    paused = true;
    notePauseChange(true);
    dispatch({ type: "END_MATCH" } as Action);
    recordScoresIfNeeded();
    updateHighScoresUi();
    showSplash();
  }

  function resetGame(): void {
    clearTimers();
    paused = false;
    matchStartedAtMs = 0;
    pausedAtMs = 0;
    pausedAccumMs = 0;
    matchRecorded = false;
    state = null;
    rebuildOverlay();
    setAlert("Ready");
    showSplash();
  }

  function onCellClick(stringIndex: number, fretIndex: number): void {
    if (!state) return;
    if (paused) return;
    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;

    const cellIndex = stringIndex * state.settings.domain.fretCount + fretIndex;
    const slot = fromVariantId(state.prompt.variantId).spelling;
    const owner = state.board.owner[slot][cellIndex];
    const isOtherOwner = owner >= 0 && owner !== state.currentPlayer;
    const action: Action = isOtherOwner ? ({ type: "STEAL_CELL", stringIndex, fretIndex } as any) : ({ type: "TAP_CELL", stringIndex, fretIndex } as any);
    dispatch(action);
  }

  function updateChordEntryUi(): void {
    if (!chordEntryEnabledEl || !chordEntrySuggestionsEl || !chordEntryPcsEl) return;

    chordEntryEnabledEl.checked = chordEntry.enabled;
    const btns = [chordEntryLockEl, chordEntryUnlockEl, chordEntryClearEl, chordEntryClaimEl];
    for (const b of btns) if (b) b.disabled = !chordEntry.enabled;
    chordEntrySuggestionsEl.disabled = !chordEntry.enabled;

    // If no match is active, we still allow selection visuals, but chord detection needs a fret count.
    const fc = state?.settings?.domain?.fretCount ?? 25;
    const pcs: number[] = [];
    for (const idx of chordEntry.selected.values()) {
      const s = Math.floor(idx / fc);
      const f = idx % fc;
      if (s < 0 || s >= 6 || f < 0 || f >= fc) continue;
      pcs.push(pitchClassAt(s, f));
    }

    const uniq = Array.from(new Set(pcs)) as any[];
    const labels = uniq.map((pc) => pcLabel(pc, chordEntry.prefer)).join(" ");
    chordEntryPcsEl.textContent = uniq.length ? `Notes: ${labels}${chordEntry.locked ? " (locked)" : ""}` : "Select 3–4 notes to see suggestions.";

    const suggestions = uniq.length >= 3 ? suggestChords(uniq as any, chordEntry.prefer) : [];
    chordEntrySuggestionsEl.innerHTML = "";
    if (!suggestions.length) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "(no match)";
      chordEntrySuggestionsEl.appendChild(opt);
      chordEntrySuggestionsEl.value = "";
      return;
    }
    for (const s of suggestions) {
      const opt = document.createElement("option");
      opt.value = s.label;
      opt.textContent = s.label;
      chordEntrySuggestionsEl.appendChild(opt);
    }

    // Prefer: keep user's previous pick if it is still present; otherwise default to first.
    const want = chordEntry.chosenLabel;
    chordEntrySuggestionsEl.value = want && Array.from(chordEntrySuggestionsEl.options).some((o) => o.value === want)
      ? want
      : chordEntrySuggestionsEl.options[0]?.value ?? "";
  }

  // Wire Chord Entry controls
  if (chordEntryEnabledEl) {
    chordEntryEnabledEl.addEventListener("change", () => {
      chordEntry.enabled = !!chordEntryEnabledEl.checked;
      if (!chordEntry.enabled) {
        chordEntry.locked = false;
        chordEntry.selected.clear();
        chordEntry.chosenLabel = "";
      }
      updateChordEntryUi();
      updateOverlayOwnership();
    });
  }
  if (chordEntryLockEl) chordEntryLockEl.addEventListener("click", () => {
    if (!chordEntry.enabled) return;
    chordEntry.locked = true;
    updateChordEntryUi();
    updateOverlayOwnership();
  });
  if (chordEntryUnlockEl) chordEntryUnlockEl.addEventListener("click", () => {
    if (!chordEntry.enabled) return;
    chordEntry.locked = false;
    updateChordEntryUi();
    updateOverlayOwnership();
  });
  if (chordEntryClearEl) chordEntryClearEl.addEventListener("click", () => {
    if (!chordEntry.enabled) return;
    chordEntry.locked = false;
    chordEntry.selected.clear();
    chordEntry.chosenLabel = "";
    updateChordEntryUi();
    updateOverlayOwnership();
  });
  if (chordEntrySuggestionsEl) chordEntrySuggestionsEl.addEventListener("change", () => {
    chordEntry.chosenLabel = chordEntrySuggestionsEl.value;
  });
  if (chordEntryClaimEl) chordEntryClaimEl.addEventListener("click", () => {
    if (!chordEntry.enabled) return;
    if (!chordEntry.selected.size) {
      setAlert("Chord Entry: select notes first");
      return;
    }
    chordEntry.locked = true;
    chordEntry.chosenLabel = chordEntrySuggestionsEl?.value ?? chordEntry.chosenLabel;
    const lbl = chordEntry.chosenLabel || "(unlabeled chord)";
    setAlert(`Chord claimed: ${lbl} (${chordEntry.selected.size} positions)`);
    updateChordEntryUi();
    updateOverlayOwnership();
  });

  // Listen to layout events
  window.addEventListener("gedu:splashSelect", (e: any) => {
    const detail = e?.detail as { session: "single" | "multi" };
    beginMatch(detail?.session ?? "single");
  });

  window.addEventListener("gedu:start", () => {
    if (!state) {
      beginMatch(session);
      return;
    }
    paused = false;
	    notePauseChange(false);
    setAlert("Running");
    if (state.phase === "IN_MATCH" || state.phase === "LAST_CHANCE") startTurnTimer();
    renderAll();
  });

  window.addEventListener("gedu:pause", () => {
    paused = true;
    notePauseChange(true);
    stopTurnTimer();
    setAlert("Paused");
    renderAll();
  });

  window.addEventListener("gedu:stop", () => {
    endMatch();
  });

  window.addEventListener("gedu:new", () => {
    resetGame();
  });

  window.addEventListener("gedu:applyFretRange", () => {
    // Easiest deterministic behavior: restart match with new domain.
    if (!state) return;
    beginMatch(session);
  });

  window.addEventListener("gedu:applySettings", () => {
    if (!state) return;
    beginMatch(session);
  });

  // Note rail selection: in dev mode or Learning difficulty, clicking a rail cell sets the current prompt.
  window.addEventListener("gedu:railSelect", (e: any) => {
    if (!state) return;
    const vid = Number(e?.detail?.variantId);
    if (!Number.isFinite(vid)) return;
    const allow = !!state.settings.dev?.enabled || state.settings.difficulty === Difficulty.LEARNING;
    if (!allow) return;
    dispatch({ type: "DEV_SET_PROMPT", variantId: vid } as any);
  });
  // 25-key fret selector (instant): on fret pick, claim if a TAB string is selected (or vice versa).
  window.addEventListener("gedu:fretPick", (e: any) => {
    const raw = Number(e?.detail?.fret);
    if (!Number.isFinite(raw)) return;

    // Store the last chosen fret even if a match hasn't started yet.
    tabSelectedFret = clamp(Math.floor(raw), 0, 24);
    // Keep the TAB overlay's default rendered number in sync with the last chosen fret.
    staffOverlayState.tabDefaultNumber = tabSelectedFret;

    if (!state) return;

    const uiMode = (state.settings as any)?.uiMode ?? "m4";
    const tabEnabled = uiMode === "m3" || uiMode === "m4" || uiMode === "m5";
    if (!tabEnabled) {
      setAlert("TAB input is disabled in this mode");
      return;
    }

    // Open string (0) is always permitted for TAB entry even if the focused range starts at 1.
    const minAllowed = 0;
    const maxAllowed = Math.min(24, state.settings.domain.maxFret);
    const clampedFret = clamp(tabSelectedFret, minAllowed, maxAllowed);
    tabSelectedFret = clampedFret;
    staffOverlayState.tabDefaultNumber = clampedFret;

    if (tabSelectedString === null) {
      setAlert(`TAB: fret ${clampedFret} selected (pick string)`);
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      return;
    }

    onCellClick(tabSelectedString, clampedFret);
  });


  // STAFF/TAB surface pick events (string selection for TAB entry)
  window.addEventListener("gedu:staffPick", (e: any) => {
    if (!state) return;
    const region = String(e?.detail?.region ?? "");
    if (region !== "tab") return;

    const uiMode = (state.settings as any)?.uiMode ?? "m4";
    const tabEnabled = uiMode === "m3" || uiMode === "m4" || uiMode === "m5";
    if (!tabEnabled) return;

    const y = Number(e?.detail?.yIndex);
    if (!Number.isFinite(y)) return;
    tabSelectedString = Math.max(0, Math.min(5, y));

    // If a fret is already selected, claim immediately.
    if (tabSelectedFret !== null) {
      // Open string (0) is always permitted for TAB entry even if the focused range starts at 1.
      const minAllowed = 0;
      const maxAllowed = Math.min(24, state.settings.domain.maxFret);
      const clampedFret = clamp(tabSelectedFret, minAllowed, maxAllowed);
      tabSelectedFret = clampedFret;
      onCellClick(tabSelectedString, clampedFret);
      return;
    }

    setAlert(`TAB: string ${tabSelectedString + 1} selected (pick fret)`);
  });

  // Dev/Test UI wiring
  const devModeToggle = doc.querySelector<HTMLInputElement>("#core-devMode");
  devModeToggle?.addEventListener("change", () => {
    syncDevTabVisibility(!!devModeToggle.checked);
  });
  syncDevTabVisibility(!!devModeToggle?.checked);

  const btnDevPrev = doc.querySelector<HTMLButtonElement>("#dev-prevPlayer");
  const btnDevNext = doc.querySelector<HTMLButtonElement>("#dev-nextPlayer");
  const btnDevEndTurn = doc.querySelector<HTMLButtonElement>("#dev-endTurn");
  const btnDevClearBoard = doc.querySelector<HTMLButtonElement>("#dev-clearBoard");
  const btnDevPhaseInMatch = doc.querySelector<HTMLButtonElement>("#dev-forceInMatch");
  const btnDevPhaseIntermission = doc.querySelector<HTMLButtonElement>("#dev-forceIntermission");
  const btnDevPhaseLastChance = doc.querySelector<HTMLButtonElement>("#dev-forceLastChance");
  const btnDevPhaseResults = doc.querySelector<HTMLButtonElement>("#dev-forceResults");

  const devPaintEnabled = doc.querySelector<HTMLInputElement>("#dev-paintEnabled");
  const devPaintPlayer = doc.querySelector<HTMLSelectElement>("#dev-paintPlayer");
  const devPaintLane = doc.querySelector<HTMLSelectElement>("#dev-paintLane");
  const devPaintMode = doc.querySelector<HTMLSelectElement>("#dev-paintMode");

  const dispatchAndRender = (action: Action) => {
    if (!state) return;
    dispatch(action);
    renderAll();
  };

  btnDevPrev?.addEventListener("click", () => {
    if (!state) return;
    const n = state.players.length;
    const next = (state.currentPlayer - 1 + n) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });
  btnDevNext?.addEventListener("click", () => {
    if (!state) return;
    const n = state.players.length;
    const next = (state.currentPlayer + 1) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });

  // Dev "End Turn" behavior:
  // Option A (selected): simulate the end of a turn by triggering the same pipeline as a natural timeout/miss.
  // This validates the real scoring/token/sequence logic.
  btnDevEndTurn?.addEventListener("click", () => dispatchAndRender({ type: "TIMEOUT" } as Action));

  btnDevClearBoard?.addEventListener("click", () => dispatchAndRender({ type: "DEV_CLEAR_BOARD" } as Action));

  const forcePhase = (phase: Phase) => dispatchAndRender({ type: "DEV_FORCE_PHASE", phase } as Action);
  btnDevPhaseInMatch?.addEventListener("click", () => forcePhase("IN_MATCH"));
  btnDevPhaseIntermission?.addEventListener("click", () => forcePhase("INTERMISSION"));
  btnDevPhaseLastChance?.addEventListener("click", () => forcePhase("LAST_CHANCE"));
  btnDevPhaseResults?.addEventListener("click", () => forcePhase("RESULTS"));

  const syncPaintControlsToState = () => {
    if (!state) return;
    const patch: Partial<DevSettings> = {
      paintEnabled: !!devPaintEnabled?.checked,
      paintPlayerIndex: clamp(Number(devPaintPlayer?.value ?? 0), 0, Math.max(0, state.players.length - 1)),
      paintLane: (devPaintLane?.value as any) ?? "prompt",
      paintMode: (devPaintMode?.value as any) ?? "paint",
    };
    dispatchAndRender({ type: "DEV_SET_PAINT", patch } as Action);
  };

  devPaintEnabled?.addEventListener("change", syncPaintControlsToState);
  devPaintPlayer?.addEventListener("change", syncPaintControlsToState);
  devPaintLane?.addEventListener("change", syncPaintControlsToState);
  devPaintMode?.addEventListener("change", syncPaintControlsToState);


  // Live settings sync: when dropdowns/toggles change, update *visual* surfaces immediately
  // (so UI Mode, Note Visibility, Display Mode, etc. take effect without requiring a restart).
  doc.addEventListener("change", (ev) => {
    const target = ev.target as HTMLElement | null;
    if (!target) return;
    const ds = (target as any).dataset as { setting?: string } | undefined;
    if (!ds?.setting) return;

    const next = buildSettingsFromUi(doc, session) as any;

    // Allow preview even before the first match is started.
    if (!state) {
      if ((target as any).id === "core-gameMode") applyUiModeVisibility(next.uiMode);
      return;
    }

    const cur = state.settings as any;
    cur.uiMode = next.uiMode;
    cur.noteVisibility = next.noteVisibility;
    cur.displayMode = next.displayMode;
    cur.tritoneLabelMode = next.tritoneLabelMode;
    cur.rootNote = next.rootNote;
    cur.modeId = next.modeId;
    cur.chordKind = next.chordKind;
    cur.highlight = next.highlight;

    applyUiModeVisibility(cur.uiMode);
    updatePromptUi();

    if (staffOverlaySvgEl && staffLayout) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
    syncFretKeypadAvailability();
  });

  // Initialize UI
  syncFretKeypadAvailability();
  updateHighScoresUi(buildSettingsFromUi(doc, session));
  setAlert("Choose Single or Multiplayer to begin");
  showSplash();
}
