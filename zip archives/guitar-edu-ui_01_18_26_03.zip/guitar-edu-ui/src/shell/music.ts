import { SlotType, VariantId, NoteVariant, PitchClass } from "./types";

// Pitch-class helpers
export const IS_BLACK: boolean[] = [
  false, true, false, true, false, false, true, false, true, false, true, false,
];

// String order matches the provided SVG: thinnest at the TOP, thickest at the BOTTOM.
// (Top = high E; bottom = low E.)
const OPEN_STRING_PC: PitchClass[] = [4, 11, 7, 2, 9, 4]; // E B G D A E (high -> low)

export function pitchClassAt(stringIndex: number, fretIndex: number): PitchClass {
  const open = OPEN_STRING_PC[stringIndex] ?? 0;
  return ((open + fretIndex) % 12) as PitchClass;
}

export function isValidSpelling(pc: PitchClass, slot: SlotType): boolean {
  if (!IS_BLACK[pc]) return slot === SlotType.NAT;
  return slot === SlotType.SHR || slot === SlotType.FLT;
}

export function toVariantId(pc: PitchClass, slot: SlotType): VariantId {
  return (pc * 3 + slot) as VariantId;
}

export function fromVariantId(vid: VariantId): NoteVariant {
  const pc = Math.floor(vid / 3) as PitchClass;
  const spelling = (vid % 3) as SlotType;
  return { pitchClass: pc, spelling };
}

export function enharmonicOppositeSlot(slot: SlotType): SlotType | null {
  if (slot === SlotType.SHR) return SlotType.FLT;
  if (slot === SlotType.FLT) return SlotType.SHR;
  return null;
}

// UI label helpers (prototype names)
const NAT_NAMES = ["C","D","E","F","G","A","B"];
const NAT_PCS: PitchClass[] = [0,2,4,5,7,9,11];

export function variantLabel(vid: VariantId): string {
  const v = fromVariantId(vid);
  const pc = v.pitchClass;
  if (!IS_BLACK[pc]) {
    const idx = NAT_PCS.indexOf(pc);
    return NAT_NAMES[idx >= 0 ? idx : 0];
  }
  // Black keys: use “sharp-name” for SHR lane and “flat-name” for FLT lane.
  // Use music glyphs (♯/♭) to reduce visual ambiguity.
  const sharpNames = ["C♯","D♯","F♯","G♯","A♯"];
  const flatNames  = ["D♭","E♭","G♭","A♭","B♭"];
  const blackPcs: PitchClass[] = [1,3,6,8,10];
  const i = blackPcs.indexOf(pc);
  return v.spelling === SlotType.FLT ? flatNames[i] : sharpNames[i];
}

// --- Chord helpers (UI ergonomics v2) ---

export const PC_NAMES_SHARP = [
  "C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B",
] as const;

export const PC_NAMES_FLAT = [
  "C","D♭","D","E♭","E","F","G♭","G","A♭","A","B♭","B",
] as const;

export type ChordQualityId =
  | "maj" | "min" | "dim" | "aug"
  | "sus2" | "sus4"
  | "7" | "maj7" | "min7" | "m7b5" | "dim7";

const CHORD_PATTERNS: Array<{ id: ChordQualityId; intervals: number[]; label: string }> = [
  { id: "maj",  intervals: [0, 4, 7], label: "" },
  { id: "min",  intervals: [0, 3, 7], label: "m" },
  { id: "dim",  intervals: [0, 3, 6], label: "dim" },
  { id: "aug",  intervals: [0, 4, 8], label: "aug" },
  { id: "sus2", intervals: [0, 2, 7], label: "sus2" },
  { id: "sus4", intervals: [0, 5, 7], label: "sus4" },

  { id: "7",    intervals: [0, 4, 7, 10], label: "7" },
  { id: "maj7", intervals: [0, 4, 7, 11], label: "maj7" },
  { id: "min7", intervals: [0, 3, 7, 10], label: "m7" },
  { id: "m7b5", intervals: [0, 3, 6, 10], label: "m7♭5" },
  { id: "dim7", intervals: [0, 3, 6, 9],  label: "dim7" },
];

export function pcLabel(pc: PitchClass, prefer: "sharp" | "flat" = "sharp"): string {
  return (prefer === "flat" ? PC_NAMES_FLAT : PC_NAMES_SHARP)[pc] ?? "C";
}

function normalizePcs(pcs: PitchClass[]): PitchClass[] {
  const set = new Set<number>();
  for (const p of pcs) set.add((p + 1200) % 12);
  return Array.from(set).sort((a,b) => a - b) as PitchClass[];
}

function matchesIntervals(root: PitchClass, pcs: PitchClass[], want: number[]): boolean {
  const rel = new Set<number>();
  for (const p of pcs) rel.add((p - root + 1200) % 12);
  for (const w of want) if (!rel.has(w)) return false;
  // Must not contain tones outside the pattern (keeps suggestions tight)
  for (const r of rel) if (!want.includes(r)) return false;
  return true;
}

export interface ChordSuggestion {
  root: PitchClass;
  quality: ChordQualityId;
  label: string; // e.g. Cmaj7, Dm
}

// Given a set of pitch classes (3–4 typically), return strong chord-name suggestions.
// This is intentionally conservative: it only returns matches with no extra tones.
export function suggestChords(pcsIn: PitchClass[], prefer: "sharp" | "flat" = "sharp"): ChordSuggestion[] {
  const pcs = normalizePcs(pcsIn);
  if (pcs.length < 3) return [];

  const out: ChordSuggestion[] = [];

  for (const root of pcs) {
    for (const pat of CHORD_PATTERNS) {
      if (matchesIntervals(root, pcs, pat.intervals)) {
        const rootName = pcLabel(root, prefer);
        out.push({ root, quality: pat.id, label: `${rootName}${pat.label}` });
      }
    }
  }

  // Rank: prioritize 7th chords over triads, then maj/min, then others.
  const rank = (q: ChordQualityId) => {
    if (q === "maj7" || q === "7" || q === "min7" || q === "m7b5" || q === "dim7") return 0;
    if (q === "maj" || q === "min") return 1;
    return 2;
  };

  out.sort((a,b) => {
    const ra = rank(a.quality);
    const rb = rank(b.quality);
    if (ra !== rb) return ra - rb;
    return a.root - b.root;
  });

  return out.slice(0, 6);
}
