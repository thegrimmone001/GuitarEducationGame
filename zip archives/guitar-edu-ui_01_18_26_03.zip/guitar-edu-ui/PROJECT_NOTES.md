# GuitarEdu Project Notes

## Staff + TAB intent
The Staff+TAB region should mirror real sheet music (Ultimate Guitar / Guitar Pro style) so students learn what they will see in real life.

## Non-negotiables
- Clefs are meaningful anchors and must be placed by engraving rules (not centered):
  - Treble clef anchors the G line; bass clef anchors the F line.
- Key signatures and time signatures must be rendered in standard positions.
- Staff must always reserve room for extended ledger lines and future chord stacking.

## Notation pitch
- A user-facing toggle is required:
  - **Written (default)**: standard guitar printed notation conventions.
  - **Concert**: sounding pitch.
- This toggle should be available now in Preferences and later surfaced in Main Menu Options.

## Fair-play constraint
- Notation viewport should be based on instrument capability (e.g., 24-fret instruments), not the currently selected practice fret range, to avoid giving players visual "growth" cues.
