# Changelog (project zips)

## Step 14.1 (Regression cleanup)
- Replaced fretboard SVG with `Guitar_FretBoard_Horizontal-Complete_v2i.svg` content (better aligned hitbox art).
- Restored Note Visibility selector to include **All** and set default to **All**.
- Restored controller defaults for `core.noteVisibility` to **all** (was regressed to naturals).
- Fixed minor indentation regression in controller settings change handler.
- Confirmed project zips must not include `node_modules/` or `dist/`.

## Step 14.2 (GEG-016 Starting tokens)
- Implemented UI coupling between Token Cap and Starting Tokens so Start is clamped to Cap in real time (Main Menu Settings).
- Marked **GEG-016** complete in CHECKLIST.md.

## Step 14.3 (GEG-020 Player card timer)
- Verified Player Card contains avatar, score, tokens, and turn timer display.
- Marked **GEG-020** complete in CHECKLIST.md.

## Step 14.4 (GEG-022 Active players only)
- Added a Multiplayer player-count selector to the splash screen (2–5).
- Match init now uses the selected player count so the in-match leaderboard renders only active players.
- Marked **GEG-022** complete in CHECKLIST.md.

## Step 14.5 (Multiplayer cap correction)
- Corrected accidental Multiplayer hard-cap (2–5) by raising the upper bound to **2–12**.
- Centralized the Multiplayer upper bound in `src/app/constants.ts` so UI + engine stay in sync.
- Preserved GEG-022 behavior: leaderboard still renders **active players only** (no empty slots).

## Step 14.6 (GEG-023 Persistent high scores)
- Confirmed the persistent High Score Board is wired to local storage via `src/shell/storage.ts` and is rendered in the Utility area under **Misc. Information → Leaderboard → High Scores**.
- Marked **GEG-023** complete in CHECKLIST.md.

## Step 14.7 (GEG-030/031 Mode selector compliance)
- Verified Game Mode selector (Modes 1–5) drives surface visibility per locked spec.
- Fixed Staff/Tab panel mode-disable styling and input gating by adding `staffSection` class to the Staff+Tab section.
- Marked **GEG-030** and **GEG-031** complete in CHECKLIST.md.


## Step 14.8 (Surface controls replace legacy board-selection modes)
- Removed the legacy surface-selection “mode” concept from canon: **Mode** is reserved for musical modes only.
- Added **Surface Controls → In Play** toggles in Core Settings (Fretboard / Note Rail / Staff / TAB).
- Surface toggles now gate both **rendering** and **allowed input** for Staff/TAB/Rail.
- Notation View remains a display crop only (Staff Only / TAB Only / Staff+TAB).
- Updated CHECKLIST Section D: marked GEG-030/031 as deprecated; marked GEG-032 complete.

## Step 14.9 (GEG-040 Learning difficulty labels)
- Confirmed Learning difficulty renders **all note labels** across the fretboard (including grayed-out range) while keeping hitboxes interactive (labels are `pointer-events:none`).
- Verified normal play actions remain available in Learning difficulty (claim/highlight, connect-segments, token awards).
- Marked **GEG-040** complete in CHECKLIST.md.

## Step 14.10 (GEG-041 SAM reveal options)
- Added **SAM Reveal** selector in Core Settings with `single` (best/closest) and `multiple` (all correct) options.
- Wired selector to `settings.feedback.samRevealMode` via `#core-sam` (mapped to `single` vs `all`).
- Marked **GEG-041** complete in CHECKLIST.md.

## Step 14.11 (GEG-041 SAM equivalents)
- Updated SAM options to the flushed-out spec: **Single**, **Equivalent (same pitch)**, **All**.
- Removed the deprecated “Multiple” label/value from the Core Settings selector.
- Extended the engine SAM pulse to support `samRevealMode: "equiv"`, revealing all actionable targets for the same pitch across allowed spellings.

## Step 14.12 (GEG-042 Default fret range)
- Set the default fret range to **min 0, max 12**, with **13 frets visible** by default.
- Updated controller defaults to respect the checklist defaults when settings are not yet stored.
- Marked **GEG-042** complete in CHECKLIST.md.

## Step 14.13 (Conversation composite added)
- Added `DOCS/conversation_composite.json` as the project-scoped, minimal canon record (append-only) capturing only implementation-relevant conversation decisions.
- Intended to be read/validated before each checklist step to prevent drift.

## Step 14.14 (GEG-043 Note visibility modes)
- Standardized Note Visibility enum values to: `all`, `natural`, `enharmonic`.
- Note Rail now reflects note visibility:
  - `natural` hides accidentals
  - `enharmonic` hides naturals and shows enharmonic spellings for accidentals
  - `all` shows all notes
- Fretboard label visibility remains driven by `variants.allowed`, so labels follow the same Note Visibility filter.
- Marked **GEG-043** complete in CHECKLIST.md.

## Step 14.15 (GEG-044 Extended tone highlighting)
- Expanded the Highlight Tones system to include **9th / 11th / 13th** (in addition to Root/3/5/7).
- Implemented the educational highlight overlay on the fretboard: selected tones are rendered as subtle rings behind ownership dots.
- Extended Chord Display → Extension options to include **11th** and **13th** for forward compatibility.
- Marked **GEG-044** complete in CHECKLIST.md.

## Step 14.16 (GEG-045 Note display options)
- Updated Core Settings → Display to the locked, global options: **Note Names / Numbers / Intervals / Interval Roman**.
- Implemented the new `numbers` display mode (degree-style labels: 1, ♭2, 2, ♭3, 3, 4, ♯4, 5, ♭6, 6, ♭7, 7) across the note rail and prompt labels.
- Deprecated legacy `romanIntervals` display mode by mapping it to `intervalRoman` for back-compat (no UI exposure).
- Marked **GEG-045** complete in CHECKLIST.md.

## Step 14.17 (Roman note display added)
- Added Core Settings → Display option: **Roman (Scale Degree)**, distinct from **Interval Roman** (Roman Numeral Interval System).
- Implemented Roman (scale-degree/function) labels across the Note Rail, prompt labels, and rail label resolver.
- Updated `DOCS/conversation_composite.json` with the canon decision for this distinction.
