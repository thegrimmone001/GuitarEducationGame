# Guitar-Edu-UI Master Checklist (Execution Order)

This checklist is designed for hands-off iteration. Each item should be advanced by snapshot batches and validated via smoke mode (`?smoke=1`) and the Event Log Report Pack download.

## A. Boot + Stability (Must never regress)
- [x] App loads without blank page / fatal module errors
- [x] Single-run boot guard (no double init / duplicate listeners)
- [x] Build badge reflects current snapshot
- [x] Smoke mode asserts critical mounts and emits `gedu:smokeTest`

## B. Core Surface Mount Contract (Eliminate “missing basics” regressions)
- [x] Fretboard stays mounted (never removed from layout)
- [x] Note Rail stays mounted (never removed from layout)
- [x] Non-active surfaces use suppression styling (not DOM removal)

## C. Prompt + Generator Plumbing
- [x] Prompt always visible in UI (Prompt banner + promptText)
- [x] Prompt sequencing on turn start (fresh actionable prompt)
- [x] Note rail tile mount asserted in smoke test

## D. Clarity & Operator UX
- [x] Event Log Copy button
- [x] Event Log Download button
- [x] Report Pack export includes Build ID + URL + last matchOptions + last engine settings + event log
- [x] Task Context present and structurally asserted in smoke test
- [x] Task Context shows Learning Target
- [x] Task Context shows Active Surfaces + Required Inputs

## E. Input Gating Consistency
- [x] Disabled surfaces cannot submit input (fretboard/staff/tab gated)
- [x] Validation only evaluates required surfaces for correctness (prevents phantom fails)

## F. Rendering & Interaction Integrity
- [ ] Staff rendering: cursor/placement correctness, no bleed into tab
  - (Stability sub-fix applied) Staff/Tab boundary clamp + hit-test guard to prevent region overlap (GEG-050)
- [ ] Tab rendering: numbers visible, spacing correct
- [ ] Fretboard rendering: prompts/marks consistent with surface layers
- [ ] Note rail rendering: prompt highlighting + exhaustion behavior

## G. Menu / Match Options Single Source of Truth
- [ ] Eliminate redundant `matchOptions` emissions at source (not just de-dupe)
- [ ] Ensure UI matchOptions → engine settings mapping is canonical
- [ ] Remove deprecated terms + enforce contract naming

## H. Automation Pipeline (Optional)
- [ ] Add CI-like script to run lint/typecheck + unit smoke (non-browser)
- [ ] Package a deterministic “release” build zip with logs

