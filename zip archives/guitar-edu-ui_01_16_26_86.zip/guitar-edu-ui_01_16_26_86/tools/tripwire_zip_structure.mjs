import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";

// Tripwire: enforce zip artifact structure.
// Rule: any zip must contain exactly one top-level folder whose name matches the zip filename (minus .zip).

const ROOT = process.cwd();

function fail(msg) {
  console.error(`TRIPWIRE FAIL: ${msg}`);
  process.exit(1);
}

function newestZipInReleases() {
  const releasesDir = path.join(ROOT, "releases");
  if (!fs.existsSync(releasesDir)) return null;
  const zips = fs.readdirSync(releasesDir)
    .filter((n) => n.toLowerCase().endsWith(".zip"))
    .map((n) => ({
      name: n,
      full: path.join(releasesDir, n),
      mtime: fs.statSync(path.join(releasesDir, n)).mtimeMs
    }))
    .sort((a, b) => b.mtime - a.mtime);
  return zips.length ? zips[0].full : null;
}

function listZipEntries(zipPath) {
  // Prefer Python (cross-platform), fall back to unzip.
  const pySnippet = [
    "import sys, zipfile",
    "p=sys.argv[1]",
    "z=zipfile.ZipFile(p,'r')",
    "for n in z.namelist():",
    "  print(n)"
  ].join("; ");

  try {
    const out = execSync(`python -c "${pySnippet}" "${zipPath}"`, { encoding: "utf8" });
    return out.split(/\r?\n/).filter(Boolean);
  } catch {
    // Windows sometimes uses 'py'
    try {
      const out = execSync(`py -c "${pySnippet}" "${zipPath}"`, { encoding: "utf8" });
      return out.split(/\r?\n/).filter(Boolean);
    } catch {
      try {
        const out = execSync(`unzip -Z1 "${zipPath}"`, { encoding: "utf8" });
        return out.split(/\r?\n/).filter(Boolean);
      } catch {
        fail("Unable to list zip entries (requires python/py or unzip). Install one of these tools to enforce packaging invariants.");
      }
    }
  }
}

const arg = process.argv[2];
const zipPath = arg ? path.resolve(ROOT, arg) : newestZipInReleases();
if (!zipPath) fail("No zip path provided and no ./releases/*.zip found.");
if (!fs.existsSync(zipPath)) fail(`Zip file not found: ${zipPath}`);

const baseName = path.basename(zipPath, path.extname(zipPath));
const entries = listZipEntries(zipPath);
if (!entries.length) fail("Zip appears empty.");

// Determine unique top-level paths
const tops = new Set();
for (const e of entries) {
  const normalized = e.replace(/\\/g, "/");
  const top = normalized.split("/")[0];
  if (top) tops.add(top);
}

if (tops.size !== 1) {
  fail(`Zip must contain exactly one top-level folder. Found: ${Array.from(tops).join(", ")}`);
}

const [onlyTop] = Array.from(tops);
if (onlyTop !== baseName) {
  fail(`Top-level folder name mismatch. Expected "${baseName}", found "${onlyTop}"`);
}

console.log(`OK: zip structure tripwire passed (${path.basename(zipPath)})`);
