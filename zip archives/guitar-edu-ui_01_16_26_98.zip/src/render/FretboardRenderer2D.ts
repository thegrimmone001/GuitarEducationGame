import { resizeCanvasToHost } from "./types";

export type FretboardView = {
  frets: number; // number of frets to display (e.g., 12 or 24)
  strings: number; // usually 6
};

/**
 * Deterministic canvas renderer for the fretboard. This is the new primary visual surface.
 * Hit-testing remains handled by existing overlays for now.
 */
export class FretboardRenderer2D {
  private canvas: HTMLCanvasElement;
  private view: FretboardView;

  constructor(canvas: HTMLCanvasElement, view: Partial<FretboardView> = {}) {
    this.canvas = canvas;
    this.view = { frets: view.frets ?? 24, strings: view.strings ?? 6 };
  }

  setView(view: Partial<FretboardView>) {
    this.view = { ...this.view, ...view };
    this.draw();
  }

  draw() {
    const { w, h } = resizeCanvasToHost(this.canvas);
    const ctx = this.canvas.getContext("2d");
    if (!ctx) return;

    // Background
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(0,0,0,0.0)";
    ctx.fillRect(0, 0, w, h);

    // Use a simple inset frame to match UI
    const padX = Math.round(w * 0.05);
    const padY = Math.round(h * 0.18);
    const gridX = padX;
    const gridY = padY;
    const gridW = w - padX * 2;
    const gridH = h - padY * 2;

    // Neck background
    ctx.fillStyle = "rgba(0,0,0,0.10)";
    ctx.fillRect(gridX, gridY, gridW, gridH);

    // Frets
    const fretCount = Math.max(1, this.view.frets);
    const colCount = fretCount + 1; // include open string column
    const colW = gridW / colCount;

    ctx.strokeStyle = "rgba(255,255,255,0.22)";
    ctx.lineWidth = 1;

    for (let i = 0; i <= colCount; i++) {
      const x = gridX + i * colW;
      ctx.beginPath();
      ctx.moveTo(x, gridY);
      ctx.lineTo(x, gridY + gridH);
      ctx.stroke();
    }

    // Nut emphasis
    ctx.strokeStyle = "rgba(255,255,255,0.45)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(gridX + colW, gridY);
    ctx.lineTo(gridX + colW, gridY + gridH);
    ctx.stroke();

    // Strings
    const stringCount = Math.max(1, this.view.strings);
    const rowH = gridH / stringCount;

    for (let s = 0; s < stringCount; s++) {
      const y = gridY + (s + 0.5) * rowH;
      const t = s / Math.max(1, stringCount - 1);
      // Thicker/stronger strings should appear at the bottom (low strings).
      ctx.strokeStyle = `rgba(255,255,255,${0.18 + 0.22 * t})`;
      ctx.lineWidth = 1 + t;
      ctx.beginPath();
      ctx.moveTo(gridX, y);
      ctx.lineTo(gridX + gridW, y);
      ctx.stroke();
    }

    // Simple fret markers (12, 15, 17, 19, 21, 24) as circles - OPTIONAL visual aid.
    // These are not authoritative; they are a fallback visual.
    const markerFrets = new Set([3, 5, 7, 9, 12, 15, 17, 19, 21, 24]);
    const markerColor = "rgba(255,255,255,0.12)";
    ctx.fillStyle = markerColor;
    for (let f = 0; f <= fretCount; f++) {
      if (!markerFrets.has(f)) continue;
      const cx = gridX + (f + 0.5) * colW;
      const cy = gridY + gridH / 2;
      const r = Math.min(colW, rowH) * 0.12;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
      if (f === 12 || f === 24) {
        // double dot
        const dy = gridH * 0.18;
        ctx.beginPath();
        ctx.arc(cx, cy - dy, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx, cy + dy, r, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
}
