import { PLAYER_COUNT_MULTI_MAX } from "../app/constants";

const NOTE_NAMES = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"];

type Opt = { label: string; value: string };

type ElAttrs = Record<string, string>;

const el = <K extends keyof HTMLElementTagNameMap>(
  tag: K,
  attrs: ElAttrs = {},
  children: Array<Element | Text | string> = [],
) => {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  for (const c of children) node.append(c instanceof Node ? c : document.createTextNode(c));
  return node;
};

const SVG_NS = "http://www.w3.org/2000/svg";

const elSvg = <K extends keyof SVGElementTagNameMap>(
  tag: K,
  attrs: ElAttrs = {},
  children: Array<SVGElement | Text | string> = [],
) => {
  const node = document.createElementNS(SVG_NS, tag) as SVGElementTagNameMap[K];
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  for (const c of children) node.append(c instanceof Node ? c : document.createTextNode(c));
  return node;
};

function build2OctaveRail(home: string) {
  const rail = el("div", { class: "rail", id: "noteStrip-rail" });
  const startIdx = NOTE_NAMES.indexOf(home);
  const seq: string[] = [];
  // Two-octave span centered on the current note.
  // 25 tiles: 12 notes to the left, the current note, 12 notes to the right.
  for (let offset = -12; offset <= 12; offset++) {
    seq.push(NOTE_NAMES[(startIdx + offset + 1200) % 12]);
  }

  seq.forEach((n, i) => {
    const isCenter = i === 12;
    rail.append(
      el(
        "div",
        {
          class: `noteTile ${n.includes("#") ? "acc" : ""}${isCenter ? " active" : ""}`.trim(),
          "data-note": n,
          "data-idx": String(i),
          ...(isCenter ? { "data-center": "1" } : {}),
        },
        [n],
      ),
    );
  });

  return rail;
}

function wireTabs(root: HTMLElement) {
  const groups = root.querySelectorAll<HTMLElement>("[data-tabs]");
  groups.forEach((g) => {
    const tabs = Array.from(g.querySelectorAll<HTMLButtonElement>(".tab"));
    const panes = Array.from(g.querySelectorAll<HTMLElement>(".pane"));
    const activate = (id: string) => {
      tabs.forEach((t) => t.classList.toggle("active", t.dataset.tab === id));
      panes.forEach((p) => p.classList.toggle("active", p.dataset.pane === id));
    };
    tabs.forEach((t) => t.addEventListener("click", () => activate(t.dataset.tab!)));
    activate(tabs[0]?.dataset.tab ?? "single");
  });
}

// Tabs that do not have panes (used for intent/selection only).
function wireInlineTabs(root: HTMLElement, selector: string) {
  const g = root.querySelector<HTMLElement>(selector);
  if (!g) return;
  const tabs = Array.from(g.querySelectorAll<HTMLButtonElement>(".tab"));
  const activate = (id: string) => {
    tabs.forEach((t) => t.classList.toggle("active", t.dataset.tab === id));
  };
  tabs.forEach((t) => t.addEventListener("click", () => activate(t.dataset.tab!)));
  activate(tabs.find((t) => t.classList.contains("active"))?.dataset.tab ?? (tabs[0]?.dataset.tab ?? ""));
}

// ---- Form helpers (UI only; engine wiring comes later) ----
function selectEl(id: string, options: Opt[], settingKey?: string, value?: string) {
  const s = document.createElement("select");
  s.id = id;
  s.className = "select";
  if (settingKey) s.dataset.setting = settingKey;
  options.forEach((o) => {
    const opt = document.createElement("option");
    opt.value = o.value;
    opt.textContent = o.label;
    s.appendChild(opt);
  });
  if (value != null) s.value = value;
  return s;
}

function numberEl(id: string, min: number, max: number, settingKey?: string, value?: number) {
  const i = document.createElement("input");
  i.type = "number";
  i.id = id;
  i.className = "numInput";
  i.min = String(min);
  i.max = String(max);
  i.step = "1";
  if (settingKey) i.dataset.setting = settingKey;
  if (value != null) i.value = String(value);
  return i;
}

function checkboxEl(id: string, checked = false, settingKey?: string) {
  const i = document.createElement("input");
  i.type = "checkbox";
  i.id = id;
  i.checked = checked;
  i.className = "toggle";
  if (settingKey) i.dataset.setting = settingKey;
  return i;
}

function formRow(label: string, control: HTMLElement, hint?: string) {
  return el("div", { class: "formRow" }, [
    el("div", { class: "formLabel" }, [label]),
    el("div", { class: "formControl" }, [control]),
    ...(hint ? [el("div", { class: "formHint" }, [hint])] : []),
  ]);
}

function formRowInline(label: string, controls: HTMLElement[]) {
  return el("div", { class: "formRow" }, [
    el("div", { class: "formLabel" }, [label]),
    el("div", { class: "formControl" }, [el("div", { class: "inline" }, controls)]),
  ]);
}

function checkGroup(title: string, items: Array<{ label: string; id: string; key: string }>) {
  const wrap = el("div", { class: "checkGroup" });
  if (title.trim().length) wrap.append(el("div", { class: "groupTitle" }, [title]));
  const grid = el("div", { class: "checks" });
  items.forEach((it) => {
    const row = el("label", { class: "check" }, [
      checkboxEl(it.id, false, it.key),
      el("span", { class: "checkText" }, [it.label]),
    ]);
    grid.append(row);
  });
  wrap.append(grid);
  return wrap;
}

function miniBtn(id: string, eventName: string, text: string, color: string) {
  const b = el("button", { class: "btn btn-sm", id, type: "button" }, [
    el("span", { class: `dot ${color}` }),
    el("span", { class: "btnText" }, [text]),
  ]);
  b.addEventListener("click", () => window.dispatchEvent(new CustomEvent(eventName)));
  return b;
}

function buildKeypad() {
  const keypad = document.getElementById("keypad");
  const display = document.getElementById("keypad-display");
  if (!keypad || !display) return;

  // 25-key fret selector (instant):
  // - 5 columns × 5 rows
  // - keys: 0..24
  // - no ENTER / DEL / CLEAR (selection is immediate)
  // Layout (row-major):
  //  0  1  2  3  4
  //  5  6  7  8  9
  // 10 11 12 13 14
  // 15 16 17 18 19
  // 20 21 22 23 24
  const keys: Array<{ label: string; value: number }> = Array.from({ length: 25 }, (_, i) => ({
    label: String(i),
    value: i,
  }));

  keypad.innerHTML = "";
  keypad.classList.add("keypad-25");

  keys.forEach((k) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "key";
    b.dataset.fret = String(k.value);
    b.textContent = k.label;
    b.addEventListener("click", () => {
      // Set display for visibility; gameplay is handled by the controller listener.
      display.textContent = k.label;
      window.dispatchEvent(new CustomEvent("gedu:fretPick", { detail: { fret: k.value } }));
    });
    keypad.appendChild(b);
  });
}

export function mountLayout(target: HTMLElement) {
  const shell = el("div", { class: "ge-shell", id: "ge-shell" });

  // Main 3 columns
  const main = el("div", { class: "ge-main" });

  // --- Left column ---
  const ops = el("div", { class: "section" }, [
    el("div", { class: "block-title" }, ["Operations"]),

    el("details", { class: "collapse", id: "ops-playstyle" }, [
      el("summary", { class: "collapseSummary" }, ["Play Style Options"]),
      el("div", { class: "collapseBody" }, [
        checkGroup("", [
          { label: "SAM (Show After Miss)", id: "ps-sam", key: "ps.sam" },
        ]),
        el("label", { class: "check", id: "ps-personalBoardsRow" }, [
          checkboxEl("ps-personalBoards", false, "ps.personalBoards"),
          el("span", { class: "checkText" }, ["Personal Boards"]),
        ]),
      ]),
    ]),

    el("div", { class: "opsGrid" }, [
      miniBtn("btn-start", "gedu:start", "Start", "green"),
      miniBtn("btn-stop", "gedu:stop", "End", "red"),
      miniBtn("btn-new", "gedu:new", "New", "blue"),
      // Canon ergonomics: provide a user-facing way to end a turn (especially multiplayer)
      // without relying on dev tools.
      miniBtn("btn-endturn", "gedu:endTurn", "End Turn", "yellow"),
    ]),

    // Intermission banner (multiplayer). Hidden unless phase === INTERMISSION.
    el("div", { class: "intermissionBanner", id: "intermission-banner", hidden: "true" }, [
      el("div", { class: "intermissionTitle" }, ["Intermission"]),
      el("div", { class: "intermissionText", id: "intermission-text" }, [""])
    ]),
    el("div", { class: "bonusBanner", id: "bonus-banner", hidden: "true" }, [
      el("div", { class: "bonusTitle" }, ["Bonus Phase"]),
      el("div", { class: "bonusText", id: "bonus-text" }, [""])
    ]),
  ]);


  const coreSettings = el("div", { class: "section" }, [
    el("div", { class: "block-title" }, ["Core Settings"]),
    el("div", { class: "subTitle" }, ["Surface Controls"]),
    (function () {
      const wrap = el("div", { class: "checkGroup" });
      wrap.append(el("div", { class: "groupTitle" }, ["In Play"]));
      const grid = el("div", { class: "checks" });
      const items = [
        { label: "Fretboard", id: "core-surface-fret", key: "core.surface.fretboard" },
        { label: "Note Rail", id: "core-surface-rail", key: "core.surface.rail" },
        { label: "Staff", id: "core-surface-staff", key: "core.surface.staff" },
        { label: "TAB", id: "core-surface-tab", key: "core.surface.tab" },
      ];
      items.forEach((it) => {
        const row = el("label", { class: "check" }, [
          checkboxEl(it.id, true, it.key),
          el("span", { class: "checkText" }, [it.label]),
        ]);
        grid.append(row);
      });
      wrap.append(grid);
      return wrap;
    })(),

    formRow(
      "Mirroring",
      selectEl(
        "core-mirror",
        [
          { label: "Placed (default)", value: "placed" },
          { label: "Off", value: "off" },
        ],
        "core.mirror",
        "placed",
      ),
    ),

    formRow(
      "SAM Reveal",
      selectEl(
        "core-sam",
        [
          { label: "Single (best/closest)", value: "single" },
          { label: "Equivalent (same pitch)", value: "equiv" },
          { label: "All (all correct)", value: "all" },
        ],
        "core.sam",
        "single",
      ),
    ),
    formRow(
      "Root Note",
      selectEl(
        "core-root",
        [
          { label: "C", value: "C" },
          { label: "C#", value: "C#" },
          { label: "D", value: "D" },
          { label: "D#", value: "D#" },
          { label: "E", value: "E" },
          { label: "F", value: "F" },
          { label: "F#", value: "F#" },
          { label: "G", value: "G" },
          { label: "G#", value: "G#" },
          { label: "A", value: "A" },
          { label: "A#", value: "A#" },
          { label: "B", value: "B" },
        ],
        "core.root",
        "C",
      ),
    ),
    formRow(
      "Mode",
      selectEl(
        "core-modes",
        [
          { label: "Chromatic", value: "chromatic" },
          { label: "Pentatonic", value: "pentatonic" },
          { label: "Blues", value: "blues" },
          { label: "Ionian (Major)", value: "ionian" },
          { label: "Dorian", value: "dorian" },
          { label: "Phrygian", value: "phrygian" },
          { label: "Lydian", value: "lydian" },
          { label: "Mixolydian", value: "mixolydian" },
          { label: "Aeolian (Minor)", value: "aeolian" },
          { label: "Locrian", value: "locrian" },
        ],
        "core.modes",
        "chromatic",
      ),
    ),
    formRow(
      "Display",
      selectEl(
        "core-display",
        [
          { label: "Note Names", value: "names" },
          { label: "Numbers", value: "numbers" },
          { label: "Intervals", value: "intervals" },
          { label: "Roman (Scale Degree)", value: "roman" },
          { label: "Interval Roman (I/ii/II/iii...)", value: "intervalRoman" },
        ],
        "core.display",
        "names",
      ),
    ),
    formRowInline("Chord Display", [
      selectEl(
        "chords-visibility",
        [
          { label: "Roman Numerals", value: "roman" },
          { label: "Nashville Numbers", value: "nashville" },
          { label: "Chord Name", value: "name" },
        ],
        "chords.visibility",
        "name",
      ),
      selectEl(
        "chords-extension",
        [
          { label: "None", value: "none" },
          { label: "Triad", value: "triad" },
          { label: "7th", value: "7th" },
          { label: "9th", value: "9th" },
          { label: "11th", value: "11th" },
          { label: "13th", value: "13th" },
        ],
        "chords.extension",
        "triad",
      ),
    ]),
    formRow(
      "Note Visibility",
      selectEl(
        "core-noteVisibility",
        [
          { label: "All", value: "all" },
          { label: "Naturals", value: "natural" },
          { label: "Enharmonics", value: "enharmonic" },
        ],
        "core.noteVisibility",
        "all",
      ),
    ),

    formRow(
      "Accidentals",
      selectEl(
        "core-accidentalView",
        [
          { label: "Both", value: "both" },
          { label: "Sharps only", value: "sharps" },
          { label: "Flats only", value: "flats" },
          { label: "Auto (context)", value: "auto" },
        ],
        "core.accidentalView",
        "both",
      ),
    ),
    checkGroup("Highlight Tones", [
      { label: "Root / Tonic", id: "core-hl-root", key: "core.hl.root" },
      { label: "3rd", id: "core-hl-3", key: "core.hl.3" },
      { label: "5th", id: "core-hl-5", key: "core.hl.5" },
      { label: "7th", id: "core-hl-7", key: "core.hl.7" },
      { label: "9th", id: "core-hl-9", key: "core.hl.9" },
      { label: "11th", id: "core-hl-11", key: "core.hl.11" },
      { label: "13th", id: "core-hl-13", key: "core.hl.13" },
    ]),

    el("div", { class: "subTitle" }, ["Game Options"]),
    formRowInline("Tokens", [
      el("div", { class: "inlineLabeled" }, [
        el("div", { class: "miniLabel" }, ["Cap"]),
        numberEl("core-tokenCap", 0, 20, "core.tokenCap", 10),
      ]),
      el("div", { class: "inlineLabeled" }, [
        el("div", { class: "miniLabel" }, ["Start"]),
        numberEl("core-startTokens", 0, 20, "core.startTokens", 0),
      ]),
    ]),
    formRowInline("Dev/Test", [
      el("label", { class: "check" }, [
        checkboxEl("core-devMode", false, "core.devMode"),
        el("span", { class: "checkText" }, ["Enable"]),
      ]),
    ]),
  ]);

  const preferences = el("div", { class: "section" }, [
    el("div", { class: "block-title" }, ["Preferences"]),
    formRow(
      "Instrument",
      selectEl(
        "pref-instrument",
        [
          { label: "Guitar", value: "guitar" },
          { label: "Bass", value: "bass" },
          { label: "Ukulele", value: "ukulele" },
          { label: "Banjo", value: "banjo" },
        ],
        "pref.instrument",
        "guitar",
      ),
    ),
    formRow(
      "Instrument Tuning",
      selectEl(
        "pref-tuning",
        [
          { label: "Standard", value: "standard" },
          { label: "Drop D", value: "dropD" },
          { label: "Open G", value: "openG" },
        ],
        "pref.tuning",
        "standard",
      ),
    ),
    el("div", { class: "subTitle" }, ["Notation"]),
    formRow(
      "Notation View",
      selectEl(
        "pref-notationView",
        [
          { label: "Staff + TAB", value: "staffTab" },
          { label: "Staff Only", value: "staff" },
          { label: "TAB Only", value: "tab" },
        ],
        "pref.notationView",
        "staffTab",
      ),
      "Display control only (does not change game rules).",
    ),
    formRow(
      "Notation Pitch",
      selectEl(
        "pref-notationPitch",
        [
          { label: "Written (default)", value: "written" },
          { label: "Concert", value: "concert" },
        ],
        "pref.notationPitch",
        "written",
      ),
      "Written is the standard for printed guitar music; Concert matches sounding pitch.",
    ),
    formRow(
      "Tritone Label",
      selectEl(
        "pref-tritoneStyle",
        [
          { label: "+/o (default)", value: "plusDim" },
          { label: "TT", value: "TT" },
          { label: "#IV / \u266dV", value: "sharpFlat" },
          { label: "+IV / oV", value: "plusDimBoth" },
          { label: "Auto (context)", value: "auto" },
        ],
        "note.tritone",
        "plusDim",
      ),
      "Affects Interval Roman and Roman (Scale Degree) tritone labels.",
    ),

    el("div", { class: "subTitle" }, ["Visual Feedback"]),
    formRow(
      "Vulnerable After Misses",
      numberEl("pref-vulnerableAfterMisses", 1, 10, "pref.vulnerableAfterMisses", 3),
      "After this many consecutive misses, the current prompt becomes visually 'vulnerable'.",
    ),
    el("label", { class: "check" }, [
      checkboxEl("pref-reducedMotion", false, "pref.reducedMotion"),
      el("span", { class: "checkText" }, ["Reduced motion (disable blinking/pulsing)"]),
    ]),

    el("div", { class: "subTitle" }, ["Education Marker Visibility"]),
    el("div", { class: "checkGroup" }, [
      el("div", { class: "checks" }, [
        el("label", { class: "check" }, [
          checkboxEl("pref-edu-show-staff", true, "pref.eduShow.staff"),
          el("span", { class: "checkText" }, ["Staff markers"]),
        ]),
        el("label", { class: "check" }, [
          checkboxEl("pref-edu-show-tab", true, "pref.eduShow.tab"),
          el("span", { class: "checkText" }, ["TAB markers"]),
        ]),
        el("label", { class: "check" }, [
          checkboxEl("pref-edu-show-fret", true, "pref.eduShow.fret"),
          el("span", { class: "checkText" }, ["Fretboard markers"]),
        ]),
      ]),
    ]),
    el("div", { class: "subTitle" }, ["Fretboard Controls"]),
    formRow(
      "Default View",
      selectEl(
        "pref-fretView",
        [
          { label: "5 frets", value: "5" },
          { label: "12 frets", value: "12" },
          { label: "24 frets", value: "24" },
        ],
        "pref.fretView",
        "12",
      ),
    ),
    formRowInline("Default Range", [
      // Canon default range starts at open string / fret 0.
      numberEl("pref-fretMin", 0, 24, "pref.fretMin", 0),
      // 13 total by default: 0..12 inclusive.
      numberEl("pref-fretMax", 0, 24, "pref.fretMax", 12),
    ]),
  ]);

  const help = el("div", { class: "section" }, [
    el("div", { class: "block-title" }, ["Help & Support"]),
    el("div", { class: "helpRow" }, [
      el("button", { class: "btn btn-sm", type: "button", id: "help-faq" }, ["FAQ"]),
      el("button", { class: "btn btn-sm", type: "button", id: "help-tutorials" }, ["Tutorials"]),
    ]),
  ]);

  const left = el("div", { class: "ge-panel ge-left" }, [
    el("div", { class: "section ge-logo" }, [
      el("div", { class: "note", "aria-hidden": "true" }),
      el("div", { class: "brand" }, ["Guitar", el("span", { class: "edu" }, ["Edu"]) ]),
    ]),
    ops,
  ]);

  // --- Center column ---
  const center = el("div", { class: "ge-panel ge-center" }, [
    el("div", { class: "section" }, [
      el("div", { class: "block-title" }, ["Staff + TAB"]),
      el("div", { class: "svgStage", id: "svgStage" }, [
        // Background + overlay are injected/managed by the controller so we can keep hitboxes
        // perfectly aligned to the SVG geometry.
        el("div", { class: "svgHost", id: "staffBgHost", "aria-hidden": "true" }),
        elSvg("svg", { class: "svgOverlay", id: "staffOverlaySvg", "aria-label": "Staff + TAB interaction layer" }),
      ]),
    ]),
    el("div", { class: "section" }, [
      el("div", { class: "noteStrip noteRail", id: "noteStrip" }, [
        el("div", { class: "homeMarker", id: "noteStrip-marker", "aria-hidden": "true" }),
        el("div", { class: "noteRailMount", id: "noteStrip-rail", "aria-label": "Note strip" }, []),
      ]),
    ]),
    el("div", { class: "section col", style: "flex:1;min-height:0" }, [
      el("div", { class: "fretStage", id: "fretStage" }, [
        el("div", { class: "svgHost", id: "fretBgHost", "aria-hidden": "true" }),
        elSvg("svg", { class: "svgOverlay", id: "fretOverlaySvg", "aria-label": "Fretboard interaction layer" }),
      ]),
    ]),
  ]);

  // --- Right column ---
  const right = el("div", { class: "ge-panel ge-right" }, [
    // Current player (upper right)
    el("div", { class: "section", style: "padding:0" }, [
      el("div", { class: "ge-playercard", id: "activePlayer-card" }, [
        el("div", { class: "avatar", "aria-hidden": "true" }),
        el("div", { class: "player-scoreRow" }, [
          el("div", { class: "score", id: "activePlayer-score" }, ["0"]),
          el("div", { class: "mult", id: "activePlayer-mult" }, ["×1"]),
        ]),
        el("div", { class: "player-target", id: "activePlayer-target", title: "Current target note (spelling matters for sharps/flats)" }, [""]),
        // Token / bonus indicators (filled in controller)
        el("div", { class: "tokenRow", id: "activePlayer-tokens", "aria-label": "Tokens" }, []),
        el("div", { class: "player-bottom" }, [
          el("div", { id: "activePlayer-name" }, ["Player 1"]),
          el("div", { class: "badge", id: "activePlayer-timer" }, ["00:00"]),
        ]),
      ]),
    ]),

    // Education Mode replaces the player card with teaching tools.
    el("div", { class: "section", style: "padding:0", id: "eduTools-wrap", hidden: "true" }, [
      el("div", { class: "ge-playercard", id: "eduTools-card" }, [
        el("div", { class: "teachPane" }, [
          el("div", { class: "teachTitle" }, ["Education Tools"]),
          el("div", { class: "teachBody" }, [
            el("div", { class: "teachHint" }, [
              "Input places markers. Eraser removes. Use the note rail (or Note utility palette) to choose what you place.",
            ]),

            el("div", { class: "teachRow" }, [
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduTool", id: "edu-tool-input", checked: "true" }),
                el("span", {}, ["Input"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduTool", id: "edu-tool-erase" }),
                el("span", {}, ["Eraser"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduTool", id: "edu-tool-rest" }),
                el("span", {}, ["Rest"]),
              ]),
            ]),

            el("div", { class: "teachRow" }, [
              el("div", { class: "teachSelected" }, [
                el("div", { class: "k" }, ["Selected:"]),
                el("div", { class: "v", id: "edu-selected" }, ["C"]),
              ]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-clear-all" }, ["Clear All"]),
            ]),

            el("div", { class: "teachSubTitle" }, ["Note Value"]),
            el("div", { class: "teachRow" }, [
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduNoteValue", id: "edu-notevalue-whole", value: "whole" }),
                el("span", {}, ["Whole"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduNoteValue", id: "edu-notevalue-half", value: "half" }),
                el("span", {}, ["Half"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduNoteValue", id: "edu-notevalue-quarter", value: "quarter", checked: "true" }),
                el("span", {}, ["Quarter"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduNoteValue", id: "edu-notevalue-eighth", value: "eighth" }),
                el("span", {}, ["8th"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduNoteValue", id: "edu-notevalue-sixteenth", value: "sixteenth" }),
                el("span", {}, ["16th"]),
              ]),
            ]),
            el("div", { class: "teachHint", style: "margin-top:6px" }, [
              "Education staff/TAB input advances the placement column by the selected note value (16-column measure grid).",
            ]),

            el("div", { class: "teachSubTitle" }, ["Edit Mode"]),
            el("div", { class: "teachRow" }, [
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduEditMode", id: "edu-edit-overwrite", value: "overwrite", checked: "true" }),
                el("span", {}, ["Overwrite"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduEditMode", id: "edu-edit-insert", value: "insert" }),
                el("span", {}, ["Insert"]),
              ]),
              el("label", { class: "teachCheck", style: "margin-left:10px" }, [
                el("input", { type: "checkbox", id: "edu-edit-refinger" }),
                el("span", {}, ["Re-finger on pitch edits"]),
              ]),
            ]),
            el("div", { class: "teachHint", style: "margin-top:6px" }, [
              "Overwrite replaces events at the cursor time (per voice). Insert shifts later events forward by the selected note value.",
            ]),

            el("div", { class: "teachSubTitle" }, ["Cursor"]),
            el("div", { class: "teachRow" }, [
              el("div", { class: "teachSelected" }, [
                el("div", { class: "k" }, ["Pos:"]),
                el("div", { class: "v", id: "edu-cursor" }, ["M1 @ 0"]),
              ]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-cursor-left", title: "Move cursor left" }, ["←"]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-cursor-right", title: "Move cursor right" }, ["→"]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-cursor-prev-measure", title: "Previous measure" }, ["M-"]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-cursor-next-measure", title: "Next measure" }, ["M+"]),
            ]),

            el("div", { class: "teachSubTitle" }, ["Staff/TAB Operational Mode"]),
            el("div", { class: "teachRow" }, [
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduStaffTabMode", id: "edu-stafftabmode-notation", value: "notation", checked: "true" }),
                el("span", {}, ["Notation"]),
              ]),
              el("label", { class: "teachRadio" }, [
                el("input", { type: "radio", name: "eduStaffTabMode", id: "edu-stafftabmode-game", value: "game" }),
                el("span", {}, ["Game"]),
              ]),
            ]),
            el("div", { class: "teachHint", style: "margin-top:6px" }, [
              "Notation mode is time-aware (durations/measures). Game mode is pitch-first. Import targets Notation mode; future conversion can map notation into game prompts.",
            ]),

            el("div", { class: "teachSubTitle" }, ["Preferences Shortcuts"]),
            el("div", { class: "teachRow" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "edu-open-prefs-markers" }, ["Marker Visibility"]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-open-prefs-notation" }, ["Notation & Labels"]),
            ]),

            el("div", { class: "teachSubTitle" }, ["Import / Export"]),
            el("div", { class: "teachHint" }, [
              "MusicXML import targets Notation mode. TAB is preserved when the MusicXML includes per-note string/fret technical data.",
            ]),
            el("div", { class: "teachRow" }, [
              el("label", { class: "teachCheck" }, [
                el("input", { type: "checkbox", id: "edu-import-requireTab" }),
                el("span", {}, ["Require TAB (string+fret)"]),
              ]),
              el("label", { class: "teachCheck" }, [
                el("input", { type: "checkbox", id: "edu-import-strictTiming" }),
                el("span", {}, ["Strict timing (divisions+durations)"]),
              ]),
            ]),
            el("div", { class: "teachRow" }, [
              el("input", { type: "file", id: "edu-import-musicxml-file", accept: ".xml,.musicxml" }),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-import-musicxml-btn" }, ["Import MusicXML"]),
            ]),
            el("textarea", {
              class: "teachTextArea",
              id: "edu-import-musicxml-text",
              placeholder: "Paste MusicXML here (optional) and click Import MusicXML",
              rows: "4",
            }),
            el("div", { class: "teachRow" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "edu-export-internal-btn" }, ["Copy Internal Score JSON"]),
            ]),
            el("div", { class: "teachCard", id: "edu-import-summary" }, [
              el("div", { class: "teachCardTitle" }, ["Import Summary"]),
              el("div", { class: "teachCardBody", id: "edu-import-summary-body" }, ["No import yet."]),
              el("div", { class: "teachCardTitle", style: "margin-top:6px" }, ["Warnings"]),
              el("ul", { class: "teachWarnList", id: "edu-import-warnings" }, []),
            ]),
            el("div", { class: "teachStatus", id: "edu-import-status", role: "status", "aria-live": "polite" }, [""]),

            el("div", { class: "teachSubTitle" }, ["Clear Surface"]),
            el("div", { class: "teachRow" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "edu-clear-staff" }, ["Staff"]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-clear-tab" }, ["TAB"]),
              el("button", { class: "btn btn-sm", type: "button", id: "edu-clear-fret" }, ["Fret"]),
            ]),
          ]),
        ]),
      ]),
    ]),


    el("div", { class: "section", "data-tabs": "right" }, [
      el("div", { class: "block-title" }, ["Utility"]),
      el("div", { class: "tabs compact" }, [
        el("button", { class: "tab active", type: "button", "data-tab": "num" }, ["Num"]),
        el("button", { class: "tab", type: "button", "data-tab": "note" }, ["Note"]),
        el("button", { class: "tab", type: "button", "data-tab": "chord" }, ["Chord"]),
        el("button", { class: "tab", type: "button", "data-tab": "scale" }, ["Scale"]),
      ]),
      el("div", { class: "tabpanes" }, [
        el("div", { class: "pane active", "data-pane": "num" }, [
          el("div", { class: "display", id: "keypad-display" }, ["0"]),
          el("div", { style: "height:10px" }),
          el("div", { class: "keypad", id: "keypad" }),
        ]),

        // NOTE
        el("div", { class: "pane", "data-pane": "note" }, [
          el("div", { class: "utilPane" }, [
            el("div", { class: "utilTitle" }, ["Note Palette (Intent)"]),
            el("div", { class: "utilHint" }, [
              "Select pitch + accidental to set the active note intent. In Education Mode this also sets what will be placed.",
            ]),
            el("div", { class: "utilSubTitle" }, ["Pitch"]),
            el("div", { class: "notePalette", id: "util-note-pitches" }, [
              el("button", { class: "chip", type: "button", "data-pc": "0" }, ["C"]),
              el("button", { class: "chip", type: "button", "data-pc": "2" }, ["D"]),
              el("button", { class: "chip", type: "button", "data-pc": "4" }, ["E"]),
              el("button", { class: "chip", type: "button", "data-pc": "5" }, ["F"]),
              el("button", { class: "chip", type: "button", "data-pc": "7" }, ["G"]),
              el("button", { class: "chip", type: "button", "data-pc": "9" }, ["A"]),
              el("button", { class: "chip", type: "button", "data-pc": "11" }, ["B"]),
            ]),

            el("div", { class: "utilSubTitle" }, ["Accidental / Spelling"]),
            el("div", { class: "accPalette", id: "util-note-acc" }, [
              el("button", { class: "chip active", type: "button", "data-slot": "nat" }, ["♮"]),
              el("button", { class: "chip", type: "button", "data-slot": "shr" }, ["♯"]),
              el("button", { class: "chip", type: "button", "data-slot": "flt" }, ["♭"]),
            ]),

            el("details", { class: "collapse" }, [
              el("summary", { class: "collapseSummary" }, ["Notation/Tab Modifiers (Education-first)"]),
              el("div", { class: "collapseBody" }, [
                el("div", { class: "utilHint" }, [
                  "These are intent modifiers. They may be gated off in Game contexts unless the lesson requires them.",
                ]),
                el("div", { class: "checks" }, [
                  el("label", { class: "check" }, [checkboxEl("util-mod-staccato"), el("span", { class: "checkText" }, ["Staccato"])]),
                  el("label", { class: "check" }, [checkboxEl("util-mod-accent"), el("span", { class: "checkText" }, ["Accent"])]),
                  el("label", { class: "check" }, [checkboxEl("util-mod-pm"), el("span", { class: "checkText" }, ["Palm Mute"])]),
                  el("label", { class: "check" }, [checkboxEl("util-mod-letRing"), el("span", { class: "checkText" }, ["Let Ring"])]),
                ]),
              ]),
            ]),

            // Intervals (nested, canon-compliant)
            el("details", { class: "collapse", id: "util-interval-details" }, [
              el("summary", { class: "collapseSummary" }, ["Intervals"]),
              el("div", { class: "collapseBody" }, [
                el("div", { class: "utilHint" }, ["Select an interval relationship and direction."]),
                el("div", { class: "utilSubTitle" }, ["Direction"]),
                el("div", { class: "accPalette", id: "util-int-dir" }, [
                  el("button", { class: "chip active", type: "button", "data-dir": "either" }, ["Either"]),
                  el("button", { class: "chip", type: "button", "data-dir": "up" }, ["Up"]),
                  el("button", { class: "chip", type: "button", "data-dir": "down" }, ["Down"]),
                ]),
                el("div", { class: "utilSubTitle" }, ["Semitones"]),
                el(
                  "div",
                  { class: "notePalette", id: "util-int-semi" },
                  Array.from({ length: 13 }, (_, i) =>
                    el("button", { class: `chip${i === 0 ? " active" : ""}`, type: "button", "data-semi": String(i) }, [String(i)]),
                  ),
                ),
                el("div", { class: "utilSubTitle" }, ["Selected"]),
                el("div", { class: "utilSelected" }, [
                  el("div", { class: "k" }, ["Interval:"]),
                  el("div", { class: "v", id: "util-int-selected" }, ["0"]),
                ]),
              ]),
            ]),

            el("div", { class: "utilSubTitle" }, ["Selected"]),
            el("div", { class: "utilSelected" }, [
              el("div", { class: "k" }, ["Note:"]),
              el("div", { class: "v", id: "util-note-selected" }, ["C"]),
            ]),
          ]),
        ]),

        // CHORD
        el("div", { class: "pane", "data-pane": "chord" }, [
          el("div", { class: "utilPane" }, [
            el("div", { class: "utilTitle" }, ["Chord Tools (Intent)"]),
            el("div", { class: "utilHint" }, ["Chord selection and chord-tone tools. Arpeggios are nested here."]),
            el("div", { style: "font-size:12px;color:rgba(215,230,255,.8);margin-top:6px" }, [
              "Chord UI placeholder (quality, inversion, extensions, voicing constraints).",
            ]),

            // Arpeggios (nested, canon-compliant)
            el("details", { class: "collapse", id: "util-arp-details" }, [
              el("summary", { class: "collapseSummary" }, ["Arpeggios"]),
              el("div", { class: "collapseBody" }, [
                el("div", { class: "utilHint" }, ["Defines a chord-tone sequence and routing constraints."]),
                el("div", { class: "utilSubTitle" }, ["Tone Set"]),
                el("div", { class: "accPalette", id: "util-arp-tone" }, [
                  el("button", { class: "chip active", type: "button", "data-tone": "triad" }, ["Triad"]),
                  el("button", { class: "chip", type: "button", "data-tone": "7th" }, ["7th"]),
                  el("button", { class: "chip", type: "button", "data-tone": "extended" }, ["Ext"]),
                ]),
                el("div", { class: "utilSubTitle" }, ["Direction"]),
                el("div", { class: "accPalette", id: "util-arp-dir" }, [
                  el("button", { class: "chip active", type: "button", "data-dir": "up" }, ["Up"]),
                  el("button", { class: "chip", type: "button", "data-dir": "down" }, ["Down"]),
                  el("button", { class: "chip", type: "button", "data-dir": "both" }, ["Both"]),
                ]),
                el("div", { class: "utilSubTitle" }, ["Routing"]),
                el("div", { class: "checks" }, [
                  el("label", { class: "check" }, [checkboxEl("util-arp-route-skip", false), el("span", { class: "checkText" }, ["Allow string skipping"]) ]),
                  el("label", { class: "check" }, [checkboxEl("util-arp-route-return", false), el("span", { class: "checkText" }, ["Allow return-crossing"]) ]),
                ]),
                formRow("Max string jump", numberEl("util-arp-route-maxJump", 1, 5, undefined, 2)),
                el("div", { class: "utilSubTitle" }, ["Selected"]),
                el("div", { class: "utilSelected" }, [
                  el("div", { class: "k" }, ["Arp:"]),
                  el("div", { class: "v", id: "util-arp-selected" }, ["Triad / Up"]),
                ]),
              ]),
            ]),
          ]),
        ]),

        // SCALE
        el("div", { class: "pane", "data-pane": "scale" }, [
          el("div", { class: "utilPane" }, [
            el("div", { class: "utilTitle" }, ["Scale Tools (Intent)"]),
            el("div", { class: "utilHint" }, ["Defines scale context and routing constraints for educational patterns."]),

            el("div", { class: "utilSubTitle" }, ["Arpeggios"]),
            el("div", { class: "utilHint" }, ["Shortcut: open Arpeggio tools under the Chord tab."]),
            el("button", { class: "btn btn-sm", type: "button", id: "util-scale-arpShortcut" }, ["Open Arpeggio Tools"]),

            el("div", { class: "utilSubTitle" }, ["Routing (String Traversal)"]),
            el("div", { class: "checks" }, [
              el("label", { class: "check" }, [checkboxEl("util-route-skip", false), el("span", { class: "checkText" }, ["Allow string skipping"])]),
              el("label", { class: "check" }, [checkboxEl("util-route-return", false), el("span", { class: "checkText" }, ["Allow return-crossing"])]),
            ]),
            formRow("Max string jump", numberEl("util-route-maxJump", 1, 5, undefined, 2), "Education patterns may require 2–5."),
          ]),
        ]),
      ]),
    ]),


    el("div", { class: "section", "data-tabs": "miscinfo" }, [
      el("div", { class: "block-title" }, ["Misc. Information"]),
      el("div", { class: "tabs compact" }, [
        el("button", { class: "tab active", type: "button", "data-tab": "ach" }, ["Achievements"]),
        el("button", { class: "tab", type: "button", "data-tab": "chord" }, ["Chords"]),
        el("button", { class: "tab", type: "button", "data-tab": "scales" }, ["Scales"]),
        el("button", { class: "tab", type: "button", "data-tab": "lb" }, ["Leaderboard"]),
        el("button", { class: "tab devHidden", type: "button", "data-tab": "dev", id: "misc-dev-tab" }, ["Dev/Test"]),
      ]),
      el("div", { class: "tabpanes" }, [
        el("div", { class: "pane active", "data-pane": "ach" }, [
          el("div", { class: "miscPane" }, ["Achievements placeholder"]),
        ]),
        el("div", { class: "pane", "data-pane": "chord" }, [
          el("div", { class: "miscPane" }, ["Chord library placeholder"]),
        ]),
        el("div", { class: "pane", "data-pane": "scales" }, [
          el("div", { class: "miscPane" }, ["Scale library placeholder"]),
        ]),
        el("div", { class: "pane", "data-pane": "lb" }, [
          el("div", { class: "tabs compact subTabs", "data-tabs": "lbsub" }, [
            el("button", { class: "tab active", type: "button", "data-tab": "match" }, ["Match"]),
            el("button", { class: "tab", type: "button", "data-tab": "high" }, ["High Scores"]),
          ]),
          el("div", { class: "tabpanes" }, [
            el("div", { class: "pane active", "data-pane": "match" }, [
              el("div", { class: "leader-list", id: "leaderboard" }, []),
            ]),
            el("div", { class: "pane", "data-pane": "high" }, [
              el("div", { class: "leader-list", id: "highscores" }, []),
            ]),
          ]),
        ]),

        el("div", { class: "pane", "data-pane": "dev", id: "misc-dev-pane" }, [
          el("div", { class: "paneForm" }, [
            el("div", { class: "formHint" }, ["Dev/Test tools are for rapid testing only."] ),
            el("div", { class: "opsGrid" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "dev-prevPlayer" }, ["Prev Player"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-nextPlayer" }, ["Next Player"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-endTurn" }, ["End Turn"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-clearBoard" }, ["Clear Board"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceInMatch" }, ["Force In-Match"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceLastChance" }, ["Force Last Chance"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceResults" }, ["Force Results"]),
            ]),

            el("div", { class: "subTitle" }, ["Paint / Erase"]),
            formRowInline("Enable", [checkboxEl("dev-paintEnabled", false)]),
            formRowInline("Player", [
              selectEl(
                "dev-paintPlayer",
                [
                  { label: "P1", value: "0" },
                  { label: "P2", value: "1" },
                  { label: "P3", value: "2" },
                  { label: "P4", value: "3" },
                  { label: "P5", value: "4" },
                ],
              ),
              selectEl(
                "dev-paintMode",
                [
                  { label: "Paint", value: "paint" },
                  { label: "Erase", value: "erase" },
                ],
              ),
            ]),
            formRow(
              "Lane",
              selectEl(
                "dev-paintLane",
                [
                  { label: "Prompt", value: "prompt" },
                  { label: "Natural", value: "nat" },
                  { label: "Sharp", value: "shr" },
                  { label: "Flat", value: "flt" },
                ],
              ),
              "Click the fretboard to paint/erase claims.",
            ),
            el("div", { class: "formHint" }, ["Tip: Click a rail tile to set the current prompt (dev only)."] ),
          ]),
        ]),
      ]),
    ]),
  ]);

  main.append(left, center, right);

  // Footer
  const footer = el("div", { class: "ge-panel ge-footer" }, [
    el("div", { class: "alerts" }, [
      el("div", { class: "alert-pill" }, ["ALERTS"]),
      el("div", { class: "alert-text", id: "alerts-text" }, ["Ready."]),
    ]),
    el("div", { class: "badge" }, ["UI"]),
  ]);

  shell.append(main, footer);

  const settingsOverlay = el("div", { class: "modalOverlay", id: "settingsOverlay", hidden: "true" }, [
    el("div", { class: "modalCard ge-panel" }, [
      el("div", { class: "modalTop" }, [
        el("div", { class: "modalTitle" }, ["Settings"]),
        el("div", { class: "modalTopRight" }, [
          el("div", { class: "versionHotspot", id: "versionHotspot", title: "Click 5 times to unlock Dev/Test" }, ["v"]),
          el("button", { class: "btn btn-sm", type: "button", id: "settings-close" }, ["Close"]),
        ]),
      ]),

      el("div", { class: "tabs", "data-tabs": "settings" }, [
        el("button", { class: "tab active", type: "button", "data-tab": "match" }, ["Match Rules"]),
        el("button", { class: "tab", type: "button", "data-tab": "presentation" }, ["Presentation"]),
        el("button", { class: "tab", type: "button", "data-tab": "tools" }, ["Educational Tools"]),
        el("button", { class: "tab devHidden", type: "button", "data-tab": "dev", id: "settings-dev-tab" }, ["Dev/Test"]),
        el("button", { class: "tab", type: "button", "data-tab": "help" }, ["Help & Reference"]),
      ]),

      el("div", { class: "tabpanes" }, [
        // MATCH RULES
        el("div", { class: "pane active", "data-pane": "match" }, [
          el("div", { class: "paneForm" }, [
            el("div", { class: "subTitle" }, ["Learning Type"]),
            el("div", { class: "tabs compact", id: "ops-modeTabs" }, [
              el("button", { class: "tab active", type: "button", "data-tab": "single" }, ["Single Note"]),
              el("button", { class: "tab", type: "button", "data-tab": "chords" }, ["Chords"]),
              el("button", { class: "tab", type: "button", "data-tab": "scales" }, ["Scales"]),
            ]),

            formRow(
              "Difficulty",
              selectEl(
                "ops-difficulty",
                [
                  { label: "Learning", value: "learning" },
                  { label: "Easy", value: "easy" },
                  { label: "Medium", value: "medium" },
                  { label: "Hard", value: "hard" },
                ],
                "ops.difficulty",
                "medium",
              ),
            ),

            el("div", { class: "subTitle" }, ["Key / Mode"]),
            formRow(
              "Root Note",
              selectEl(
                "core-root",
                [
                  { label: "C", value: "C" },
                  { label: "C#", value: "C#" },
                  { label: "D", value: "D" },
                  { label: "D#", value: "D#" },
                  { label: "E", value: "E" },
                  { label: "F", value: "F" },
                  { label: "F#", value: "F#" },
                  { label: "G", value: "G" },
                  { label: "G#", value: "G#" },
                  { label: "A", value: "A" },
                  { label: "A#", value: "A#" },
                  { label: "B", value: "B" },
                ],
                "core.root",
                "C",
              ),
            ),
            formRow(
              "Mode",
              selectEl(
                "core-modes",
                [
                  { label: "Chromatic", value: "chromatic" },
                  { label: "Pentatonic", value: "pentatonic" },
                  { label: "Blues", value: "blues" },
                  { label: "Ionian (Major)", value: "ionian" },
                  { label: "Dorian", value: "dorian" },
                  { label: "Phrygian", value: "phrygian" },
                  { label: "Lydian", value: "lydian" },
                  { label: "Mixolydian", value: "mixolydian" },
                  { label: "Aeolian (Minor)", value: "aeolian" },
                  { label: "Locrian", value: "locrian" },
                ],
                "core.modes",
                "chromatic",
              ),
            ),

            el("div", { class: "subTitle" }, ["Fretboard Controls"]),
            formRowInline("Fret Range", [
              numberEl("pref-fretMin", 0, 24, "pref.fretMin", 0),
              numberEl("pref-fretMax", 0, 24, "pref.fretMax", 12),
            ]),
            formRow(
              "Fret View",
              selectEl(
                "pref-fretView",
                [
                  { label: "5", value: "5" },
                  { label: "12", value: "12" },
                  { label: "24", value: "24" },
                ],
                "pref.fretView",
                "12",
              ),
              "Sets the maximum playable fret (min/max must be within this).",
            ),

            el("div", { class: "subTitle" }, ["Timing Rules"]),
            formRowInline("Turn / Intermission / Bonus (ms)", [
              numberEl("tim-turnMs", 1000, 600000, "tim.turnMs", 30000),
              numberEl("tim-intermissionMs", 0, 600000, "tim.intermissionMs", 3000),
              numberEl("tim-bonusMs", 0, 600000, "tim.bonusMs", 8000),
            ]),
          ]),
        ]),

        // PRESENTATION
        el("div", { class: "pane", "data-pane": "presentation" }, [
          el("div", { class: "paneForm" }, [
            el("div", { class: "subTitle" }, ["Surface Controls"]),
            checkGroup("In Play", [
              { label: "Fretboard", id: "core-surface-fret", key: "core.surface.fretboard" },
              { label: "Note Rail", id: "core-surface-rail", key: "core.surface.rail" },
              { label: "Staff", id: "core-surface-staff", key: "core.surface.staff" },
              { label: "TAB", id: "core-surface-tab", key: "core.surface.tab" },
            ]),

            el("div", { class: "subTitle" }, ["Display"]),
            formRow(
              "Display",
              selectEl(
                "core-display",
                [
                  { label: "Note Names", value: "names" },
                  { label: "Numbers", value: "numbers" },
                  { label: "Intervals", value: "intervals" },
                  { label: "Roman (Scale Degree)", value: "roman" },
                  { label: "Interval Roman (I/ii/II/iii...)", value: "intervalRoman" },
                ],
                "core.display",
                "names",
              ),
            ),
            formRow(
              "Accidentals",
              selectEl(
                "core-accidentalView",
                [
                  { label: "Both", value: "both" },
                  { label: "Sharps only", value: "sharps" },
                  { label: "Flats only", value: "flats" },
                  { label: "Auto (context)", value: "auto" },
                ],
                "core.accidentalView",
                "both",
              ),
            ),
            formRow(
              "Note Visibility",
              selectEl(
                "core-noteVisibility",
                [
                  { label: "All", value: "all" },
                  { label: "Naturals", value: "natural" },
                  { label: "Enharmonics", value: "enharmonic" },
                ],
                "core.noteVisibility",
                "all",
              ),
            ),

            el("div", { class: "subTitle" }, ["Notation"]),
            formRow(
              "Notation View",
              selectEl(
                "pref-notationView",
                [
                  { label: "Staff + TAB", value: "staffTab" },
                  { label: "Staff Only", value: "staff" },
                  { label: "TAB Only", value: "tab" },
                ],
                "pref.notationView",
                "staffTab",
              ),
            ),
            formRow(
              "Notation Pitch",
              selectEl(
                "pref-notationPitch",
                [
                  { label: "Written (default)", value: "written" },
                  { label: "Concert", value: "concert" },
                ],
                "pref.notationPitch",
                "written",
              ),
            ),

            el("div", { class: "subTitle" }, ["Motion"]),
            formRowInline("Reduced Motion", [checkboxEl("pref-reducedMotion", false, "pref.reducedMotion")]),
          ]),
        ]),

        // EDUCATIONAL TOOLS
        el("div", { class: "pane", "data-pane": "tools" }, [
          el("div", { class: "paneForm" }, [
            el("div", { class: "formHint" }, ["Educational tools and overlays will be expanded. Current utilities remain available in-game."]),
            el("div", { class: "formHint" }, ["(Chord/Scale tools are placeholders pending checklist items.)"]),
          ]),
        ]),

        // DEV/TEST (gated)
        el("div", { class: "pane devHidden", "data-pane": "dev", id: "settings-dev-pane" }, [
          el("div", { class: "paneForm" }, [
            el("div", { class: "formHint" }, ["Dev/Test tools are hidden by default. Unlock via version hotspot."] ),
            formRowInline("Dev/Test", [
              el("label", { class: "check" }, [
                checkboxEl("core-devMode", false, "core.devMode"),
                el("span", { class: "checkText" }, ["Enable"]),
              ]),
            ]),
            el("div", { class: "opsGrid" }, [
              el("button", { class: "btn btn-sm", type: "button", id: "dev-prevPlayer" }, ["Prev Player"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-nextPlayer" }, ["Next Player"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-endTurn" }, ["End Turn"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-clearBoard" }, ["Clear Board"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceInMatch" }, ["Force In-Match"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceLastChance" }, ["Force Last Chance"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceResults" }, ["Force Results"]),
              el("button", { class: "btn btn-sm", type: "button", id: "dev-forceBonus" }, ["Force Bonus"]),
            ]),

            el("div", { class: "subTitle" }, ["Paint / Erase"]),
            formRowInline("Enable", [checkboxEl("dev-paintEnabled", false)]),
            formRowInline("Player", [
              selectEl(
                "dev-paintPlayer",
                [
                  { label: "P1", value: "0" },
                  { label: "P2", value: "1" },
                  { label: "P3", value: "2" },
                  { label: "P4", value: "3" },
                  { label: "P5", value: "4" },
                ],
              ),
              selectEl(
                "dev-paintMode",
                [
                  { label: "Paint", value: "paint" },
                  { label: "Erase", value: "erase" },
                ],
              ),
            ]),
            formRow(
              "Lane",
              selectEl(
                "dev-paintLane",
                [
                  { label: "Prompt", value: "prompt" },
                  { label: "Natural", value: "nat" },
                  { label: "Sharp", value: "shr" },
                  { label: "Flat", value: "flt" },
                ],
              ),
            ),
          ]),
        ]),

        // HELP
        el("div", { class: "pane", "data-pane": "help" }, [
          el("div", { class: "paneForm" }, [
            el("div", { class: "formHint" }, ["Help/Reference content will be populated from canon docs."]),
          ]),
        ]),
      ]),
    ]),
  ]);

  shell.append(settingsOverlay);

  // --- Splash overlay (Single / Multiplayer + Settings + Account) ---
  const splash = el("div", { class: "splashOverlay show", id: "splash" }, [
    el("div", { class: "splashCard ge-panel" }, [
      el("div", { class: "splashTop" }, [
        el("div", { class: "splashTitle" }, [
          el("div", { class: "splashBrand" }, ["GuitarEdu"]),
          el("div", { class: "splashSub" }, ["Select a session to begin"]),
        ]),
        el("div", { class: "splashActions" }, [
          el("button", { class: "btn btn-sm", type: "button", id: "splash-settings" }, ["Settings"]),
          el("button", { class: "btn btn-sm", type: "button", id: "splash-account" }, ["Account"]),
        ]),
      ]),
      el("div", { class: "splashModes" }, [
        el("button", { class: "splashBtn", type: "button", id: "splash-edu", "data-session": "edu" }, [
          el("div", { class: "splashBtnTitle" }, ["Education Mode"]),
          el("div", { class: "splashBtnHint" }, ["Instructor / classroom (no scoring)"]),
        ]),
        el("button", { class: "splashBtn", type: "button", id: "splash-single", "data-session": "single" }, [
          el("div", { class: "splashBtnTitle" }, ["Single Player"]),
          el("div", { class: "splashBtnHint" }, ["Race to the finish (no turns)"]),
        ]),
        el("button", { class: "splashBtn", type: "button", id: "splash-multi", "data-session": "multi" }, [
          el("div", { class: "splashBtnTitle" }, ["Multiplayer"]),
          el("div", { class: "splashBtnHint" }, ["Turn-based (bonus only when available)"]),
        ]),
      ]),
      // Multiplayer player count (affects active players/leaderboard only; gameplay rules unchanged).
      el("div", { class: "splashPlayerCount" }, [
        el("div", { class: "splashPlayerCountLabel" }, ["Players"]),
        selectEl(
          "splash-playerCount",
          Array.from({ length: Math.max(0, PLAYER_COUNT_MULTI_MAX - 1) }, (_, i) => {
            const n = i + 2;
            return { label: String(n), value: String(n) };
          }),
          undefined,
          "2",
        ),
        el("div", { class: "splashPlayerCountHint" }, ["Used for Multiplayer."]),
      ]),
      el("div", { class: "splashFooter" }, [
        "Note: Gameplay menu items are being wired in next. Settings/Account will be connected later.",
      ]),
    ]),
  ]);

  // Splash events
  splash.querySelectorAll<HTMLButtonElement>("[data-session]").forEach((b) => {
    b.addEventListener("click", () => {
      const session = (b.dataset.session ?? "single") as "single" | "multi" | "edu";
      const pc = splash.querySelector<HTMLSelectElement>("#splash-playerCount");
      const playerCount = pc ? Number(pc.value || 2) : 2;
      window.dispatchEvent(new CustomEvent("gedu:splashSelect", { detail: { session, playerCount } }));
    });
  });
  const settingsBtn = splash.querySelector<HTMLButtonElement>("#splash-settings");
  settingsBtn?.addEventListener("click", () => window.dispatchEvent(new CustomEvent("gedu:splashSettings")));
  const accountBtn = splash.querySelector<HTMLButtonElement>("#splash-account");
  accountBtn?.addEventListener("click", () => window.dispatchEvent(new CustomEvent("gedu:splashAccount")));

  shell.append(splash);

  target.replaceChildren(shell);

  wireTabs(shell);
  wireInlineTabs(shell, "#ops-modeTabs");
  buildKeypad();
}
