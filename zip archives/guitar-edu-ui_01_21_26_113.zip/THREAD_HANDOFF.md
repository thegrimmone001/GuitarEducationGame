# Thread Handoff

This file exists to reduce drift when a conversation thread is restarted.

## Active build

- Active package: `guitar-edu-ui_01_21_26_112.zip`

## Canon locks reinforced in this build

- Display Format dropdown must include **Numbers** as a distinct option (alongside Note Names, Steps, Intervals, Roman, Roman Interval).
  - **Numbers** = degree-style labels: `1, ♭2, 2, ♭3, 3, 4, ♯4/♭5, 5, ♭6, 6, ♭7, 7`.
  - **Steps** = total semitone distance from the root: `0–11`.

## New-thread starter prompt (copy/paste)

Project: Guitar Learning Game / guitar-edu-ui
Goal: Get the main menus (splash + panels) fully caught up and canon-compliant, then replace Surface Layers with Surface Controls exactly as the docs require.

Authoritative sources:

Guitar_Learning_Game_Authoritative_System_Manual_v1_0_EXHAUSTIVE.docx

conversations.json + the 16-part upload archives (treat as authoritative history)

Any DOCS/* mapping/spec/decisions files inside the zips

Hard constraints (no exceptions):

No assumptions. No new systems. No invented panels/tools. Only implement what the uploaded docs define.

No crop functions. Staff + TAB are always visible.

Education button goes straight to main UI. Education is not a match. No match settings flow for Education.

Education controls are not settings and will live in the panel that replaces the player score card (upper right).

Token Cap / Starting Tokens are multiplayer match settings only, not main menu settings.

Import/Export stays non-main-menu.

Scope A — Finish splash + panels structurally (menus-first):

Splash must have: Single Player, Multiplayer, Education, Settings, FAQ/Help + separate Account area.

Single Player submenu: Free Play | Challenge (Challenge naming is canon).

Multiplayer flow remains distinct from single player and uses match settings appropriately.

Settings and FAQ/Help panels must be real and wired, but only for items explicitly listed in docs.

Remove any non-canon “test panel” or debugging UI from Settings/menu surfaces.

Display Format dropdown must include:

Note Names

Numbers (required)

Steps

Intervals

Roman (traditional, unadulterated)

Roman Interval (Roman Numeral Interval System)
Implement mappings exactly per docs / conversations.json.

Scope B — Replace Surface Layers with Surface Controls (docs-required):

Remove legacy Surface Layers terminology and settings (view/asked/answered).

Implement Surface Controls: Prompt / Mark / Display / SAM + Cardinality exactly as specified in the docs.

Ensure staff/tab/fretboard/note rail behavior keys match Surface Controls and do not hide surfaces.

If Surface Presets A–J are referenced but the mapping isn’t found in uploaded docs, do not guess—leave presets non-functional and log what definition is missing with file references.

Deliverables:

Updated code ZIP with correct folder structure and build naming.

A short “Canon Compliance Notes” section listing what changed and which doc sections/files justified it.

No extra features beyond the two scopes above.

Quick continuity recap (so the next thread starts aligned)

Education ≠ Challenge: distinct behavior, controls, and flow.

No crop; staff/tab always present.

Remove legacy Surface Layers; move to Surface Controls (Prompt/Mark/Display/SAM + Cardinality).

Display Format must include Numbers (now explicitly required), alongside Steps, Roman, Roman Interval, etc.

Import/Export stays out of main menu.

If you upload the four required items (base ZIP, manual DOCX, conversations.json, the 16-part set), the next thread can proceed deterministically without filling gaps by inference.
