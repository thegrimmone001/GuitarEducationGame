# Decisions Log

A running log of architectural decisions that impact future development.

## 2026-01-10 — Surface Matrix replaces View Layout
- Decision: replace the older “View Layout” idea with a **Surface Input Matrix** that deterministically defines, per UI mode, which surfaces are:
  - required for a valid answer
  - eligible to accept input
  - permitted to show placed marks
- Rationale: reduces ambiguity, prevents regressions, and keeps rules enforceable at the controller level.

## 2026-01-10 — Surface Layers are visual-only
- Decision: add **Surface Layers** toggles as visual filters only.
- Rule: layer toggles never remove a surface; they only hide that surface’s rendered content.
- Rationale: matches the requirement that “not visible” does not mean the section disappears.

## 2026-01-10 — Surface Layer terminology
- Decision: rename the user-facing layer names to **Display / Prompt / Marks** (was View / Asked / Answered).
- Rule: internal preference keys remain `pref.layers.view|asked|answered` for backward compatibility; only labels and documentation change.
- Rationale: the new names are surface-agnostic and describe intent across Rail, Fretboard, Staff, and TAB.

## 2026-01-10 — Staff+TAB are treated as a rendered template
- Decision: treat the Staff+TAB background as a **static rendered template**, not a dynamically constructed SVG surface.
- Rule: overlay geometry (measures/columns, staff core lines, tab bands) must be derivable without assuming the SVG uses exactly 5 staff lines or exposes barline segments.
- Implementation note: normalize STAFF to the **middle 5 lines** (core staff) and derive measure spans from repeated long horizontal segments.
- Rationale: keeps the hit-grid stable today and makes it safe to swap the background to a raster image later without breaking interaction.

## 2026-01-10 — README is the canonical repo entrypoint
- Decision: restore a root **`README.md`** and treat it as the canonical entrypoint for onboarding and thread alignment.
- Rule: when starting work (especially in a new chat thread), follow the **Thread Boot Protocol** defined in `README.md`.
- Rationale: reduces drift across sessions and keeps implementation aligned with the project’s written specification.

## 2026-01-10 — Intermission is a first-class phase overlay
- Decision: represent multiplayer intermission as a dedicated **phase overlay** instead of relying on transient alerts.
- Rule: the overlay is shown only when `phase === INTERMISSION` and `PlayType === MULTI`, and it may be dismissed early via tap/click to start the next turn.
- Rationale: makes the turn break explicit to players on smartboards and prevents “instant next turn” confusion.
