import {
  Action,
  DevSettings,
  Difficulty,
  GameSettings,
  GameState,
  MatchType,
  ModeId,
  Phase,
  PlayType,
  PlayerProfile,
  SlotType,
  VariantId,
} from "../shell/types";
import { reducer } from "../shell/engineReducer";
import { createChromaticRail, RailConfig } from "../shell/rail";
import { fromVariantId, IS_BLACK, pitchClassAt, toVariantId, variantLabel } from "../shell/music";
import { describePromptProfileId } from "../shell/promptProfiles";
import { cellCenter, computeLayoutFromSvg, hitTestCell, mapLayoutToNeck, parseSvgNeckBounds, parseSvgViewBox, FretboardLayout } from "../shell/fretboardLayout";
import { attachBoardPointerHandlers } from "../shell/uiAdapter";
import { renderOverlay } from "../shell/fretboardOverlay";
import { attachStaffTabPointerHandlers, createStaffTabOverlayState, parseStaffTabLayout, renderStaffTabOverlay, StaffTabLayout, StaffTabHit } from "../shell/staffTabOverlay";
import { getLeaderboard, recordScore } from "../shell/storage";

type UiRoot = HTMLElement | Document;

// ----------------------------
// Helpers
// ----------------------------

const PLAYER_COUNT_MULTI = 5;

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

function formatMs(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${pad2(m)}:${pad2(r)}`;
}

function escapeHtml(s: string): string {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function pcFromUiNoteName(name: string): number {
  const n = String(name || "C").trim().toUpperCase();
  const map: Record<string, number> = {
    C: 0,
    "C#": 1,
    DB: 1,
    D: 2,
    "D#": 3,
    EB: 3,
    E: 4,
    F: 5,
    "F#": 6,
    GB: 6,
    G: 7,
    "G#": 8,
    AB: 8,
    A: 9,
    "A#": 10,
    BB: 10,
    B: 11,
  };
  return map[n] ?? 0;
}

function intervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "P1",
    1: "m2",
    2: "M2",
    3: "m3",
    4: "M3",
    5: "P4",
    6: "TT",
    7: "P5",
    8: "m6",
    9: "M6",
    10: "m7",
    11: "M7",
  };
  return names[s] ?? `+${s}`;
}

function romanIntervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "I",
    1: "♭II",
    2: "II",
    3: "♭III",
    4: "III",
    5: "IV",
    6: "♭V",
    7: "V",
    8: "♭VI",
    9: "VI",
    10: "♭VII",
    11: "VII",
  };
  return names[s] ?? `+${s}`;
}

type TritoneStyle = "plusDim" | "TT" | "sharp4" | "flat5" | "auto";

function inferPreferSharp4(settings: GameSettings): boolean {
  const pid = (settings.promptProfileId ?? "").toLowerCase();
  if (pid.includes("lydian")) return true;
  if (pid.includes("locrian")) return false;
  if (pid.includes(":flats") || pid.includes("b")) return false;
  return true;
}

function intervalRomanName(semitones: number, style: TritoneStyle, preferSharp4: boolean): string {
  const s = ((semitones % 12) + 12) % 12;
  switch (s) {
    case 0: return "I";
    case 1: return "ii";
    case 2: return "II";
    case 3: return "iii";
    case 4: return "III";
    case 5: return "IV";
    case 6: {
      if (style === "TT") return "TT";
      if (style === "sharp4") return "IV\u266f";
      if (style === "flat5") return "V\u266d";
      if (style === "auto") return preferSharp4 ? "IV\u266f" : "V\u266d";
      return preferSharp4 ? "+IV" : "oV";
    }
    case 7: return "V";
    case 8: return "vi";
    case 9: return "VI";
    case 10: return "vii";
    case 11: return "VII";
    default: return `+${s}`;
  }
}

function labelForVariant(vid: VariantId, displayMode: string, rootPc: number, settings: GameSettings): string {
  if (displayMode === "intervals") {
    const pc = fromVariantId(vid).pitchClass;
    return intervalName(pc - rootPc);
  }
  if (displayMode === "romanIntervals") {
    const pc = fromVariantId(vid).pitchClass;
    return romanIntervalName(pc - rootPc);
  }
  if (displayMode === "intervalRoman") {
    const pc = fromVariantId(vid).pitchClass;
    const style = (((settings as any).tritoneStyle ?? "plusDim") as TritoneStyle);
    const preferSharp4 = inferPreferSharp4(settings);
    return intervalRomanName(pc - rootPc, style, preferSharp4);
  }
  return variantLabel(vid);
}

function buildPlayers(count: number): PlayerProfile[] {
  const c = clamp(count, 1, 16);
  const out: PlayerProfile[] = [];
  for (let i = 0; i < c; i++) out.push({ id: i, name: `P${i + 1}`, colorId: i, patternId: i });
  return out;
}

function defaultSettings(): GameSettings {
  return {
    modeId: ModeId.FRETBOARD,
    playType: PlayType.MULTI,
    matchType: MatchType.BLACKOUT,
    difficulty: Difficulty.MEDIUM,
    fixedRoundsTotal: 3,
    timers: { turnMs: 15_000, intermissionMs: 900 },
    domain: { fretCount: 25, minFret: 0, maxFret: 24, enabledStrings: [true, true, true, true, true, true] },
    feedback: {
      samEnabled: true,
      samDurationMs: 900,
      samRevealMode: "single",
      claimLabelMode: "off",
      claimLabelDurationMs: 900,
      samIncludeLabel: true,
    },
    steal: {
      tokenCap: 10,
      globalStealOnExhausted: true,
      enharmonicOppositeStealBonus: 5,
      breakConnectMaxTierBonus: 25,
    },
    accessibility: { colorBlindMode: true },
    dev: { enabled: false, paintEnabled: false, paintPlayerIndex: 0, paintLane: "prompt", paintMode: "paint" },
    notation: { view: "staffTab", pitch: "written" },
    promptProfileId: "chromatic",
  };
}

function modeToPromptProfileId(root: string, mode: string): string {
  const m = String(mode || "chromatic").toLowerCase();
  const r = String(root || "C").trim();
  if (m === "chromatic") return "chromatic";
  if (m === "pentatonic") return `scale:${r}:pentatonic:sharps`;
  if (m === "blues") return `scale:${r}:blues:sharps`;
  if (["ionian", "dorian", "phrygian", "lydian", "mixolydian", "aeolian", "locrian"].includes(m)) {
    return `scale:${r}:${m}:sharps`;
  }
  // Fallback
  return "chromatic";
}

function difficultyFromUi(v: string): Difficulty {
  const s = String(v || "medium").toLowerCase();
  if (s === "learning") return Difficulty.LEARNING;
  if (s === "easy") return Difficulty.EASY;
  if (s === "hard") return Difficulty.HARD;
  return Difficulty.MEDIUM;
}

function readEnabledStrings(root: UiRoot): boolean[] {
  const sel = (root as Document).querySelector<HTMLSelectElement>("#pref-strings");
  const enabled = [false, false, false, false, false, false];
  if (!sel) return [true, true, true, true, true, true];
  const values = Array.from(sel.selectedOptions).map((o) => o.value);
  if (values.length === 0) return [true, true, true, true, true, true];

  // UI values are string numbers "1".."6" (1st string = high E). Engine indices are 0..5 (0 = high E).
  for (const v of values) {
    const n = Number(v);
    if (!Number.isFinite(n)) continue;
    const engineIdx = clamp(n, 1, 6) - 1;
    if (engineIdx >= 0 && engineIdx < 6) enabled[engineIdx] = true;
  }
  return enabled;
}

function readInt(root: UiRoot, selector: string, fallback: number): number {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  const n = Number(el?.value);
  return Number.isFinite(n) ? n : fallback;
}

function readStr(root: UiRoot, selector: string, fallback: string): string {
  const el = (root as Document).querySelector<HTMLInputElement | HTMLSelectElement>(selector);
  return (el?.value ?? fallback) as string;
}

function readBool(root: UiRoot, selector: string, fallback = false): boolean {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  if (!el) return fallback;
  return !!el.checked;
}

function buildSettingsFromUi(root: UiRoot, session: "single" | "multi" | "edu"): GameSettings {
  const d = defaultSettings();

  const playType = session === "multi" ? PlayType.MULTI : PlayType.SINGLE;
  const difficulty = difficultyFromUi(readStr(root, "#ops-difficulty", "medium"));
  const uiMode = readStr(root, "#core-gameMode", "m4");
  const rootNote = readStr(root, "#core-root", "C");
  const mode = readStr(root, "#core-modes", "chromatic");
  const promptProfileId = modeToPromptProfileId(rootNote, mode);

  const displayMode = readStr(root, "#core-display", "names");
  const tritoneStyle = readStr(root, "#pref-tritoneStyle", "plusDim");
  const noteVisibilityUi = readStr(root, "#core-noteVisibility", "all");
  const accidentalViewUi = readStr(root, "#core-accidentalView", "both");
  let noteVisibility: "all" | "natural" | "enharmonic" =
    noteVisibilityUi === "all" ? "all" : noteVisibilityUi === "enharmonics" ? "enharmonic" : "natural";
  // Learning difficulty assumes the player knows nothing: allow all spellings by default.
  if (difficulty === Difficulty.LEARNING) noteVisibility = "all";

  // How to render accidentals on the note rail (and other name-based displays).
  // Default is "both" (stack sharp and flat). "auto" can later be used for key/mode recipes.
  const accidentalView = (difficulty === Difficulty.LEARNING ? "both" : accidentalViewUi) as any;

  // Notation preferences (UI only). Default mirrors printed guitar notation.
  const notationView = readStr(root, "#pref-notationView", "staffTab") as any;
  const notationPitch = readStr(root, "#pref-notationPitch", "written") as any;

  // Surface layer visibility (visual only). These never remove a surface; they only hide content.
  // Display = passive layer (labels / reference). Prompt = prompt-highlight layer.
  // Marks = player-placed mark visibility.
  const layerView = readBool(root, "#pref-layerView", true);
  const layerAsked = readBool(root, "#pref-layerAsked", true);
  const layerAnswered = readBool(root, "#pref-layerAnswered", true);

  const samModeUi = readStr(root, "#core-sam", "single");
  const samRevealMode = samModeUi === "multiple" ? "all" : "single";

  const viewFrets = clamp(readInt(root, "#pref-fretView", 12), 1, 24);
  // Fret count represents playable columns including open string (fret 0).
  const fretCount = viewFrets + 1;

  const minFretRaw = clamp(readInt(root, "#pref-fretMin", 1), 0, viewFrets);
  const maxFretRaw = clamp(readInt(root, "#pref-fretMax", 12), minFretRaw, viewFrets);
  const minFret = minFretRaw;
  const maxFret = maxFretRaw;
  const enabledStrings = readEnabledStrings(root);

  // Token / Dev settings (Main Menu Settings)
  const tokenCap = clamp(readInt(root, "#core-tokenCap", 10), 0, 20);
  const startTokens = clamp(readInt(root, "#core-startTokens", 0), 0, tokenCap);
  const devEnabled = readBool(root, "#core-devMode", false);

  // Dev/Test pane settings (only takes effect when dev is enabled)
  const devPaintEnabled = readBool(root, "#dev-paintEnabled", false);
  const devPaintPlayerIndex = clamp(Number(readStr(root, "#dev-paintPlayer", "0")), 0, 4);
  const devPaintLane = readStr(root, "#dev-paintLane", "prompt") as any;
  const devPaintMode = readStr(root, "#dev-paintMode", "paint") as any;

  const s: GameSettings = {
    ...d,
    modeId: ModeId.FRETBOARD,
    playType,
    matchType: MatchType.BLACKOUT,
    difficulty,
    promptProfileId,
    domain: { ...d.domain, fretCount, minFret, maxFret, enabledStrings },
    feedback: { ...d.feedback, samRevealMode },
    steal: { ...d.steal, tokenCap },
    dev: {
      ...d.dev,
      enabled: devEnabled,
      paintEnabled: devPaintEnabled,
      paintPlayerIndex: devPaintPlayerIndex,
      paintLane: devPaintLane,
      paintMode: devPaintMode,
    },
    notation: {
      view: (notationView === "staff" || notationView === "tab" ? notationView : "staffTab"),
      pitch: (notationPitch === "concert" ? "concert" : "written"),
    },
  };

  // Non-typed extensions used by promptProfiles (kept compatible with the shell version).
  (s as any).noteVisibility = noteVisibility;
  (s as any).accidentalView = accidentalView;
  (s as any).displayMode = displayMode;
  (s as any).tritoneStyle = tritoneStyle;
  (s as any).rootNote = rootNote;
  (s as any).uiMode = uiMode;
  (s as any).startTokens = startTokens;
  (s as any).surfaceLayers = { view: layerView, asked: layerAsked, answered: layerAnswered };
  return s;
}

// ----------------------------
// Controller
// ----------------------------

export function initGameController(root: UiRoot): void {
  const doc = root as Document;

  const splash = doc.querySelector<HTMLElement>("#splash");
  const intermissionOverlay = doc.querySelector<HTMLElement>("#intermissionOverlay");
  const intermissionNext = doc.querySelector<HTMLElement>("#intermission-next");
  const intermissionTimer = doc.querySelector<HTMLElement>("#intermission-timer");
  const intermissionStart = doc.querySelector<HTMLButtonElement>("#intermission-start");
  const promptText = doc.querySelector<HTMLElement>("#promptText");
  const alertsText = doc.querySelector<HTMLElement>("#alerts-text");

  const activeName = doc.querySelector<HTMLElement>("#activePlayer-name");
  const activeScore = doc.querySelector<HTMLElement>("#activePlayer-score");
  const activeMult = doc.querySelector<HTMLElement>("#activePlayer-mult");
  const activeTarget = doc.querySelector<HTMLElement>("#activePlayer-target");
  const activeTimer = doc.querySelector<HTMLElement>("#activePlayer-timer");
  const activeTokens = doc.querySelector<HTMLElement>("#activePlayer-tokens");
  const leaderboard = doc.querySelector<HTMLElement>("#leaderboard");
  const highscores = doc.querySelector<HTMLElement>("#highscores");

  const devTab = doc.querySelector<HTMLElement>("#misc-dev-tab");
  const devPane = doc.querySelector<HTMLElement>("#misc-dev-pane");

  const fretStage = doc.querySelector<HTMLElement>("#fretStage");
  const fretBgHost = doc.querySelector<HTMLElement>("#fretBgHost");
  const fretOverlaySvg = doc.querySelector<SVGSVGElement>("#fretOverlaySvg");
  const staffBgHost = doc.querySelector<HTMLElement>("#staffBgHost");
  const staffOverlaySvg = doc.querySelector<SVGSVGElement>("#staffOverlaySvg");
  const noteStripRail = doc.querySelector<HTMLElement>("#noteStrip-rail");

  if (!fretStage || !fretBgHost || !fretOverlaySvg) throw new Error("Fretboard surface not found");
  const fretStageEl: HTMLElement = fretStage;
  const fretBgHostEl: HTMLElement = fretBgHost;
  const fretOverlaySvgEl: SVGSVGElement = fretOverlaySvg;
  const staffBgHostEl: HTMLElement | null = staffBgHost;
  const staffOverlaySvgEl: SVGSVGElement | null = staffOverlaySvg;

  // Rail (shell feature)
  const rail = createChromaticRail();
  if (noteStripRail) {
    noteStripRail.innerHTML = "";
    noteStripRail.appendChild(rail.el);
  }

  let session: "single" | "multi" | "edu" = "single";

  // Education mode (instructor) state
  let eduTool: "input" | "erase" = "input";
  // VariantId convention in this codebase: 0=C natural, 1=C# ...; spelling is derived.
  let eduSelectedVariantId: number = 0;
  const eduFretMarks = new Map<number, number>(); // cellIndex -> variantId
  let eduShowStaff = true;
  let eduShowTab = true;
  let eduShowFret = true;
  let eduFretHandlersInstalled = false;
  let settings: GameSettings = buildSettingsFromUi(doc, session);
  let players: PlayerProfile[] = buildPlayers(session === "single" ? 1 : PLAYER_COUNT_MULTI);
  let state: GameState | null = null;

  let paused = false;
  let turnEndsAt = 0;
  let timerHandle: number | null = null;
  let intermissionHandle: number | null = null;
  let intermissionTickHandle: number | null = null;
  let intermissionEndsAt = 0;
  let samHandle: number | null = null;

  // Match timing (used for persistent high score entries)
  let matchStartedAtMs = 0;
  let pausedAtMs = 0;
  let pausedAccumMs = 0;
  let matchRecorded = false;
  // TAB input state (instant): select string + fret (either order), claim immediately.
  let tabSelectedString: number | null = null;
  let tabSelectedFret: number | null = null;

  let tabSelectedCol: number | null = null;

  // Composite answer progress (controller-owned; cleared on prompt/turn changes)
  let pendingStaffPick: { col: number; yIndex: number } | null = null;
  let pendingTabPick: { col: number; stringIndex: number; fret: number; action: "TAP_CELL" | "STEAL_CELL" } | null = null;
  let pendingFretPick:
    | { action: "TAP_CELL" | "STEAL_CELL"; stringIndex: number; fretIndex: number }
    | null = null;


  let fretLayout: FretboardLayout | null = null;
  let staffLayout: StaffTabLayout | null = null;
  const staffOverlayState = createStaffTabOverlayState();
  let activePulse: {
    playerId: number;
    variantId: number;
    durationMs: number;
    ghost: any | null;
    ghosts?: any[];
    scoreDelta: number;
    includeLabel?: boolean;
  } | null = null;
  let pulseHandle: number | null = null;

  function setAlert(msg: string | null): void {
    if (!alertsText) return;
    const phase = state?.phase ?? "TITLE";
    alertsText.textContent = `${phase}: ${msg ?? ""}`;
  }

  function clearTimers(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    if (intermissionHandle !== null) window.clearTimeout(intermissionHandle);
    if (intermissionTickHandle !== null) window.clearInterval(intermissionTickHandle);
    if (samHandle !== null) window.clearTimeout(samHandle);
    timerHandle = null;
    intermissionHandle = null;
    intermissionTickHandle = null;
    intermissionEndsAt = 0;
    samHandle = null;
  }

  function stopTurnTimer(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    timerHandle = null;
    turnEndsAt = 0;
    if (activeTimer) activeTimer.textContent = "00:00";
  }

  function startTurnTimer(): void {
    stopTurnTimer();
    if (!state) return;
    applyUiModeVisibility();
    const ms = state.settings.timers.turnMs;
    turnEndsAt = Date.now() + ms;
    if (activeTimer) activeTimer.textContent = formatMs(ms);
    timerHandle = window.setInterval(() => {
      if (!state || paused) return;
      const left = turnEndsAt - Date.now();
      if (activeTimer) activeTimer.textContent = formatMs(left);
      if (left <= 0) {
        stopTurnTimer();
        dispatch({ type: "TIMEOUT" } as Action);
      }
    }, 100);
  }

  function hideIntermissionOverlay(): void {
    if (intermissionOverlay) intermissionOverlay.classList.remove("show");
    if (intermissionTickHandle !== null) window.clearInterval(intermissionTickHandle);
    intermissionTickHandle = null;
    intermissionEndsAt = 0;
  }

  function showIntermissionOverlay(nextPlayerId?: number): void {
    if (!state) return;
    if (state.settings.playType !== PlayType.MULTI) return;
    if (state.phase !== "INTERMISSION") return;

    const nextId = nextPlayerId ?? state.players[state.currentPlayer]?.profile.id ?? 0;
    const nextProfile = state.players.find((p) => p.profile.id === nextId)?.profile;
    const name = nextProfile?.name ?? `P${Number(nextId) + 1}`;

    if (intermissionNext) intermissionNext.textContent = `Next: ${name}`;

    const ms = Math.max(0, state.settings.timers.intermissionMs ?? 0);
    intermissionEndsAt = Date.now() + ms;
    if (intermissionTimer) intermissionTimer.textContent = formatMs(ms);

    if (intermissionOverlay) intermissionOverlay.classList.add("show");

    if (intermissionTickHandle !== null) window.clearInterval(intermissionTickHandle);
    intermissionTickHandle = window.setInterval(() => {
      if (!state || paused) return;
      const left = Math.max(0, intermissionEndsAt - Date.now());
      if (intermissionTimer) intermissionTimer.textContent = formatMs(left);
      if (left <= 0) {
        // The START_TURN dispatch is driven by intermissionHandle; this just keeps UI tidy.
        if (intermissionTickHandle !== null) window.clearInterval(intermissionTickHandle);
        intermissionTickHandle = null;
      }
    }, 100);
  }

  function startTurnEarly(reason: "tap" | "button" | "auto" = "tap"): void {
    if (!state) return;
    if (paused) return;
    if (state.phase !== "INTERMISSION") return;
    if (state.settings.playType !== PlayType.MULTI) return;

    if (intermissionHandle !== null) window.clearTimeout(intermissionHandle);
    intermissionHandle = null;
    hideIntermissionOverlay();
    setAlert(reason === "auto" ? "Starting turn" : "Starting early");
    dispatch({ type: "START_TURN" } as Action);
  }

  function hideSplash(): void {
    splash?.classList.remove("show");
  }

  function showSplash(): void {
    splash?.classList.add("show");
  }

  function notePauseChange(isNowPaused: boolean): void {
    const now = Date.now();
    if (isNowPaused) {
      if (pausedAtMs === 0) pausedAtMs = now;
      return;
    }
    if (pausedAtMs !== 0) {
      pausedAccumMs += Math.max(0, now - pausedAtMs);
      pausedAtMs = 0;
    }
  }

  function currentMatchDurationMs(): number {
    if (!matchStartedAtMs) return 0;
    const now = Date.now();
    const pauseExtra = pausedAtMs ? Math.max(0, now - pausedAtMs) : 0;
    const pausedTotal = pausedAccumMs + pauseExtra;
    return Math.max(0, now - matchStartedAtMs - pausedTotal);
  }

  function syncDevTabVisibility(isDevEnabled?: boolean): void {
    const enabled =
      isDevEnabled ?? ((doc.querySelector<HTMLInputElement>("#core-devMode")?.checked ?? false) === true);
    if (devTab) devTab.classList.toggle("devHidden", !enabled);
    if (devPane) devPane.classList.toggle("devHidden", !enabled);

    // If dev is disabled and the dev pane is currently active, bounce back to Achievements.
    if (!enabled) {
      const miscTabs = doc.querySelector<HTMLElement>("[data-tabs=\"miscinfo\"]");
      const activeTab = miscTabs?.querySelector<HTMLElement>(".tab.active");
      if (activeTab && activeTab.getAttribute("data-tab") === "dev") {
        miscTabs?.querySelector<HTMLElement>(".tab[data-tab=\"ach\"]")?.click();
      }
    }
  }

  function updateHighScoresUi(useSettings?: GameSettings): void {
    if (!highscores) return;
    const s = useSettings ?? state?.settings ?? settings;
    const entries = getLeaderboard(s).slice(0, 10);
    if (entries.length === 0) {
      highscores.innerHTML = `<div class="hint">No saved scores yet. Finish a match to populate this list.</div>`;
      return;
    }
    highscores.innerHTML = entries
      .map((e) => {
        const when = new Date(e.atIso).toLocaleDateString();
        const dur = e.durationMs ? ` • ${formatMs(e.durationMs)}` : "";
        return `<div class="leader-row"><div class="leader-name">${escapeHtml(e.name)}</div><div class="leader-score">${e.score}</div><div class="leader-meta">${when}${dur}</div></div>`;
      })
      .join("");
  }

  function recordScoresIfNeeded(): void {
    if (!state) return;
    if (matchRecorded) return;
    matchRecorded = true;
    const dur = currentMatchDurationMs();
    for (const p of state.players) {
      recordScore(state.settings, p.profile.name, p.score, dur);
    }
    updateHighScoresUi(state.settings);
  }

  const SVG_ENTITY_MAP: Record<string, string> = {
    ns_extend: "http://ns.adobe.com/Extensibility/1.0/",
    ns_ai: "http://ns.adobe.com/AdobeIllustrator/10.0/",
    ns_graphs: "http://ns.adobe.com/Graphs/1.0/",
    ns_vars: "http://ns.adobe.com/Variables/1.0/",
    ns_imrep: "http://ns.adobe.com/ImageReplacement/1.0/",
    ns_sfw: "http://ns.adobe.com/SaveForWeb/1.0/",
    ns_custom: "http://ns.adobe.com/GenericCustomNamespace/1.0/",
    ns_adobe_xpath: "http://ns.adobe.com/XPath/1.0/",
  };

  const ASSET_BASE = (import.meta as any).env?.BASE_URL ?? "/";
  function assetUrl(path: string): string {
    const clean = path.startsWith("/") ? path.slice(1) : path;
    return new URL(clean, window.location.origin + ASSET_BASE).toString();
  }

  // Staff/TAB hit-grid resolution.
  // 16 columns per measure = 16th-note grid in 4/4.
  // When we add smaller rhythmic divisions (32nds, tuplets, swing, etc.),
  // we can increase this (e.g., 32, 48, 64...) or move to a tick-based grid.
  const DEFAULT_STAFF_COLUMNS_PER_MEASURE = 16;

  function sanitizeSvgText(raw: string): string {
    let t = raw;

    // Replace Illustrator entity references (browsers do not evaluate SVG DTD entities when injecting via innerHTML).
    for (const [k, v] of Object.entries(SVG_ENTITY_MAP)) {
      t = t.replaceAll("&" + k + ";", v);
    }

    // Remove XML declaration and DOCTYPE (including internal subsets).
    t = t.replace(/<\?xml[\s\S]*?\?>/g, "");
    t = t.replace(/<!DOCTYPE[\s\S]*?\]>/g, "");
    t = t.replace(/<!DOCTYPE[^>]*>/g, "");
    t = t.replace(/<!ENTITY[\s\S]*?>/g, "");

    // Remove Adobe-only foreignObject blocks (keeps the real <g> content).
    t = t.replace(/<foreignObject[\s\S]*?<\/foreignObject>/g, "");

    return t;
  }

  async function loadSvgIntoHost(
    host: HTMLElement,
    urlPath: string,
    preserveAspectRatio: string = "xMidYMid meet",
  ): Promise<string> {
    const res = await fetch(assetUrl(urlPath));
    if (!res.ok) throw new Error("Failed to load " + urlPath + ": " + res.status);

    const raw = await res.text();
    const svgText = sanitizeSvgText(raw);
    host.innerHTML = svgText;

    const svg = host.querySelector("svg") as SVGSVGElement | null;
    if (svg) {
      svg.setAttribute("width", "100%");
      svg.setAttribute("height", "100%");
      svg.setAttribute("preserveAspectRatio", preserveAspectRatio);
    }

    return svgText;
  }




  function chooseTabPitchAction(stringIndex: number, fretIndex: number): "TAP_CELL" | "STEAL_CELL" {
    if (!state) return "TAP_CELL";
    const cellIndex = stringIndex * state.fretCount + fretIndex;
    const lane = fromVariantId(state.prompt.variantId).spelling;
    const owner = state.board.owner[lane][cellIndex];
    const currentPid = state.players[state.currentPlayer]?.profile.id ?? -1;
    return owner >= 0 && owner !== currentPid ? "STEAL_CELL" : "TAP_CELL";
  }

  function dispatchFromFretSurface(action: Action): void {
    // Non-cell actions (dev/test, settings, etc.) pass through unchanged.
    if (action.type !== "TAP_CELL" && action.type !== "STEAL_CELL") {
      dispatch(action);
      return;
    }

    // Composite modes gate input and delay committing the TAP/STEAL until all required surfaces are filled.
    if (!state || paused) return;
    const matrix = getSurfaceMatrix();
    if (!matrix.fret.input) return;

    pendingFretPick = { action: action.type, stringIndex: action.stringIndex, fretIndex: action.fretIndex };
    submitCompositeIfReady();
  }
  async function setupSvgSurfaces(): Promise<void> {
    // Staff background (optional)
    if (staffBgHostEl && staffOverlaySvgEl) {
      // NOTE: loadSvgIntoHost expects a relative asset path (it applies assetUrl() internally).
      const staffText = await loadSvgIntoHost(staffBgHostEl, "/Guitar-Notes_Tab_Staff-Blank-3Measures.svg", "xMidYMid meet");
      const vb = parseSvgViewBox(staffText);
      staffOverlaySvgEl.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
      staffOverlaySvgEl.setAttribute("preserveAspectRatio", "xMidYMid meet");
      staffLayout = parseStaffTabLayout(staffText, DEFAULT_STAFF_COLUMNS_PER_MEASURE);
      renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      attachStaffTabPointerHandlers(staffOverlaySvgEl, staffLayout, staffOverlayState, (hit: StaffTabHit) => {
        window.dispatchEvent(new CustomEvent("gedu:staffPick", { detail: hit }));
      });

      // Apply the initial crop according to the current UI Mode.
      // (Mode 2 = staff only, Mode 3 = tab only, others = both.)
      const uiModeEl = doc.getElementById("core-gameMode") as HTMLSelectElement | null;
      const uiMode = uiModeEl?.value ?? "m4";
      applyStaffTabCrop(uiMode);
    }

    // Visual background SVG: prefer the v2i artwork; fall back to the vector SVG if needed.
    let bgText = "";
    try {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete_v2i.svg"),
        "xMinYMin meet",
      );
    } catch {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"),
        "xMinYMin meet",
      );
    }

    // Compute the hitbox layout directly from the background SVG whenever possible.
    // Our photo-style v2i asset now exposes enough geometry (via image transforms) to
    // recover fret and string positions, which keeps markers perfectly centered.
    let layout: FretboardLayout;
    let vb: { x: number; y: number; w: number; h: number };
    try {
      const cleanBgText = sanitizeSvgText(bgText);
      layout = computeLayoutFromSvg(cleanBgText);
      vb = layout.viewBox;
    } catch (e) {
      console.warn("Failed to compute layout from background SVG; falling back to vector geometry mapping.", e);

      // Geometry fallback: compute from the clean vector SVG and map into the background.
      const hitRaw = await (await fetch(assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"))).text();
      const hitText = sanitizeSvgText(hitRaw);
      const baseLayout = computeLayoutFromSvg(hitText);

      layout = baseLayout;
      vb = baseLayout.viewBox;
      try {
        const bgVB = parseSvgViewBox(bgText);
        const bgNeck = parseSvgNeckBounds(bgText);
        layout = mapLayoutToNeck(baseLayout, bgVB, bgNeck);
        vb = bgVB;
      } catch (e2) {
        console.warn("Failed to map fretboard layout to background SVG; using base layout.", e2);
      }
    }

    fretLayout = layout;

    fretOverlaySvgEl.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
    fretOverlaySvgEl.setAttribute("preserveAspectRatio", "xMinYMin meet");
    fretOverlaySvgEl.setAttribute("width", "100%");
    fretOverlaySvgEl.setAttribute("height", "100%");

    attachBoardPointerHandlers(
      { layout: fretLayout, svgRoot: fretOverlaySvgEl, dispatch: dispatchFromFretSurface },
      () => state,
      fretOverlaySvgEl,
    );

    // Education mode: allow placing markers on the fretboard even when no match is running.
    if (!eduFretHandlersInstalled) {
      eduFretHandlersInstalled = true;
      fretOverlaySvgEl.addEventListener("pointerdown", (ev: PointerEvent) => {
        if (session !== "edu") return;
        if (!fretLayout) return;
        // Convert client -> svg coords
        const rect = fretOverlaySvgEl.getBoundingClientRect();
        const vb = fretOverlaySvgEl.viewBox.baseVal;
        const sx = vb.x + ((ev.clientX - rect.left) * vb.width) / Math.max(1, rect.width);
        const sy = vb.y + ((ev.clientY - rect.top) * vb.height) / Math.max(1, rect.height);

        const hit = hitTestCell(fretLayout, sx, sy);
        if (!hit) return;
        const fretCols = Math.max(1, fretLayout.fretBoundaries.length - 1);
        const cellIndex = hit.stringIndex * fretCols + hit.fretIndex;
        if (eduTool === "erase") eduFretMarks.delete(cellIndex);
        else eduFretMarks.set(cellIndex, eduSelectedVariantId);
        renderEduFretMarks();
        applyEduVisibility();
      }, { passive: true });
    }

    // Initial render if a game is already running.
    updateOverlayOwnership();
    syncFretKeypadAvailability();
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
  }

  function applyStaffTabCrop(uiMode: string): void {
    if (!staffLayout || !staffOverlaySvgEl || !staffBgHostEl) return;

    const full = staffLayout.viewBox;
    let y0 = full.y;
    let y1 = full.y + full.h;

    // Add a small padding so we don't clip clefs/labels.
    const staffPad = staffLayout.staff.halfStep * 2;
    const tabGap = (staffLayout.tab.lineYs[1] ?? staffLayout.tab.lineYs[0] ?? 10) - (staffLayout.tab.lineYs[0] ?? 0);
    const tabPad = Math.max(6, Math.abs(tabGap) * 0.9);

    if (uiMode === "m2") {
      // Staff only
      y0 = staffLayout.staff.yMin - staffPad;
      y1 = staffLayout.staff.yMax + staffPad;
    } else if (uiMode === "m3") {
      // Tab only
      y0 = staffLayout.tab.yMin - tabPad;
      y1 = staffLayout.tab.yMax + tabPad;
    }

    // Clamp to the original viewBox.
    y0 = Math.max(full.y, y0);
    y1 = Math.min(full.y + full.h, y1);
    const h = Math.max(1, y1 - y0);

    const vbStr = `${full.x} ${y0} ${full.w} ${h}`;
    staffOverlaySvgEl.setAttribute("viewBox", vbStr);
    staffOverlaySvgEl.setAttribute("preserveAspectRatio", "xMidYMid meet");

    // Update the embedded background SVG to match.
    const bgSvg = staffBgHostEl.querySelector("svg");
    if (bgSvg) {
      bgSvg.setAttribute("viewBox", vbStr);
      bgSvg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    }
  }

  // --- Education helpers ---
  function updateEduSelectedUi(): void {
    const el = doc.getElementById("edu-selected");
    if (!el) return;
    const lab = variantLabel(eduSelectedVariantId);
    el.textContent = lab;
  }

  function clearEduMarks(which: "all" | "staff" | "tab" | "fret"): void {
    if (which === "all" || which === "staff") staffOverlayState.staffMarksByCol.clear();
    if (which === "all" || which === "tab") staffOverlayState.tabMarksByCol.clear();
    if (which === "all" || which === "fret") eduFretMarks.clear();
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
    renderEduFretMarks();
    applyEduVisibility();
  }

  function applyEduVisibility(): void {
    if (session !== "edu") return;
    if (staffOverlaySvgEl) {
      const gStaff = staffOverlaySvgEl.querySelector<SVGGElement>("#geduStaffMarks");
      const gTab = staffOverlaySvgEl.querySelector<SVGGElement>("#geduTabNumbers");
      if (gStaff) gStaff.style.display = eduShowStaff ? "" : "none";
      if (gTab) gTab.style.display = eduShowTab ? "" : "none";
    }
    const gFret = fretOverlaySvgEl.querySelector<SVGGElement>("#geduEduMarks");
    if (gFret) gFret.style.display = eduShowFret ? "" : "none";
  }

  function renderEduFretMarks(): void {
    if (session !== "edu") return;
    if (!fretLayout) return;

    const NS = "http://www.w3.org/2000/svg";
    let g = fretOverlaySvgEl.querySelector<SVGGElement>("#geduEduMarks");
    if (!g) {
      g = document.createElementNS(NS, "g") as SVGGElement;
      g.setAttribute("id", "geduEduMarks");
      fretOverlaySvgEl.appendChild(g);
    }
    while (g.firstChild) g.removeChild(g.firstChild);

    const fretCols = Math.max(1, fretLayout.fretBoundaries.length - 1);
    const r = Math.max(6, Math.min(10, fretLayout.dotRadius * 1.25));
    for (const [cellIndex, vid] of eduFretMarks.entries()) {
      const stringIndex = Math.floor(cellIndex / fretCols);
      const fretIndex = cellIndex % fretCols;
      const c = cellCenter(fretLayout, stringIndex, fretIndex);

      const circ = document.createElementNS(NS, "circle");
      circ.setAttribute("cx", String(c.cx));
      circ.setAttribute("cy", String(c.cy));
      circ.setAttribute("r", String(r));
      circ.setAttribute("fill", "rgba(255,255,255,0.12)");
      circ.setAttribute("stroke", "rgba(255,255,255,0.65)");
      circ.setAttribute("stroke-width", "1");
      g.appendChild(circ);

      const t = document.createElementNS(NS, "text");
      t.setAttribute("x", String(c.cx));
      t.setAttribute("y", String(c.cy + r * 0.35));
      t.setAttribute("text-anchor", "middle");
      t.setAttribute("font-size", String(Math.max(9, r * 0.95)));
      t.setAttribute("font-weight", "700");
      t.setAttribute("fill", "rgba(255,255,255,0.95)");
      t.textContent = variantLabel(vid);
      g.appendChild(t);
    }
  }

  void setupSvgSurfaces().catch((err) => {
    console.error("Failed to set up SVG surfaces", err);
  });

  function rebuildOverlay(): void {
    // No-op: fretboard interaction and rendering are handled by the SVG overlay.
    // This stub is kept so older calls (e.g., start/reset) don't crash.
  }

  function updateOverlayOwnership(): void {
    if (!state || !fretLayout) return;
    renderOverlay(fretOverlaySvgEl, fretLayout, state, activePulse);
  }

  function updateActivePlayerUi(): void {
    if (!state) return;
    const pIndex = state.currentPlayer;
    const p = state.players[pIndex];
    if (!p) return;

    if (activeName) activeName.textContent = players[pIndex]?.name ?? `P${pIndex + 1}`;
    if (activeScore) activeScore.textContent = String(p.score);
    if (activeMult) activeMult.textContent = `×${1 + (state.turn?.streakTier ?? 0)}`;

    if (activeTokens) {
      const cap = state.settings.steal.tokenCap;
      activeTokens.innerHTML = "";
      for (let i = 0; i < cap; i++) {
        const dot = document.createElement("span");
        dot.className = "tokenDot" + (i < p.tokenCount ? " filled" : "");
        activeTokens.appendChild(dot);
      }
    }
  }

  function updateLeaderboardUi(): void {
    if (!state || !leaderboard) return;
    leaderboard.innerHTML = "";
    for (let i = 0; i < state.players.length; i++) {
      const p = state.players[i];
      const row = document.createElement("div");
      row.className = "leader-chip" + (i === state.currentPlayer ? " active" : "");
      row.innerHTML = `
        <div class="leader-avatar">${(players[i]?.name ?? `P${i + 1}`).slice(0, 2)}</div>
        <div class="leader-name">${players[i]?.name ?? `P${i + 1}`}</div>
        <div class="leader-score">${p.score}</div>
        <div class="leader-tokens">${p.tokenCount}</div>
      `;
      leaderboard.appendChild(row);
    }
  }

  function updatePromptUi(): void {
    if (!state) return;
    const displayMode = (state.settings as any).displayMode ?? "names";
    const rootPc = pcFromUiNoteName((state.settings as any).rootNote ?? "C");
    const label = labelForVariant(state.prompt.variantId, displayMode, rootPc, state.settings);

    // Update the visible target label (and promptText if that element exists).
    if (promptText) promptText.textContent = label;
    if (activeTarget) {
      const v = fromVariantId(state.prompt.variantId);
      const isBlack = IS_BLACK[v.pitchClass];
      const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
      activeTarget.textContent = spelling ? `Target: ${label} (${spelling})` : `Target: ${label}`;
      activeTarget.classList.toggle("is-sharp", isBlack && v.spelling === SlotType.SHR);
      activeTarget.classList.toggle("is-flat", isBlack && v.spelling === SlotType.FLT);
    }

    // Rail config
    const railMode: RailConfig["mode"] = state.settings.promptProfileId.startsWith("scale") || state.settings.promptProfileId.startsWith("key") ? "FIXED_REFERENCE" : "ROTATE_COMPASS";
    const anchor = toVariantId(rootPc as any, SlotType.NAT);
    rail.setConfig(
      {
        mode: railMode,
        anchorVariantId: anchor,
        currentVariantId: state.prompt.variantId,
      },
      state.settings,
    );

    // Make the sharp/flat requirement visible at a glance without giving away fretboard positions.
    const v = fromVariantId(state.prompt.variantId);
    const isBlack = IS_BLACK[v.pitchClass];
    const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
    const targetSuffix = spelling ? ` | Target: ${label} (${spelling})` : ` | Target: ${label}`;
    setAlert(describePromptProfileId(state.settings.promptProfileId) + targetSuffix);
  }




  type SurfaceMatrix = {
    staff: { required: boolean; input: boolean; showMarks: boolean };
    tab: { required: boolean; input: boolean; showMarks: boolean };
    fret: { required: boolean; input: boolean; showMarks: boolean };
  };

  function getSurfaceLayers(): { view: boolean; asked: boolean; answered: boolean } {
    const src = ((state?.settings ?? settings) as any) ?? {};
    const l = (src.surfaceLayers ?? {}) as any;
    return {
      view: l.view !== false,
      asked: l.asked !== false,
      answered: l.answered !== false,
    };
  }

  function getUiMode(): string {
    return (((state?.settings as any) ?? {}) as any).uiMode ?? "m4";
  }

  function getSurfaceMatrix(): SurfaceMatrix {
    const uiMode = getUiMode();
    const inMatch = !!state && (state.phase === "IN_MATCH" || state.phase === "LAST_CHANCE");

    // Requirements (must supply at least one pitch-producing surface: TAB or FRET).
    const needStaff = uiMode === "m2" || uiMode === "m4" || uiMode === "m5";
    const needTab = uiMode === "m3" || uiMode === "m4" || uiMode === "m5";
    const needFret = uiMode === "m1" || uiMode === "m2" || uiMode === "m4";

    return {
      staff: { required: needStaff, input: inMatch && needStaff, showMarks: needStaff },
      tab: { required: needTab, input: inMatch && needTab, showMarks: needTab },
      fret: { required: needFret, input: inMatch && needFret, showMarks: false },
    };
  }

  function clearTurnInputProgress(reason: "prompt" | "turn" | "manual" = "manual"): void {
    pendingStaffPick = null;
    pendingTabPick = null;
    pendingFretPick = null;

    tabSelectedString = null;
    tabSelectedFret = null;
    tabSelectedCol = null;

    // Clear transient UI marks (but keep EDU marks untouched; EDU has its own controls).
    if (session !== "edu") {
      staffOverlayState.staffMarksByCol.clear();
      staffOverlayState.tabMarksByCol.clear();
      staffOverlayState.tabDefaultNumber = 0;
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
    }

    if (reason === "prompt") {
      setAlert(null);
    }
  }

  function staffLetterForYIndex(layout: StaffTabLayout | null, yIndex: number): string | null {
    if (!layout || layout.staff.stepCenters.length === 0) return null;

    // Use the bottom staff line as the reference step.
    const bottomLineY = layout.staff.lineYs[layout.staff.lineYs.length - 1] ?? layout.staff.stepCenters[layout.staff.stepCenters.length - 1];

    let ref = 0;
    let best = Infinity;
    for (let i = 0; i < layout.staff.stepCenters.length; i++) {
      const d = Math.abs(layout.staff.stepCenters[i] - bottomLineY);
      if (d < best) {
        best = d;
        ref = i;
      }
    }

    // In treble clef, the bottom line is E.
    const letters = ["C", "D", "E", "F", "G", "A", "B"] as const;
    const eIndex = 2;
    const offset = ref - yIndex;
    const idx = ((eIndex + offset) % 7 + 7) % 7;
    return letters[idx] ?? null;
  }

  function expectedPromptLetter(): string | null {
    if (!state) return null;
    const label = variantLabel(state.prompt.variantId);
    const letter = label.trim().slice(0, 1);
    return letter ? letter.toUpperCase() : null;
  }

  function submitCompositeIfReady(): void {
    if (!state) return;

    const matrix = getSurfaceMatrix();
    if (session === "edu") return;
    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;

    // Wait until all required surfaces have a value.
    if (matrix.staff.required && !pendingStaffPick) return;
    if (matrix.tab.required && !pendingTabPick) return;
    if (matrix.fret.required && !pendingFretPick) return;

    // Determine the pitch-producing selection.
    const pitchSel = pendingFretPick
      ? { action: pendingFretPick.action, stringIndex: pendingFretPick.stringIndex, fretIndex: pendingFretPick.fretIndex }
      : pendingTabPick
        ? { action: pendingTabPick.action, stringIndex: pendingTabPick.stringIndex, fretIndex: pendingTabPick.fret }
        : null;

    if (!pitchSel) return;

    const target = fromVariantId(state.prompt.variantId);

    let staffDrivenPc: number | null = null;

    // Validate TAB vs FRET agreement (exact position, not just pitch-class).
    if (matrix.tab.required && matrix.fret.required && pendingTabPick && pendingFretPick) {
      if (pendingTabPick.stringIndex !== pendingFretPick.stringIndex || pendingTabPick.fret !== pendingFretPick.fretIndex) {
        dispatch({ type: "TIMEOUT" });
        clearTurnInputProgress("manual");
        return;
      }
    }
    // Validate STAFF letter spelling (drives pitch+spelling intent).
    if (matrix.staff.required && pendingStaffPick) {
      const needLetter = expectedPromptLetter();
      const gotLetter = staffLetterForYIndex(staffLayout, pendingStaffPick.yIndex);
      if (!needLetter || !gotLetter || gotLetter.toUpperCase() !== needLetter) {
        dispatch({ type: "TIMEOUT" });
        clearTurnInputProgress("manual");
        return;
      }

      const letterPc: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
      const basePc = letterPc[gotLetter.toUpperCase()];
      if (basePc === undefined) {
        dispatch({ type: "TIMEOUT" });
        clearTurnInputProgress("manual");
        return;
      }

      // If the target is spelled as a sharp/flat, treat the staff letter as the natural anchor.
      if (target.spelling === SlotType.SHR) staffDrivenPc = (basePc + 1) % 12;
      else if (target.spelling === SlotType.FLT) staffDrivenPc = (basePc + 11) % 12;
      else staffDrivenPc = basePc;
    }

    // Validate rhythmic column alignment between STAFF and TAB.

    if (matrix.staff.required && matrix.tab.required && pendingStaffPick && pendingTabPick) {
      if (pendingStaffPick.col !== pendingTabPick.col) {
        dispatch({ type: "TIMEOUT" });
        clearTurnInputProgress("manual");
        return;
      }
    }

    // Validate pitch class from the chosen string/fret.
    const pc = pitchClassAt(pitchSel.stringIndex, pitchSel.fretIndex);
    const requiredPc = staffDrivenPc ?? target.pitchClass;
    if (pc !== requiredPc) {
      dispatch({ type: "TIMEOUT" });
      clearTurnInputProgress("manual");
      return;
    }

    // Submit the pitch action to the engine (prompt spelling is handled inside the engine).
    dispatch({ type: pitchSel.action, stringIndex: pitchSel.stringIndex, fretIndex: pitchSel.fretIndex });
    clearTurnInputProgress("manual");
  }

  function syncFretKeypadAvailability(): void {
    const pad = doc.getElementById("keypad");
    if (!pad) return;

    const matrix = getSurfaceMatrix();
    const enabled = session === "edu" ? true : !!state && matrix.tab.input;

    // Disable keys outside the current playable domain range.
    // Note: the 24-key UI is always present, but keys outside [minFret..maxFret] are disabled.
    const minAllowed = state ? state.settings.domain.minFret : 0;
    const maxAllowed = state ? Math.min(24, state.settings.domain.maxFret) : 24;

    const keys = pad.querySelectorAll<HTMLButtonElement>("button.key");
    keys.forEach((b) => {
      const f = Number(b.dataset.fret);
      // Open string (0) remains available even when the focused fret range starts at 1.
      const outOfRange = !Number.isFinite(f) || (f !== 0 && (f < minAllowed || f > maxAllowed)) || (f === 0 && maxAllowed < 0);
      const disabled = !enabled || outOfRange;
      b.disabled = disabled;
      b.classList.toggle("disabled", disabled);

      // Visual feedback for selected fret
      b.classList.toggle("selected", Number.isFinite(f) && f === tabSelectedFret);
    });
  }

  function applyUiModeVisibility(overrideUiMode?: string): void {
    const uiMode: string = overrideUiMode ?? (((state?.settings as any) ?? {}) as any).uiMode ?? "m4";
    const showFret = uiMode !== "m5";

    const matrix = getSurfaceMatrix();

    // STAFF/TAB stage
    const staffSection = doc.getElementById("staffTabStage")?.closest(".section") as HTMLElement | null;
    if (staffSection) {
      // Keep the Staff/Tab panel in the layout so the UI does not jump;
      // in modes where it is not active we simply mark it disabled.
      staffSection.hidden = false;
      const enabled = session === "edu" ? true : matrix.staff.input || matrix.tab.input;
      staffSection.classList.toggle("isDisabled", !enabled);

      if (staffOverlaySvgEl) {
        staffOverlaySvgEl.style.pointerEvents = enabled ? "auto" : "none";

        // Gameplay marks are gated by the surface matrix; education mode uses its own toggles.
        if (session !== "edu") {
          const layers = getSurfaceLayers();
          const gStaff = staffOverlaySvgEl.querySelector<SVGGElement>("#geduStaffMarks");
          const gTab = staffOverlaySvgEl.querySelector<SVGGElement>("#geduTabNumbers");
          const showAnswered = layers.answered;
          if (gStaff) gStaff.style.display = matrix.staff.showMarks && showAnswered ? "" : "none";
          if (gTab) gTab.style.display = matrix.tab.showMarks && showAnswered ? "" : "none";
        }
      }
    }

    // FRET stage
    const fretSection = doc.getElementById("fretStage")?.closest(".section") as HTMLElement | null;
    if (fretSection) {
      fretSection.hidden = !showFret;
      const enabled = session === "edu" ? true : matrix.fret.input || !!state?.settings.dev?.enabled;
      fretSection.classList.toggle("isDisabled", showFret && !enabled);
      if (fretOverlaySvgEl) fretOverlaySvgEl.style.pointerEvents = enabled ? "auto" : "none";
    }

    // If staff+tab is visible, crop the viewBox based on the selected UI Mode.
    // m2 = staff only, m3 = tab only, others = both.
    applyStaffTabCrop(uiMode);

    // Apply note rail layer visibility (labels / prompt highlight / answered layer).
    rail.setLayers(getSurfaceLayers());
  }

  function renderAll(): void {
    // Education mode renders overlays without the game engine state.
    if (!state) {
      if (session !== "edu") return;
      applyUiModeVisibility();
      updateEduSelectedUi();
      renderEduFretMarks();
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      applyEduVisibility();
      return;
    }
    applyUiModeVisibility();
    updatePromptUi();
    updateActivePlayerUi();
    updateLeaderboardUi();
    updateOverlayOwnership();
    syncFretKeypadAvailability();
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
  }

  function handleEffects(effects: any[]): void {
    const s0 = state;
    if (!s0) return;

    for (const eff of effects) {
      switch (eff.type) {
        case "PROMPT_CHANGED":
          clearTurnInputProgress("prompt");
          updatePromptUi();
          break;

        case "TURN_STARTED":
          clearTurnInputProgress("turn");
          hideIntermissionOverlay();
          applyUiModeVisibility();
          setAlert("Turn started");
          startTurnTimer();
          break;

        case "TURN_ENDED":
          clearTurnInputProgress("turn");
          stopTurnTimer();
          // In single-player, keep things flowing.
          if (s0.settings.playType === PlayType.SINGLE) {
            dispatch({ type: "START_TURN" } as Action);
          } else {
            // Multiplayer: respect intermission.
            showIntermissionOverlay(eff.nextPlayerId);
            const waitMs = Math.max(0, s0.settings.timers.intermissionMs ?? 0);
            if (waitMs <= 0) {
              startTurnEarly("auto");
              break;
            }
            intermissionHandle = window.setTimeout(() => {
              if (!state || paused) return;
              startTurnEarly("auto");
            }, waitMs);
          }
          break;

        case "FEEDBACK_PULSE": {
          // SAM pulse (highlight correct locations)
          if (!s0.settings.feedback.samEnabled) break;

          activePulse = {
            playerId: eff.playerId,
            variantId: eff.variantId,
            durationMs: eff.durationMs ?? s0.settings.feedback.samDurationMs,
            ghost: (eff.ghost ?? null) as any,
            ghosts: (eff.ghosts ?? undefined) as any,
            scoreDelta: (eff.scoreDelta ?? 0) as any,
            includeLabel: (eff.includeLabel ?? false) as any,
          };

          if (samHandle !== null) window.clearTimeout(samHandle);
          samHandle = window.setTimeout(() => {
            activePulse = null;
            renderAll();
          }, activePulse.durationMs);
          break;
        }

        case "ALERT":
          setAlert(String(eff.message ?? ""));
          break;

        case "MATCH_COMPLETE":
          stopTurnTimer();
          hideIntermissionOverlay();
          paused = true;
          notePauseChange(true);
          recordScoresIfNeeded();
          updateHighScoresUi();
          setAlert("Match complete");
          showSplash();
          break;
      }
    }

    renderAll();
  }

  function dispatch(action: Action): void {
    const r = reducer(state, action);
    state = r.state;
    handleEffects(r.effects);
  }

  function beginMatch(sess: "single" | "multi"): void {
    clearTimers();
    hideIntermissionOverlay();
    paused = false;

    session = sess;
    settings = buildSettingsFromUi(doc, session);
    syncDevTabVisibility(!!settings.dev?.enabled);

    // Hide instructor tools during standard play.
    const teachTab = doc.getElementById("utility-teach-tab") as HTMLButtonElement | null;
    const teachPane = doc.getElementById("utility-teach-pane") as HTMLDivElement | null;
    if (teachTab) teachTab.hidden = true;
    if (teachPane) teachPane.hidden = true;
    players = buildPlayers(session === "single" ? 1 : PLAYER_COUNT_MULTI);

    const init = reducer(null, { type: "INIT_MATCH", settings, players } as Action);
    state = init.state;

    // Match timing (used for persistent high scores)
    matchStartedAtMs = Date.now();
    pausedAtMs = 0;
    pausedAccumMs = 0;
    matchRecorded = false;

    // Apply starting tokens (clamped to the configured token cap).
    const startTokens = clamp(Number((settings as any).startTokens ?? 0), 0, settings.steal.tokenCap);
    if (state && startTokens > 0) {
      for (const p of state.players) p.tokenCount = startTokens;
    }

    updateHighScoresUi(settings);

    rebuildOverlay();
    renderAll();
    handleEffects(init.effects);

    // Start the first turn immediately.
    dispatch({ type: "START_TURN" } as Action);
    hideSplash();
  }

  function beginEducation(): void {
    session = "edu";
    hideIntermissionOverlay();
    settings = buildSettingsFromUi(doc, session);
    // Instructor session: no scoring, no timers, no turns.
    players = buildPlayers(1);
    state = null;
    paused = false;
    stopTurnTimer();
    setAlert("Education Mode");

    // Unhide Teach tab and switch to it.
    const teachTab = doc.getElementById("utility-teach-tab") as HTMLButtonElement | null;
    const teachPane = doc.getElementById("utility-teach-pane") as HTMLDivElement | null;
    if (teachTab) teachTab.hidden = false;
    if (teachPane) teachPane.hidden = false;
    teachTab?.click();

    // Default selection reads from note rail if available; fall back to C.
    updateEduSelectedUi();

    // Clear any previous marks and redraw.
    clearEduMarks("all");
    renderAll();
  }

  function endMatch(): void {
    if (!state) return;
    clearTimers();
    hideIntermissionOverlay();
    paused = true;
    notePauseChange(true);
    dispatch({ type: "END_MATCH" } as Action);
    recordScoresIfNeeded();
    updateHighScoresUi();
    showSplash();
  }

  function resetGame(): void {
    clearTimers();
    hideIntermissionOverlay();
    paused = false;
    matchStartedAtMs = 0;
    pausedAtMs = 0;
    pausedAccumMs = 0;
    matchRecorded = false;
    state = null;
    rebuildOverlay();
    setAlert("Ready");
    showSplash();
  }

  function onCellClick(stringIndex: number, fretIndex: number): void {
    if (!state) return;
    if (paused) return;
    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;

    const cellIndex = stringIndex * state.fretCount + fretIndex;
    const slot = fromVariantId(state.prompt.variantId).spelling;
    const owner = state.board.owner[slot][cellIndex];
    const currentPid = state.players[state.currentPlayer]?.profile.id ?? -1;
    const isOtherOwner = owner >= 0 && owner !== currentPid;
    const actionType: "TAP_CELL" | "STEAL_CELL" = isOtherOwner ? "STEAL_CELL" : "TAP_CELL";

    pendingFretPick = { action: actionType, stringIndex, fretIndex };
    submitCompositeIfReady();
  }

  // Intermission overlay interaction (multiplayer)
  intermissionOverlay?.addEventListener("click", () => startTurnEarly("tap"));
  intermissionStart?.addEventListener("click", (ev) => {
    ev.stopPropagation();
    startTurnEarly("button");
  });

  // Listen to layout events
  window.addEventListener("gedu:splashSelect", (e: any) => {
    const detail = e?.detail as { session: "single" | "multi" | "edu" };
    const sess = detail?.session ?? "single";
    if (sess === "edu") beginEducation();
    else beginMatch(sess);
  });

  window.addEventListener("gedu:start", () => {
    if (session === "edu") {
      setAlert("Education Mode");
      renderAll();
      return;
    }
    if (!state) {
      beginMatch(session);
      return;
    }
    paused = false;
	    notePauseChange(false);
    setAlert("Running");
    if (state.phase === "IN_MATCH" || state.phase === "LAST_CHANCE") startTurnTimer();
    renderAll();
  });

  window.addEventListener("gedu:pause", () => {
    if (session === "edu") {
      setAlert("Education Mode");
      return;
    }
    paused = true;
    notePauseChange(true);
    stopTurnTimer();
    setAlert("Paused");
    renderAll();
  });

  window.addEventListener("gedu:stop", () => {
    if (session === "edu") {
      clearEduMarks("all");
      showSplash();
      return;
    }
    endMatch();
  });

  window.addEventListener("gedu:new", () => {
    if (session === "edu") {
      clearEduMarks("all");
      setAlert("Education Mode");
      renderAll();
      return;
    }
    resetGame();
  });

  window.addEventListener("gedu:applyFretRange", () => {
    // Easiest deterministic behavior: restart match with new domain.
    if (!state) return;
    beginMatch(session === "multi" ? "multi" : "single");
  });

  window.addEventListener("gedu:applySettings", () => {
    if (session === "edu") {
      settings = buildSettingsFromUi(doc, session);
      renderAll();
      return;
    }
    if (!state) return;
    beginMatch(session as any);
  });

  // Note rail selection: in dev mode or Learning difficulty, clicking a rail cell sets the current prompt.
  window.addEventListener("gedu:railSelect", (e: any) => {
    const vid = Number(e?.detail?.variantId);
    if (!Number.isFinite(vid)) return;

    // Education mode: the rail selects what will be placed.
    if (session === "edu") {
      eduSelectedVariantId = vid;
      updateEduSelectedUi();
      renderAll();
      return;
    }

    if (!state) return;
    const allow = !!state.settings.dev?.enabled || state.settings.difficulty === Difficulty.LEARNING;
    if (!allow) return;
    dispatch({ type: "DEV_SET_PROMPT", variantId: vid } as any);
  });
  // 25-key fret selector (instant): on fret pick, claim if a TAB string is selected (or vice versa).
  window.addEventListener("gedu:fretPick", (e: any) => {
    const raw = Number(e?.detail?.fret);
    if (!Number.isFinite(raw)) return;

    const requested = clamp(Math.floor(raw), 0, 24);
    tabSelectedFret = requested;
    staffOverlayState.tabDefaultNumber = requested;

    // Education mode: just update the default number.
    if (session === "edu") {
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      return;
    }

    if (!state) return;

    const matrix = getSurfaceMatrix();
    if (!matrix.tab.input) {
      setAlert("TAB input is disabled in this mode");
      return;
    }

    const maxAllowed = Math.min(24, state.settings.domain.maxFret);
    const clampedFret = clamp(requested, 0, maxAllowed);
    tabSelectedFret = clampedFret;
    staffOverlayState.tabDefaultNumber = clampedFret;

    // If a TAB (string+column) is already selected, complete the TAB answer now.
    if (tabSelectedString !== null && tabSelectedCol !== null) {
      pendingTabPick = {
        col: tabSelectedCol,
        stringIndex: tabSelectedString,
        fret: clampedFret,
        action: chooseTabPitchAction(tabSelectedString, clampedFret),
      };
      staffOverlayState.tabMarksByCol.set(tabSelectedCol, { stringIndex: tabSelectedString, fret: clampedFret });
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      submitCompositeIfReady();
      return;
    }

    setAlert(`TAB: fret ${clampedFret} selected (pick string/column)`);
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
  });


  // STAFF/TAB surface pick events
  window.addEventListener("gedu:staffPick", (e: any) => {
    const region = String(e?.detail?.region ?? "");
    const col = Number(e?.detail?.col);
    const y = Number(e?.detail?.yIndex);
    if (!Number.isFinite(col) || !Number.isFinite(y)) return;

    // Education mode: place/erase simple markers on staff or tab.
    if (session === "edu") {
      if (region === "staff") {
        if (eduTool === "erase") staffOverlayState.staffMarksByCol.delete(col);
        else staffOverlayState.staffMarksByCol.set(col, y);
      }
      if (region === "tab") {
        if (eduTool === "erase") {
          staffOverlayState.tabMarksByCol.delete(col);
        } else {
          const fret = clamp(Number(tabSelectedFret ?? staffOverlayState.tabDefaultNumber ?? 0), 0, 24);
          staffOverlayState.tabMarksByCol.set(col, { stringIndex: clamp(y, 0, 5), fret });
        }
      }
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      applyEduVisibility();
      return;
    }

    if (!state) return;
    if (paused) return;
    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;

    const matrix = getSurfaceMatrix();

    if (region === "staff") {
      if (!matrix.staff.input) return;

      pendingStaffPick = { col: Math.floor(col), yIndex: Math.floor(y) };
      staffOverlayState.staffMarksByCol.set(Math.floor(col), Math.floor(y));
      if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
      submitCompositeIfReady();
      return;
    }

    if (region !== "tab") return;
    if (!matrix.tab.input) return;

    tabSelectedString = clamp(Math.floor(y), 0, 5);
    tabSelectedCol = Math.floor(col);

    const maxAllowed = Math.min(24, state.settings.domain.maxFret);
    const previewFret = clamp(Number(tabSelectedFret ?? staffOverlayState.tabDefaultNumber ?? 0), 0, maxAllowed);

    // Visual feedback immediately.
    staffOverlayState.tabMarksByCol.set(tabSelectedCol, { stringIndex: tabSelectedString, fret: previewFret });
    if (staffLayout && staffOverlaySvgEl) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);

    // If the fret hasn't been chosen yet, wait for a keypad selection.
    if (tabSelectedFret === null) {
      setAlert(`TAB: string ${tabSelectedString + 1} selected (pick fret)`);
      return;
    }

    pendingTabPick = {
      col: tabSelectedCol,
      stringIndex: tabSelectedString,
      fret: previewFret,
      action: chooseTabPitchAction(tabSelectedString, previewFret),
    };
    submitCompositeIfReady();
  });

  // Dev/Test UI wiring
  // Education (Teach) UI wiring
  const eduToolInput = doc.querySelector<HTMLInputElement>("#edu-tool-input");
  const eduToolErase = doc.querySelector<HTMLInputElement>("#edu-tool-erase");
  const eduShowStaffChk = doc.querySelector<HTMLInputElement>("#edu-show-staff");
  const eduShowTabChk = doc.querySelector<HTMLInputElement>("#edu-show-tab");
  const eduShowFretChk = doc.querySelector<HTMLInputElement>("#edu-show-fret");
  const btnEduClearAll = doc.querySelector<HTMLButtonElement>("#edu-clear-all");
  const btnEduClearStaff = doc.querySelector<HTMLButtonElement>("#edu-clear-staff");
  const btnEduClearTab = doc.querySelector<HTMLButtonElement>("#edu-clear-tab");
  const btnEduClearFret = doc.querySelector<HTMLButtonElement>("#edu-clear-fret");

  const syncEduControlsToState = () => {
    if (eduToolInput) eduToolInput.checked = eduTool === "input";
    if (eduToolErase) eduToolErase.checked = eduTool === "erase";
    if (eduShowStaffChk) eduShowStaffChk.checked = eduShowStaff;
    if (eduShowTabChk) eduShowTabChk.checked = eduShowTab;
    if (eduShowFretChk) eduShowFretChk.checked = eduShowFret;
    updateEduSelectedUi();
    applyEduVisibility();
  };

  eduToolInput?.addEventListener("change", () => {
    if (eduToolInput.checked) eduTool = "input";
    if (session === "edu") renderAll();
  });
  eduToolErase?.addEventListener("change", () => {
    if (eduToolErase.checked) eduTool = "erase";
    if (session === "edu") renderAll();
  });
  eduShowStaffChk?.addEventListener("change", () => { eduShowStaff = !!eduShowStaffChk.checked; applyEduVisibility(); });
  eduShowTabChk?.addEventListener("change", () => { eduShowTab = !!eduShowTabChk.checked; applyEduVisibility(); });
  eduShowFretChk?.addEventListener("change", () => { eduShowFret = !!eduShowFretChk.checked; applyEduVisibility(); });
  btnEduClearAll?.addEventListener("click", () => clearEduMarks("all"));
  btnEduClearStaff?.addEventListener("click", () => clearEduMarks("staff"));
  btnEduClearTab?.addEventListener("click", () => clearEduMarks("tab"));
  btnEduClearFret?.addEventListener("click", () => clearEduMarks("fret"));
  syncEduControlsToState();

  const devModeToggle = doc.querySelector<HTMLInputElement>("#core-devMode");
  devModeToggle?.addEventListener("change", () => {
    syncDevTabVisibility(!!devModeToggle.checked);
  });
  syncDevTabVisibility(!!devModeToggle?.checked);

  const btnDevPrev = doc.querySelector<HTMLButtonElement>("#dev-prevPlayer");
  const btnDevNext = doc.querySelector<HTMLButtonElement>("#dev-nextPlayer");
  const btnDevEndTurn = doc.querySelector<HTMLButtonElement>("#dev-endTurn");
  const btnDevClearBoard = doc.querySelector<HTMLButtonElement>("#dev-clearBoard");
  const btnDevPhaseInMatch = doc.querySelector<HTMLButtonElement>("#dev-forceInMatch");
  const btnDevPhaseIntermission = doc.querySelector<HTMLButtonElement>("#dev-forceIntermission");
  const btnDevPhaseLastChance = doc.querySelector<HTMLButtonElement>("#dev-forceLastChance");
  const btnDevPhaseResults = doc.querySelector<HTMLButtonElement>("#dev-forceResults");

  const devPaintEnabled = doc.querySelector<HTMLInputElement>("#dev-paintEnabled");
  const devPaintPlayer = doc.querySelector<HTMLSelectElement>("#dev-paintPlayer");
  const devPaintLane = doc.querySelector<HTMLSelectElement>("#dev-paintLane");
  const devPaintMode = doc.querySelector<HTMLSelectElement>("#dev-paintMode");

  const dispatchAndRender = (action: Action) => {
    if (!state) return;
    dispatch(action);
    renderAll();
  };

  btnDevPrev?.addEventListener("click", () => {
    if (!state) return;
    const n = state.players.length;
    const next = (state.currentPlayer - 1 + n) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });
  btnDevNext?.addEventListener("click", () => {
    if (!state) return;
    const n = state.players.length;
    const next = (state.currentPlayer + 1) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });

  // Dev "End Turn" behavior:
  // Option A (selected): simulate the end of a turn by triggering the same pipeline as a natural timeout/miss.
  // This validates the real scoring/token/sequence logic.
  btnDevEndTurn?.addEventListener("click", () => dispatchAndRender({ type: "TIMEOUT" } as Action));

  btnDevClearBoard?.addEventListener("click", () => dispatchAndRender({ type: "DEV_CLEAR_BOARD" } as Action));

  const forcePhase = (phase: Phase) => dispatchAndRender({ type: "DEV_FORCE_PHASE", phase } as Action);
  btnDevPhaseInMatch?.addEventListener("click", () => forcePhase("IN_MATCH"));
  btnDevPhaseIntermission?.addEventListener("click", () => forcePhase("INTERMISSION"));
  btnDevPhaseLastChance?.addEventListener("click", () => forcePhase("LAST_CHANCE"));
  btnDevPhaseResults?.addEventListener("click", () => forcePhase("RESULTS"));

  const syncPaintControlsToState = () => {
    if (!state) return;
    const patch: Partial<DevSettings> = {
      paintEnabled: !!devPaintEnabled?.checked,
      paintPlayerIndex: clamp(Number(devPaintPlayer?.value ?? 0), 0, Math.max(0, state.players.length - 1)),
      paintLane: (devPaintLane?.value as any) ?? "prompt",
      paintMode: (devPaintMode?.value as any) ?? "paint",
    };
    dispatchAndRender({ type: "DEV_SET_PAINT", patch } as Action);
  };

  devPaintEnabled?.addEventListener("change", syncPaintControlsToState);
  devPaintPlayer?.addEventListener("change", syncPaintControlsToState);
  devPaintLane?.addEventListener("change", syncPaintControlsToState);
  devPaintMode?.addEventListener("change", syncPaintControlsToState);


  // Live settings sync: when dropdowns/toggles change, update *visual* surfaces immediately
  // (so UI Mode, Note Visibility, Display Mode, etc. take effect without requiring a restart).
  doc.addEventListener("change", (ev) => {
    const target = ev.target as HTMLElement | null;
    if (!target) return;
    const ds = (target as any).dataset as { setting?: string } | undefined;
    if (!ds?.setting) return;

    const next = buildSettingsFromUi(doc, session) as any;

    // Allow preview even before the first match is started.
    if (!state) {
      if ((target as any).id === "core-gameMode") applyUiModeVisibility(next.uiMode);
      return;
    }

    const cur = state.settings as any;
    cur.uiMode = next.uiMode;
    cur.noteVisibility = next.noteVisibility;
    cur.displayMode = next.displayMode;
    cur.tritoneLabelMode = next.tritoneLabelMode;
    cur.rootNote = next.rootNote;
    cur.modeId = next.modeId;
    cur.chordKind = next.chordKind;
    cur.highlight = next.highlight;

    applyUiModeVisibility(cur.uiMode);
    updatePromptUi();

    if (staffOverlaySvgEl && staffLayout) renderStaffTabOverlay(staffOverlaySvgEl, staffLayout, staffOverlayState);
    syncFretKeypadAvailability();
  });

  // Initialize UI
  syncFretKeypadAvailability();
  updateHighScoresUi(buildSettingsFromUi(doc, session));
  setAlert("Choose Single or Multiplayer to begin");
  showSplash();
}
