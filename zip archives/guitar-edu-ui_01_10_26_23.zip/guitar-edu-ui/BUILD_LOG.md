# Build Log

This log tracks packaged zip milestones and their intent.

## Canon progress marker

For “where we are in the master checklist,” keep `CANON_PROGRESS.md` up to date. Each build should either advance or reaffirm the canon position.

## 2026-01-10 — 01_10_26_16
- Purpose: lock in Staff+Tab overlay rewrite and controller-owned mark state.
- Core: Surface Input Matrix + composite submission gating (Staff drives pitch).

## 2026-01-10 — 01_10_26_17
- Purpose: stabilize surface-matrix application in the DOM and add user-facing layer toggles.
- Core: `staffTabStage` id alignment; Surface Layers (View/Asked/Answered); rail layer controls.

## 2026-01-10 — 01_10_26_18
- Purpose: align the user-facing Surface Layers terminology with the Surface Matrix vocabulary.
- Core: rename UI labels to Display/Prompt/Marks (internal keys unchanged).

## 2026-01-10 — 01_10_26_19
- Purpose: make the Staff+TAB overlay geometry match the 3-measure rendered template.
- Core: normalize to the core 5 staff lines + derive measure spans from repeated long line segments (fixes column math and enables reliable tab-number rendering).
- Added: `getBlank3MeasureStaffTabLayout()` fallback so geometry remains correct even if the background is swapped to a raster render (no SVG line primitives).

## 2026-01-10 — 01_10_26_20
- Purpose: restore a canonical repo entrypoint for onboarding and cross-thread alignment.
- Core: added root `README.md` including Thread Boot Protocol and the project’s canon docs order.
- Canon: introduced `CANON_PROGRESS.md` as the crosswalk between the DOCX canon and the repo backlog.

## 2026-01-10 — 01_10_26_22
- Purpose: add an explicit meta tracking bucket for recurring UI/UX and rendering refinements to reduce cross-thread regressions.
- Core: `CANON_PROGRESS.md` gains **E) Refinements, Adjustments, and Fine Tuning** (cross-cutting), and `README.md` references it as part of the boot protocol.

## 2026-01-10 — 01_10_26_23
- Purpose: restore the missing multiplayer intermission UX so the phase is visible and behaves like a real turn break.
- Core: phase-driven intermission overlay with countdown + tap-to-start-early; auto-transition to the next turn remains controller-driven.
