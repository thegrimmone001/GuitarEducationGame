# Canon Progress Marker (A1.xx alignment)

This file exists to prevent “context drift” across new chat threads.

## Canonical source of truth

- `Guitar_Education_Game_Comprehensive_Guide_Merged_Canon.docx` (Generated: 2026-01-07)

## Current build snapshot

- **Build package:** `guitar-edu-ui_01_10_26_23.zip`
- **Current milestone:** Representation Systems + Multi-Surface Input
- **Milestone definition (what “done” looks like):**
  - Staff behaves like printed sheet music (ledger lines, correct vertical placement, no bleed into TAB).
  - TAB renders strings + numbers (no dots) and aligns to staff by a shared timing grid.
  - When multiple answer surfaces are enabled, a submission only passes when *all enabled* answer surfaces are correct.

## Canon checklist position (high signal)

### ✅ Canon items we are treating as “already implemented”

- A1 Page layout/grid exists (header + main + footer layout).
- B1 Fret range controls: 0–24 support, presets (5/12/24), default min 1 max 12, and dimming outside range.
- C1 Accidentals buttons removed; note labels can still show A#/Bb within a single cell.
- D1 Main menu structure decisions (Single Note / Chords / Scales first; audio settings on main menu; fretboard controls grouped with instruments).
- D3 SAM lives in Game Mode Options (needs strict behavior definitions, but placement is correct).

### 🛠 Canon items actively in completion/bug-fix

- A2 Player cards: “timer inside card” and final card variant confirmation.
- A3 Utility: expand coverage (Chord/Scale utility, mode-specific input controls).
- B3 Fretboard hitbox alignment + an authoritative coordinate system.
- E2 Rail: “current note centered” polish.
- F1 Turn controls: consistent End/Start/Pause/Reset behavior + correct placement.
 - A4 Intermission phase: overlay + countdown + early-start interaction implemented; needs runtime verification.
- F2 Dev/Test mode: currently visible but lacks reliable phase simulation controls.
- G1 Token minting correctness (segment-driven tokens; multiplayer-only).
- G2 Bonus phase: trigger, visibility, and dev hooks for testing.
- I1 UI cleanup: remove stray/legacy UI artifacts.
- I2 Assets: canonical asset manifest + fallback behavior.

### 🧩 Canon items that still require a one-page lock-in table

- C2 Display modes: priority/stacking rules for Note Names vs Numbers vs Intervals vs Roman Numeral Interval.
- D2 Difficulty matrix: Learning/Easy/Medium/Hard rule table (labels, hints, SAM, mistake handling).
- D3 SAM: strict acceptance/visibility rules per mode (Any/Best/Designated) and how it interacts with difficulty.
- E1 Rail interactivity: when the rail is input vs reference vs inspection.
- Segment definition: what counts as a unique segment across content types (notes/chords/scales/arpeggios).

## Non-negotiable rules reinforced by the canon

- If a mode presents multiple inputs (staff + TAB + fretboard, etc.), the player must answer correctly on all required inputs or it is a miss.
- Staff pitch is the authoritative pitch source; TAB and fretboard must match it.
- “Not visible” means “marks hidden,” not “surface removed.”


---

## E) Refinements, Adjustments, and Fine Tuning (meta bucket)

This section is an **added tracking bucket** to reduce repeated regressions and “treading over the same issues.”

- It **does not** replace or renumber the DOCX canon’s **E) Generator / Rail System** section.
- It is a **cross-cutting** place to log the small-but-critical UI/UX and rendering correctness fixes that tend to reappear.
- Primary backlog location remains **`CHECKLIST.md` → M) Polish**.

### E1. Rendering correctness refinements

- Staff ledger lines **never** bleed into TAB.
- TAB renders **numbers**, not dots, and numbers are clipped to TAB bounds.
- Staff noteheads, stems, and ledger lines only render inside the staff’s clip group.
- Staff + TAB remain rhythmically aligned to the shared timing grid as spacing evolves.

### E2. Surface + layer semantics refinements

- “Not visible” hides **marks**, not the entire surface section.
- Layers remain: **Display / Prompt / Marks** (visual-only filters).
- Controller-owned mark state only (no view-owned state).

### E3. Interaction + usability refinements

- Touch targets remain full-size (no “half-hit” requirements for sharp/flat split visuals).
- Hitboxes remain stable across scaling and responsive layout.
- Input eligibility gating is respected (no accidental input on non-input surfaces).

### E4. Layout + spacing refinements

- Remove legacy resizing bars; center primary gameplay surfaces.
- Staff/TAB measure count adapts to available space (default 3, fewer on narrow screens).
- Prevent overlapping bounds between staff and TAB (strict separation).

### E5. Terminology + labeling refinements

- Use stable player-facing names (e.g., Display / Prompt / Marks) while preserving internal preference keys.
- Ensure “Surface Matrix” terminology is used consistently in UI labels and docs.

### E6. Documentation + versioning refinements

- Maintain a single canonical entrypoint (`README.md`).
- Ensure every build package updates logs and the canon progress marker.
