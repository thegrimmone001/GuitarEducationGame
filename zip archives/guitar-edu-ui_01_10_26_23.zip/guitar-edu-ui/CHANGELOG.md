# Changelog

Canon zip-to-zip changes for the Guitar Education Game UI.

## 2026-01-10 — Patch 01_10_26_16
- Fixed a phase constant mismatch that disabled input gating (`in_match` vs `IN_MATCH`).
- Implemented a **Surface Input Matrix** to define, per UI mode, which surfaces are required, accept input, and show placed marks.
- Added composite submission logic so **Staff drives pitch**, and (when required) **Fret + Tab must match** the same string/fret.
- Implemented TAB entry ordering: **string → fret** or **fret → string**, including retaining the selected TAB column.
- Fixed TAB default number handling to avoid null/default rendering issues.
- Cleaned up Staff+Tab overlay mark visibility toggling per UI mode.

## 2026-01-10 — Patch 01_10_26_17
- Aligned the Staff+Tab stage container id (`staffTabStage`) with the controller so surface-matrix gating applies reliably.
- Added **Surface Layers** checkboxes (**View / Asked / Answered**) and wired them into gameplay mark visibility (visual only; surfaces remain present).
- Added `rail.setLayers()` with view-layer label hiding and asked-layer target highlighting control.

## 2026-01-10 — Patch 01_10_26_18
- Renamed Surface Layers UI labels to **Display / Prompt / Marks** (was **View / Asked / Answered**) without changing underlying preference keys.

## 2026-01-10 — Patch 01_10_26_19
- Staff+TAB overlay: fixed geometry extraction for the 3-measure blank staff/TAB template.
  - Normalize STAFF to the core **5 lines** (for correct treble-line letter mapping).
  - Derive measure spans from repeated long line segments (robust even with shortened left-most measure lines for clef/TAB label).
  - Stabilizes column math and prevents TAB number placement from collapsing into a tiny segment.
  - Added a safe fallback `getBlank3MeasureStaffTabLayout()` so the overlay can stay correct even if the background is swapped to a raster asset (no SVG line primitives).

## 2026-01-10 — Patch 01_10_26_20
- Added root **`README.md`** as the canonical repo entrypoint.
- Documented the required **Thread Boot Protocol** and canon-doc read order to prevent cross-thread drift.
- Added **`CANON_PROGRESS.md`** to pin “where we are in the canon list” (A1.xx alignment crosswalk) and keep progress visible in the repo.

## 2026-01-10 — Patch 01_10_26_22
- Added a meta backlog bucket: **E) Refinements, Adjustments, and Fine Tuning** in `CANON_PROGRESS.md` to track recurring rendering/UX polish items and prevent regressions.
- Updated `README.md` to include `CANON_PROGRESS.md` in the canon-doc read order and highlight the Refinements bucket during Thread Boot.

## 2026-01-10 — Patch 01_10_26_23
- Added a multiplayer **Intermission overlay** that visibly represents the `INTERMISSION` phase between turns.
- Overlay includes a countdown timer and supports **tap/button to start the next turn early**.
- Turn start now explicitly clears intermission UI/timers to prevent stuck overlay states.
