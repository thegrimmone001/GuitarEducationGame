# DEFERRED ISSUE: MULTI_SURFACE_DESYNC (Now Active)

## Problem Definition
When STAFF, TAB, and FRETBOARD are active together, a user can enter what appears to be the same pitch on each surface, but the runtime validator rejects it or marks different pitches across surfaces. This presents as "surfaces disagree" even when the user selects a visually correct location.

## Root Cause
The project uses **two different string-index conventions**:

- **Canonical (SVG + engine):** string index **0 = high E (top)**, increasing downward to low E.
- **Controller tuning helper (pre-fix):** standard tuning MIDI array was **low→high**, causing `pitchClassFromStringFret()` to compute different MIDI/PC values than the engine (`pitchMidiAt()` / `pitchClassAt()`).

This mismatch breaks cross-surface pitch truth whenever TAB or STAFF validation relies on the controller-side tuning helper.

## Minimal Fix
Align `STANDARD_TUNING_MIDI` in `src/app/gameController.ts` to match the canonical **high→low** string order:

- Standard tuning is now defined as: `E4 B3 G3 D3 A2 E2` (high→low)

No other behavior is changed.

## Verification (Design-Level)
After the fix, the following invariant holds:

> For any (stringIndex, fret), the pitch computed by controller tuning helpers must match the engine helpers, assuming standard tuning.

This restores a single pitch-truth model across STAFF/TAB/FRETBOARD.
