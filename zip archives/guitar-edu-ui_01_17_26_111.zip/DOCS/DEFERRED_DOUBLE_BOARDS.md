# Deferred Issue Resolution — DOUBLE_BOARDS

## Problem Definition
The playfield can appear duplicated ("double boards") because both the SVG background host and the Canvas2D renderer can be visible at the same time. This produces overlapping fretboards and/or staff+tab visuals and makes the playfield confusing.

## Root Cause
Two visual pipelines exist concurrently:

1) **SVG background host**
- Fretboard background SVG is injected into `#fretBgHost` via `loadSvgIntoHost()` in `src/app/gameController.ts`.
- Staff/TAB template SVG is injected into `#staffBgHost` via `loadSvgIntoHost()` in `src/app/gameController.ts`.

2) **Canvas2D primary renderer**
- Fretboard is drawn to `#fretCanvas` by `FretboardRenderer2D` through `initCanvasRenderers()` in `src/render/RendererManager.ts`.
- Staff/TAB is drawn to `#staffCanvas` by `StaffTabRenderer2D` through `initCanvasRenderers()` in `src/render/RendererManager.ts`.

When both are visible, the user sees two overlapping boards.

## Minimal Fix
Hide SVG background hosts by default (CSS), while keeping SVG overlays for hitboxes/interaction:
- Update `src/styles.css` so `.svgHost` is `display:none`.

This preserves the SVG assets for geometry and layout parsing without allowing them to render as competing visuals.

## Verification
- With this patch, only the Canvas2D visuals are visible.
- SVG overlays remain active for pointer hitboxes and overlay marks.
- The background SVG content may still be injected for geometry parsing but will not be displayed.

## Files Changed
- `src/styles.css`
- `DOCS/DEFERRED_DOUBLE_BOARDS.md`
