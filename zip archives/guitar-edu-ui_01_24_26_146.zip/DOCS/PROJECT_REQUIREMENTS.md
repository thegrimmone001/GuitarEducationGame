# GLG — Project Requirements (Living)

This file is the **single place** to summarize the *current* requirements for the GLG UI/UX and menu system.

## 1) Canon compliance
- The repo must enforce a **canon gate** that prevents shipping changes when required docs were not read/applied.
- Any new decision made in chat must be written into canon docs (minimum: `DECISIONS_LOG.md`, `CHECKLIST.md`, and the relevant mapping doc).

## 2) Basic Initialization vs Advanced
### 2.1 Basic Initialization (must stay simple, high-frequency)
Basic Initialization is where a user should be able to start a normal session with minimal thinking.

Must include:
- Session / play intent
- Learning Type (Single Notes / Chords / Scales)
- Key + pitch framework
- Accidentals pool
- **Preset selector** (A–J)
- **Timer essentials** (fast picks):
  - Timer Mode: Off / Check Clock / Turn
  - Turn timer default: **10 seconds**

### 2.2 Advanced (deep configuration)
Advanced is for detail work and edge cases.

Must include:
- Full timer configuration (turn, match, player clock, game total, add-correct time)
- Surface controls matrix completion (Prompt/Mark/Display/SAM + cardinality)
- Instrument controls (non-default instrument/tuning) and other lower-frequency settings

## 3) Timers
- Default: players have **10-second turns** when Turn mode is selected.
- OFF must not zero-out saved timer values in UI state; values should persist and only be ignored by the engine when mode is off.
- Intermission is confirmation-gated (Start Turn / tap) and has **no timer control**.

Intermission note:
- Multiplayer intermission is confirmation-gated (no timer) and therefore has no adjustable control.

## 4) Presets
- Presets are A–J bundles that control prompt/mark/display behavior.
- Player-facing preset names must be **glanceable** and include a one-line description of what the player does.
- The authoritative A–J surface mapping lives in `PROJECT_NOTES.md` under “Surface Control System”.

## 5) Readability and theme
- No white-on-white (or low-contrast) UI states are acceptable.
- Provide a theme option:
  - **Auto** (follows browser/system prefers-color-scheme)
  - **Dark**
  - **Light**
- Theme choice must maintain contrast across panels, text, and controls.

## 6) Known current gameplay/rendering defects (tracked, not blocking menu work)
These issues are acknowledged but are explicitly **not** the current focus while menus are being stabilized:
- Fretboard/staff pick behaviors incorrect
- Note generator not working
- Layout/utility menus/task context not correct

