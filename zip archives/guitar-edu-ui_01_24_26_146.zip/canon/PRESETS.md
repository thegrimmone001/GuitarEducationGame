# Presets (A–J)

Presets are quick-start configurations. They set:

- **Prompt Surface**: where the question appears.
- **Required Input Surfaces**: where the player must answer (mark).
- **Allowed Input Surfaces**: where the player is permitted to answer.
- **Answer Persistence** per surface: whether correct answers remain visible after being marked (**Display** in UI).
- **Answer Set** and **Answer Count** defaults.

## Global defaults

- **Answer Set**: `single` (one specific instance of the note)
- **Answer Count**: `1`
- If multiple surfaces are required, the default rule is:
  - **Answer Count 1, single instance on each required surface.**

## Preset list

Abbreviations:

- `NR` = Note Rail
- `FB` = Fretboard
- `TAB` = Tab
- `→` = prompts shown on the left, answers required on the right

| ID | Name | Short | Prompt Surface | Required Input | Allowed Input | Persist (Display) |
|---:|------|-------|---------------|----------------|--------------|------------------|
| A | Fretboard Trainer | NR→FB | Note Rail | Fretboard | Fretboard | FB |
| B | Staff Trainer | NR→Staff | Note Rail | Staff | Staff | Staff |
| C | TAB Trainer | NR→TAB | Note Rail | TAB | TAB | TAB |
| D | Fretboard + Staff | NR→FB+Staff | Note Rail | Fretboard, Staff | Fretboard, Staff | FB, Staff |
| E | Fretboard + TAB | NR→FB+TAB | Note Rail | Fretboard, TAB | Fretboard, TAB | FB, TAB |
| F | Staff + TAB | NR→Staff+TAB | Note Rail | Staff, TAB | Staff, TAB | Staff, TAB |
| G | Fretboard + Staff + TAB | NR→FB+Staff+TAB | Note Rail | Fretboard, Staff, TAB | Fretboard, Staff, TAB | FB, Staff, TAB |
| H | Note Rail Answer (from Fretboard) | FB→NR | Fretboard | Note Rail | Note Rail | FB, NR |
| I | Note Rail Answer (from Staff) | Staff→NR | Staff | Note Rail | Note Rail | Staff, NR |
| J | Note Rail Answer (from TAB) | TAB→NR | TAB | Note Rail | Note Rail | TAB, NR |

## Notes on persistence

- **Persist** means correct answers remain visible after being marked.
- For learning modes, persistence is usually on for required input surfaces.
- For drill modes, persistence can be turned off to avoid memorization effects.
