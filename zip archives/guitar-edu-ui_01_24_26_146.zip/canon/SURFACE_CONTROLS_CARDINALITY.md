# Surface Controls: Answer Cardinality, Sets, and Scope

This document defines the rules behind **marks/answers** when one or more surfaces require input.

## Terminology

- **Prompt Surface**: the surface that asks the question (where the note/chord/scale is presented).
- **Input / Mark**: the player's answer placed on a surface.
- **Display** (UI term): **answer persistence**. When enabled, correct answers remain visible after being marked.
  - Display is **not** board visibility. All boards are always visible.

## Answer Set

Answer Set describes *which candidates count as correct*.

- **Single** (default): one specific instance is correct.
- **Equivalent** (future): any note of the same pitch (enharmonic + octave equivalents as defined by the current ruleset).
- **All** (future): any note of the same name.

## Answer Count

Answer Count describes *how many correct marks are required to satisfy the prompt*.

- Default: **1**.
- The system must support 1, 2, 3, 4, … as selectable values.

### Multi-surface default rule

When multiple surfaces are configured as **Required Input**, the default behavior is:

- **Answer Count 1** and **Single instance** on **each required surface**.

This makes it possible to require, for example, staff and tab answers while also requiring the fretboard.

## Surface Scope (Prompt and Answer distribution)

Surface Scope controls how prompts and/or required answers are distributed when more than one surface is eligible.

Planned scope values:

- **Single**: one specified surface only.
- **Rotating**: cycle through a surface list in order (deterministic).
- **Random**: choose one surface at random from the eligible list.
- **All**: show/require on all eligible surfaces simultaneously.

Scope is intended to be configurable **per surface** (or per surface group) so combinations like the following are possible:

- Prompt from Note Rail, always require Fretboard input, and rotate required answers between Staff and TAB.

