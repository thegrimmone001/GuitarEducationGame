# Menu Docs Patch — 2026-01-24

This patch updates canon documents to reflect decisions made in chat that were not recorded, specifically:
- Preset A–J authoritative mapping is confirmed to exist in PROJECT_NOTES.md.
- Preset picker must show a short task-focused description (UI/UX requirement).
- Theme selector requirement: Auto (browser), Dark, Light with guaranteed contrast.
- Timer OFF must preserve timer parameters (no zeroing).

## How to apply
Replace the corresponding files in your repo root:
- DECISIONS_LOG.md
- CHECKLIST.md

No code changes are included in this patch.
