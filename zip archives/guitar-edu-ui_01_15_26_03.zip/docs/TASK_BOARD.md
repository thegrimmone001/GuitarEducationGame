# TASK BOARD

| ID | Task | Status | Notes |
|----|------|--------|-------|
| GEG-001 | Restore rendering integrity (staff/tab/fretboard/note rail) | DONE | Force Canvas2D surfaces to repaint during `renderAll()` so panels cannot remain blank after splash/visibility transitions. |

| GEG-002 | Add Copy button for Event Log + fix Note Rail init ordering | DONE | Copy-to-clipboard for rapid bug reports; prevents TDZ init hazard |
