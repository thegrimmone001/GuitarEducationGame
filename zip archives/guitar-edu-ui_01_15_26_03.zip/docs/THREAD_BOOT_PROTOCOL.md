# THREAD BOOT PROTOCOL

This document defines how ChatGPT operates on this project.

## Precedence
1. MATCH_SETTINGS_SPEC.md
2. DECISIONS_LOG.md
3. CODE
4. MEMORY

## Rules
- No deprecated terminology
- No speculative features
- Batch execution only
- Always return a versioned zip snapshot

## Output Requirements
- CHANGELOG.md updated
- BUILD_LOG.md updated
- TASK_BOARD.md updated
