import "./styles.css";
import { mountLayout } from "./ui/layout";
import { initGameController } from "./app/gameController";
import { hydrateFromIndexedDb } from "./shell/storage";
import { installEventLog } from "./app/eventLog";

const app = document.getElementById("app");
if (!app) throw new Error("#app not found");

mountLayout(app);
installEventLog(document);

// Engine-backed controller (merged from the shell version into the new layout).
// IMPORTANT: initialize the controller immediately so UI events (enterUI, beginSession, etc.)
// cannot fire before listeners are attached. Hydration runs after and should never block wiring.
initGameController(document);

// Hydrate any persisted snapshot (USB/offline friendly) AFTER controller wiring.
(async () => {
  try {
    await hydrateFromIndexedDb();
  } catch {
    /* ignore */
  }
})();

