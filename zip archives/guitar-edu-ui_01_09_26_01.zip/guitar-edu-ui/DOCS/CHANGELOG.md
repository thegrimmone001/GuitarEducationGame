# Changelog (project zips)

## Step 14.1 (Regression cleanup)
- Replaced fretboard SVG with `Guitar_FretBoard_Horizontal-Complete_v2i.svg` content (better aligned hitbox art).
- Restored Note Visibility selector to include **All** and set default to **All**.
- Restored controller defaults for `core.noteVisibility` to **all** (was regressed to naturals).
- Fixed minor indentation regression in controller settings change handler.
- Confirmed project zips must not include `node_modules/` or `dist/`.

## 01_06_26_03 (Step A1 — Notation stabilization, foundation)
- STAFF overlay renders engraving-style **noteheads** with **stems** (quarter-note default styling for now).
- STAFF and TAB marks are split into separate SVG groups: `geduStaffMarks` and `geduTabMarks`.
  - Enables independent visibility toggles.
  - Prevents STAFF ledger/engraving artifacts from bleeding into TAB.
- Added a minimal **4/4 time signature** rendering layer (key signature wiring deferred until key-context is unified).
- Added `src/shell/notation.ts` providing canonical mapping primitives from **spelled pitch** to **treble staff yIndex**.
- Added the merged canonical guide document into `DOCS/` for in-project reference.

## 01_09_26_01 (Spec sync — Turn model, match setup locking, steal policy, analytics)
- Updated documentation to reflect current canon:
  - Turn Mode is match-locked (default **Play Until Miss**; option **Single Input Per Turn**).
  - Bonus Turn timing: starts at **30s**, **+3s** per correct, **first miss ends**; token→time during Bonus Turn: **1 token = +5s**.
  - MatchConfig is inaccessible during gameplay (no queued changes).
  - Steal Eligibility Policy (S1 vulnerability-gated default; S2 token-based anytime); blinking never consumes tokens.
  - Steal requires current required note from generator; vulnerability can expand to multiple notes after threshold.
  - Expanded metadata/analytics scope (heat maps, recall metrics, representation-specific knowledge).

