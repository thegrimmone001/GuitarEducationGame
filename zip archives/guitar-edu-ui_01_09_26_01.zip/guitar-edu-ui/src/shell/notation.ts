// Canon notation utilities.
//
// Goal: provide a deterministic bridge between pitch (note spelling) and staff
// placement (diatonic steps), supporting future MusicXML-grade engraving.
//
// IMPORTANT: This module does not attempt full engraving. It provides the core
// mapping primitives so STAFF/TAB/FRETBOARD can share a single truth engine.

import type { StaffTabLayout } from "./staffTabOverlay";

export type Accidental = "nat" | "sharp" | "flat";

export interface SpelledPitch {
  pc: number; // 0-11
  octave: number; // scientific pitch, e.g., C4
  accidental: Accidental;
}

// Diatonic step within an octave: C=0 ... B=6
function diatonicStepForPc(pc: number, accidental: Accidental): number {
  const p = ((pc % 12) + 12) % 12;

  // Natural pitch classes
  // C 0, D 2, E 4, F 5, G 7, A 9, B 11
  // For accidentals, we map to the spelled note letter, not the pitch class alone.
  switch (p) {
    case 0: return 0; // C
    case 2: return 1; // D
    case 4: return 2; // E
    case 5: return 3; // F
    case 7: return 4; // G
    case 9: return 5; // A
    case 11: return 6; // B

    // Black keys: choose the diatonic letter based on spelling intent.
    // C#/Db
    case 1: return accidental === "flat" ? 1 : 0;
    // D#/Eb
    case 3: return accidental === "flat" ? 2 : 1;
    // F#/Gb
    case 6: return accidental === "flat" ? 4 : 3;
    // G#/Ab
    case 8: return accidental === "flat" ? 5 : 4;
    // A#/Bb
    case 10: return accidental === "flat" ? 6 : 5;
    default:
      return 0;
  }
}

function absDiatonicStep(p: SpelledPitch): number {
  return p.octave * 7 + diatonicStepForPc(p.pc, p.accidental);
}

// Treble clef baseline for guitar written pitch:
// Bottom line of the staff is E4 in treble clef.
const E4_ABS_STEP = 4 * 7 + 2; // octave 4, E (C=0,D=1,E=2)

/**
 * Convert a spelled pitch into the closest staff yIndex within the current SVG layout.
 *
 * The returned yIndex corresponds to layout.staff.stepCenters.
 *
 * This is the canonical mapping used to ensure staff rendering is not a fixed vertical slot.
 */
export function staffYIndexForTreble(layout: StaffTabLayout, pitch: SpelledPitch): number {
  const staffLines = layout.staff.lineYs;
  const bottomLineY = staffLines[staffLines.length - 1] ?? 0;

  // Find the step index whose center matches the bottom staff line.
  let bottomIndex = 0;
  let best = Infinity;
  for (let i = 0; i < layout.staff.stepCenters.length; i++) {
    const d = Math.abs(layout.staff.stepCenters[i] - bottomLineY);
    if (d < best) { best = d; bottomIndex = i; }
  }

  const deltaSteps = absDiatonicStep(pitch) - E4_ABS_STEP;
  // Higher pitch moves up (smaller y), which is lower yIndex.
  return bottomIndex - deltaSteps;
}
