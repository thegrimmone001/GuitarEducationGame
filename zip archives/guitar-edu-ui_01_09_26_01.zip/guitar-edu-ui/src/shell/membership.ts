import { GameSettings, PitchClass } from "./types";
import { IS_BLACK } from "./music";

// Canon A6: Single source of truth for pitch-class membership.
//
// Key rule:
// - Chromatic is a Mode. When Chromatic is active, keyContext is an anchor/spelling bias only;
//   it MUST NOT restrict pitch-class membership.
// - For non-chromatic scale/key modes, membership is constrained by root + mode intervals.
// - Accidentals study mode: membership is black-key pitch classes only.

export type MembershipKind = "chromatic" | "accidentals" | "scale";
export type SpellingPreference = "sharps" | "flats";

// Relative interval sets (pitch classes) for supported modes.
const IONIAN = [0, 2, 4, 5, 7, 9, 11];
const DORIAN = [0, 2, 3, 5, 7, 9, 10];
const PHRYGIAN = [0, 1, 3, 5, 7, 8, 10];
const LYDIAN = [0, 2, 4, 6, 7, 9, 11];
const MIXOLYDIAN = [0, 2, 4, 5, 7, 9, 10];
const AEOLIAN = [0, 2, 3, 5, 7, 8, 10];
const LOCRIAN = [0, 1, 3, 5, 6, 8, 10];
const PENTATONIC = [0, 2, 4, 7, 9];
const BLUES = [0, 3, 5, 6, 7, 10];

export type ScaleMode =
  | "maj" | "major" | "ionian"
  | "min" | "minor" | "aeolian"
  | "dorian" | "phrygian" | "lydian" | "mixolydian" | "locrian"
  | "pentatonic" | "blues";

function intervalsForMode(mode: ScaleMode): number[] {
  switch (mode) {
    case "maj":
    case "major":
    case "ionian":
      return IONIAN;
    case "min":
    case "minor":
    case "aeolian":
      return AEOLIAN;
    case "dorian":
      return DORIAN;
    case "phrygian":
      return PHRYGIAN;
    case "lydian":
      return LYDIAN;
    case "mixolydian":
      return MIXOLYDIAN;
    case "locrian":
      return LOCRIAN;
    case "pentatonic":
      return PENTATONIC;
    case "blues":
      return BLUES;
  }
}

function pcFromNoteName(name: string): number | null {
  const n = name.trim().toUpperCase();
  const map: Record<string, number> = {
    C: 0, "C#": 1, DB: 1,
    D: 2, "D#": 3, EB: 3,
    E: 4,
    F: 5, "F#": 6, GB: 6,
    G: 7, "G#": 8, AB: 8,
    A: 9, "A#": 10, BB: 10,
    B: 11,
  };
  return map[n] ?? null;
}

function keyContextToPref(keyContext: string | undefined | null): SpellingPreference | null {
  const kc = (keyContext ?? "none").trim();
  if (!kc || kc === "none") return null;
  const flatKeys = new Set(["F", "Bb", "Eb", "Ab", "Db", "Gb", "Cb"]);
  const sharpKeys = new Set(["G", "D", "A", "E", "B", "F#", "C#"]);
  if (flatKeys.has(kc)) return "flats";
  if (sharpKeys.has(kc)) return "sharps";
  // C (or unknown) provides no preference.
  return null;
}

export interface MembershipResult {
  kind: MembershipKind;
  // 1 means allowed
  allowedPitchClasses: Uint8Array; // length 12
  // For black-key naming/rail bias.
  pref: SpellingPreference | null;
  // Root is meaningful for scale/key modes.
  rootPc: PitchClass | null;
  mode: ScaleMode | null;
}

// Parse the existing promptProfileId format into a membership definition.
// This stays compatible with current saves and UI, while centralizing the logic.
export function deriveMembership(settings: GameSettings): MembershipResult {
  const profileId = (settings.promptProfileId ?? "chromatic").trim();
  const lower = profileId.toLowerCase();

  // Chromatic (explicit)
  if (lower === "chromatic" || lower.startsWith("chromatic:")) {
    const allowed = new Uint8Array(12);
    for (let pc = 0; pc < 12; pc++) allowed[pc] = 1;
    return {
      kind: "chromatic",
      allowedPitchClasses: allowed,
      pref: keyContextToPref((settings as any).keyContext),
      rootPc: null,
      mode: null,
    };
  }

  // Accidentals study mode
  if (lower === "accidentals" || lower.startsWith("accidentals:")) {
    const allowed = new Uint8Array(12);
    for (let pc = 0; pc < 12; pc++) allowed[pc] = IS_BLACK[pc] ? 1 : 0;
    // If a keyContext exists, it can still bias display, but membership is black keys only.
    return {
      kind: "accidentals",
      allowedPitchClasses: allowed,
      pref: keyContextToPref((settings as any).keyContext),
      rootPc: null,
      mode: null,
    };
  }

  // Existing format: kind:root:mode:pref
  const parts = profileId.split(":").map(s => s.trim());
  const rootName = parts[1] || "";
  const modePart = (parts[2] || "").toLowerCase();
  const prefPart = (parts[3] || "").toLowerCase();

  const isMode = (m: string): m is ScaleMode => {
    return [
      "maj","major","ionian",
      "min","minor","aeolian",
      "dorian","phrygian","lydian","mixolydian","locrian",
      "pentatonic","blues",
    ].includes(m);
  };

  const rootPcNum = pcFromNoteName(rootName);
  const mode = isMode(modePart) ? modePart : null;

  const pref: SpellingPreference | null =
    prefPart === "flats" ? "flats"
    : prefPart === "sharps" ? "sharps"
    : keyContextToPref((settings as any).keyContext);

  if (rootPcNum === null || mode === null) {
    // Fallback: naturals only membership (legacy-safe)
    const allowed = new Uint8Array(12);
    for (let pc = 0; pc < 12; pc++) allowed[pc] = IS_BLACK[pc] ? 0 : 1;
    return {
      kind: "scale",
      allowedPitchClasses: allowed,
      pref,
      rootPc: null,
      mode: null,
    };
  }

  const rootPc = rootPcNum as PitchClass;
  const allowed = new Uint8Array(12);
  for (const step of intervalsForMode(mode)) {
    const pc = (rootPc + step) % 12;
    allowed[pc] = 1;
  }

  return {
    kind: "scale",
    allowedPitchClasses: allowed,
    pref,
    rootPc,
    mode,
  };
}
