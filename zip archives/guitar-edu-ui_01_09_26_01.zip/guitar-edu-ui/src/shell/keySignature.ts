// Canon key signature + accidental necessity utilities.
// This module provides deterministic, engraving-consistent behavior for:
// - Key signature rendering (major keys for now)
// - Accidentals "as needed" relative to the selected key context
// - Spelling preference (sharps vs flats) for context-dependent views

import { SlotType } from "./types";
import { IS_BLACK } from "./music";

export type Letter = "A" | "B" | "C" | "D" | "E" | "F" | "G";
export type Accidental = "nat" | "sharp" | "flat";
export type KeySigSide = "sharps" | "flats";

/** Major key signature side and count. "none" and "C" map to count 0. */
export function keySignatureSide(keyContext: string | undefined | null): KeySigSide | null {
  const k = (keyContext ?? "none").trim();
  if (!k || k === "none" || k === "C") return null;
  const flatKeys = new Set(["F", "Bb", "Eb", "Ab", "Db", "Gb", "Cb"]);
  const sharpKeys = new Set(["G", "D", "A", "E", "B", "F#", "C#"]);
  if (flatKeys.has(k)) return "flats";
  if (sharpKeys.has(k)) return "sharps";
  return null;
}

export function keySignatureCount(keyContext: string | undefined | null): number {
  const k = (keyContext ?? "none").trim();
  if (!k || k === "none" || k === "C") return 0;
  const counts: Record<string, number> = {
    // Sharps
    "G": 1, "D": 2, "A": 3, "E": 4, "B": 5, "F#": 6, "C#": 7,
    // Flats
    "F": 1, "Bb": 2, "Eb": 3, "Ab": 4, "Db": 5, "Gb": 6, "Cb": 7,
  };
  return counts[k] ?? 0;
}

/** Letters altered by the key signature (e.g., in G: {F:'sharp'}). */
export function keySignatureLetterMap(keyContext: string | undefined | null): Partial<Record<Letter, Accidental>> {
  const side = keySignatureSide(keyContext);
  const count = keySignatureCount(keyContext);
  const map: Partial<Record<Letter, Accidental>> = {};
  if (!side || count <= 0) return map;

  const sharpOrder: Letter[] = ["F","C","G","D","A","E","B"];
  const flatOrder: Letter[] = ["B","E","A","D","G","C","F"];
  const order = side === "sharps" ? sharpOrder : flatOrder;
  for (let i = 0; i < Math.min(count, order.length); i++) {
    map[order[i]] = side === "sharps" ? "sharp" : "flat";
  }
  return map;
}

/**
 * Convert a VariantId (pc*3+slot) to a spelled letter+accidental (no double accidentals).
 * NAT lane uses natural names for white keys; black keys must use SHR/FLT lanes to be valid.
 */
export function variantToLetterAccidental(pc: number, slot: number): { letter: Letter; accidental: Accidental } {
  // Natural lane: choose natural letter for white keys.
  if (slot === SlotType.NAT) {
    // pc -> natural letter mapping (C D E F G A B)
    const map: Record<number, Letter> = { 0:"C", 2:"D", 4:"E", 5:"F", 7:"G", 9:"A", 11:"B" };
    const letter = map[pc] ?? "C";
    return { letter, accidental: "nat" };
  }

  // Sharp spelling table
  const sharpLetters: Letter[] = ["C","C","D","D","E","F","F","G","G","A","A","B"];
  const sharpAcc: Accidental[] = ["nat","sharp","nat","sharp","nat","nat","sharp","nat","sharp","nat","sharp","nat"];

  // Flat spelling table
  const flatLetters: Letter[]  = ["C","D","D","E","E","F","G","G","A","A","B","B"];
  const flatAcc: Accidental[]  = ["nat","flat","nat","flat","nat","nat","flat","nat","flat","nat","flat","nat"];

  if (slot === SlotType.SHR) return { letter: sharpLetters[pc] ?? "C", accidental: sharpAcc[pc] ?? "nat" };
  if (slot === SlotType.FLT) return { letter: flatLetters[pc] ?? "C", accidental: flatAcc[pc] ?? "nat" };

  return { letter: "C", accidental: "nat" };
}

/**
 * Determine which accidental glyph must be rendered "as needed" relative to the key signature.
 * Returns null when no glyph is required (key signature already implies the spelling).
 *
 * Rules:
 * - If key signature alters the pitch's letter and the target accidental differs, render the needed accidental.
 * - If no key signature (or keyContext none), render sharps/flats for black keys; naturals render nothing.
 */
export function accidentalToRender(pc: number, slot: number, keyContext: string | undefined | null): Accidental | null {
  const { letter, accidental } = variantToLetterAccidental(pc, slot);
  const implied = keySignatureLetterMap(keyContext)[letter] ?? "nat";

  // If key signature implies the same accidental, no glyph is needed.
  if (implied === accidental) return null;

  // If key signature implies something else, render whatever is needed to reach the target.
  // Natural signs are required when key implies sharp/flat but the target is natural.
  if (accidental === "nat") return "nat";
  return accidental;
}

/**
 * Apply context-dependent spelling preference:
 * - In "context" visibility, keep all pitch classes but restrict black-key lanes to sharps or flats,
 *   based on the selected key context. If keyContext is none/unknown, keep both.
 */
export function applyContextSpellingPreference(allowed: Uint8Array, keyContext: string | undefined | null): Uint8Array {
  const side = keySignatureSide(keyContext);
  if (!side) return allowed;

  for (let pc = 0; pc < 12; pc++) {
    if (!IS_BLACK[pc]) continue;
    const i = pc * 3;
    if (side === "sharps") allowed[i + SlotType.FLT] = 0;
    if (side === "flats") allowed[i + SlotType.SHR] = 0;
    // Black keys have no natural spelling.
    allowed[i + SlotType.NAT] = 0;
  }
  return allowed;
}
