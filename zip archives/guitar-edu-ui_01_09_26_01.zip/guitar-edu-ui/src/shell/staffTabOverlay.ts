import { keySignatureCount, keySignatureSide, keySignatureLetterMap, variantToLetterAccidental } from "./keySignature";

const SVG_NS = "http://www.w3.org/2000/svg";

export type StaffTabRegion = "staff" | "tab";

export interface StaffTabLayout {
  viewBox: { x: number; y: number; w: number; h: number };
  measures: Array<{ x0: number; x1: number }>;
  columnsPerMeasure: number;
  staff: {
    lineYs: number[]; // 5 values
    halfStep: number; // lineGap / 2
    stepCenters: number[]; // includes a small ledger margin
    yMin: number;
    yMax: number;
  };
  tab: {
    lineYs: number[]; // 6 values
    stringBands: number[]; // 7 values
    yMin: number;
    yMax: number;
  };
}

export interface StaffTabHit {
  region: StaffTabRegion;
  measureIndex: number;
  colInMeasure: number;
  col: number; // global column across all measures
  yIndex: number; // staff step index OR string index
  rect: { x: number; y: number; w: number; h: number };
  cx: number;
  cy: number;
}

// Rhythm grid helper (A8)
// Converts a global column index into measure/beat/subdivision information.
//
// Notes:
// - We assume 4/4 for now (beatsPerMeasure = 4). This is a guardrail layer
//   that will later generalize when time signatures become first-class.
// - This function is intentionally pure and reusable by:
//     * rendering (stronger beat grid lines)
//     * controllers (cursor advance / snapping)
//     * validators (future rhythm-aware checks)
export interface RhythmColInfo {
  measureIndex: number;
  colInMeasure: number;
  beatIndex: number; // 0..3 in 4/4
  subIndex: number; // 0..(beatCols-1)
  isMeasureBoundary: boolean;
  isBeatBoundary: boolean;
}

export function rhythmInfoFromCol(layout: StaffTabLayout, col: number, beatsPerMeasure = 4): RhythmColInfo {
  const measureIndex = Math.max(0, Math.floor(col / layout.columnsPerMeasure));
  const colInMeasure = ((col % layout.columnsPerMeasure) + layout.columnsPerMeasure) % layout.columnsPerMeasure;
  const beatCols = layout.columnsPerMeasure / beatsPerMeasure;
  const beatColsInt = Number.isInteger(beatCols) && beatCols > 0 ? beatCols : 0;
  const beatIndex = beatColsInt > 0 ? Math.floor(colInMeasure / beatColsInt) : 0;
  const subIndex = beatColsInt > 0 ? colInMeasure % beatColsInt : colInMeasure;
  const isMeasureBoundary = colInMeasure === 0;
  const isBeatBoundary = beatColsInt > 0 ? colInMeasure % beatColsInt === 0 : false;
  return { measureIndex, colInMeasure, beatIndex, subIndex, isMeasureBoundary, isBeatBoundary };
}

function num(v: string | null): number | null {
  if (v == null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function uniqCluster(values: number[], eps = 0.02): number[] {
  const s = [...values].sort((a, b) => a - b);
  const out: number[] = [];
  for (const v of s) {
    const last = out[out.length - 1];
    if (last == null || Math.abs(last - v) > eps) out.push(v);
  }
  return out;
}

function parseViewBox(svgText: string): { x: number; y: number; w: number; h: number } {
  const m = svgText.match(/viewBox=\"([^\"]+)\"/);
  if (!m) throw new Error("Staff SVG missing viewBox");
  const parts = m[1]
    .trim()
    .split(/[ ,]+/)
    .map(Number)
    .filter((n) => Number.isFinite(n));
  if (parts.length !== 4) throw new Error("Invalid viewBox");
  return { x: parts[0], y: parts[1], w: parts[2], h: parts[3] };
}

export function parseStaffTabLayout(svgText: string, columnsPerMeasure = 16): StaffTabLayout {
  const viewBox = parseViewBox(svgText);

  const dom = new DOMParser().parseFromString(svgText, "image/svg+xml");

  // Horizontal lines
  const lines = Array.from(dom.querySelectorAll("line"))
    .map((l) => {
      const x1 = num(l.getAttribute("x1"));
      const x2 = num(l.getAttribute("x2"));
      const y1 = num(l.getAttribute("y1"));
      const y2 = num(l.getAttribute("y2"));
      if (x1 == null || x2 == null || y1 == null || y2 == null) return null;
      if (Math.abs(y1 - y2) > 1e-3) return null;
      return { x1: Math.min(x1, x2), x2: Math.max(x1, x2), y: y1 };
    })
    .filter(Boolean) as Array<{ x1: number; x2: number; y: number }>;

  const yVals = uniqCluster(lines.map((l) => l.y));
  if (yVals.length < 11) {
    throw new Error(`Unexpected staff/tab line count: ${yVals.length}`);
  }

  // Split into 2 groups using the biggest Y gap.
  const ys = [...yVals].sort((a, b) => a - b);
  let bestGap = -1;
  let cut = 0;
  for (let i = 0; i < ys.length - 1; i++) {
    const g = ys[i + 1] - ys[i];
    if (g > bestGap) {
      bestGap = g;
      cut = i + 1;
    }
  }
  const g1 = ys.slice(0, cut);
  const g2 = ys.slice(cut);

  // Staff should be the group with 5 lines; tab the group with 6 lines.
  const staffYs = g1.length === 5 ? g1 : g2.length === 5 ? g2 : g1;
  const tabYs = g1.length === 6 ? g1 : g2.length === 6 ? g2 : g2;

  const staffLines = [...staffYs].sort((a, b) => a - b);
  const tabLines = [...tabYs].sort((a, b) => a - b);

  if (staffLines.length !== 5 || tabLines.length !== 6) {
    // Fail soft: still return something usable.
    // (Some SVGs may include extra ledger lines or title elements.)
  }

  // Measure segments from the staff lines: unique (x1,x2) pairs.
  const segKeys = new Set<string>();
  const segs: Array<{ x0: number; x1: number }> = [];
  for (const l of lines) {
    if (Math.abs(l.y - staffLines[0]) < 0.2 || Math.abs(l.y - staffLines[staffLines.length - 1]) < 0.2) {
      const x0 = l.x1;
      const x1 = l.x2;
      const key = `${x0.toFixed(3)}-${x1.toFixed(3)}`;
      if (!segKeys.has(key)) {
        segKeys.add(key);
        segs.push({ x0, x1 });
      }
    }
  }
  segs.sort((a, b) => a.x0 - b.x0);

  // If SVG doesn't provide explicit segments, fall back to a single full-width segment.
  if (segs.length === 0) {
    const minX = Math.min(...lines.map((l) => l.x1));
    const maxX = Math.max(...lines.map((l) => l.x2));
    segs.push({ x0: minX, x1: maxX });
  }

  // Staff steps (line + space grid). One diatonic step = half a line gap.
  const staffGap = staffLines.length >= 2 ? (staffLines[1] - staffLines[0]) : 8;
  const halfStep = staffGap / 2;
  const staffTop = staffLines[0] ?? 0;
  const staffBottom = staffLines[staffLines.length - 1] ?? staffTop + 4 * staffGap;

  // Include ample ledger steps above and below to support future pitch ranges and
  // smaller rhythmic subdivisions without reworking the hit grid. Each "step" is
  // a line or space (half a staff line gap).
  const extra = 14;
  const stepCenters: number[] = [];
  const stepCount = (staffLines.length - 1) * 2 + 1 + extra * 2; // e.g., 9 + 4 = 13
  const startY = staffTop - extra * halfStep;
  for (let i = 0; i < stepCount; i++) stepCenters.push(startY + i * halfStep);

  const staffYMin = staffTop - (extra + 1) * halfStep;
  const staffYMax = staffBottom + (extra + 1) * halfStep;

  // Tab bands for string selection.
  const tabGap = tabLines.length >= 2 ? (tabLines[1] - tabLines[0]) : 10;
  const bands: number[] = [];
  bands.push((tabLines[0] ?? 0) - tabGap / 2);
  for (let i = 0; i < tabLines.length - 1; i++) bands.push((tabLines[i] + tabLines[i + 1]) / 2);
  bands.push((tabLines[tabLines.length - 1] ?? 0) + tabGap / 2);

  const tabYMin = bands[0];
  const tabYMax = bands[bands.length - 1];

  return {
    viewBox,
    measures: segs,
    columnsPerMeasure,
    staff: { lineYs: staffLines, halfStep, stepCenters, yMin: staffYMin, yMax: staffYMax },
    tab: { lineYs: tabLines, stringBands: bands, yMin: tabYMin, yMax: tabYMax },
  };
}

export function hitTestStaffTab(layout: StaffTabLayout, x: number, y: number): StaffTabHit | null {
  // Find measure segment
  let measureIndex = -1;
  for (let i = 0; i < layout.measures.length; i++) {
    const m = layout.measures[i];
    if (x >= m.x0 && x <= m.x1) {
      measureIndex = i;
      break;
    }
  }
  if (measureIndex < 0) return null;

  const m = layout.measures[measureIndex];
  const w = Math.max(1e-6, m.x1 - m.x0);
  const colW = w / layout.columnsPerMeasure;
  const colInMeasure = Math.max(0, Math.min(layout.columnsPerMeasure - 1, Math.floor((x - m.x0) / colW)));
  const col = measureIndex * layout.columnsPerMeasure + colInMeasure;

  // Region
  if (y >= layout.staff.yMin && y <= layout.staff.yMax) {
    // staff
    const steps = layout.staff.stepCenters;
    let best = 0;
    let bestD = Infinity;
    for (let i = 0; i < steps.length; i++) {
      const d = Math.abs(steps[i] - y);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }

    const cy = steps[best];
    const rectH = layout.staff.halfStep * 2;
    const rectY = cy - rectH / 2;

    return {
      region: "staff",
      measureIndex,
      colInMeasure,
      col,
      yIndex: best,
      rect: { x: m.x0 + colInMeasure * colW, y: rectY, w: colW, h: rectH },
      cx: m.x0 + colInMeasure * colW + colW / 2,
      cy,
    };
  }

  if (y >= layout.tab.yMin && y <= layout.tab.yMax) {
    // tab
    let stringIndex = -1;
    const b = layout.tab.stringBands;
    for (let i = 0; i < b.length - 1; i++) {
      if (y >= b[i] && y < b[i + 1]) {
        stringIndex = i;
        break;
      }
    }
    if (stringIndex < 0) return null;

    const y0 = layout.tab.stringBands[stringIndex];
    const y1 = layout.tab.stringBands[stringIndex + 1];
    const cy = (y0 + y1) / 2;

    return {
      region: "tab",
      measureIndex,
      colInMeasure,
      col,
      yIndex: stringIndex,
      rect: { x: m.x0 + colInMeasure * colW, y: y0, w: colW, h: y1 - y0 },
      cx: m.x0 + colInMeasure * colW + colW / 2,
      cy,
    };
  }

  return null;
}

function svgEl<K extends keyof SVGElementTagNameMap>(tag: K, attrs: Record<string, string> = {}): SVGElementTagNameMap[K] {
  const n = document.createElementNS(SVG_NS, tag) as SVGElementTagNameMap[K];
  for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
  return n;
}

function ensureGroup(svg: SVGSVGElement, id: string): SVGGElement {
  let g = svg.querySelector(`#${id}`) as SVGGElement | null;
  if (!g) {
    g = document.createElementNS(SVG_NS, "g") as SVGGElement;
    g.id = id;
    g.setAttribute("pointer-events", "none");
    svg.appendChild(g);
  }
  return g;
}

function ensureSubGroup(parent: SVGGElement, id: string): SVGGElement {
  let g = parent.querySelector(`#${id}`) as SVGGElement | null;
  if (!g) {
    g = document.createElementNS(SVG_NS, "g") as SVGGElement;
    g.id = id;
    g.setAttribute("pointer-events", "none");
    parent.appendChild(g);
  }
  return g;
}

export interface StaffTabOverlayState {
  hover: StaffTabHit | null;
  /**
   * If true, the overlay renders only interactive hitboxes/hover feedback.
   * All visual engraving (staff lines, clef, signatures, notes, TAB numbers)
   * must be rendered by the canvas-based notation renderer.
   */
  hitboxesOnly?: boolean;
  // Selected key context for engraving (major keys for now). Use "none" for no key signature.
  keyContext: string;
  // Subdivision-aligned marks.
  //
  // NOTE: For now we store at most one STAFF mark and one TAB mark per subdivision column.
  // This enforces tight visual alignment between STAFF and TAB while we build out the
  // grid + hitboxes. Later (chords/polyphony) can expand these to arrays per column.
  staffMarksByCol: Map<number, { yIndex: number; variantId?: number; accidental?: "nat" | "sharp" | "flat" }>; // col -> staff yIndex (+ spelling)
  tabMarksByCol: Map<number, { stringIndex: number; fret: number }>; // col -> TAB string + fret
  // The default fret number to stamp when clicking the TAB surface.
  // The controller can update this as the player interacts with the keypad.
  tabDefaultNumber: number;

  // Cursor for placing successive prompt notes into rhythmic columns.
  // This is a visual/notation cursor only (not gameplay scoring).
  promptColCursor: number;
  // Tracks the last rendered prompt so we can advance the cursor deterministically.
  lastPromptVariantId: string | null;
}

export function createStaffTabOverlayState(): StaffTabOverlayState {
  return {
    hover: null,
    hitboxesOnly: true,
    keyContext: "none",
    staffMarksByCol: new Map(),
    tabMarksByCol: new Map(),
    tabDefaultNumber: 0,
    promptColCursor: 0,
    lastPromptVariantId: null,
  };
}

export function renderStaffTabOverlay(svg: SVGSVGElement, layout: StaffTabLayout, s: StaffTabOverlayState): void {
  const gridG = ensureGroup(svg, "staffTab-grid");
  const marksG = ensureGroup(svg, "staffTab-marks");
  const sigG = ensureGroup(svg, "staffTab-signatures");
  const hoverG = ensureGroup(svg, "staffTab-hover");

  // Enforce z-order: grid (bottom) -> signatures -> marks -> hover (top)
  svg.appendChild(gridG);
  svg.appendChild(sigG);
  svg.appendChild(marksG);
  svg.appendChild(hoverG);

  // Clear
  gridG.replaceChildren();
  sigG.replaceChildren();
  marksG.replaceChildren();
  hoverG.replaceChildren();

  // Split marks into staff vs TAB so we can:
  // - apply separate visibility toggles
  // - clip staff-only engraving so ledger lines never bleed into TAB
  const staffMarksG = ensureSubGroup(marksG, "geduStaffMarks");
  const tabMarksG = ensureSubGroup(marksG, "geduTabMarks");
  staffMarksG.replaceChildren();
  tabMarksG.replaceChildren();

  // Staff clipPath (prevents ledger lines and noteheads from entering TAB).
  const staffClip = svgEl("clipPath", { id: "staffMarksClip" });
  staffClip.appendChild(
    svgEl("rect", {
      x: String(layout.viewBox.x),
      y: String(layout.staff.yMin),
      width: String(layout.viewBox.w),
      height: String(layout.staff.yMax - layout.staff.yMin),
    })
  );
  const defs2 = svg.querySelector("defs") ?? svg.insertBefore(svgEl("defs"), svg.firstChild);
  const existing2 = defs2.querySelector("#staffMarksClip");
  if (existing2) existing2.replaceWith(staffClip);
  else defs2.appendChild(staffClip);
  staffMarksG.setAttribute("clip-path", "url(#staffMarksClip)");

  // === Signatures (prototype) ===
  // Canon requirement: staff must support key and time signatures.
  // Current implementation renders a default 4/4 time signature and leaves
  // key signature empty until key context is wired into the engine.
  // This is intentionally minimal but structurally correct.
  const firstMeasure = layout.measures[0];
  if (!s.hitboxesOnly && firstMeasure && layout.staff.lineYs.length >= 5) {
    const staffLines = layout.staff.lineYs;
    const topLine = staffLines[0] ?? 0;
    // Treble clef (𝄞) anchored to the staff. This is a structural engraving element.
    // Note: We render as text for now; a path-based clef can replace this later if needed.
    const lineGap = layout.staff.halfStep * 2;
    const clefX = firstMeasure.x0 + Math.max(10, (firstMeasure.x1 - firstMeasure.x0) * 0.02);
    // Treble clef centers around the G line (second line from bottom).
    const gLineY = staffLines[3] ?? staffLines[staffLines.length - 2] ?? staffLines[Math.floor(staffLines.length / 2)] ?? 0;
    const clefFont = Math.max(22, Math.min(60, lineGap * 4.8));
    const clef = svgEl("text", {
      x: String(clefX),
      y: String(gLineY + lineGap * 1.65),
      "text-anchor": "start",
      "font-size": String(clefFont),
      "font-weight": "400",
      "font-family": "ui-serif, Georgia, Cambria, Times New Roman, Times, serif",
      fill: "rgba(0,0,0,0.9)",
    });
    clef.textContent = "𝄞";
    sigG.appendChild(clef);

    // Used for sizing signatures relative to staff spacing.
    // (Do not re-declare lineGap; it must remain stable within this block.)

    // Place to the left of the first measure grid, but after the clef glyph.
    // We do not know the clef width from the background SVG, so this is a
    // measured offset that can be refined once a dedicated engraving layer exists.
    // Place to the left of the first measure grid, but after the clef glyph.
    // We do not know the clef width from the background SVG, so this is a
    // measured offset that can be refined once a dedicated engraving layer exists.
    const sigBaseX = clefX + clefFont * 0.55 + Math.max(8, (firstMeasure.x1 - firstMeasure.x0) * 0.02);

    // Key signature (major keys for now). "none" means no signature is rendered.
    const ksCount = keySignatureCount(s.keyContext);
    const ksSide = keySignatureSide(s.keyContext);

    const ksFont = Math.max(12, Math.min(20, lineGap * 1.05));
    const ksDx = Math.max(9, Math.min(16, lineGap * 0.9));

    let afterSigX = sigBaseX;

    if (ksCount > 0 && ksSide) {
      const sharpYs = [
        staffLines[0], // F# (top line)
        (staffLines[2] + staffLines[3]) / 2, // C# (space)
        staffLines[3], // G# (line 2)
        staffLines[1], // D# (line 4)
        (staffLines[3] + staffLines[4]) / 2, // A# (space)
        (staffLines[0] + staffLines[1]) / 2, // E# (space)
        staffLines[2], // B# (line 3)
      ].filter((n) => Number.isFinite(n));

      const flatYs = [
        staffLines[2], // Bb (line 3)
        (staffLines[0] + staffLines[1]) / 2, // Eb (space)
        (staffLines[3] + staffLines[4]) / 2, // Ab (space)
        staffLines[1], // Db (line 4)
        staffLines[3], // Gb (line 2)
        (staffLines[2] + staffLines[3]) / 2, // Cb (space)
        staffLines[0], // Fb (top line)
      ].filter((n) => Number.isFinite(n));

      const ys = ksSide === "sharps" ? sharpYs : flatYs;
      const glyph = ksSide === "sharps" ? "♯" : "♭";

      for (let i = 0; i < Math.min(ksCount, ys.length); i++) {
        const t = svgEl("text", {
          x: String(sigBaseX + i * ksDx),
          y: String(ys[i] + lineGap * 0.15),
          "text-anchor": "start",
          "font-size": String(ksFont),
          "font-weight": "400",
          "font-family": "ui-serif, Georgia, Cambria, Times New Roman, Times, serif",
          fill: "rgba(0,0,0,0.9)",
        });
        t.textContent = glyph;
        sigG.appendChild(t);
      }

      afterSigX = sigBaseX + Math.min(ksCount, ys.length) * ksDx + Math.max(6, ksDx * 0.35);
    }

    const x = afterSigX;

    const timeTopY = topLine + lineGap * 1.15;
    const timeBotY = topLine + lineGap * 2.85;
    const fontSize = Math.max(14, Math.min(22, lineGap * 1.25));

    const tTop = svgEl("text", {
      x: String(x),
      y: String(timeTopY),
      "text-anchor": "start",
      "font-size": String(fontSize),
      "font-weight": "600",
      "font-family": "ui-serif, Georgia, Cambria, Times New Roman, Times, serif",
      fill: "rgba(0,0,0,0.88)",
    });
    tTop.textContent = "4";

    const tBot = svgEl("text", {
      x: String(x),
      y: String(timeBotY),
      "text-anchor": "start",
      "font-size": String(fontSize),
      "font-weight": "600",
      "font-family": "ui-serif, Georgia, Cambria, Times New Roman, Times, serif",
      fill: "rgba(0,0,0,0.88)",
    });
    tBot.textContent = "4";

    // Guard against accidental bleed into TAB by keeping the signature inside the staff band.
    const clip = svgEl("clipPath", { id: "staffSigClip" });
    clip.appendChild(
      svgEl("rect", {
        x: String(layout.viewBox.x),
        y: String(layout.staff.yMin),
        width: String(layout.viewBox.w),
        height: String(layout.staff.yMax - layout.staff.yMin),
      })
    );
    const defs = svg.querySelector("defs") ?? svg.insertBefore(svgEl("defs"), svg.firstChild);
    // Replace prior clipPath if present.
    const existing = defs.querySelector("#staffSigClip");
    if (existing) existing.replaceWith(clip);
    else defs.appendChild(clip);

    sigG.setAttribute("clip-path", "url(#staffSigClip)");
    sigG.appendChild(tTop);
    sigG.appendChild(tBot);

    // No additional signature elements in this pass.
  }

  // === Rhythmic grid guardrails ===
  // The overlay uses a strict col grid (columnsPerMeasure) shared by STAFF and TAB.
  // This must remain stable across modes so that:
  // - clicks snap deterministically to the same rhythmic column
  // - staff noteheads and tab numbers align to subdivisions
  // - stronger beat boundaries remain visually obvious
  const gridY0 = layout.staff.yMin;
  const gridY1 = layout.tab.yMax;
  const beatsPerMeasure = 4; // 4/4 for now; time signatures can generalize later.
  const beatCols = layout.columnsPerMeasure / beatsPerMeasure;
  const beatColsInt = Number.isInteger(beatCols) && beatCols > 0 ? beatCols : 0;

  for (let mi = 0; mi < layout.measures.length; mi++) {
    const m = layout.measures[mi];
    const w = Math.max(1e-6, m.x1 - m.x0);
    const colW = w / layout.columnsPerMeasure;

    // Measure boundary lines (barlines). These act as the strongest visual anchors.
    for (const bx of [m.x0, m.x1]) {
      gridG.appendChild(
        svgEl("line", {
          x1: String(bx),
          y1: String(gridY0),
          x2: String(bx),
          y2: String(gridY1),
          stroke: "rgba(0,0,0,0.28)",
          "stroke-width": "2",
        })
      );
    }

    // Subdivision / beat lines.
    for (let ci = 1; ci < layout.columnsPerMeasure; ci++) {
      const x = m.x0 + ci * colW;
      const isBeat = beatColsInt > 0 ? ci % beatColsInt === 0 : false;
      const stroke = isBeat ? "rgba(0,0,0,0.18)" : "rgba(0,0,0,0.10)";
      const width = isBeat ? "1.5" : "1";
      gridG.appendChild(
        svgEl("line", {
          x1: String(x),
          y1: String(gridY0),
          x2: String(x),
          y2: String(gridY1),
          stroke,
          "stroke-width": width,
        })
      );
    }
  }

  // === Marks ===
  // The SVG overlay is retained primarily for hitboxes. When the canvas renderer is active,
  // all engraving/marks must be drawn in canvas to avoid duplicated visuals and regressions
  // (e.g., staff notes appearing in TAB space).
  if (!s.hitboxesOnly) {
  // Staff marks are rendered as real notation noteheads with stems.
  // (Rhythm flags/beaming are deferred until rhythmic value is introduced.)
  const staffMarkEntries = [...s.staffMarksByCol.entries()].sort((a, b) => a[0] - b[0]);

  // Measure-aware accidental carry: track current accidental state per staff position (yIndex) within each measure.
  // State initializes from the key signature and persists until the barline.
  const measureAccState = new Map<number, Map<number, "nat" | "sharp" | "flat">>();

  // Precompute bottomIndex for yIndex->diatonic letter mapping (matches staffYIndexForTreble anchoring).
  const staffLinesForAbs = layout.staff.lineYs;
  const bottomLineYForAbs = staffLinesForAbs[staffLinesForAbs.length - 1] ?? 0;
  let bottomIndexForAbs = 0;
  let bestForAbs = Infinity;
  for (let i = 0; i < layout.staff.stepCenters.length; i++) {
    const d = Math.abs(layout.staff.stepCenters[i] - bottomLineYForAbs);
    if (d < bestForAbs) { bestForAbs = d; bottomIndexForAbs = i; }
  }

  const STEP_TO_LETTER = ["C", "D", "E", "F", "G", "A", "B"] as const;
  const keyLetterMap = keySignatureLetterMap(s.keyContext);

  function letterForYIndex(yIndex: number): typeof STEP_TO_LETTER[number] {
    // bottom line is E4, which is diatonic index 2 (C=0, D=1, E=2).
    const deltaSteps = bottomIndexForAbs - yIndex;
    const idx = ((2 + deltaSteps) % 7 + 7) % 7;
    return STEP_TO_LETTER[idx] ?? "C";
  }

  function impliedAccidentalForYIndex(yIndex: number): "nat" | "sharp" | "flat" {
    const letter = letterForYIndex(yIndex);
    return (keyLetterMap as any)[letter] ?? "nat";
  }

  function getMeasureMap(measureIndex: number): Map<number, "nat" | "sharp" | "flat"> {
    let m = measureAccState.get(measureIndex);
    if (!m) { m = new Map(); measureAccState.set(measureIndex, m); }
    return m;
  }

  function currentAccidental(measureIndex: number, yIndex: number): "nat" | "sharp" | "flat" {
    const m = getMeasureMap(measureIndex);
    const existing = m.get(yIndex);
    if (existing) return existing;
    const implied = impliedAccidentalForYIndex(yIndex);
    m.set(yIndex, implied);
    return implied;
  }

  function setAccidental(measureIndex: number, yIndex: number, acc: "nat" | "sharp" | "flat") {
    getMeasureMap(measureIndex).set(yIndex, acc);
  }

  for (const [col, m0] of staffMarkEntries) {
    const yIndex = (m0 as any)?.yIndex;
    if (!Number.isFinite(col) || !Number.isFinite(yIndex)) continue;

    const measureIndex = Math.floor(col / layout.columnsPerMeasure);
    const colInMeasure = col % layout.columnsPerMeasure;
    const m = layout.measures[measureIndex];
    if (!m) continue;
    const colW = (m.x1 - m.x0) / layout.columnsPerMeasure;

    const cy = layout.staff.stepCenters[yIndex] ?? null;
    if (cy == null) continue;
    const cx = m.x0 + colInMeasure * colW + colW / 2;

    // Accidental glyph (♯/♭/♮) with measure-aware accidental carry.
    let spelledAcc: "nat" | "sharp" | "flat" = "nat";
    const vid = (m0 as any)?.variantId as (number | undefined);
    if (vid != null) {
      const pc = Math.floor(vid / 3);
      const slot = vid % 3;
      spelledAcc = (variantToLetterAccidental(pc, slot).accidental as ("nat" | "sharp" | "flat"));
    } else {
      const explicitAcc = (m0 as any)?.accidental as ("nat" | "sharp" | "flat" | undefined);
      if (explicitAcc) spelledAcc = explicitAcc;
    }

    const currentAcc = currentAccidental(measureIndex, yIndex);
    let accGlyph = "";
    if (spelledAcc !== currentAcc) {
      accGlyph = spelledAcc === "sharp" ? "♯" : spelledAcc === "flat" ? "♭" : "♮";
      setAccidental(measureIndex, yIndex, spelledAcc);
    }

// Ledger lines: draw short horizontal lines when the note sits above/below
    // the 5-line staff area.
    const staffLines = layout.staff.lineYs;
    const topLine = staffLines[0] ?? cy;
    const bottomLine = staffLines[staffLines.length - 1] ?? cy;
    const lineGap = layout.staff.halfStep * 2;
    const ledgerHalfLen = Math.max(10, Math.min(22, colW * 0.22));

    const addLedger = (yLedger: number) => {
      const ln = svgEl("line", {
        x1: String(cx - ledgerHalfLen),
        y1: String(yLedger),
        x2: String(cx + ledgerHalfLen),
        y2: String(yLedger),
        stroke: "rgba(0,0,0,0.55)",
        "stroke-width": "1.2",
        "stroke-linecap": "round",
      });
      staffMarksG.appendChild(ln);
    };

    if (cy < topLine - 0.5) {
      for (let yLedger = topLine - lineGap; yLedger >= cy - 0.5; yLedger -= lineGap) addLedger(yLedger);
    } else if (cy > bottomLine + 0.5) {
      for (let yLedger = bottomLine + lineGap; yLedger <= cy + 0.5; yLedger += lineGap) addLedger(yLedger);
    }

    const rx = Math.max(2.6, layout.staff.halfStep * 0.95);
    const ry = Math.max(2.2, layout.staff.halfStep * 0.70);
    const head = svgEl("ellipse", {
      cx: String(cx),
      cy: String(cy),
      rx: String(rx),
      ry: String(ry),
      fill: "rgba(0,0,0,0.92)",
      stroke: "rgba(0,0,0,0.92)",
      "stroke-width": "0.6",
      transform: `rotate(-18 ${cx} ${cy})`,
    });

    if (accGlyph) {
      const fontSize = Math.max(12, Math.min(22, lineGap * 1.05));
      const tAcc = svgEl("text", {
        x: String(cx - rx * 2.2),
        y: String(cy + fontSize * 0.35),
        "text-anchor": "middle",
        "font-size": String(fontSize),
        "font-weight": "700",
        "font-family": "ui-serif, Georgia, Cambria, Times New Roman, Times, serif",
        fill: "rgba(0,0,0,0.88)",
      });
      tAcc.textContent = accGlyph;
      staffMarksG.appendChild(tAcc);
    }

    staffMarksG.appendChild(head);

    // Stem direction rule (standard engraving heuristic):
    // notes below the middle line: stem up; on/above: stem down.
    const middleLine = staffLines[Math.floor(staffLines.length / 2)] ?? cy;
    const stemLen = Math.max(10, lineGap * 3.4);
    const stemXOffset = rx * 0.85;

    if (cy > middleLine + 0.2) {
      // stem up
      const stem = svgEl("line", {
        x1: String(cx + stemXOffset),
        y1: String(cy),
        x2: String(cx + stemXOffset),
        y2: String(cy - stemLen),
        stroke: "rgba(0,0,0,0.92)",
        "stroke-width": "1.2",
        "stroke-linecap": "round",
      });
      staffMarksG.appendChild(stem);
    } else {
      // stem down
      const stem = svgEl("line", {
        x1: String(cx - stemXOffset),
        y1: String(cy),
        x2: String(cx - stemXOffset),
        y2: String(cy + stemLen),
        stroke: "rgba(0,0,0,0.92)",
        "stroke-width": "1.2",
        "stroke-linecap": "round",
      });
      staffMarksG.appendChild(stem);
    }
  }

  for (const [col, v] of s.tabMarksByCol.entries()) {
    const stringIndex = v?.stringIndex;
    const fretNum = v?.fret;
    if (!Number.isFinite(col) || !Number.isFinite(stringIndex)) continue;

    const measureIndex = Math.floor(col / layout.columnsPerMeasure);
    const colInMeasure = col % layout.columnsPerMeasure;
    const m = layout.measures[measureIndex];
    if (!m) continue;
    const colW = (m.x1 - m.x0) / layout.columnsPerMeasure;

    const y0 = layout.tab.stringBands[stringIndex];
    const y1 = layout.tab.stringBands[stringIndex + 1];
    if (y0 == null || y1 == null) continue;

    const cx = m.x0 + colInMeasure * colW + colW / 2;
    const cy = (y0 + y1) / 2;

    // TAB uses fret numbers (text), not noteheads/dots.
    const label = String(Math.max(0, Math.min(24, Math.floor(Number(fretNum) || 0))));

    // Small pill background improves readability over string lines.
    const pad = Math.max(2.5, Math.min(colW, y1 - y0) * 0.10);
    const fontSize = Math.max(9, Math.min(18, (y1 - y0) * 0.55));

    const bg = svgEl("rect", {
      x: String(cx - (label.length === 1 ? fontSize * 0.38 : fontSize * 0.62) - pad),
      y: String(cy - fontSize * 0.55 - pad * 0.6),
      width: String((label.length === 1 ? fontSize * 0.76 : fontSize * 1.24) + pad * 2),
      height: String(fontSize * 1.1 + pad * 1.2),
      rx: String(Math.max(2, fontSize * 0.22)),
      ry: String(Math.max(2, fontSize * 0.22)),
      fill: "rgba(255,255,255,0.85)",
      stroke: "rgba(0,0,0,0.35)",
      "stroke-width": "1",
    });
    tabMarksG.appendChild(bg);

    const t = svgEl("text", {
      x: String(cx),
      y: String(cy + fontSize * 0.34),
      "text-anchor": "middle",
      "font-size": String(fontSize),
      "font-family": "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial",
      fill: "rgba(0,0,0,0.92)",
    });
    t.textContent = label;
    tabMarksG.appendChild(t);
  }

  }

  // Hover
  if (s.hover) {
    // Column hover: spans both STAFF and TAB so the player can clearly see subdivision alignment.
    const colRect = svgEl("rect", {
      x: String(s.hover.rect.x),
      y: String(gridY0),
      width: String(s.hover.rect.w),
      height: String(gridY1 - gridY0),
      rx: "2",
      ry: "2",
      fill: "rgba(0,0,0,0.06)",
      stroke: "rgba(0,0,0,0.28)",
      "stroke-width": "1",
    });
    hoverG.appendChild(colRect);

    // Region hover: gives local precision for clicking.
    const r = s.hover.rect;
    const hoverRect = svgEl("rect", {
      x: String(r.x),
      y: String(r.y),
      width: String(r.w),
      height: String(r.h),
      rx: "2",
      ry: "2",
      fill: "rgba(0,0,0,0.03)",
      stroke: "rgba(0,0,0,0.18)",
      "stroke-width": "1",
    });
    hoverG.appendChild(hoverRect);

    // Small center marker
    const dot = svgEl("circle", {
      cx: String(s.hover.cx),
      cy: String(s.hover.cy),
      r: "2.5",
      fill: "rgba(0,0,0,0.55)",
    });
    hoverG.appendChild(dot);
  }
}

function clientToSvg(svg: SVGSVGElement, clientX: number, clientY: number): { x: number; y: number } {
  const pt = svg.createSVGPoint();
  pt.x = clientX;
  pt.y = clientY;
  const ctm = svg.getScreenCTM();
  if (!ctm) return { x: 0, y: 0 };
  const p = pt.matrixTransform(ctm.inverse());
  return { x: p.x, y: p.y };
}

export function attachStaffTabPointerHandlers(
  svg: SVGSVGElement,
  layout: StaffTabLayout,
  state: StaffTabOverlayState,
  onPick?: (hit: StaffTabHit) => void,
): void {
  const render = () => renderStaffTabOverlay(svg, layout, state);

  svg.addEventListener(
    "pointermove",
    (ev) => {
      const p = clientToSvg(svg, ev.clientX, ev.clientY);
      const hit = hitTestStaffTab(layout, p.x, p.y);
      state.hover = hit;
      render();
    },
    { passive: true },
  );

  svg.addEventListener(
    "pointerleave",
    () => {
      state.hover = null;
      render();
    },
    { passive: true },
  );

  svg.addEventListener(
    "pointerdown",
    (ev) => {
      const p = clientToSvg(svg, ev.clientX, ev.clientY);
      const hit = hitTestStaffTab(layout, p.x, p.y);
      if (!hit) return;

      // Toggle a local marker (dev/test + proving subdivision-aligned hitboxes).
      // One mark per subdivision column for now.
      if (hit.region === "staff") {
        const prev = state.staffMarksByCol.get(hit.col);
        if (prev && prev.yIndex === hit.yIndex) state.staffMarksByCol.delete(hit.col);
        else state.staffMarksByCol.set(hit.col, { yIndex: hit.yIndex });
      } else {
        const prev = state.tabMarksByCol.get(hit.col);
        if (prev && prev.stringIndex === hit.yIndex && prev.fret === state.tabDefaultNumber) state.tabMarksByCol.delete(hit.col);
        else state.tabMarksByCol.set(hit.col, { stringIndex: hit.yIndex, fret: state.tabDefaultNumber });
      }

      state.hover = hit;
      onPick?.(hit);
      render();
    },
    { passive: true },
  );

  // Initial paint
  render();
}