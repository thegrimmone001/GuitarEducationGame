import {
  Action,
  DevSettings,
  Difficulty,
  GameSettings,
  GameState,
  MatchType,
  ModeId,
  Phase,
  PlayType,
  PlayerProfile,
  SlotType,
  VariantId,
} from "../shell/types";
import { reducer } from "../shell/engineReducer";
import { createChromaticRail, RailConfig } from "../shell/rail";
import { fromVariantId, IS_BLACK, pitchClassAt, toVariantId, variantLabel } from "../shell/music";
import { keySignatureSide } from "../shell/keySignature";
import { describePromptProfileId } from "../shell/promptProfiles";
import { cellCenter, computeLayoutFromSvg, hitTestCell, mapLayoutToNeck, parseSvgNeckBounds, parseSvgViewBox, FretboardLayout } from "../shell/fretboardLayout";
import { attachBoardPointerHandlers } from "../shell/uiAdapter";
import { renderOverlay } from "../shell/fretboardOverlay";
import { getLeaderboard, recordScore } from "../shell/storage";
import { renderNotationCanvas } from "./notationCanvas";

type UiRoot = HTMLElement | Document;

// ----------------------------
// Helpers
// ----------------------------

const PLAYER_COUNT_MULTI = 5;

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

function formatMs(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${pad2(m)}:${pad2(r)}`;
}

function escapeHtml(s: string): string {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function pcFromUiNoteName(name: string): number {
  const n = String(name || "C").trim().toUpperCase();
  const map: Record<string, number> = {
    C: 0,
    "C#": 1,
    DB: 1,
    D: 2,
    "D#": 3,
    EB: 3,
    E: 4,
    F: 5,
    "F#": 6,
    GB: 6,
    G: 7,
    "G#": 8,
    AB: 8,
    A: 9,
    "A#": 10,
    BB: 10,
    B: 11,
  };
  return map[n] ?? 0;
}

function intervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "P1",
    1: "m2",
    2: "M2",
    3: "m3",
    4: "M3",
    5: "P4",
    6: "TT",
    7: "P5",
    8: "m6",
    9: "M6",
    10: "m7",
    11: "M7",
  };
  return names[s] ?? `+${s}`;
}

function romanIntervalName(semitones: number): string {
  const s = ((semitones % 12) + 12) % 12;
  const names: Record<number, string> = {
    0: "I",
    1: "♭II",
    2: "II",
    3: "♭III",
    4: "III",
    5: "IV",
    6: "♭V",
    7: "V",
    8: "♭VI",
    9: "VI",
    10: "♭VII",
    11: "VII",
  };
  return names[s] ?? `+${s}`;
}

type TritoneStyle = "plusDim" | "TT" | "sharp4" | "flat5" | "auto";

function inferPreferSharp4(settings: GameSettings): boolean {
  const pid = (settings.promptProfileId ?? "").toLowerCase();
  if (pid.includes("lydian")) return true;
  if (pid.includes("locrian")) return false;
  if (pid.includes(":flats") || pid.includes("b")) return false;
  return true;
}

function intervalRomanName(semitones: number, style: TritoneStyle, preferSharp4: boolean): string {
  const s = ((semitones % 12) + 12) % 12;
  switch (s) {
    case 0: return "I";
    case 1: return "ii";
    case 2: return "II";
    case 3: return "iii";
    case 4: return "III";
    case 5: return "IV";
    case 6: {
      if (style === "TT") return "TT";
      if (style === "sharp4") return "IV\u266f";
      if (style === "flat5") return "V\u266d";
      if (style === "auto") return preferSharp4 ? "IV\u266f" : "V\u266d";
      return preferSharp4 ? "+IV" : "oV";
    }
    case 7: return "V";
    case 8: return "vi";
    case 9: return "VI";
    case 10: return "vii";
    case 11: return "VII";
    default: return `+${s}`;
  }
}

function labelForVariant(vid: VariantId, displayMode: string, rootPc: number, settings: GameSettings): string {
  if (displayMode === "intervals") {
    const pc = fromVariantId(vid).pitchClass;
    return intervalName(pc - rootPc);
  }
  if (displayMode === "romanIntervals") {
    const pc = fromVariantId(vid).pitchClass;
    return romanIntervalName(pc - rootPc);
  }
  if (displayMode === "intervalRoman") {
    const pc = fromVariantId(vid).pitchClass;
    const style = (((settings as any).tritoneStyle ?? "plusDim") as TritoneStyle);
    const preferSharp4 = inferPreferSharp4(settings);
    return intervalRomanName(pc - rootPc, style, preferSharp4);
  }
  return variantLabel(vid);
}

function buildPlayers(count: number): PlayerProfile[] {
  const c = clamp(count, 1, 16);
  const out: PlayerProfile[] = [];
  for (let i = 0; i < c; i++) out.push({ id: i, name: `P${i + 1}`, colorId: i, patternId: i });
  return out;
}

function defaultSettings(): GameSettings {
  return {
    modeId: ModeId.FRETBOARD,
    playType: PlayType.MULTI,
    matchType: MatchType.BLACKOUT,
    difficulty: Difficulty.MEDIUM,
    fixedRoundsTotal: 3,
    timers: { turnMs: 15_000, intermissionMs: 900 },
    domain: { fretCount: 25, minFret: 0, maxFret: 24, enabledStrings: [true, true, true, true, true, true] },
    feedback: {
      samEnabled: true,
      samDurationMs: 900,
      samRevealMode: "single",
      claimLabelMode: "off",
      claimLabelDurationMs: 900,
      samIncludeLabel: true,
    },
    steal: {
      tokenCap: 10,
      globalStealOnExhausted: true,
      enharmonicOppositeStealBonus: 5,
      breakConnectMaxTierBonus: 25,
    },
    accessibility: { colorBlindMode: true },
    dev: { enabled: false, paintEnabled: false, paintPlayerIndex: 0, paintLane: "prompt", paintMode: "paint" },
    notation: { view: "staffTab", pitch: "written" },
    promptProfileId: "chromatic",
    keyContext: "none",
    noteVisibility: "all",
    accidentalView: "auto",
  };
}

function modeToPromptProfileId(root: string, mode: string, keyContext: string): string {
  const m = String(mode || "chromatic").toLowerCase();
  const r = String(root || "C").trim();

  // Spelling preference derived from key context when applicable.
  // In chromatic mode, keyContext is a starting reference and may bias spelling,
  // but it must not constrain membership.
  const side = keySignatureSide(keyContext);
  const pref = side === "flats" ? "flats" : "sharps";

  if (m === "chromatic") return "chromatic";
  if (m === "pentatonic") return `scale:${r}:pentatonic:${pref}`;
  if (m === "blues") return `scale:${r}:blues:${pref}`;
  if (["ionian", "dorian", "phrygian", "lydian", "mixolydian", "aeolian", "locrian"].includes(m)) {
    return `scale:${r}:${m}:${pref}`;
  }
  // Fallback
  return "chromatic";
}


function difficultyFromUi(v: string): Difficulty {
  const s = String(v || "medium").toLowerCase();
  if (s === "learning") return Difficulty.LEARNING;
  if (s === "easy") return Difficulty.EASY;
  if (s === "hard") return Difficulty.HARD;
  return Difficulty.MEDIUM;
}

function readEnabledStrings(root: UiRoot): boolean[] {
  const sel = (root as Document).querySelector<HTMLSelectElement>("#pref-strings");
  const enabled = [false, false, false, false, false, false];
  if (!sel) return [true, true, true, true, true, true];
  const values = Array.from(sel.selectedOptions).map((o) => o.value);
  if (values.length === 0) return [true, true, true, true, true, true];

  // UI values are string numbers "1".."6" (1st string = high E). Engine indices are 0..5 (0 = high E).
  for (const v of values) {
    const n = Number(v);
    if (!Number.isFinite(n)) continue;
    const engineIdx = clamp(n, 1, 6) - 1;
    if (engineIdx >= 0 && engineIdx < 6) enabled[engineIdx] = true;
  }
  return enabled;
}

function readInt(root: UiRoot, selector: string, fallback: number): number {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  const n = Number(el?.value);
  return Number.isFinite(n) ? n : fallback;
}

function readStr(root: UiRoot, selector: string, fallback: string): string {
  const el = (root as Document).querySelector<HTMLInputElement | HTMLSelectElement>(selector);
  return (el?.value ?? fallback) as string;
}

function readBool(root: UiRoot, selector: string, fallback = false): boolean {
  const el = (root as Document).querySelector<HTMLInputElement>(selector);
  if (!el) return fallback;
  return !!el.checked;
}

function buildSettingsFromUi(root: UiRoot, session: "single" | "multi" | "edu"): GameSettings {
  const d = defaultSettings();

  const playType = session === "multi" ? PlayType.MULTI : PlayType.SINGLE;
  const difficulty = difficultyFromUi(readStr(root, "#ops-difficulty", "medium"));
  const uiMode = readStr(root, "#core-gameMode", "m4");
  const rootNote = readStr(root, "#core-root", "C");
  // Key signature and key quality are separate:
  // - keySignature: what gets drawn on the staff (sharps/flats after clef)
  // - keyQuality: major/minor context (does NOT change the key signature glyphs)
  // Back-compat: if an older build stored core.keyContext, treat it as keySignature.
  const keySignature =
    readStr(root, "#core-keySignature", "") || readStr(root, "#core-keyContext", "none");
  const keyQuality = readStr(root, "#core-keyQuality", "major");
  const mode = readStr(root, "#core-modes", "chromatic");
  // Prompt profile spelling preference is derived from key signature side when applicable.
  const promptProfileId = modeToPromptProfileId(rootNote, mode, keySignature);

  const displayMode = readStr(root, "#core-display", "names");
  const tritoneStyle = readStr(root, "#pref-tritoneStyle", "plusDim");
  const noteVisibilityUi = readStr(root, "#core-noteVisibility", "all");
  const accidentalViewUi = readStr(root, "#core-accidentalView", "both");
  let noteVisibility: "all" | "natural" | "enharmonic" | "context" =
    noteVisibilityUi === "all"
      ? "all"
      : noteVisibilityUi === "enharmonics"
        ? "enharmonic"
        : noteVisibilityUi === "context"
          ? "context"
          : "natural";
  // Learning difficulty assumes the player knows nothing: allow all spellings by default.
  if (difficulty === Difficulty.LEARNING) noteVisibility = "all";

  // How to render accidentals on the note rail (and other name-based displays).
  // "auto" aligns to the selected key context when known; otherwise it falls back to "both".
  const side = keySignatureSide(keySignature);
  const accidentalView = (() => {
    if (difficulty === Difficulty.LEARNING) return "both";
    if (accidentalViewUi !== "auto") return accidentalViewUi;
    return side === "flats" ? "flats" : side === "sharps" ? "sharps" : "both";
  })() as any;

  // Notation preferences (UI only). Default mirrors printed guitar notation.
  const notationView = readStr(root, "#pref-notationView", "staffTab") as any;
  const notationPitch = readStr(root, "#pref-notationPitch", "written") as any;

  const samModeUi = readStr(root, "#core-sam", "single");
  const samRevealMode = samModeUi === "multiple" ? "all" : "single";

  const viewFrets = clamp(readInt(root, "#pref-fretView", 12), 1, 24);
  // Fret count represents playable columns including open string (fret 0).
  const fretCount = viewFrets + 1;

  const minFretRaw = clamp(readInt(root, "#pref-fretMin", 1), 0, viewFrets);
  const maxFretRaw = clamp(readInt(root, "#pref-fretMax", 12), minFretRaw, viewFrets);
  const minFret = minFretRaw;
  const maxFret = maxFretRaw;
  const enabledStrings = readEnabledStrings(root);

  // Token / Dev settings (Main Menu Settings)
  const tokenCap = clamp(readInt(root, "#core-tokenCap", 10), 0, 20);
  const startTokens = clamp(readInt(root, "#core-startTokens", 0), 0, tokenCap);
  const devEnabled = readBool(root, "#core-devMode", false);

  // Dev/Test pane settings (only takes effect when dev is enabled)
  const devPaintEnabled = readBool(root, "#dev-paintEnabled", false);
  const devPaintPlayerIndex = clamp(Number(readStr(root, "#dev-paintPlayer", "0")), 0, 4);
  const devPaintLane = readStr(root, "#dev-paintLane", "prompt") as any;
  const devPaintMode = readStr(root, "#dev-paintMode", "paint") as any;

  const s: GameSettings = {
    ...d,
    modeId: ModeId.FRETBOARD,
    playType,
    matchType: MatchType.BLACKOUT,
    difficulty,
    promptProfileId,
    domain: { ...d.domain, fretCount, minFret, maxFret, enabledStrings },
    feedback: { ...d.feedback, samRevealMode },
    steal: { ...d.steal, tokenCap },
    dev: {
      ...d.dev,
      enabled: devEnabled,
      paintEnabled: devPaintEnabled,
      paintPlayerIndex: devPaintPlayerIndex,
      paintLane: devPaintLane,
      paintMode: devPaintMode,
    },
    notation: {
      view: (notationView === "staff" || notationView === "tab" ? notationView : "staffTab"),
      pitch: (notationPitch === "concert" ? "concert" : "written"),
    },
  };

  // Non-typed extensions used by promptProfiles (kept compatible with the shell version).
  (s as any).noteVisibility = noteVisibility;
  (s as any).accidentalView = accidentalView;
  (s as any).displayMode = displayMode;
  (s as any).tritoneStyle = tritoneStyle;
  (s as any).rootNote = rootNote;
  // Canon: key signature and key quality are tracked separately.
  (s as any).keySignature = keySignature;
  (s as any).keyQuality = keyQuality;
  // Back-compat: existing shell utilities still read keyContext.
  (s as any).keyContext = keySignature;
  (s as any).uiMode = uiMode;
  (s as any).startTokens = startTokens;
  return s;
}

// ----------------------------
// Controller
// ----------------------------

export function initGameController(root: UiRoot): void {
  const doc = root as Document;

  const splash = doc.querySelector<HTMLElement>("#splash");
  const promptText = doc.querySelector<HTMLElement>("#promptText");
  const alertsText = doc.querySelector<HTMLElement>("#alerts-text");

  const activeName = doc.querySelector<HTMLElement>("#activePlayer-name");
  const activeScore = doc.querySelector<HTMLElement>("#activePlayer-score");
  const activeMult = doc.querySelector<HTMLElement>("#activePlayer-mult");
  const activeTarget = doc.querySelector<HTMLElement>("#activePlayer-target");
  const activeTimer = doc.querySelector<HTMLElement>("#activePlayer-timer");
  const activeTokens = doc.querySelector<HTMLElement>("#activePlayer-tokens");
  const leaderboard = doc.querySelector<HTMLElement>("#leaderboard");
  const highscores = doc.querySelector<HTMLElement>("#highscores");

  const devTab = doc.querySelector<HTMLElement>("#misc-dev-tab");
  const devPane = doc.querySelector<HTMLElement>("#misc-dev-pane");

  const fretStage = doc.querySelector<HTMLElement>("#fretStage");
  const fretBgHost = doc.querySelector<HTMLElement>("#fretBgHost");
  const fretOverlaySvg = doc.querySelector<SVGSVGElement>("#fretOverlaySvg");
  const noteStripRail = doc.querySelector<HTMLElement>("#noteStrip-rail");

  if (!fretStage || !fretBgHost || !fretOverlaySvg) throw new Error("Fretboard surface not found");
  const fretStageEl: HTMLElement = fretStage;
  const fretBgHostEl: HTMLElement = fretBgHost;
  const fretOverlaySvgEl: SVGSVGElement = fretOverlaySvg;

  // Rail (shell feature)
  const rail = createChromaticRail();
  if (noteStripRail) {
    noteStripRail.innerHTML = "";
    noteStripRail.appendChild(rail.el);
  }

  let session: "single" | "multi" | "edu" = "single";

  // Education mode (instructor) state
  let eduTool: "input" | "erase" = "input";
  // VariantId convention in this codebase: 0=C natural, 1=C# ...; spelling is derived.
  let eduSelectedVariantId: number = 0;
  const eduFretMarks = new Map<number, number>(); // cellIndex -> variantId
  let eduShowStaff = true;
  let eduShowTab = true;
  let eduShowFret = true;
  let eduFretHandlersInstalled = false;
  let settings: GameSettings = buildSettingsFromUi(doc, session);
  let players: PlayerProfile[] = buildPlayers(session === "single" ? 1 : PLAYER_COUNT_MULTI);
  let state: GameState | null = null;

  let paused = false;
  let turnEndsAt = 0;
  let timerHandle: number | null = null;
  let intermissionHandle: number | null = null;
  let samHandle: number | null = null;

  // Match timing (used for persistent high score entries)
  let matchStartedAtMs = 0;
  let pausedAtMs = 0;
  let pausedAccumMs = 0;
  let matchRecorded = false;
  // TAB input state (instant): select string + fret (either order), claim immediately.
  let tabSelectedString: number | null = null;
  let tabSelectedFret: number | null = null;


  let fretLayout: FretboardLayout | null = null;
  let activePulse: {
    playerId: number;
    variantId: number;
    durationMs: number;
    ghost: any | null;
    ghosts?: any[];
    scoreDelta: number;
    includeLabel?: boolean;
  } | null = null;
  let pulseHandle: number | null = null;

  function setAlert(msg: string): void {
    if (!alertsText) return;
    const phase = state?.phase ?? "TITLE";
    alertsText.textContent = `${phase}: ${msg}`;
  }

  function clearTimers(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    if (intermissionHandle !== null) window.clearTimeout(intermissionHandle);
    if (samHandle !== null) window.clearTimeout(samHandle);
    timerHandle = null;
    intermissionHandle = null;
    samHandle = null;
  }

  function stopTurnTimer(): void {
    if (timerHandle !== null) window.clearInterval(timerHandle);
    timerHandle = null;
    turnEndsAt = 0;
    if (activeTimer) activeTimer.textContent = "00:00";
  }

  function startTurnTimer(): void {
    stopTurnTimer();
    if (!state) return;
    applyUiModeVisibility();
    renderNotationCanvas();
    const ms = state.settings.timers.turnMs;
    turnEndsAt = Date.now() + ms;
    if (activeTimer) activeTimer.textContent = formatMs(ms);
    timerHandle = window.setInterval(() => {
      if (!state || paused) return;
      const left = turnEndsAt - Date.now();
      if (activeTimer) activeTimer.textContent = formatMs(left);
      if (left <= 0) {
        stopTurnTimer();
        dispatch({ type: "TIMEOUT" } as Action);
      }
    }, 100);
  }

  function hideSplash(): void {
    splash?.classList.remove("show");
  }

  function showSplash(): void {
    splash?.classList.add("show");
  }

  function notePauseChange(isNowPaused: boolean): void {
    const now = Date.now();
    if (isNowPaused) {
      if (pausedAtMs === 0) pausedAtMs = now;
      return;
    }
    if (pausedAtMs !== 0) {
      pausedAccumMs += Math.max(0, now - pausedAtMs);
      pausedAtMs = 0;
    }
  }

  function currentMatchDurationMs(): number {
    if (!matchStartedAtMs) return 0;
    const now = Date.now();
    const pauseExtra = pausedAtMs ? Math.max(0, now - pausedAtMs) : 0;
    const pausedTotal = pausedAccumMs + pauseExtra;
    return Math.max(0, now - matchStartedAtMs - pausedTotal);
  }

  function syncDevTabVisibility(isDevEnabled?: boolean): void {
    const enabled =
      isDevEnabled ?? ((doc.querySelector<HTMLInputElement>("#core-devMode")?.checked ?? false) === true);
    if (devTab) devTab.classList.toggle("devHidden", !enabled);
    if (devPane) devPane.classList.toggle("devHidden", !enabled);

    // If dev is disabled and the dev pane is currently active, bounce back to Achievements.
    if (!enabled) {
      const miscTabs = doc.querySelector<HTMLElement>("[data-tabs=\"miscinfo\"]");
      const activeTab = miscTabs?.querySelector<HTMLElement>(".tab.active");
      if (activeTab && activeTab.getAttribute("data-tab") === "dev") {
        miscTabs?.querySelector<HTMLElement>(".tab[data-tab=\"ach\"]")?.click();
      }
    }
  }

  function updateHighScoresUi(useSettings?: GameSettings): void {
    if (!highscores) return;
    const s = useSettings ?? state?.settings ?? settings;
    const entries = getLeaderboard(s).slice(0, 10);
    if (entries.length === 0) {
      highscores.innerHTML = `<div class="hint">No saved scores yet. Finish a match to populate this list.</div>`;
      return;
    }
    highscores.innerHTML = entries
      .map((e) => {
        const when = new Date(e.atIso).toLocaleDateString();
        const dur = e.durationMs ? ` • ${formatMs(e.durationMs)}` : "";
        return `<div class="leader-row"><div class="leader-name">${escapeHtml(e.name)}</div><div class="leader-score">${e.score}</div><div class="leader-meta">${when}${dur}</div></div>`;
      })
      .join("");
  }

  function recordScoresIfNeeded(): void {
    if (!state) return;
    if (matchRecorded) return;
    matchRecorded = true;
    const dur = currentMatchDurationMs();
    for (const p of state.players) {
      recordScore(state.settings, p.profile.name, p.score, dur);
    }
    updateHighScoresUi(state.settings);
  }

  const SVG_ENTITY_MAP: Record<string, string> = {
    ns_extend: "http://ns.adobe.com/Extensibility/1.0/",
    ns_ai: "http://ns.adobe.com/AdobeIllustrator/10.0/",
    ns_graphs: "http://ns.adobe.com/Graphs/1.0/",
    ns_vars: "http://ns.adobe.com/Variables/1.0/",
    ns_imrep: "http://ns.adobe.com/ImageReplacement/1.0/",
    ns_sfw: "http://ns.adobe.com/SaveForWeb/1.0/",
    ns_custom: "http://ns.adobe.com/GenericCustomNamespace/1.0/",
    ns_adobe_xpath: "http://ns.adobe.com/XPath/1.0/",
  };

  const ASSET_BASE = (import.meta as any).env?.BASE_URL ?? "/";
  function assetUrl(path: string): string {
    const clean = path.startsWith("/") ? path.slice(1) : path;
    return new URL(clean, window.location.origin + ASSET_BASE).toString();
  }

  function sanitizeSvgText(raw: string): string {
    let t = raw;

    // Replace Illustrator entity references (browsers do not evaluate SVG DTD entities when injecting via innerHTML).
    for (const [k, v] of Object.entries(SVG_ENTITY_MAP)) {
      t = t.replaceAll("&" + k + ";", v);
    }

    // Remove XML declaration and DOCTYPE (including internal subsets).
    t = t.replace(/<\?xml[\s\S]*?\?>/g, "");
    t = t.replace(/<!DOCTYPE[\s\S]*?\]>/g, "");
    t = t.replace(/<!DOCTYPE[^>]*>/g, "");
    t = t.replace(/<!ENTITY[\s\S]*?>/g, "");

    // Remove Adobe-only foreignObject blocks (keeps the real <g> content).
    t = t.replace(/<foreignObject[\s\S]*?<\/foreignObject>/g, "");

    return t;
  }

  async function loadSvgIntoHost(
    host: HTMLElement,
    urlPath: string,
    preserveAspectRatio: string = "xMidYMid meet",
  ): Promise<string> {
    const res = await fetch(assetUrl(urlPath));
    if (!res.ok) throw new Error("Failed to load " + urlPath + ": " + res.status);

    const raw = await res.text();
    const svgText = sanitizeSvgText(raw);
    host.innerHTML = svgText;

    const svg = host.querySelector("svg") as SVGSVGElement | null;
    if (svg) {
      svg.setAttribute("width", "100%");
      svg.setAttribute("height", "100%");
      svg.setAttribute("preserveAspectRatio", preserveAspectRatio);
    }

    return svgText;
  }


  async function setupSvgSurfaces(): Promise<void> {

    // Visual background SVG: prefer the v2i artwork; fall back to the vector SVG if needed.
    let bgText = "";
    try {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete_v2i.svg"),
        "xMinYMin meet",
      );
    } catch {
      bgText = await loadSvgIntoHost(
        fretBgHostEl,
        assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"),
        "xMinYMin meet",
      );
    }

    // Compute the hitbox layout directly from the background SVG whenever possible.
    // Our photo-style v2i asset now exposes enough geometry (via image transforms) to
    // recover fret and string positions, which keeps markers perfectly centered.
    let layout: FretboardLayout;
    let vb: { x: number; y: number; w: number; h: number };
    try {
      const cleanBgText = sanitizeSvgText(bgText);
      layout = computeLayoutFromSvg(cleanBgText);
      vb = layout.viewBox;
    } catch (e) {
      console.warn("Failed to compute layout from background SVG; falling back to vector geometry mapping.", e);

      // Geometry fallback: compute from the clean vector SVG and map into the background.
      const hitRaw = await (await fetch(assetUrl("/Guitar_FretBoard_Horizontal-Complete.svg"))).text();
      const hitText = sanitizeSvgText(hitRaw);
      const baseLayout = computeLayoutFromSvg(hitText);

      layout = baseLayout;
      vb = baseLayout.viewBox;
      try {
        const bgVB = parseSvgViewBox(bgText);
        const bgNeck = parseSvgNeckBounds(bgText);
        layout = mapLayoutToNeck(baseLayout, bgVB, bgNeck);
        vb = bgVB;
      } catch (e2) {
        console.warn("Failed to map fretboard layout to background SVG; using base layout.", e2);
      }
    }

    fretLayout = layout;

    fretOverlaySvgEl.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
    fretOverlaySvgEl.setAttribute("preserveAspectRatio", "xMinYMin meet");
    fretOverlaySvgEl.setAttribute("width", "100%");
    fretOverlaySvgEl.setAttribute("height", "100%");

    attachBoardPointerHandlers(
      { layout: fretLayout, svgRoot: fretOverlaySvgEl, dispatch },
      () => state,
      fretOverlaySvgEl,
    );

    // Education mode: allow placing markers on the fretboard even when no match is running.
    if (!eduFretHandlersInstalled) {
      eduFretHandlersInstalled = true;
      fretOverlaySvgEl.addEventListener("pointerdown", (ev: PointerEvent) => {
        if (session !== "edu") return;
        if (!fretLayout) return;
        // Convert client -> svg coords
        const rect = fretOverlaySvgEl.getBoundingClientRect();
        const vb = fretOverlaySvgEl.viewBox.baseVal;
        const sx = vb.x + ((ev.clientX - rect.left) * vb.width) / Math.max(1, rect.width);
        const sy = vb.y + ((ev.clientY - rect.top) * vb.height) / Math.max(1, rect.height);

        const hit = hitTestCell(fretLayout, sx, sy);
        if (!hit) return;
        const fretCols = Math.max(1, fretLayout.fretBoundaries.length - 1);
        const cellIndex = hit.stringIndex * fretCols + hit.fretIndex;
        if (eduTool === "erase") eduFretMarks.delete(cellIndex);
        else eduFretMarks.set(cellIndex, eduSelectedVariantId);
        renderEduFretMarks();
        applyEduVisibility();
      }, { passive: true });
    }

    // Initial render if a game is already running.
    updateOverlayOwnership();
    syncFretKeypadAvailability();
  }

  // --- Education helpers ---
  function updateEduSelectedUi(): void {
    const el = doc.getElementById("edu-selected");
    if (!el) return;
    const lab = variantLabel(eduSelectedVariantId);
    el.textContent = lab;
  }

  function clearEduMarks(which: "all" | "staff" | "tab" | "fret"): void {
    if (which === "all" || which === "fret") eduFretMarks.clear();
    renderEduFretMarks();
    applyEduVisibility();
  }

  function applyEduVisibility(): void {
    if (session !== "edu") return;
    const gFret = fretOverlaySvgEl.querySelector<SVGGElement>("#geduEduMarks");
    if (gFret) gFret.style.display = eduShowFret ? "" : "none";
  }

  function renderEduFretMarks(): void {
    if (session !== "edu") return;
    if (!fretLayout) return;

    const NS = "http://www.w3.org/2000/svg";
    let g = fretOverlaySvgEl.querySelector<SVGGElement>("#geduEduMarks");
    if (!g) {
      g = document.createElementNS(NS, "g") as SVGGElement;
      g.setAttribute("id", "geduEduMarks");
      fretOverlaySvgEl.appendChild(g);
    }
    while (g.firstChild) g.removeChild(g.firstChild);

    const fretCols = Math.max(1, fretLayout.fretBoundaries.length - 1);
    const r = Math.max(6, Math.min(10, fretLayout.dotRadius * 1.25));
    for (const [cellIndex, vid] of eduFretMarks.entries()) {
      const stringIndex = Math.floor(cellIndex / fretCols);
      const fretIndex = cellIndex % fretCols;
      const c = cellCenter(fretLayout, stringIndex, fretIndex);

      const circ = document.createElementNS(NS, "circle");
      circ.setAttribute("cx", String(c.cx));
      circ.setAttribute("cy", String(c.cy));
      circ.setAttribute("r", String(r));
      circ.setAttribute("fill", "rgba(255,255,255,0.12)");
      circ.setAttribute("stroke", "rgba(255,255,255,0.65)");
      circ.setAttribute("stroke-width", "1");
      g.appendChild(circ);

      const t = document.createElementNS(NS, "text");
      t.setAttribute("x", String(c.cx));
      t.setAttribute("y", String(c.cy + r * 0.35));
      t.setAttribute("text-anchor", "middle");
      t.setAttribute("font-size", String(Math.max(9, r * 0.95)));
      t.setAttribute("font-weight", "700");
      t.setAttribute("fill", "rgba(255,255,255,0.95)");
      t.textContent = variantLabel(vid);
      g.appendChild(t);
    }
  }

  void setupSvgSurfaces().catch((err) => {
    console.error("Failed to set up SVG surfaces", err);
  });

  function rebuildOverlay(): void {
    // No-op: fretboard interaction and rendering are handled by the SVG overlay.
    // This stub is kept so older calls (e.g., start/reset) don't crash.
  }

  function updateOverlayOwnership(): void {
    if (!state || !fretLayout) return;
    renderOverlay(fretOverlaySvgEl, fretLayout, state, activePulse);
  }

  function updateActivePlayerUi(): void {
    if (!state) return;
    const pIndex = state.currentPlayer;
    const p = state.players[pIndex];
    if (!p) return;

    if (activeName) activeName.textContent = players[pIndex]?.name ?? `P${pIndex + 1}`;
    if (activeScore) activeScore.textContent = String(p.score);
    if (activeMult) activeMult.textContent = `×${1 + (state.turn?.streakTier ?? 0)}`;

    if (activeTokens) {
      const cap = state.settings.steal.tokenCap;
      activeTokens.innerHTML = "";
      for (let i = 0; i < cap; i++) {
        const dot = document.createElement("span");
        dot.className = "tokenDot" + (i < p.tokenCount ? " filled" : "");
        activeTokens.appendChild(dot);
      }
    }
  }

  function updateLeaderboardUi(): void {
    if (!state || !leaderboard) return;
    leaderboard.innerHTML = "";
    for (let i = 0; i < state.players.length; i++) {
      const p = state.players[i];
      const row = document.createElement("div");
      row.className = "leader-chip" + (i === state.currentPlayer ? " active" : "");
      row.innerHTML = `
        <div class="leader-avatar">${(players[i]?.name ?? `P${i + 1}`).slice(0, 2)}</div>
        <div class="leader-name">${players[i]?.name ?? `P${i + 1}`}</div>
        <div class="leader-score">${p.score}</div>
        <div class="leader-tokens">${p.tokenCount}</div>
      `;
      leaderboard.appendChild(row);
    }
  }

  function updatePromptUi(): void {
    if (!state) return;
    const displayMode = (state.settings as any).displayMode ?? "names";
    const rootPc = pcFromUiNoteName((state.settings as any).rootNote ?? "C");
    const label = labelForVariant(state.prompt.variantId, displayMode, rootPc, state.settings);

    // Update the visible target label (and promptText if that element exists).
    if (promptText) promptText.textContent = label;
    if (activeTarget) {
      const v = fromVariantId(state.prompt.variantId);
      const isBlack = IS_BLACK[v.pitchClass];
      const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
      activeTarget.textContent = spelling ? `Target: ${label} (${spelling})` : `Target: ${label}`;
      activeTarget.classList.toggle("is-sharp", isBlack && v.spelling === SlotType.SHR);
      activeTarget.classList.toggle("is-flat", isBlack && v.spelling === SlotType.FLT);
    }

    // Rail config
    const railMode: RailConfig["mode"] = state.settings.promptProfileId.startsWith("scale") || state.settings.promptProfileId.startsWith("key") ? "FIXED_REFERENCE" : "ROTATE_COMPASS";
    const anchor = toVariantId(rootPc as any, SlotType.NAT);
    rail.setConfig(
      {
        mode: railMode,
        anchorVariantId: anchor,
        currentVariantId: state.prompt.variantId,
      },
      state.settings,
    );

    // Make the sharp/flat requirement visible at a glance without giving away fretboard positions.
    const v = fromVariantId(state.prompt.variantId);
    const isBlack = IS_BLACK[v.pitchClass];
    const spelling = isBlack && v.spelling === SlotType.SHR ? "sharp" : (isBlack && v.spelling === SlotType.FLT ? "flat" : "");
    const targetSuffix = spelling ? ` | Target: ${label} (${spelling})` : ` | Target: ${label}`;
    setAlert(describePromptProfileId(state.settings.promptProfileId) + targetSuffix);
  }


  function syncFretKeypadAvailability(): void {
    const pad = doc.getElementById("keypad");
    if (!pad) return;

    // Disable keys outside the current playable domain range.
    // Note: the 24-key UI is always present, but keys outside [minFret..maxFret] are disabled.
    const minAllowed = state ? state.settings.domain.minFret : 0;
    const maxAllowed = state ? Math.min(24, state.settings.domain.maxFret) : 24;

    const keys = pad.querySelectorAll<HTMLButtonElement>("button.key");
    keys.forEach((b) => {
      const f = Number(b.dataset.fret);
      // Open string (0) remains available even when the focused fret range starts at 1.
      const disabled = !Number.isFinite(f) || (f !== 0 && (f < minAllowed || f > maxAllowed)) || (f === 0 && maxAllowed < 0);
      b.disabled = disabled;
      b.classList.toggle("disabled", disabled);
    });
  }

  function applyUiModeVisibility(overrideUiMode?: string): void {
    const uiMode: string = overrideUiMode ?? (((state?.settings as any) ?? {}) as any).uiMode ?? "m4";
    const showStaffTab = uiMode !== "m1";
    const showFret = uiMode !== "m5";

    const staffSection = doc.getElementById("svgStage")?.closest(".section") as HTMLElement | null;
    if (staffSection) {
      // Keep the Staff/Tab panel in the layout so the UI does not jump;
      // in modes where it is not active we simply mark it disabled.
      staffSection.hidden = false;
      staffSection.classList.toggle("isDisabled", !showStaffTab);
    }

    const fretSection = doc.getElementById("fretStage")?.closest(".section") as HTMLElement | null;
    if (fretSection) fretSection.hidden = !showFret;
  }

  function renderAll(): void {
    // Education mode renders overlays without the game engine state.
    if (!state) {
      if (session !== "edu") return;
      applyUiModeVisibility();
      renderNotationCanvas();
      updateEduSelectedUi();
      renderEduFretMarks();
      applyEduVisibility();
      return;
    }
    applyUiModeVisibility();
    renderNotationCanvas();
    updatePromptUi();
    updateActivePlayerUi();
    updateLeaderboardUi();
    updateOverlayOwnership();
    syncFretKeypadAvailability();
  }

  function handleEffects(effects: any[]): void {
    const s0 = state;
    if (!s0) return;

    for (const eff of effects) {
      switch (eff.type) {
        case "PROMPT_CHANGED":
          updatePromptUi();
          break;

        case "TURN_STARTED":
          setAlert("Turn started");
          startTurnTimer();
          break;

        case "TURN_ENDED":
          stopTurnTimer();
          // In single-player, keep things flowing.
          if (s0.settings.playType === PlayType.SINGLE) {
            dispatch({ type: "START_TURN" } as Action);
          } else {
            // Multiplayer: respect intermission.
            intermissionHandle = window.setTimeout(() => {
              if (!state || paused) return;
              dispatch({ type: "START_TURN" } as Action);
            }, s0.settings.timers.intermissionMs);
          }
          break;

        case "FEEDBACK_PULSE": {
          // SAM pulse (highlight correct locations)
          if (!s0.settings.feedback.samEnabled) break;

          activePulse = {
            playerId: eff.playerId,
            variantId: eff.variantId,
            durationMs: eff.durationMs ?? s0.settings.feedback.samDurationMs,
            ghost: (eff.ghost ?? null) as any,
            ghosts: (eff.ghosts ?? undefined) as any,
            scoreDelta: (eff.scoreDelta ?? 0) as any,
            includeLabel: (eff.includeLabel ?? false) as any,
          };

          if (samHandle !== null) window.clearTimeout(samHandle);
          samHandle = window.setTimeout(() => {
            activePulse = null;
            renderAll();
          }, activePulse.durationMs);
          break;
        }

        case "ALERT":
          setAlert(String(eff.message ?? ""));
          break;

        case "MATCH_COMPLETE":
          stopTurnTimer();
          paused = true;
          notePauseChange(true);
          recordScoresIfNeeded();
          updateHighScoresUi();
          setAlert("Match complete");
          showSplash();
          break;
      }
    }

    renderAll();
  }

  function dispatch(action: Action): void {
    const r = reducer(state, action);
    state = r.state;
    handleEffects(r.effects);
  }

  function beginMatch(sess: "single" | "multi"): void {
    clearTimers();
    paused = false;

    session = sess;
    settings = buildSettingsFromUi(doc, session);
    syncDevTabVisibility(!!settings.dev?.enabled);

    // Hide instructor tools during standard play.
    const teachTab = doc.getElementById("utility-teach-tab") as HTMLButtonElement | null;
    const teachPane = doc.getElementById("utility-teach-pane") as HTMLDivElement | null;
    if (teachTab) teachTab.hidden = true;
    if (teachPane) teachPane.hidden = true;
    players = buildPlayers(session === "single" ? 1 : PLAYER_COUNT_MULTI);

    const init = reducer(null, { type: "INIT_MATCH", settings, players } as Action);
    state = init.state;

    // Match timing (used for persistent high scores)
    matchStartedAtMs = Date.now();
    pausedAtMs = 0;
    pausedAccumMs = 0;
    matchRecorded = false;

    // Apply starting tokens (clamped to the configured token cap).
    const startTokens = clamp(Number((settings as any).startTokens ?? 0), 0, settings.steal.tokenCap);
    if (state && startTokens > 0) {
      for (const p of state.players) p.tokenCount = startTokens;
    }

    updateHighScoresUi(settings);

    rebuildOverlay();
    renderAll();
    handleEffects(init.effects);

    // Start the first turn immediately.
    dispatch({ type: "START_TURN" } as Action);
    hideSplash();
  }

  function beginEducation(): void {
    session = "edu";
    settings = buildSettingsFromUi(doc, session);
    // Instructor session: no scoring, no timers, no turns.
    players = buildPlayers(1);
    state = null;
    paused = false;
    stopTurnTimer();
    setAlert("Education Mode");

    // Unhide Teach tab and switch to it.
    const teachTab = doc.getElementById("utility-teach-tab") as HTMLButtonElement | null;
    const teachPane = doc.getElementById("utility-teach-pane") as HTMLDivElement | null;
    if (teachTab) teachTab.hidden = false;
    if (teachPane) teachPane.hidden = false;
    teachTab?.click();

    // Default selection reads from note rail if available; fall back to C.
    updateEduSelectedUi();

    // Clear any previous marks and redraw.
    clearEduMarks("all");
    renderAll();
  }

  function endMatch(): void {
    if (!state) return;
    clearTimers();
    paused = true;
    notePauseChange(true);
    dispatch({ type: "END_MATCH" } as Action);
    recordScoresIfNeeded();
    updateHighScoresUi();
    showSplash();
  }

  function resetGame(): void {
    clearTimers();
    paused = false;
    matchStartedAtMs = 0;
    pausedAtMs = 0;
    pausedAccumMs = 0;
    matchRecorded = false;
    state = null;
    rebuildOverlay();
    setAlert("Ready");
    showSplash();
  }

  function onCellClick(stringIndex: number, fretIndex: number): void {
    if (!state) return;
    if (paused) return;
    if (state.phase !== "IN_MATCH" && state.phase !== "LAST_CHANCE") return;

    const cellIndex = stringIndex * state.settings.domain.fretCount + fretIndex;
    const slot = fromVariantId(state.prompt.variantId).spelling;
    const owner = state.board.owner[slot][cellIndex];
    const isOtherOwner = owner >= 0 && owner !== state.currentPlayer;
    const action: Action = isOtherOwner ? ({ type: "STEAL_CELL", stringIndex, fretIndex } as any) : ({ type: "TAP_CELL", stringIndex, fretIndex } as any);
    dispatch(action);
  }

  // Listen to layout events
  window.addEventListener("gedu:splashSelect", (e: any) => {
    const detail = e?.detail as { session: "single" | "multi" | "edu" };
    const sess = detail?.session ?? "single";
    if (sess === "edu") beginEducation();
    else beginMatch(sess);
  });

  window.addEventListener("gedu:start", () => {
    if (session === "edu") {
      setAlert("Education Mode");
      renderAll();
      return;
    }
    if (!state) {
      beginMatch(session);
      return;
    }
    paused = false;
	    notePauseChange(false);
    setAlert("Running");
    if (state.phase === "IN_MATCH" || state.phase === "LAST_CHANCE") startTurnTimer();
    renderAll();
  });

  window.addEventListener("gedu:pause", () => {
    if (session === "edu") {
      setAlert("Education Mode");
      return;
    }
    paused = true;
    notePauseChange(true);
    stopTurnTimer();
    setAlert("Paused");
    renderAll();
  });

  window.addEventListener("gedu:stop", () => {
    if (session === "edu") {
      clearEduMarks("all");
      showSplash();
      return;
    }
    endMatch();
  });

  window.addEventListener("gedu:new", () => {
    if (session === "edu") {
      clearEduMarks("all");
      setAlert("Education Mode");
      renderAll();
      return;
    }
    resetGame();
  });

  window.addEventListener("gedu:applyFretRange", () => {
    // Easiest deterministic behavior: restart match with new domain.
    if (!state) return;
    beginMatch(session === "multi" ? "multi" : "single");
  });

  window.addEventListener("gedu:applySettings", () => {
    if (session === "edu") {
      settings = buildSettingsFromUi(doc, session);
      renderAll();
      return;
    }
    if (!state) return;
    beginMatch(session as any);
  });

  // Note rail selection: in dev mode or Learning difficulty, clicking a rail cell sets the current prompt.
  window.addEventListener("gedu:railSelect", (e: any) => {
    const vid = Number(e?.detail?.variantId);
    if (!Number.isFinite(vid)) return;

    // Education mode: the rail selects what will be placed.
    if (session === "edu") {
      eduSelectedVariantId = vid;
      updateEduSelectedUi();
      renderAll();
      return;
    }

    if (!state) return;
    const allow = !!state.settings.dev?.enabled || state.settings.difficulty === Difficulty.LEARNING;
    if (!allow) return;
    dispatch({ type: "DEV_SET_PROMPT", variantId: vid } as any);
  });
  // 25-key fret selector (instant): on fret pick, claim if a TAB string is selected (or vice versa).
  window.addEventListener("gedu:fretPick", (e: any) => {
    const raw = Number(e?.detail?.fret);
    if (!Number.isFinite(raw)) return;

    // Store the last chosen fret even if a match hasn't started yet.
    tabSelectedFret = clamp(Math.floor(raw), 0, 24);

    if (!state) return;

    const uiMode = (state.settings as any)?.uiMode ?? "m4";
    const tabEnabled = uiMode === "m3" || uiMode === "m4" || uiMode === "m5";
    if (!tabEnabled) {
      setAlert("TAB input is disabled in this mode");
      return;
    }

    // Open string (0) is always permitted for TAB entry even if the focused range starts at 1.
    const minAllowed = 0;
    const maxAllowed = Math.min(24, state.settings.domain.maxFret);
    const clampedFret = clamp(tabSelectedFret, minAllowed, maxAllowed);
    tabSelectedFret = clampedFret;

    if (tabSelectedString === null) {
      setAlert(`TAB: fret ${clampedFret} selected (pick string)`);
      return;
    }

    onCellClick(tabSelectedString, clampedFret);
  });
  // Dev/Test UI wiring
  // Education (Teach) UI wiring
  const eduToolInput = doc.querySelector<HTMLInputElement>("#edu-tool-input");
  const eduToolErase = doc.querySelector<HTMLInputElement>("#edu-tool-erase");
  const eduShowStaffChk = doc.querySelector<HTMLInputElement>("#edu-show-staff");
  const eduShowTabChk = doc.querySelector<HTMLInputElement>("#edu-show-tab");
  const eduShowFretChk = doc.querySelector<HTMLInputElement>("#edu-show-fret");
  const btnEduClearAll = doc.querySelector<HTMLButtonElement>("#edu-clear-all");
  const btnEduClearStaff = doc.querySelector<HTMLButtonElement>("#edu-clear-staff");
  const btnEduClearTab = doc.querySelector<HTMLButtonElement>("#edu-clear-tab");
  const btnEduClearFret = doc.querySelector<HTMLButtonElement>("#edu-clear-fret");

  const syncEduControlsToState = () => {
    if (eduToolInput) eduToolInput.checked = eduTool === "input";
    if (eduToolErase) eduToolErase.checked = eduTool === "erase";
    if (eduShowStaffChk) eduShowStaffChk.checked = eduShowStaff;
    if (eduShowTabChk) eduShowTabChk.checked = eduShowTab;
    if (eduShowFretChk) eduShowFretChk.checked = eduShowFret;
    updateEduSelectedUi();
    applyEduVisibility();
  };

  eduToolInput?.addEventListener("change", () => {
    if (eduToolInput.checked) eduTool = "input";
    if (session === "edu") renderAll();
  });
  eduToolErase?.addEventListener("change", () => {
    if (eduToolErase.checked) eduTool = "erase";
    if (session === "edu") renderAll();
  });
  eduShowStaffChk?.addEventListener("change", () => { eduShowStaff = !!eduShowStaffChk.checked; applyEduVisibility(); });
  eduShowTabChk?.addEventListener("change", () => { eduShowTab = !!eduShowTabChk.checked; applyEduVisibility(); });
  eduShowFretChk?.addEventListener("change", () => { eduShowFret = !!eduShowFretChk.checked; applyEduVisibility(); });
  btnEduClearAll?.addEventListener("click", () => clearEduMarks("all"));
  btnEduClearStaff?.addEventListener("click", () => clearEduMarks("staff"));
  btnEduClearTab?.addEventListener("click", () => clearEduMarks("tab"));
  btnEduClearFret?.addEventListener("click", () => clearEduMarks("fret"));
  syncEduControlsToState();

  const devModeToggle = doc.querySelector<HTMLInputElement>("#core-devMode");
  devModeToggle?.addEventListener("change", () => {
    syncDevTabVisibility(!!devModeToggle.checked);
  });
  syncDevTabVisibility(!!devModeToggle?.checked);

  const btnDevPrev = doc.querySelector<HTMLButtonElement>("#dev-prevPlayer");
  const btnDevNext = doc.querySelector<HTMLButtonElement>("#dev-nextPlayer");
  const btnDevEndTurn = doc.querySelector<HTMLButtonElement>("#dev-endTurn");
  const btnDevClearBoard = doc.querySelector<HTMLButtonElement>("#dev-clearBoard");
  const btnDevPhaseInMatch = doc.querySelector<HTMLButtonElement>("#dev-forceInMatch");
  const btnDevPhaseIntermission = doc.querySelector<HTMLButtonElement>("#dev-forceIntermission");
  const btnDevPhaseLastChance = doc.querySelector<HTMLButtonElement>("#dev-forceLastChance");
  const btnDevPhaseResults = doc.querySelector<HTMLButtonElement>("#dev-forceResults");

  const devPaintEnabled = doc.querySelector<HTMLInputElement>("#dev-paintEnabled");
  const devPaintPlayer = doc.querySelector<HTMLSelectElement>("#dev-paintPlayer");
  const devPaintLane = doc.querySelector<HTMLSelectElement>("#dev-paintLane");
  const devPaintMode = doc.querySelector<HTMLSelectElement>("#dev-paintMode");

  const dispatchAndRender = (action: Action) => {
    if (!state) return;
    dispatch(action);
    renderAll();
  };

  btnDevPrev?.addEventListener("click", () => {
    if (!state) return;
    const n = state.players.length;
    const next = (state.currentPlayer - 1 + n) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });
  btnDevNext?.addEventListener("click", () => {
    if (!state) return;
    const n = state.players.length;
    const next = (state.currentPlayer + 1) % n;
    dispatchAndRender({ type: "DEV_SET_CURRENT_PLAYER", playerIndex: next } as Action);
  });

  // Dev "End Turn" behavior:
  // Option A (selected): simulate the end of a turn by triggering the same pipeline as a natural timeout/miss.
  // This validates the real scoring/token/sequence logic.
  btnDevEndTurn?.addEventListener("click", () => dispatchAndRender({ type: "TIMEOUT" } as Action));

  btnDevClearBoard?.addEventListener("click", () => dispatchAndRender({ type: "DEV_CLEAR_BOARD" } as Action));

  const forcePhase = (phase: Phase) => dispatchAndRender({ type: "DEV_FORCE_PHASE", phase } as Action);
  btnDevPhaseInMatch?.addEventListener("click", () => forcePhase("IN_MATCH"));
  btnDevPhaseIntermission?.addEventListener("click", () => forcePhase("INTERMISSION"));
  btnDevPhaseLastChance?.addEventListener("click", () => forcePhase("LAST_CHANCE"));
  btnDevPhaseResults?.addEventListener("click", () => forcePhase("RESULTS"));

  const syncPaintControlsToState = () => {
    if (!state) return;
    const patch: Partial<DevSettings> = {
      paintEnabled: !!devPaintEnabled?.checked,
      paintPlayerIndex: clamp(Number(devPaintPlayer?.value ?? 0), 0, Math.max(0, state.players.length - 1)),
      paintLane: (devPaintLane?.value as any) ?? "prompt",
      paintMode: (devPaintMode?.value as any) ?? "paint",
    };
    dispatchAndRender({ type: "DEV_SET_PAINT", patch } as Action);
  };

  devPaintEnabled?.addEventListener("change", syncPaintControlsToState);
  devPaintPlayer?.addEventListener("change", syncPaintControlsToState);
  devPaintLane?.addEventListener("change", syncPaintControlsToState);
  devPaintMode?.addEventListener("change", syncPaintControlsToState);


  // Live settings sync: when dropdowns/toggles change, update *visual* surfaces immediately
  // (so UI Mode, Note Visibility, Display Mode, etc. take effect without requiring a restart).
  doc.addEventListener("change", (ev) => {
    const target = ev.target as HTMLElement | null;
    if (!target) return;
    const ds = (target as any).dataset as { setting?: string } | undefined;
    if (!ds?.setting) return;

    const next = buildSettingsFromUi(doc, session) as any;

    // Allow preview even before the first match is started.
    if (!state) {
      if ((target as any).id === "core-gameMode") applyUiModeVisibility(next.uiMode);
      return;
    }

    const cur = state.settings as any;
    cur.uiMode = next.uiMode;
    cur.noteVisibility = next.noteVisibility;
    cur.displayMode = next.displayMode;
    cur.tritoneLabelMode = next.tritoneLabelMode;
    cur.rootNote = next.rootNote;
    cur.modeId = next.modeId;
    cur.chordKind = next.chordKind;
    cur.highlight = next.highlight;

    applyUiModeVisibility(cur.uiMode);
    updatePromptUi();
    syncFretKeypadAvailability();
  });

  // Initialize UI
  syncFretKeypadAvailability();
  updateHighScoresUi(buildSettingsFromUi(doc, session));
  setAlert("Choose Single or Multiplayer to begin");
  showSplash();
}