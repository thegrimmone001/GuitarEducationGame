import { NotationLayout, TimeSignature } from "./notationLayout";

export type KeySigSide = "sharps" | "flats" | null;

const SHARP_KEYS = ["G", "D", "A", "E", "B", "F#", "C#"];
const FLAT_KEYS = ["F", "Bb", "Eb", "Ab", "Db", "Gb", "Cb"];

export function keySigSide(k: string): KeySigSide {
  if (!k || k === "none") return null;
  if (SHARP_KEYS.includes(k)) return "sharps";
  if (FLAT_KEYS.includes(k)) return "flats";
  return null;
}

export function keySigCount(k: string): number {
  if (!k || k === "none") return 0;
  const s = keySigSide(k);
  if (s === "sharps") return SHARP_KEYS.indexOf(k) + 1;
  if (s === "flats") return FLAT_KEYS.indexOf(k) + 1;
  return 0;
}

type AccidentalMark = "sharp" | "flat" | "natural";

const SHARP_ORDER: string[] = ["F", "C", "G", "D", "A", "E", "B"];
const FLAT_ORDER: string[] = ["B", "E", "A", "D", "G", "C", "F"];

function impliedAccidentalForLetter(keySignature: string, letter: string): AccidentalMark | null {
  const side = keySigSide(keySignature);
  const count = keySigCount(keySignature);
  if (!side || count <= 0) return null;
  if (side === "sharps") return SHARP_ORDER.slice(0, count).includes(letter) ? "sharp" : null;
  return FLAT_ORDER.slice(0, count).includes(letter) ? "flat" : null;
}

function parseNoteSpelling(s: string | undefined): { letter: string | null; accidental: AccidentalMark | null } {
  if (!s) return { letter: null, accidental: null };
  const m = String(s).trim().match(/^([A-Ga-g])\s*([#♯b♭♮])?/);
  if (!m) return { letter: null, accidental: null };
  const letter = m[1].toUpperCase();
  const acc = m[2];
  if (acc === "#" || acc === "♯") return { letter, accidental: "sharp" };
  if (acc === "b" || acc === "♭") return { letter, accidental: "flat" };
  if (acc === "♮") return { letter, accidental: "natural" };
  return { letter, accidental: null }; // natural with no mark in spelling
}

function desiredAccidentalMark(keySignature: string, spelling: { letter: string | null; accidental: AccidentalMark | null }): AccidentalMark | null {
  if (!spelling.letter) return null;
  // If spelling has explicit sharp/flat/natural, respect it. Otherwise, natural (no mark).
  return spelling.accidental;
}

function initialMeasureAccState(keySignature: string): Record<string, AccidentalMark | null> {
  const state: Record<string, AccidentalMark | null> = {};
  for (const L of ["A","B","C","D","E","F","G"]) {
    state[L] = impliedAccidentalForLetter(keySignature, L);
  }
  return state;
}

// Key signature accidental placement per clef.
// We store Y offsets as multiples of staffGap from the TOP line (layout.staffLineY(0)).
// Positions follow standard engraving conventions for treble and bass clefs.
const TREBLE_SHARP_Y = [
  0.0,  // F# : top line
  1.5,  // C# : 3rd space (from bottom)
  -0.5, // G# : space above staff
  1.0,  // D# : 4th line (from bottom)
  2.5,  // A# : 2nd space (from bottom)
  0.5,  // E# : top space
  2.0,  // B# : 3rd line (from bottom)
] as const;

const TREBLE_FLAT_Y = [
  2.0,  // Bb : middle line
  0.5,  // Eb : 4th space (from bottom)
  2.5,  // Ab : 2nd space (from bottom)
  1.0,  // Db : 4th line (from bottom)
  3.0,  // Gb : 2nd line (from bottom)
  1.5,  // Cb : 3rd space (from bottom)
  3.5,  // Fb : 1st space (from bottom)
] as const;

const BASS_SHARP_Y = [
  1.0,  // F# : 4th line
  2.5,  // C# : 2nd space
  0.5,  // G# : 4th space
  2.0,  // D# : 3rd line
  3.5,  // A# : 1st space
  1.5,  // E# : 3rd space
  3.0,  // B# : 2nd line
] as const;

const BASS_FLAT_Y = [
  3.0,  // Bb : 2nd line
  1.5,  // Eb : 3rd space
  3.5,  // Ab : 1st space
  2.0,  // Db : 3rd line
  4.0,  // Gb : 1st line (bottom line)
  2.5,  // Cb : 2nd space
  4.5,  // Fb : space below staff
] as const;

function keySigYOffsets(clef: ClefType, side: "sharps" | "flats"): readonly number[] {
  if (clef === "bass") return side === "flats" ? BASS_FLAT_Y : BASS_SHARP_Y;
  return side === "flats" ? TREBLE_FLAT_Y : TREBLE_SHARP_Y;
}




export type StaffNote = {
  /** Render kind: a pitched notehead or a rest symbol. */
  kind?: "note" | "rest";
  /** Column index in the shared rhythm grid. */
  col: number;
  /** Diatonic step index in staff-space (0=top line, increases downward by half-steps of lines/spaces). */
  yIndex: number;
  /** Selected pitch spelling at time of placement (e.g., C, F#, Bb). */
  note?: string;
  /** Rendered accidental mark ("nat" is kept for backwards compatibility; "natural" is preferred). */
  accidental?: "sharp" | "flat" | "natural" | "nat" | null;
  /** Duration: whole, half, quarter, eighth (A1.6 baseline). */
  duration?: "w" | "h" | "q" | "e";
  /** For grand staff: which staff this note belongs to. */
  staff?: "treble" | "bass";
  isPrompt?: boolean;
};

export type TabNumber = {
  col: number;
  stringIndex: 0 | 1 | 2 | 3 | 4 | 5;
  fret: number;
  isPrompt?: boolean;
};

export type ClefType = "treble" | "bass" | "grand";

export type RenderModel = {
  clef: ClefType;
  keySignature: string;
  timeSignature: TimeSignature;
  staffNotes: StaffNote[];
  tabNumbers: TabNumber[];
};

/**
 * Draws STAFF + TAB bands, signatures, and a light rhythm grid.
 */
export function renderNotation(ctx: CanvasRenderingContext2D, layout: NotationLayout, model: RenderModel): void {
  // Background clear handled by caller.
  drawSystems(ctx, layout);
  drawGrid(ctx, layout);
  drawBarlines(ctx, layout);
  drawClef(ctx, layout, model.clef);
  drawKeySignature(ctx, layout, model.clef, model.keySignature);
  drawTimeSignature(ctx, layout, model.clef, model.timeSignature);
  drawStaffNotes(ctx, layout, model.clef, model.staffNotes, model.keySignature);
  drawTabNumbers(ctx, layout, model.tabNumbers);
}

/**
 * Barlines at measure boundaries.
 * These are distinct from the light rhythm grid and must not bleed into the TAB in a confusing way.
 */
export function drawBarlines(ctx: CanvasRenderingContext2D, layout: NotationLayout): void {
  ctx.save();
  const totalCols = layout.measures * layout.colsPerMeasure;
  if (totalCols <= 0) return;

  const x0 = layout.colX(0);
  const x1 = layout.colX(1);
  const colW = x1 - x0;
  if (!(colW > 0)) return;

  ctx.strokeStyle = "rgba(0,0,0,0.32)";
  ctx.lineWidth = 1.5;

  const drawOneStaffBar = (staffLineY: (i: 0|1|2|3|4) => number) => {
    for (let m = 0; m <= layout.measures; m++) {
      const boundaryCol = m * layout.colsPerMeasure;
      const xBoundary = layout.colX(boundaryCol) - 0.5 * colW;
      const xx = Math.round(xBoundary) + 0.5;

      ctx.beginPath();
      ctx.moveTo(xx, staffLineY(0));
      ctx.lineTo(xx, staffLineY(4));
      ctx.stroke();
    }
  };

  // Staff barlines
  drawOneStaffBar(layout.staffLineY);
  if (layout.staffSystem === "grand" && layout.bassStaffLineY) {
    drawOneStaffBar(layout.bassStaffLineY);
  }

  // Tab barlines
  for (let m = 0; m <= layout.measures; m++) {
    const boundaryCol = m * layout.colsPerMeasure;
    const xBoundary = layout.colX(boundaryCol) - 0.5 * colW;
    const xx = Math.round(xBoundary) + 0.5;

    ctx.beginPath();
    ctx.moveTo(xx, layout.tabLineY(0));
    ctx.lineTo(xx, layout.tabLineY(5));
    ctx.stroke();
  }

  ctx.restore();
}

export function drawSystems(ctx: CanvasRenderingContext2D, layout: NotationLayout): void {
  ctx.save();

  const drawOneStaff = (staffLineY: (i: 0|1|2|3|4) => number) => {
    ctx.lineWidth = 1.25;
    ctx.strokeStyle = "rgba(0,0,0,0.85)";
    for (let i = 0; i < 5; i++) {
      const y = Math.round(staffLineY(i as 0|1|2|3|4)) + 0.5;
      ctx.beginPath();
      ctx.moveTo(layout.padL, y);
      ctx.lineTo(layout.width - layout.padR, y);
      ctx.stroke();
    }
  };

  // Primary staff
  drawOneStaff(layout.staffLineY);

  // Secondary staff (grand staff)
  if (layout.staffSystem === "grand" && layout.bassStaffLineY) {
    drawOneStaff(layout.bassStaffLineY);

    // Brace / bracket indicator (minimal, font-independent)
    // Canon: do not over-stylize; provide a predictable visual link between the two staves.
    const x = layout.signatureX + 2;
    const yTop = layout.staffLineY(0);
    const yBot = layout.bassStaffLineY(4);
    ctx.strokeStyle = "rgba(0,0,0,0.70)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, yTop - layout.staffGap * 0.5);
    ctx.bezierCurveTo(x - 10, yTop + layout.staffGap, x - 10, yBot - layout.staffGap, x, yBot + layout.staffGap * 0.5);
    ctx.stroke();
  }

  // Tab lines
  ctx.lineWidth = 1.05;
  ctx.strokeStyle = "rgba(0,0,0,0.78)";
  for (let i = 0; i < 6; i++) {
    const y = Math.round(layout.tabLineY(i as 0 | 1 | 2 | 3 | 4 | 5)) + 0.5;
    ctx.beginPath();
    ctx.moveTo(layout.padL, y);
    ctx.lineTo(layout.width - layout.padR, y);
    ctx.stroke();
  }

  ctx.restore();
}

export function drawGrid(ctx: CanvasRenderingContext2D, layout: NotationLayout): void {
  ctx.save();
  const totalCols = layout.measures * layout.colsPerMeasure;
  if (totalCols <= 0) return;

  const x0 = layout.colX(0);
  const x1 = layout.colX(1);
  const colW = x1 - x0;

  const drawBand = (top: number, bottom: number) => {
    for (let col = 0; col < totalCols; col++) {
      const x = layout.colX(col);
      const inMeasure = col % layout.colsPerMeasure;

      const isMeasureBoundary = inMeasure === 0;
      const isBeatBoundary = inMeasure % Math.max(1, layout.colsPerMeasure / 4) === 0;

      ctx.strokeStyle = isMeasureBoundary
        ? "rgba(0,0,0,0.18)"
        : isBeatBoundary
          ? "rgba(0,0,0,0.10)"
          : "rgba(0,0,0,0.05)";
      ctx.lineWidth = isMeasureBoundary ? 1.25 : 1;

      const xx = Math.round(x) + 0.5;
      ctx.beginPath();
      ctx.moveTo(xx, top);
      ctx.lineTo(xx, bottom);
      ctx.stroke();

      if (colW <= 0) break;
    }
  };

  // Staff band(s): do not draw through the between-gap or staff->tab gap.
  drawBand(layout.staffBandTop, layout.staffBandBottom);

  // In grand staff, we want the subtle grid to remain inside each staff band,
  // not across the between-gap. So redraw per band with correct bounds.
  if (layout.staffSystem === "grand" && layout.bassStaffBandTop != null && layout.bassStaffBandBottom != null) {
    // Primary band
    const primaryTop = layout.staffBandTop;
    const primaryBottom = (layout.bassStaffBandTop ?? layout.staffBandBottom) - 0.0001;
    // Secondary band
    const secondaryTop = layout.bassStaffBandTop;
    const secondaryBottom = layout.bassStaffBandBottom;

    // Clear the previous staff band grid by overdrawing? Avoid; instead, just draw cleanly in both bands.
    // The initial drawBand(layout.staffBandTop, layout.staffBandBottom) might have crossed the between-gap.
    // So we re-draw with a clip to enforce the gap.
    ctx.save();
    // Clip to primary band
    ctx.beginPath();
    ctx.rect(layout.padL, primaryTop, layout.width - layout.padL - layout.padR, primaryBottom - primaryTop);
    ctx.clip();
    drawBand(primaryTop, primaryBottom);
    ctx.restore();

    ctx.save();
    ctx.beginPath();
    ctx.rect(layout.padL, secondaryTop, layout.width - layout.padL - layout.padR, secondaryBottom - secondaryTop);
    ctx.clip();
    drawBand(secondaryTop, secondaryBottom);
    ctx.restore();
  }

  // TAB band
  drawBand(layout.tabTop, layout.tabBottom);

  ctx.restore();
}

/**
 * Clef rendering (font-independent).
 */
export function drawClef(ctx: CanvasRenderingContext2D, layout: NotationLayout, clef: ClefType): void {
  const drawSingle = (staffTop: number, staffGap: number, kind: "treble" | "bass") => {
    ctx.save();
    const x = layout.signatureX + 10;
    const g = staffGap;
    const topY = staffTop;
    const midY = topY + 2 * g;
    const s = Math.max(0.85, g / 10);

    ctx.strokeStyle = "rgba(0,0,0,0.88)";
    ctx.fillStyle = "rgba(0,0,0,0.88)";
    ctx.lineWidth = 2.2 * s;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (kind === "bass") {
      const fLineY = topY + 1 * g;

      ctx.beginPath();
      ctx.moveTo(x + 6 * s, fLineY - 18 * s);
      ctx.bezierCurveTo(x + 26 * s, fLineY - 18 * s, x + 28 * s, fLineY + 6 * s, x + 12 * s, fLineY + 10 * s);
      ctx.bezierCurveTo(x - 2 * s, fLineY + 14 * s, x + 2 * s, fLineY + 30 * s, x + 20 * s, fLineY + 30 * s);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(x + 18 * s, fLineY + 28 * s);
      ctx.quadraticCurveTo(x + 6 * s, fLineY + 40 * s, x + 6 * s, fLineY + 54 * s);
      ctx.stroke();

      const dotX = x + 34 * s;
      const dotR = 2.8 * s;
      ctx.beginPath();
      ctx.arc(dotX, fLineY - 0.5 * g, dotR, 0, Math.PI * 2);
      ctx.arc(dotX, fLineY + 0.5 * g, dotR, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
      return;
    }

    // Treble clef
    ctx.beginPath();
    ctx.moveTo(x, midY - 18 * s);
    ctx.bezierCurveTo(x + 14 * s, midY - 26 * s, x + 20 * s, midY - 6 * s, x + 2 * s, midY);
    ctx.bezierCurveTo(x - 14 * s, midY + 6 * s, x - 10 * s, midY + 20 * s, x + 6 * s, midY + 18 * s);
    ctx.bezierCurveTo(x + 22 * s, midY + 14 * s, x + 14 * s, midY - 2 * s, x + 2 * s, midY + 4 * s);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(x + 2 * s, midY - 30 * s);
    ctx.lineTo(x + 2 * s, midY + 36 * s);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(x + 10 * s, midY + 24 * s, 10 * s, Math.PI * 0.1, Math.PI * 1.9);
    ctx.stroke();

    ctx.restore();
  };

  if (clef === "grand") {
    drawSingle(layout.staffTop, layout.staffGap, "treble");
    if (layout.bassStaffTop != null) drawSingle(layout.bassStaffTop, layout.staffGap, "bass");
    return;
  }
  drawSingle(layout.staffTop, layout.staffGap, clef);
}

export function drawKeySignature(ctx: CanvasRenderingContext2D, layout: NotationLayout, clef: ClefType, keySignature: string): void {
  const side = keySigSide(keySignature);
  const count = keySigCount(keySignature);
  if (!side || count <= 0) return;

  const drawFor = (staffLineY0: number, staffClef: "treble" | "bass") => {
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,0.90)";
    ctx.textBaseline = "middle";
    ctx.textAlign = "center";
    ctx.font = `${Math.round(Math.max(16, layout.staffGap * 1.8))}px serif`;

    const glyph = side === "flats" ? "♭" : "♯";
    const offsets = keySigYOffsets(staffClef, side);

    let x = layout.signatureX + layout.clefBoxW;
    for (let i = 0; i < count; i++) {
      const y = staffLineY0 + (offsets[i] ?? 0) * layout.staffGap;
      ctx.fillText(glyph, x, y);
      x += layout.keySigStepX;
    }
    ctx.restore();
  };

  if (clef === "grand") {
    drawFor(layout.staffLineY(0), "treble");
    if (layout.bassStaffLineY) drawFor(layout.bassStaffLineY(0), "bass");
    return;
  }

  drawFor(layout.staffLineY(0), clef);
}

export function drawTimeSignature(ctx: CanvasRenderingContext2D, layout: NotationLayout, clef: ClefType, ts: TimeSignature): void {
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.90)";
  ctx.textBaseline = "alphabetic";
  ctx.textAlign = "left";
  ctx.font = `${Math.round(Math.max(14, layout.staffGap * 1.85))}px serif`;

  const x = layout.timeSigX;

  if (clef === "grand" && layout.bassStaffTop != null) {
    // Center between the two staves.
    const yMid = (layout.staffBottom + layout.bassStaffTop) / 2;
    ctx.fillText(String(ts.top), x, yMid - 0.2 * layout.staffGap);
    ctx.fillText(String(ts.bottom), x, yMid + 1.2 * layout.staffGap);
    ctx.restore();
    return;
  }

  ctx.fillText(String(ts.top), x, layout.staffTop + 1.3 * layout.staffGap);
  ctx.fillText(String(ts.bottom), x, layout.staffTop + 2.7 * layout.staffGap);
  ctx.restore();
}

/**
 * Render staff notes/rests.
 * For grand staff, notes are rendered into their explicit staff bands (no guessing, no auto-switching).
 */
export function drawStaffNotes(ctx: CanvasRenderingContext2D, layout: NotationLayout, clef: ClefType, notes: StaffNote[], keySignature: string): void {
  const treble = notes.filter(n => (n.staff ?? "treble") === "treble");
  const bass = notes.filter(n => (n.staff ?? "treble") === "bass");

  drawStaffNotesOnBand(ctx, layout, treble, keySignature, {
    bandTop: layout.staffBandTop,
    bandBottom: clef === "grand" && layout.bassStaffBandTop != null ? layout.bassStaffBandTop : layout.staffBandBottom,
    staffTop: layout.staffTop,
    staffLineY: layout.staffLineY,
  });

  if (clef === "grand" && layout.bassStaffBandTop != null && layout.bassStaffBandBottom != null && layout.bassStaffTop != null && layout.bassStaffLineY) {
    drawStaffNotesOnBand(ctx, layout, bass, keySignature, {
      bandTop: layout.bassStaffBandTop,
      bandBottom: layout.bassStaffBandBottom,
      staffTop: layout.bassStaffTop,
      staffLineY: layout.bassStaffLineY,
    });
  }
}

type StaffBand = {
  bandTop: number;
  bandBottom: number;
  staffTop: number;
  staffLineY: (i: 0|1|2|3|4) => number;
};

function drawStaffNotesOnBand(
  ctx: CanvasRenderingContext2D,
  layout: NotationLayout,
  notes: StaffNote[],
  keySignature: string,
  band: StaffBand,
): void {
  ctx.save();

  // Clip to this staff band.
  ctx.beginPath();
  ctx.rect(layout.padL, band.bandTop, layout.width - layout.padL - layout.padR, band.bandBottom - band.bandTop);
  ctx.clip();

  // Measure-aware accidental carry (A1.6): accidentals persist within a measure and reset at barlines.
  const colsPerMeasure = Math.max(1, layout.colsPerMeasure);
  const sorted = [...notes].sort((a, b) => a.col - b.col);

  let currentMeasure = -1;
  let accState: Record<string, AccidentalMark | null> = initialMeasureAccState(keySignature ?? "none");

  for (const n of sorted) {
    const x = layout.colX(n.col);
    const y = band.staffTop + (n.yIndex * layout.staffGap) / 2;

    const mIndex = Math.floor(n.col / colsPerMeasure);
    if (mIndex !== currentMeasure) {
      currentMeasure = mIndex;
      accState = initialMeasureAccState(keySignature ?? "none");
    }

    let renderAcc: AccidentalMark | null = null;
    if ((n.kind ?? "note") === "note") {
      const spelling = parseNoteSpelling(n.note);
      const desired = desiredAccidentalMark(keySignature ?? "none", spelling);
      if (spelling.letter) {
        const prev = accState[spelling.letter] ?? null;
        const desiredResolved: AccidentalMark | null = desired ?? null;
        if (desiredResolved !== prev) {
          renderAcc = desiredResolved ?? "natural";
          accState[spelling.letter] = desiredResolved;
        }
      }
    }

    drawStaffNoteOnBand(ctx, layout, x, y, { ...n, accidental: renderAcc ?? undefined }, band);
  }

  ctx.restore();
}

function drawStaffNoteOnBand(
  ctx: CanvasRenderingContext2D,
  layout: NotationLayout,
  x: number,
  y: number,
  note: StaffNote,
  band: StaffBand,
): void {
  if ((note.kind ?? "note") === "rest") {
    drawStaffRest(ctx, layout, x, y, note.duration ?? "q", Boolean(note.isPrompt));
    return;
  }

  const rX = Math.max(5, layout.staffGap * 0.65);
  const rY = Math.max(3.5, layout.staffGap * 0.45);
  const dur = note.duration ?? "q";

  const topLineY = band.staffLineY(0);
  const bottomLineY = band.staffLineY(4);

  // Ledger lines
  ctx.strokeStyle = "rgba(0,0,0,0.80)";
  ctx.lineWidth = 1;
  const ledgerHalfSteps = Math.round(((topLineY - y) * 2) / layout.staffGap);
  const ledgerBelowHalfSteps = Math.round(((y - bottomLineY) * 2) / layout.staffGap);

  if (y < topLineY - 0.1) {
    const steps = Math.max(0, Math.ceil(ledgerHalfSteps / 2));
    for (let i = 1; i <= steps; i++) {
      const ly = topLineY - i * layout.staffGap;
      ctx.beginPath();
      ctx.moveTo(x - rX * 1.2, ly);
      ctx.lineTo(x + rX * 1.2, ly);
      ctx.stroke();
    }
  } else if (y > bottomLineY + 0.1) {
    const steps = Math.max(0, Math.ceil(ledgerBelowHalfSteps / 2));
    for (let i = 1; i <= steps; i++) {
      const ly = bottomLineY + i * layout.staffGap;
      ctx.beginPath();
      ctx.moveTo(x - rX * 1.2, ly);
      ctx.lineTo(x + rX * 1.2, ly);
      ctx.stroke();
    }
  }

  // Accidentals
  if (note.accidental) {
    ctx.fillStyle = "rgba(0,0,0,0.90)";
    ctx.font = `${Math.round(Math.max(14, layout.staffGap * 1.6))}px serif`;
    ctx.textBaseline = "middle";
    ctx.textAlign = "center";
    const glyph = note.accidental === "sharp" ? "♯" : note.accidental === "flat" ? "♭" : "♮";
    ctx.fillText(glyph, x - rX * 2.2, y);
  }

  // Notehead (A1.6 baseline)
  const fill = dur === "w" || dur === "h" ? "rgba(255,255,255,1)" : note.isPrompt ? "rgba(0,0,0,0.92)" : "rgba(0,0,0,0.84)";
  ctx.strokeStyle = "rgba(0,0,0,0.88)";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.ellipse(x, y, rX, rY, -0.35, 0, Math.PI * 2);
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.stroke();

  // Stem (none for whole)
  if (dur !== "w") {
    const middleLineY = band.staffLineY(2);
    const stemUp = y > middleLineY;

    const stemH = layout.staffGap * 3.2;
    ctx.strokeStyle = "rgba(0,0,0,0.88)";
    ctx.lineWidth = 1.6;

    const xStem = stemUp ? x + rX * 0.85 : x - rX * 0.85;
    const y0 = y;
    const y1 = stemUp ? y - stemH : y + stemH;

    ctx.beginPath();
    ctx.moveTo(xStem, y0);
    ctx.lineTo(xStem, y1);
    ctx.stroke();

    // Flag for eighth (beaming comes later)
    if (dur === "e") {
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      if (stemUp) {
        ctx.moveTo(xStem, y1);
        ctx.quadraticCurveTo(xStem + rX * 1.6, y1 + layout.staffGap * 0.3, xStem + rX * 1.2, y1 + layout.staffGap * 1.1);
      } else {
        ctx.moveTo(xStem, y1);
        ctx.quadraticCurveTo(xStem + rX * 1.6, y1 - layout.staffGap * 0.3, xStem + rX * 1.2, y1 - layout.staffGap * 1.1);
      }
      ctx.stroke();
    }
  }
}

function drawStaffRest(
  ctx: CanvasRenderingContext2D,
  layout: NotationLayout,
  x: number,
  y: number,
  dur: "w" | "h" | "q" | "e",
  isPrompt: boolean,
): void {
  ctx.save();
  const ink = isPrompt ? "rgba(0,0,0,0.92)" : "rgba(0,0,0,0.84)";
  ctx.fillStyle = ink;
  ctx.strokeStyle = ink;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  const g = layout.staffGap;
  const w = Math.max(10, g * 1.25);
  const h = Math.max(6, g * 0.55);

  // Whole/Half: simple rectangles on a line position (standard engraving behavior).
  if (dur === "w" || dur === "h") {
    // Whole rests hang from the 4th line; half rests sit on the 3rd line.
    const lineY = dur === "w" ? layout.staffLineY(1) : layout.staffLineY(2);
    const ry = Math.round(lineY - h / 2) + 0.5;
    const rx = Math.round(x - w / 2) + 0.5;
    ctx.fillRect(rx, ry, w, h);
    ctx.restore();
    return;
  }

  // Quarter/Eighth: a simplified "squiggle" that reads like a rest without SMuFL dependency.
  ctx.lineWidth = Math.max(2, g * 0.18);

  // Base vertical stroke with two bends.
  ctx.beginPath();
  ctx.moveTo(x, y - g * 1.2);
  ctx.quadraticCurveTo(x - g * 0.35, y - g * 0.55, x + g * 0.15, y - g * 0.10);
  ctx.quadraticCurveTo(x + g * 0.45, y + g * 0.25, x - g * 0.05, y + g * 0.55);
  ctx.quadraticCurveTo(x - g * 0.55, y + g * 0.90, x + g * 0.10, y + g * 1.25);
  ctx.stroke();

  // Small "dot" at the end for the typical rest tail.
  ctx.beginPath();
  ctx.arc(x + g * 0.10, y + g * 1.25, Math.max(1.6, g * 0.12), 0, Math.PI * 2);
  ctx.fill();

  // Eighth rest adds a single flag.
  if (dur === "e") {
    ctx.beginPath();
    ctx.moveTo(x + g * 0.08, y - g * 0.55);
    ctx.quadraticCurveTo(x + g * 0.65, y - g * 0.70, x + g * 0.35, y - g * 0.18);
    ctx.stroke();
  }

  ctx.restore();
}

export function drawTabNumbers(ctx: CanvasRenderingContext2D, layout: NotationLayout, nums: TabNumber[]): void {
  ctx.save();

  // Hard clip to the TAB band.
  // Canon: tab content must never intrude upward into the staff region.
  ctx.beginPath();
  ctx.rect(
    layout.padL,
    layout.tabTop - layout.tabGap * 0.6,
    layout.width - layout.padL - layout.padR,
    (layout.tabBottom - layout.tabTop) + layout.tabGap * 1.2,
  );
  ctx.clip();
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const fontPx = Math.round(Math.max(12, layout.tabGap * 1.35));
  ctx.font = `${fontPx}px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial`;

  for (const t of nums) {
    const x = layout.colX(t.col);
    const y = layout.tabLineY(t.stringIndex);
    const text = String(t.fret);

    // Readability: numbers should not visually fuse with the TAB lines.
    // Draw a small white backing plate behind the text.
    const w = Math.max(fontPx * 0.9, ctx.measureText(text).width + 8);
    const h = Math.max(fontPx * 0.95, fontPx + 6);
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.fillRect(x - w / 2, y - h / 2, w, h);

    ctx.fillStyle = "rgba(0,0,0,0.92)";
    ctx.fillText(text, x, y);
  }

  ctx.restore();
}
