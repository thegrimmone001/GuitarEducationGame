export type TimeSignature = { top: number; bottom: number };

/**
 * Single geometry authority for the notation canvas.
 *
 * Canon intent:
 * - STAFF and TAB are separate systems with separate line spacing.
 * - All placement derives from shared geometry, not ad-hoc coordinate math.
 * - Grand staff is supported as a predictable, non-leaky layout mode.
 */
export type NotationLayout = {
  // canvas CSS pixels (NOT device pixels)
  width: number;
  height: number;

  // outer padding
  padL: number;
  padR: number;
  padT: number;
  padB: number;

  // staff system mode
  staffSystem: "single" | "grand";

  // Primary staff geometry (treble when grand; otherwise the only staff).
  // staffBandTop/staffBandBottom reserve extra vertical space for ledger lines above/below the 5-line staff.
  staffBandTop: number;
  staffTop: number;
  staffGap: number; // distance between staff lines
  staffLineY: (i: 0 | 1 | 2 | 3 | 4) => number;
  staffBottom: number;
  staffBandBottom: number;

  // Secondary staff geometry (bass staff when grand; undefined otherwise)
  bassStaffBandTop?: number;
  bassStaffTop?: number;
  bassStaffLineY?: (i: 0 | 1 | 2 | 3 | 4) => number;
  bassStaffBottom?: number;
  bassStaffBandBottom?: number;
  staffBetweenGap?: number;

  // tab geometry
  tabTop: number;
  tabGap: number; // distance between tab lines
  tabLineY: (i: 0 | 1 | 2 | 3 | 4 | 5) => number;
  tabBottom: number;

  // separation gap (between last staff band and TAB)
  staffToTabGap: number;

  // signature region
  signatureX: number;
  clefBoxW: number;
  keySigStepX: number;
  timeSigX: number;

  // rhythm grid (visual guardrails)
  measures: number;
  colsPerMeasure: number;
  colX: (col: number) => number;
};

export type NotationLayoutParams = {
  width: number;
  height: number;
  measures?: number;
  colsPerMeasure?: number;
  padL?: number;
  padR?: number;
  padT?: number;
  padB?: number;
  staffSystem?: "single" | "grand";
};

/**
 * Computes the layout for the notation canvas.
 *
 * Grand staff policy:
 * - Always render both staves when enabled.
 * - Never auto-switch or auto-collapse based on the target note (no giveaway).
 * - Staff band heights remain stable per mode; only measure count changes responsively (handled elsewhere).
 */
export function computeNotationLayout(p: NotationLayoutParams): NotationLayout {
  const width = Math.max(1, p.width);
  const height = Math.max(1, p.height);

  const padL = p.padL ?? 18;
  const padR = p.padR ?? 18;
  const padT = p.padT ?? 12;
  const padB = p.padB ?? 12;

  const measures = p.measures ?? 3;
  const colsPerMeasure = p.colsPerMeasure ?? 16;

  const staffSystem = p.staffSystem ?? "single";

  const availH = Math.max(1, height - padT - padB);

  // Staff/tab gaps are derived from available height but clamped to readable ranges.
  let staffGap = clamp(availH / 20, 8, 12);
  let tabGap = clamp(availH / 22, 7, 10);
  let staffToTabGap = clamp(availH * 0.08, 14, 20);

  // Extra headroom for ledger lines above/below each 5-line staff.
  let ledgerPad = clamp(availH * 0.16, staffGap * 3.0, staffGap * 5.0);

  // Gap between staves in grand staff (visual breathing room).
  let staffBetweenGap = clamp(availH * 0.06, staffGap * 2.0, staffGap * 3.2);

  let staffH = 4 * staffGap;
  let tabH = 5 * tabGap;

  // Total height needed depends on staff system.
  const needSingle = (ledgerPad * 2 + staffH) + staffToTabGap + tabH;
  const needGrand = (ledgerPad * 2 + staffH) + staffBetweenGap + (ledgerPad * 2 + staffH) + staffToTabGap + tabH;
  const need = staffSystem === "grand" ? needGrand : needSingle;

  // Fit if panel is short.
  if (need > availH) {
    const scale = availH / need;
    staffGap *= scale;
    tabGap *= scale;
    ledgerPad = Math.max(10, ledgerPad * scale);
    staffBetweenGap = Math.max(8, staffBetweenGap * scale);
    staffToTabGap = Math.max(10, staffToTabGap * scale);
    staffH = 4 * staffGap;
    tabH = 5 * tabGap;
  }

  // --- Staff system geometry ---
  const staffBandTop = padT;
  const staffTop = staffBandTop + ledgerPad;
  const staffBottom = staffTop + staffH;
  let staffBandBottom = staffBottom + ledgerPad;

  let bassStaffBandTop: number | undefined;
  let bassStaffTop: number | undefined;
  let bassStaffBottom: number | undefined;
  let bassStaffBandBottom: number | undefined;

  if (staffSystem === "grand") {
    bassStaffBandTop = staffBandBottom + staffBetweenGap;
    bassStaffTop = bassStaffBandTop + ledgerPad;
    bassStaffBottom = bassStaffTop + staffH;
    bassStaffBandBottom = bassStaffBottom + ledgerPad;
    staffBandBottom = bassStaffBandBottom;
  }

  const tabTop = staffBandBottom + staffToTabGap;
  const tabBottom = tabTop + tabH;

  const bandW = width - padL - padR;

  // Signature placement: reserve a clef box and then place key signature and time signature.
  const signatureX = padL;
  const clefBoxW = Math.max(28, staffGap * 2.9);
  const keySigStepX = Math.max(11, staffGap * 1.22);
  const timeSigX = signatureX + clefBoxW + keySigStepX * 8; // enough room for up to 7 accidentals + padding

  // Rhythm columns span from after signatures to the right edge.
  const gridStartX = timeSigX + keySigStepX * 2;
  const gridEndX = padL + bandW;
  const totalCols = measures * colsPerMeasure;
  const colW = totalCols > 0 ? (gridEndX - gridStartX) / totalCols : 10;

  const colX = (col: number) => gridStartX + (col + 0.5) * colW;

  return {
    width,
    height,
    padL,
    padR,
    padT,
    padB,
    staffSystem,
    staffBandTop,
    staffTop,
    staffGap,
    staffLineY: (i) => staffTop + i * staffGap,
    staffBottom,
    staffBandBottom,
    bassStaffBandTop,
    bassStaffTop,
    bassStaffLineY: bassStaffTop ? ((i: 0|1|2|3|4) => bassStaffTop + i*staffGap) : undefined,
    bassStaffBottom,
    bassStaffBandBottom,
    staffBetweenGap: staffSystem === "grand" ? staffBetweenGap : undefined,
    tabTop,
    tabGap,
    tabLineY: (i) => tabTop + i * tabGap,
    tabBottom,
    staffToTabGap,
    signatureX,
    clefBoxW,
    keySigStepX,
    timeSigX,
    measures,
    colsPerMeasure,
    colX,
  };
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}
