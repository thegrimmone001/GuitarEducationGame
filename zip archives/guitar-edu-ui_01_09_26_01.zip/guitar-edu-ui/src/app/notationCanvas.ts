import { computeNotationLayout } from "./notation/notationLayout";
import { renderNotation, RenderModel } from "./notation/notationRenderer";

type Settings = Record<string, any>;

/**
 * Minimal Canvas renderer scaffolding for the Staff+TAB stage.
 *
 * Canon goals for this layer:
 * - Key signatures (sharps/flats) are rendered after the clef and before the time signature.
 * - Major/minor does not change the signature glyphs; it affects context later.
 * - This is a rendering layer only (hitboxes remain on the existing overlay for now).
 */



function getClefFromSettings(settings: Settings): RenderModel["clef"] {
  // Canon: clef selection must be deterministic and must not auto-switch based on target pitch.
  // If core.clef is not explicitly set, fall back to a predictable instrument-based default.
  const raw = (settings as any)?.["core.clef"];
  const fallbackInstrument = String((settings as any)?.["pref.instrument"] ?? "guitar").trim().toLowerCase();
  const fallbackClef = fallbackInstrument === "bass" ? "bass" : "treble";
  const c = String(raw ?? fallbackClef).trim().toLowerCase();
  if (c === "grand") return "grand";
  return c === "bass" ? "bass" : "treble";
}

function getKeySignatureFromSettings(settings: Settings): string {
  // Back-compat: earlier builds used core.keyContext.
  const ks = String((settings as any)?.["core.keySignature"] ?? "").trim();
  if (ks) return ks;
  return String((settings as any)?.["core.keyContext"] ?? "none").trim() || "none";
}

type MarkerStore = {
  staffNotes: RenderModel["staffNotes"];
  tabNumbers: RenderModel["tabNumbers"];
};

function getMarkerStore(): MarkerStore {
  const w = window as any;
  if (!w.__GEDU_NOTATION_MARKERS) {
    w.__GEDU_NOTATION_MARKERS = { staffNotes: [], tabNumbers: [] } as MarkerStore;
  }
  return w.__GEDU_NOTATION_MARKERS as MarkerStore;
}

function isEduSession(): boolean {
  // Controller sets this when the splash selects Education Mode.
  return Boolean((window as any).__GEDU_SESSION === "edu");
}

function getSelectedNote(): string {
  return String((window as any).__GEDU_SELECTED_NOTE ?? "C");
}

function getEduTool(): "input" | "erase" {
  const erase = document.getElementById("edu-tool-erase") as HTMLInputElement | null;
  return erase?.checked ? "erase" : "input";
}

type EduDuration = "w" | "h" | "q" | "e";

function getEduDuration(): EduDuration {
  const ids: Array<[EduDuration, string]> = [
    ["w", "edu-dur-w"],
    ["h", "edu-dur-h"],
    ["q", "edu-dur-q"],
    ["e", "edu-dur-e"],
  ];
  for (const [dur, id] of ids) {
    const el = document.getElementById(id) as HTMLInputElement | null;
    if (el?.checked) return dur;
  }
  return "q";
}

function getEduPlaceKind(): "note" | "rest" {
  const rest = document.getElementById("edu-place-rest") as HTMLInputElement | null;
  return rest?.checked ? "rest" : "note";
}

function isShowing(surface: "staff" | "tab"): boolean {
  const id = surface === "staff" ? "edu-show-staff" : "edu-show-tab";
  const el = document.getElementById(id) as HTMLInputElement | null;
  return el ? Boolean(el.checked) : true;
}

function activeUtilityTab(): string {
  const section = document.querySelector<HTMLElement>('[data-tabs="right"]');
  const active = section?.querySelector<HTMLElement>(`.tab.active`) ?? null;
  return String(active?.getAttribute("data-tab") ?? "num");
}

function getFretNumberFallback(): number {
  const raw = (window as any).__GEDU_FRET_NUMBER;
  const n = Number(raw);
  return Number.isFinite(n) ? Math.max(0, Math.min(36, n)) : 0;
}

function dist2(ax: number, ay: number, bx: number, by: number) {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
}

type PitchParts = { letter: "A" | "B" | "C" | "D" | "E" | "F" | "G"; acc: "sharp" | "flat" | null };

function parsePitch(note: string): PitchParts {
  const s = String(note || "C").trim();
  const m = s.match(/^([A-Ga-g])\s*([#♯b♭])?/) ?? null;
  const letter = (m?.[1]?.toUpperCase() ?? "C") as PitchParts["letter"];
  const accRaw = m?.[2] ?? "";
  const acc = accRaw === "#" || accRaw === "♯" ? "sharp" : accRaw === "b" || accRaw === "♭" ? "flat" : null;
  return { letter, acc };
}

function letterIndex(letter: PitchParts["letter"]): number {
  // Diatonic index for C..B.
  switch (letter) {
    case "C":
      return 0;
    case "D":
      return 1;
    case "E":
      return 2;
    case "F":
      return 3;
    case "G":
      return 4;
    case "A":
      return 5;
    case "B":
      return 6;
  }
}

function clefTopLineIndex(clef: RenderModel["clef"]): number {
  // yIndex 0 = top line of the staff.
  // Treble top line is F5. Bass top line is A3.
  if (clef === "bass") {
    return 3 * 7 + letterIndex("A");
  }
  return 5 * 7 + letterIndex("F");
}

function closestYIndexForPitch(clef: RenderModel["clef"], pitch: PitchParts, desiredYIndex: number): number {
  // Choose the octave that places the selected pitch class closest to the clicked staff position.
  // This keeps engraving-correct behavior (staff position defines register) while still letting
  // the user steer octave/register by click height.
  const ref = clefTopLineIndex(clef);
  const li = letterIndex(pitch.letter);
  let best = 0;
  let bestD = Number.POSITIVE_INFINITY;
  for (let octave = 0; octave <= 8; octave++) {
    const noteIdx = octave * 7 + li;
    const yIndex = ref - noteIdx;
    const d = Math.abs(yIndex - desiredYIndex);
    if (d < bestD) {
      bestD = d;
      best = yIndex;
    }
  }
  return best;
}

let bound = false;

function bestLayout(width: number, height: number, clef: RenderModel["clef"]) {
  // Responsive measures: prefer 3, fall back to 2 or 1 as space tightens.
  // Selection is based on the resulting rhythmic column width (colW) so TAB
  // numbers and noteheads remain readable.
  const colsPerMeasure = 16;
  const minColW = 18; // CSS px
  for (const measures of [3, 2, 1]) {
    const l = computeNotationLayout({ width, height, measures, colsPerMeasure, staffSystem: clef === "grand" ? "grand" : "single" });
    const colW = l.colX(1) - l.colX(0);
    if (Number.isFinite(colW) && colW >= minColW) return l;
  }
  return computeNotationLayout({ width, height, measures: 1, colsPerMeasure, staffSystem: clef === "grand" ? "grand" : "single" });
}

export function renderNotationCanvas(): void {
  const canvas = document.getElementById("notationCanvas") as HTMLCanvasElement | null;
  if (!canvas) return;

  // When the canvas renderer is active, the legacy SVG background must be hidden.
  // The SVG overlay remains for hitboxes until interaction is moved to canvas.
  const stage = document.getElementById("svgStage");
  stage?.classList.add("canvasNotationActive");
  const settings = (window as any).__GEDU_SETTINGS as Settings | undefined;
  const clef = getClefFromSettings(settings ?? ({} as any));
  const keySignature = getKeySignatureFromSettings(settings ?? ({} as any));

  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const w = Math.max(1, Math.floor(rect.width * dpr));
  const h = Math.max(1, Math.floor(rect.height * dpr));
  if (canvas.width !== w) canvas.width = w;
  if (canvas.height !== h) canvas.height = h;

  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.clearRect(0, 0, w, h);
  ctx.save();
  ctx.scale(dpr, dpr);

  // Paper background (the notation stage is white).
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, rect.width, rect.height);

  const layout = bestLayout(rect.width, rect.height, clef);

  // Bind canvas interactions once. This is intentionally scoped to Education Mode,
  // where the canvas acts as a teaching surface (Input/Eraser).
  if (!bound) {
    bound = true;
    canvas.addEventListener("pointerdown", (ev) => {
      if (!isEduSession()) return;
      const r = canvas.getBoundingClientRect();
      const x = ev.clientX - r.left;
      const y = ev.clientY - r.top;
      const settingsNow = (window as any).__GEDU_SETTINGS as Settings | undefined;
      const clefNow = getClefFromSettings(settingsNow ?? ({} as any));
      const l = bestLayout(r.width, r.height, clefNow);
      const store = getMarkerStore();
      const tool = getEduTool();
      const totalCols = l.measures * l.colsPerMeasure;
      const colW = totalCols > 1 ? l.colX(1) - l.colX(0) : 12;
      const gridStartX = l.colX(0) - 0.5 * colW;
      const col = Math.max(0, Math.min(Math.max(0, totalCols - 1), Math.round((x - gridStartX) / colW)));

      // Split the surface: staff (including ledger headroom) on top, tab on bottom.
      // Using staffBandBottom avoids accidental clicks in the ledger region being misrouted to TAB.
      const splitY = (l.staffBandBottom + l.tabTop) / 2;
      const isStaff = y < splitY;

      if (isStaff && isShowing("staff")) {
        // Clamp within the staff system band(s) (includes ledger headroom) so notes cannot drift
        // into the TAB region and clicks above the band remain deterministic.
        const yClamped = Math.max(l.staffBandTop, Math.min(l.staffBandBottom, y));

        // In grand staff, choose the target staff strictly by where the user clicked.
        // Canon: never auto-switch staff based on pitch (no giveaway).
        const isGrand = clefNow === "grand" && l.staffSystem === "grand" && l.bassStaffBandTop != null && l.bassStaffTop != null;
        const targetStaff: "treble" | "bass" = isGrand && yClamped >= (l.bassStaffBandTop as number) ? "bass" : "treble";

        const staffBandTop = targetStaff === "bass" && l.bassStaffBandTop != null ? l.bassStaffBandTop : l.staffBandTop;
        const staffBandBottom = targetStaff === "bass" && l.bassStaffBandBottom != null ? l.bassStaffBandBottom : (isGrand && l.bassStaffBandTop != null ? l.bassStaffBandTop : l.staffBandBottom);
        const staffTopLine = targetStaff === "bass" && l.bassStaffTop != null ? l.bassStaffTop : l.staffTop;

        const placeKind = getEduPlaceKind();
        const yInBand = Math.max(staffBandTop, Math.min(staffBandBottom, yClamped));
        const desiredYIndex = Math.round(((yInBand - staffTopLine) * 2) / l.staffGap);

        const note = getSelectedNote();
        const pitch = parsePitch(note);

        // Canon: staff position defines register; choose the octave that is closest to the user's click height
        // *within the selected staff only*.
        const clefForPlacement: "treble" | "bass" = targetStaff === "bass" ? "bass" : "treble";
        const yIndex = placeKind === "rest" ? 4 : closestYIndexForPitch(clefForPlacement, pitch, desiredYIndex);
        const accidental = placeKind === "rest" ? null : pitch.acc;
        const duration = getEduDuration();

        const cx = l.colX(col);
        const cy = staffTopLine + (l.staffGap / 2) * yIndex;

        if (tool === "erase") {
          const thresh2 = 16 * 16;
          const idx = store.staffNotes.findIndex((n) => {
            const nStaff = (n as any).staff ?? "treble";
            if (nStaff !== targetStaff) return false;
            const nTop = nStaff === "bass" && l.bassStaffTop != null ? l.bassStaffTop : l.staffTop;
            return dist2(l.colX(n.col), nTop + (l.staffGap / 2) * n.yIndex, cx, cy) < thresh2;
          });
          if (idx >= 0) store.staffNotes.splice(idx, 1);
        } else {
          store.staffNotes.push({ kind: placeKind, col, yIndex, accidental, duration, note, staff: targetStaff, isPrompt: false });
        }
        renderNotationCanvas();
        return;
      }

      if (!isStaff && isShowing("tab")) {
        const yRel = y - l.tabTop;
        const si = Math.max(0, Math.min(5, Math.round(yRel / l.tabGap)));
        const stringIndex = si as 0 | 1 | 2 | 3 | 4 | 5;
        const fret = getFretNumberFallback();
        const cx = l.colX(col);
        const cy = l.tabTop + l.tabGap * stringIndex;

        if (tool === "erase") {
          const thresh2 = 16 * 16;
          const idx = store.tabNumbers.findIndex((t) => dist2(l.colX(t.col), l.tabTop + l.tabGap * t.stringIndex, cx, cy) < thresh2);
          if (idx >= 0) store.tabNumbers.splice(idx, 1);
        } else {
          store.tabNumbers.push({ col, stringIndex, fret, isPrompt: false });
        }
        renderNotationCanvas();
      }
    });
  }

  const store = getMarkerStore();

  // Render-model: in gameplay modes, this will be fed by the engine.
  // In Education Mode, it uses the local marker store.
  const model: RenderModel = {
    clef,
    keySignature,
    timeSignature: { top: 4, bottom: 4 },
    staffNotes: isEduSession() && isShowing("staff") ? store.staffNotes : [],
    tabNumbers: isEduSession() && isShowing("tab") ? store.tabNumbers : [],
  };

  renderNotation(ctx, layout, model);
  ctx.restore();
}