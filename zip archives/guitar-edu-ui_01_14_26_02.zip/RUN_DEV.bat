@echo off
setlocal enabledelayedexpansion

REM Guitar-Edu-UI One-Click Dev Runner (Windows)
REM - Installs dependencies if needed
REM - Starts Vite dev server in a dedicated window
REM - Waits for the server to become reachable (5173..5180)
REM - Opens the app in your default browser

REM Anchor to the folder containing this .bat (robust on Windows)
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

REM --- Logging (always-on) ---
set "LOG_DIR=%SCRIPT_DIR%logs"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1

set "RUNLOG=%LOG_DIR%\run_dev.log"
set "DEVLOG=%LOG_DIR%\devserver.log"

REM Start a fresh run log each launch
(
  echo ============================================================
  echo [RUN_DEV] Launch started: %DATE% %TIME%
  echo [RUN_DEV] Working directory: %CD%
  echo [RUN_DEV] Script path: %~f0
  echo ============================================================
) >"%RUNLOG%"


echo [RUN_DEV] Working directory: %CD%
echo [RUN_DEV] Logging: %RUNLOG%
echo [RUN_DEV] Dev server log: %DEVLOG%

REM Helper to log a single line to RUNLOG
set "_LOG_PREFIX=[RUN_DEV]"

REM --- Detect Node major version (used for Windows/Rollup native deps reliability) ---
set "NODE_MAJOR="
for /f "usebackq delims=" %%V in (`node -p "process.versions.node.split('.')[0]" 2^>nul`) do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR (
  echo [RUN_DEV] ERROR: Node.js is not available on PATH.
  echo %_LOG_PREFIX% ERROR: Node.js is not available on PATH.>>"%RUNLOG%"
  echo [RUN_DEV] Install Node.js (recommended: Node 20 LTS) and try again.
  echo %_LOG_PREFIX% Install Node.js (recommended: Node 20 LTS) and try again.>>"%RUNLOG%"
  pause
  exit /b 1
)

echo [RUN_DEV] Node detected:
node -v
echo %_LOG_PREFIX% Node detected:>>"%RUNLOG%"
node -v>>"%RUNLOG%" 2>&1

REM If Node is very new, npm optional native deps can be flaky on Windows.
REM We'll automatically use a safer install flow and run a quick Rollup sanity check.
set "NEEDS_OPTIONAL_INSTALL=0"
for /f "delims=" %%N in ("%NODE_MAJOR%") do (
  if %%N GEQ 23 set "NEEDS_OPTIONAL_INSTALL=1"
)

REM Do not fall through into function labels
goto :MAIN

REM --- Function: repair rollup native optional dependency install ---
:REPAIR_ROLLUP
echo [RUN_DEV] Repairing native deps (Windows/Rollup) ...
echo %_LOG_PREFIX% Repairing native deps (Windows/Rollup) ...>>"%RUNLOG%"
echo [RUN_DEV] Removing node_modules and package-lock.json
echo %_LOG_PREFIX% Removing node_modules and package-lock.json>>"%RUNLOG%"
if exist "node_modules\" rmdir /s /q "node_modules"
if exist "package-lock.json" del /q "package-lock.json"
echo [RUN_DEV] Cleaning npm cache...
echo %_LOG_PREFIX% Cleaning npm cache...>>"%RUNLOG%"
call npm cache clean --force
echo [RUN_DEV] Installing dependencies with optional native packages...
echo %_LOG_PREFIX% Installing dependencies with optional native packages...>>"%RUNLOG%"
call npm install --include=optional
if errorlevel 1 (
  echo [RUN_DEV] ERROR: npm install failed during repair.
  echo %_LOG_PREFIX% ERROR: npm install failed during repair.>>"%RUNLOG%"
  pause
  exit /b 1
)
echo [RUN_DEV] Rebuilding rollup...
echo %_LOG_PREFIX% Rebuilding rollup...>>"%RUNLOG%"
call npm rebuild rollup
exit /b 0

REM --- Quick sanity check: can Node require rollup? ---
:CHECK_ROLLUP
node -e "require('rollup');" >nul 2>&1
if errorlevel 1 (
  echo [RUN_DEV] Detected Rollup native dependency issue.
  echo %_LOG_PREFIX% Detected Rollup native dependency issue.>>"%RUNLOG%"
  if "%NEEDS_OPTIONAL_INSTALL%"=="1" (
    call :REPAIR_ROLLUP
  )
)
exit /b 0

:MAIN

REM --- Dependency install (only if missing) ---
if not exist "node_modules\" (
  echo [RUN_DEV] node_modules not found. Installing dependencies...
  echo %_LOG_PREFIX% node_modules not found. Installing dependencies...>>"%RUNLOG%"
  if "%NEEDS_OPTIONAL_INSTALL%"=="1" (
    call npm install --include=optional
  ) else (
    call npm install
  )
  if errorlevel 1 (
    echo [RUN_DEV] npm install failed.
    echo %_LOG_PREFIX% ERROR: npm install failed.>>"%RUNLOG%"
    pause
    exit /b 1
  )
)

REM After install, validate rollup can load; repair if needed.
call :CHECK_ROLLUP

REM --- Start dev server (visible output in its own window) ---
echo [RUN_DEV] Starting dev server...
echo %_LOG_PREFIX% Starting dev server...>>"%RUNLOG%"

REM Run dev server in a dedicated window AND log all output to DEVLOG.
REM Note: Use doubled quotes for robust Windows cmd parsing.
echo %_LOG_PREFIX% Launching DEVSERVER_RUNNER.bat>>"%RUNLOG%"
start "Guitar-Edu-UI Dev Server" cmd /k ""%SCRIPT_DIR%DEVSERVER_RUNNER.bat""

REM --- Wait for server to respond (5173..5180) ---
set "FOUND_URL="
for /L %%S in (1,1,45) do (
  for %%P in (5173 5174 5175 5176 5177 5178 5179 5180) do (
    powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try{$c.Connect('localhost',%%P);$c.Close(); exit 0} catch { exit 1 }" >nul 2>&1
    if not errorlevel 1 (
      set "FOUND_URL=http://localhost:%%P/"
      echo %_LOG_PREFIX% Server reachable at http://localhost:%%P/>>"%RUNLOG%"
      goto :OPEN
    )
  )
  timeout /t 1 /nobreak >nul
)

:OPEN
if defined FOUND_URL (
  echo [RUN_DEV] Server reachable at !FOUND_URL!
  echo [RUN_DEV] Opening browser...
  echo %_LOG_PREFIX% Opening browser at !FOUND_URL!>>"%RUNLOG%"
  start "" "!FOUND_URL!"
  echo [RUN_DEV] Done.
  echo %_LOG_PREFIX% Done.>>"%RUNLOG%"
  endlocal
  exit /b 0
)

echo [RUN_DEV] Could not detect a running dev server on ports 5173-5180 within 45 seconds.
echo [RUN_DEV] Check the \"Guitar-Edu-UI Dev Server\" window for errors.
echo %_LOG_PREFIX% ERROR: Could not detect a running dev server on ports 5173-5180 within 45 seconds.>>"%RUNLOG%"
echo %_LOG_PREFIX% Check logs: %DEVLOG%>>"%RUNLOG%"
pause
endlocal
exit /b 1
