import "./styles.css";
import { mountLayout } from "./ui/layout";
import { initGameController } from "./app/gameController";
import { hydrateFromIndexedDb } from "./shell/storage";

const app = document.getElementById("app");
if (!app) throw new Error("#app not found");

mountLayout(app);

// Engine-backed controller (merged from the shell version into the new layout).
// Hydrate any persisted snapshot first (USB/offline friendly).
(async () => {
  try { await hydrateFromIndexedDb(); } catch { /* ignore */ }
  initGameController(document);
})();

