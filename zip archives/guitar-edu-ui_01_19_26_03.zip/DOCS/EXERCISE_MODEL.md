# Exercise Model

Status: Draft scaffold (becomes authoritative when GEG-401..GEG-404 begins).

## Purpose
A deterministic internal representation for imported or generated musical material (e.g., from MusicXML) that can:
- drive prompts (note/chord/scale tasks)
- render to staff/tab timelines
- optionally suggest fretboard positions via explicit policies

## Core entities (v1)
- **Exercise**: metadata + list of Parts
- **Part**: instrument context (tuning, string count) + Measures
- **Measure**: time signature + ordered Events
- **Event** (one time-slice):
  - kind: Note | Chord | Rest
  - duration: rational (beats) + subdivision index
  - pitches: list of Pitch (chord has 2+)
  - ties: start/stop/continue flags
  - annotations: optional (player answers, hints)

## Pitch representation
- MIDI number (primary)
- Spelling: step (A-G), alter (-2..+2), octave
- Context: key signature + accidental rules at time

## Mapping to fretboard
- Mapping is optional and policy-driven.
- Store as: list of candidate positions per pitch:
  - (stringIndex, fret, confidence=policy-rank)
- Never store only a single position if multiple are valid under the policy; store ordered candidates.

## Rendering expectations
- Staff/Tab share a subdivision timeline; Events align to a single column index.
- Chords render as vertical stacks in the same column.

## Serialization
- JSON is the internal interchange format for fixtures and regression tests.
