# Changelog (legacy)

This file is retained for historical context.

**Canonical changelog is `/<repo>/CHANGELOG.md`.**

---

## Step 14.1 (Regression cleanup)
- Replaced fretboard SVG with `Guitar_FretBoard_Horizontal-Complete_v2i.svg` content (better aligned hitbox art).
- Restored Note Visibility selector to include **All** and set default to **All**.
- Restored controller defaults for `core.noteVisibility` to **all** (was regressed to naturals).
- Fixed minor indentation regression in controller settings change handler.
- Confirmed project zips must not include `node_modules/` or `dist/`.

## 2026-01-10 — Patch 01_10_26_16
- Fixed a phase constant mismatch that disabled input gating (`in_match` vs `IN_MATCH`).
- Implemented a **Surface Input Matrix** to define, per UI mode, which surfaces are required, accept input, and show placed marks.
- Added composite submission logic so **Staff drives pitch**, and (when required) **Fret + Tab must match** the same string/fret.
- Implemented TAB entry ordering: **string → fret** or **fret → string**, including retaining the selected TAB column.
- Fixed TAB default number handling to avoid null/default rendering issues.
- Cleaned up Staff+Tab overlay mark visibility toggling per UI mode.

## 2026-01-10 — Patch 01_10_26_17
- Aligned the Staff+Tab stage container id (`staffTabStage`) with the controller so surface-matrix gating applies reliably.
- Added **Surface Layers** checkboxes (**View / Asked / Answered**) and wired them into gameplay mark visibility (visual only; surfaces remain present).
- Added `rail.setLayers()` with view-layer label hiding and asked-layer target highlighting control.

## 2026-01-10 — Patch 01_10_26_18
- Renamed Surface Layers UI labels to **Display / Prompt / Marks** (was **View / Asked / Answered**) without changing underlying preference keys.

### 01_14_26_04
- Added `LOCK_IN_TABLES.md` (truth tables + right-click shortcut canon stub).
- Added `GEG-116` to checklist.
