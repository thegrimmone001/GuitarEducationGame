# MusicXML Spec

Status: Draft scaffold (becomes authoritative when GEG-401..GEG-404 begins).

## Scope
### Import
- Parse MusicXML Score/Part into the internal Exercise Model.
- Support: notes, chords, rests, measures, time signatures, key signatures, accidentals, ties.

### Export
- Export Exercise Model drills to MusicXML.
- Optional: export player answer record as annotations (non-destructive; never overwrites the base score).

## Deterministic mapping requirement
When mapping pitches to fretboard positions:
- Must respect active tuning and active fret range.
- Must use a deterministic disambiguation policy, selected explicitly in settings:
  - **Lowest-fret** policy (default candidate)
  - **Nearest-position** policy (minimize hand movement from last mapped note)
- Ambiguity must be represented in the Exercise Model (do not silently randomize).

## Out of scope (v1)
- Full engraving-quality layout.
- MIDI import/export.
- Playback/audio synthesis.

## Acceptance gates
- GEG-401..GEG-404 define the acceptance criteria and fixtures.
