// Centralized constants used across UI + controller.
// Keep conservative defaults but avoid hard-limiting the engine.

// Current upper bound for multiplayer player count used by the splash selector.
export const PLAYER_COUNT_MULTI_MAX = 12;
