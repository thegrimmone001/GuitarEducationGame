# Deprecated Terms (Updated)

The following terms must not appear in user-facing UI or logic contracts:

- Surface Layers
- Asked / Answered / View
- Mode (when referring to surface behavior)
- Free Play (root-only)

Use Surface Controls and canonical menu structure instead.