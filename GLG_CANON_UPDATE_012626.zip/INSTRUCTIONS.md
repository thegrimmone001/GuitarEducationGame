# Canon Instructions — STRICT MODE

1. All work must reference current canon files.
2. No feature creation without approval.
3. No renaming of canonical terms.
4. Menu logic is locked.
5. If uncertain, STOP and ASK.

This instruction set supersedes all prior guidance.