# Guitar Learning Game — Canon Status (012626)

This document declares the current authoritative canon for the Guitar Learning Game.

## Canon Sources (Superseding)
- Menu Structure.txt
- GLG Schema Registry v1.1
- MatchOptions Master JSON Schema v1.1
- Surface Controls JSON Schema v1.1
- Guitar Learning Game — Canon Continuation.txt
- Runtime logs 012526-01 → 04

All prior documents are valid only insofar as they do not conflict with the above.

## Phase Status
- Phase A: Complete
- Phase B: Complete (Menu + Match Initialization + Timers)
- Phase C: Pending

## Key Locks
- Menu spine architecture is locked.
- Presets are initialization-only.
- Prompt / Mark / Persistence / SAM are the only surface roles.
- Accidentals support Auto / Sharps / Flats / Both.